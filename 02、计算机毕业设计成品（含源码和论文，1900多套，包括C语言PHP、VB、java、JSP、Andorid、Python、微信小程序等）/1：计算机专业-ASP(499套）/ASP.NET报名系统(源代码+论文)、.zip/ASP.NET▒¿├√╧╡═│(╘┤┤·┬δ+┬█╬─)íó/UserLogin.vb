'Imports used by the function login in order to access the database
Imports System
Imports System.Data
Imports System.Data.SqlClient

'TODO Lab 16: add the Imports for forms-based auth
Imports System.Web.Security

Public Class UserLogin

    Function Login(ByVal strUserName As String, ByVal strUserPassword As String) As String

        'Retrieve the connection string from the <appSettings> section of Web.config
        Dim conStrinfo As String = ConfigurationSettings.AppSettings("conStrinfo")

        'Create Instance of Connection and Command Object
        Dim objConnection As SqlConnection = New SqlConnection(conStrinfo)
        Dim objCommand As SqlCommand = New SqlCommand("userLogin", objConnection)

        'Mark the Command as a SPROC
        objCommand.CommandType = CommandType.StoredProcedure


        'Add Parameters to SPROC

        'Email (user name) input parameter
        Dim parameterUserName As SqlParameter = New SqlParameter("@userName", SqlDbType.VarChar, 50)
        parameterUserName.Value = strUserName
        objCommand.Parameters.Add(parameterUserName)

        'Password input parameter
        Dim parameterUserPassword As SqlParameter = New SqlParameter("@userPassword", SqlDbType.VarChar, 20)
        parameterUserPassword.Value = strUserPassword
        objCommand.Parameters.Add(parameterUserPassword)

        'EmployeeID output parameter
        Dim parameterUserID As SqlParameter = New SqlParameter("@userID", SqlDbType.Int, 4)
        parameterUserID.Direction = ParameterDirection.Output
        objCommand.Parameters.Add(parameterUserID)

        Try
            'Open the connection and execute the Command
            objConnection.Open()
            objCommand.ExecuteNonQuery()
        Catch e As Exception
            'An error occurred
            'lblInfo.Text = "Error of connection to the database, please try again later."
        Finally
            'Close the Connection
            If objConnection.State = ConnectionState.Open Then
                objConnection.Close()
            End If
        End Try

        Dim UserId As Integer = CInt(parameterUserID.Value)

        If UserId = 0 Then
            Return ""
        Else
            Return UserId.ToString()
        End If

    End Function

End Class
