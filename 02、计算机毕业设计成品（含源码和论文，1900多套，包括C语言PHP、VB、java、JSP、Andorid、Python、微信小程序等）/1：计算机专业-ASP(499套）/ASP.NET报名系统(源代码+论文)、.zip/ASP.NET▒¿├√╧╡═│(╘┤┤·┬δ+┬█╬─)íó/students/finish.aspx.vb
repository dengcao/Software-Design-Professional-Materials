Imports System.Data.SqlClient

Public Class difficulty
    Inherits System.Web.UI.Page

#Region " Web ������������ɵĴ��� "

    '�õ����� Web ���������������ġ�
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.StuSDA = New System.Data.SqlClient.SqlDataAdapter
        Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlConnection1 = New System.Data.SqlClient.SqlConnection
        Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
        Me.StuDS1 = New WebApply.StuDS
        CType(Me.StuDS1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'StuSDA
        '
        Me.StuSDA.DeleteCommand = Me.SqlDeleteCommand1
        Me.StuSDA.InsertCommand = Me.SqlInsertCommand1
        Me.StuSDA.SelectCommand = Me.SqlSelectCommand1
        Me.StuSDA.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "StuInfo", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("����", "����"), New System.Data.Common.DataColumnMapping("����֤", "����֤"), New System.Data.Common.DataColumnMapping("ѧ��֤", "ѧ��֤"), New System.Data.Common.DataColumnMapping("�Ƿ�ͨ��", "�Ƿ�ͨ��")})})
        Me.StuSDA.UpdateCommand = Me.SqlUpdateCommand1
        '
        'SqlDeleteCommand1
        '
        Me.SqlDeleteCommand1.CommandText = "DELETE FROM StuInfo WHERE (ID = @Original_����֤) AND (StuID = @Original_ѧ��֤) AND (S" & _
        "tuName = @Original_����) AND (StuState = @Original_�Ƿ�ͨ��)"
        Me.SqlDeleteCommand1.Connection = Me.SqlConnection1
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_����֤", System.Data.SqlDbType.VarChar, 18, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "����֤", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ѧ��֤", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ѧ��֤", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_����", System.Data.SqlDbType.NVarChar, 6, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "����", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_�Ƿ�ͨ��", System.Data.SqlDbType.VarChar, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "�Ƿ�ͨ��", System.Data.DataRowVersion.Original, Nothing))
        '
        'SqlConnection1
        '
        Me.SqlConnection1.ConnectionString = "workstation id=C04;packet size=4096;user id=sa;initial catalog=info;persist secur" & _
        "ity info=True;password=sa"
        '
        'SqlInsertCommand1
        '
        Me.SqlInsertCommand1.CommandText = "INSERT INTO StuInfo(StuName, ID, StuID, StuState) VALUES (@StuName, @ID, @StuID, " & _
        "@StuState); SELECT StuName AS ����, ID AS ����֤, StuID AS ѧ��֤, StuState AS �Ƿ�ͨ�� FROM" & _
        " StuInfo WHERE (ID = @����֤)"
        Me.SqlInsertCommand1.Connection = Me.SqlConnection1
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuName", System.Data.SqlDbType.NVarChar, 6, "����"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.VarChar, 18, "����֤"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuID", System.Data.SqlDbType.VarChar, 15, "ѧ��֤"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuState", System.Data.SqlDbType.VarChar, 2, "�Ƿ�ͨ��"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@����֤", System.Data.SqlDbType.VarChar, 18, "����֤"))
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT StuName AS ����, ID AS ����֤, StuID AS ѧ��֤, StuState AS �Ƿ�ͨ�� FROM StuInfo WHER" & _
        "E (ID = @ID)"
        Me.SqlSelectCommand1.Connection = Me.SqlConnection1
        Me.SqlSelectCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.VarChar, 18, "����֤"))
        '
        'SqlUpdateCommand1
        '
        Me.SqlUpdateCommand1.CommandText = "UPDATE StuInfo SET StuName = @StuName, ID = @ID, StuID = @StuID, StuState = @StuS" & _
        "tate WHERE (ID = @Original_����֤) AND (StuID = @Original_ѧ��֤) AND (StuName = @Orig" & _
        "inal_����) AND (StuState = @Original_�Ƿ�ͨ��); SELECT StuName AS ����, ID AS ����֤, StuID" & _
        " AS ѧ��֤, StuState AS �Ƿ�ͨ�� FROM StuInfo WHERE (ID = @����֤)"
        Me.SqlUpdateCommand1.Connection = Me.SqlConnection1
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuName", System.Data.SqlDbType.NVarChar, 6, "����"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.VarChar, 18, "����֤"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuID", System.Data.SqlDbType.VarChar, 15, "ѧ��֤"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuState", System.Data.SqlDbType.VarChar, 2, "�Ƿ�ͨ��"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_����֤", System.Data.SqlDbType.VarChar, 18, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "����֤", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ѧ��֤", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ѧ��֤", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_����", System.Data.SqlDbType.NVarChar, 6, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "����", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_�Ƿ�ͨ��", System.Data.SqlDbType.VarChar, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "�Ƿ�ͨ��", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@����֤", System.Data.SqlDbType.VarChar, 18, "����֤"))
        '
        'StuDS1
        '
        Me.StuDS1.DataSetName = "StuDS"
        Me.StuDS1.Locale = New System.Globalization.CultureInfo("zh-CN")
        CType(Me.StuDS1, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents StuSDA As System.Data.SqlClient.SqlDataAdapter
    Protected WithEvents SqlConnection1 As System.Data.SqlClient.SqlConnection
    Protected WithEvents StuDS1 As WebApply.StuDS
    Protected WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand

    'ע��: ����ռλ�������� Web ���������������ġ�
    '��Ҫɾ�����ƶ�����
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: �˷��������� Web ����������������
        '��Ҫʹ�ô���༭���޸�����
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�ڴ˴����ó�ʼ��ҳ���û�����
        'Session("ID") = 147
        Dim conStrinfo As String = ConfigurationSettings.AppSettings("conStrinfo")
        Dim objConnection As SqlConnection = New SqlConnection(conStrinfo)
        Dim sda As New SqlDataAdapter
        Dim objCommand As SqlCommand = New SqlCommand _
        ("SELECT AllowID AS ׼��֤,StuName AS ����,sex as �Ա�,ID AS ����֤,StuID AS ѧ��֤,xibie AS ϵ��,ClassNm AS �༶,jibie as ������ FROM StuInfo WHERE ID='" & Session("ID").ToString & " '", objConnection)
        sda.SelectCommand = objCommand

        objCommand.CommandType = CommandType.Text

        '''Try
        '''    objConnection.Open()
        '''    objCommand.ExecuteNonQuery()
        '''Catch ex As Exception
        '''    'Label9.Text = ex.ToString
        '''Finally
        '''    If objConnection.State = ConnectionState.Open Then
        '''        objConnection.Close()
        '''    End If
        '''End Try

        Dim ds As New DataSet
        sda.Fill(ds)
        DataGrid1.DataSource = ds
        DataGrid1.DataBind()

        ''StuSDA.SelectCommand.Parameters("@ID").Value() = Session("ID")
        ''Response.Write(Session("ID"))
        '''STUDS1.Clear()
        ''StuSDA.Fill(StuDS1)
        ''DataGrid1.DataSource = StuDS1
        ''DataGrid1.DataBind()
    End Sub

End Class
