Public Class admin_manage
    Inherits System.Web.UI.Page

#Region " Web ������������ɵĴ��� "

    '�õ����� Web ���������������ġ�
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.SqlConnection1 = New System.Data.SqlClient.SqlConnection
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SignUp_Sda = New System.Data.SqlClient.SqlDataAdapter
        Me.User_Sda = New System.Data.SqlClient.SqlDataAdapter
        Me.SqlDeleteCommand2 = New System.Data.SqlClient.SqlCommand
        Me.SqlInsertCommand2 = New System.Data.SqlClient.SqlCommand
        Me.SqlSelectCommand2 = New System.Data.SqlClient.SqlCommand
        Me.SqlUpdateCommand2 = New System.Data.SqlClient.SqlCommand
        '
        'SqlConnection1
        '
        Me.SqlConnection1.ConnectionString = "workstation id=C23;packet size=4096;user id=sa;initial catalog=info;persist secur" & _
        "ity info=True;password=sa"
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT StuName, sex, ID, StuID, StuState FROM StuInfo"
        Me.SqlSelectCommand1.Connection = Me.SqlConnection1
        '
        'SqlInsertCommand1
        '
        Me.SqlInsertCommand1.CommandText = "INSERT INTO StuInfo(StuName, sex, ID, StuID, StuState) VALUES (@StuName, @sex, @I" & _
        "D, @StuID, @StuState); SELECT StuName, sex, ID, StuID, StuState FROM StuInfo WHE" & _
        "RE (ID = @ID)"
        Me.SqlInsertCommand1.Connection = Me.SqlConnection1
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuName", System.Data.SqlDbType.NVarChar, 6, "StuName"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@sex", System.Data.SqlDbType.VarChar, 2, "sex"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.VarChar, 18, "ID"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuID", System.Data.SqlDbType.VarChar, 15, "StuID"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuState", System.Data.SqlDbType.VarChar, 2, "StuState"))
        '
        'SqlUpdateCommand1
        '
        Me.SqlUpdateCommand1.CommandText = "UPDATE StuInfo SET StuName = @StuName, sex = @sex, ID = @ID, StuID = @StuID, StuS" & _
        "tate = @StuState WHERE (ID = @Original_ID) AND (StuID = @Original_StuID) AND (St" & _
        "uName = @Original_StuName) AND (StuState = @Original_StuState) AND (sex = @Origi" & _
        "nal_sex); SELECT StuName, sex, ID, StuID, StuState FROM StuInfo WHERE (ID = @ID)" & _
        ""
        Me.SqlUpdateCommand1.Connection = Me.SqlConnection1
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuName", System.Data.SqlDbType.NVarChar, 6, "StuName"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@sex", System.Data.SqlDbType.VarChar, 2, "sex"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.VarChar, 18, "ID"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuID", System.Data.SqlDbType.VarChar, 15, "StuID"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuState", System.Data.SqlDbType.VarChar, 2, "StuState"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.VarChar, 18, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_StuID", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "StuID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_StuName", System.Data.SqlDbType.NVarChar, 6, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "StuName", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_StuState", System.Data.SqlDbType.VarChar, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "StuState", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_sex", System.Data.SqlDbType.VarChar, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "sex", System.Data.DataRowVersion.Original, Nothing))
        '
        'SqlDeleteCommand1
        '
        Me.SqlDeleteCommand1.CommandText = "DELETE FROM StuInfo WHERE (ID = @Original_ID) AND (StuID = @Original_StuID) AND (" & _
        "StuName = @Original_StuName) AND (StuState = @Original_StuState) AND (sex = @Ori" & _
        "ginal_sex)"
        Me.SqlDeleteCommand1.Connection = Me.SqlConnection1
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.VarChar, 18, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_StuID", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "StuID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_StuName", System.Data.SqlDbType.NVarChar, 6, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "StuName", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_StuState", System.Data.SqlDbType.VarChar, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "StuState", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_sex", System.Data.SqlDbType.VarChar, 2, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "sex", System.Data.DataRowVersion.Original, Nothing))
        '
        'SignUp_Sda
        '
        Me.SignUp_Sda.DeleteCommand = Me.SqlDeleteCommand1
        Me.SignUp_Sda.InsertCommand = Me.SqlInsertCommand1
        Me.SignUp_Sda.SelectCommand = Me.SqlSelectCommand1
        Me.SignUp_Sda.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "StuInfo", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("StuName", "StuName"), New System.Data.Common.DataColumnMapping("sex", "sex"), New System.Data.Common.DataColumnMapping("ID", "ID"), New System.Data.Common.DataColumnMapping("StuID", "StuID"), New System.Data.Common.DataColumnMapping("StuState", "StuState")})})
        Me.SignUp_Sda.UpdateCommand = Me.SqlUpdateCommand1
        '
        'User_Sda
        '
        Me.User_Sda.DeleteCommand = Me.SqlDeleteCommand2
        Me.User_Sda.InsertCommand = Me.SqlInsertCommand2
        Me.User_Sda.SelectCommand = Me.SqlSelectCommand2
        Me.User_Sda.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "UserInfo", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("UserID", "UserID"), New System.Data.Common.DataColumnMapping("UserName", "UserName"), New System.Data.Common.DataColumnMapping("UserPassword", "UserPassword")})})
        Me.User_Sda.UpdateCommand = Me.SqlUpdateCommand2
        '
        'SqlDeleteCommand2
        '
        Me.SqlDeleteCommand2.CommandText = "DELETE FROM UserInfo WHERE (UserID = @Original_UserID) AND (UserName = @Original_" & _
        "UserName) AND (UserPassword = @Original_UserPassword)"
        Me.SqlDeleteCommand2.Connection = Me.SqlConnection1
        Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserID", System.Data.SqlDbType.BigInt, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserName", System.Data.SqlDbType.NVarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserName", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserPassword", System.Data.SqlDbType.NVarChar, 25, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserPassword", System.Data.DataRowVersion.Original, Nothing))
        '
        'SqlInsertCommand2
        '
        Me.SqlInsertCommand2.CommandText = "INSERT INTO UserInfo(UserName, UserPassword) VALUES (@UserName, @UserPassword); S" & _
        "ELECT UserID, UserName, UserPassword FROM UserInfo WHERE (UserID = @@IDENTITY)"
        Me.SqlInsertCommand2.Connection = Me.SqlConnection1
        Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.NVarChar, 16, "UserName"))
        Me.SqlInsertCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserPassword", System.Data.SqlDbType.NVarChar, 25, "UserPassword"))
        '
        'SqlSelectCommand2
        '
        Me.SqlSelectCommand2.CommandText = "SELECT UserID, UserName, UserPassword FROM UserInfo"
        Me.SqlSelectCommand2.Connection = Me.SqlConnection1
        '
        'SqlUpdateCommand2
        '
        Me.SqlUpdateCommand2.CommandText = "UPDATE UserInfo SET UserName = @UserName, UserPassword = @UserPassword WHERE (Use" & _
        "rID = @Original_UserID) AND (UserName = @Original_UserName) AND (UserPassword = " & _
        "@Original_UserPassword); SELECT UserID, UserName, UserPassword FROM UserInfo WHE" & _
        "RE (UserID = @UserID)"
        Me.SqlUpdateCommand2.Connection = Me.SqlConnection1
        Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.NVarChar, 16, "UserName"))
        Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserPassword", System.Data.SqlDbType.NVarChar, 25, "UserPassword"))
        Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserID", System.Data.SqlDbType.BigInt, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserName", System.Data.SqlDbType.NVarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserName", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserPassword", System.Data.SqlDbType.NVarChar, 25, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserPassword", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand2.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.BigInt, 8, "UserID"))

    End Sub
    Protected WithEvents SqlConnection1 As System.Data.SqlClient.SqlConnection
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Mg_Object As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Dp_State As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Allow As System.Web.UI.WebControls.RadioButton
    Protected WithEvents NotAllow As System.Web.UI.WebControls.RadioButton
    Protected WithEvents ForWaiting As System.Web.UI.WebControls.RadioButton
    Protected WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SignUp_Sda As System.Data.SqlClient.SqlDataAdapter
    Protected WithEvents User_Sda As System.Data.SqlClient.SqlDataAdapter
    Protected WithEvents SqlSelectCommand2 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlInsertCommand2 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlUpdateCommand2 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlDeleteCommand2 As System.Data.SqlClient.SqlCommand
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button

    'ע��: ����ռλ�������� Web ���������������ġ�
    '��Ҫɾ�����ƶ�����
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: �˷��������� Web ����������������
        '��Ҫʹ�ô���༭���޸�����
        InitializeComponent()
    End Sub

#End Region

    Dim dv As DataView

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�ڴ˴����ó�ʼ��ҳ���û�����
        Dim index1, index2 As Int16
        index1 = 0 : index2 = 0 '���Բ�Ҫ
        'dv.RowFilter = Nothing
        Call Display(index1, index2)
    End Sub

    Sub Display(ByVal mIndex As Int16, ByVal dIndex As Int16)
        'User_Sda.Fill(All_DS.UserInfo)
        'SignUp_Sda.Fill(All_DS.StuInfo)


        'Mg_Object.SelectedIndex = mIndex
        'Dp_State.SelectedIndex = dIndex

        'If Mg_Object.SelectedIndex = 0 Then
        '    dv = New DataView(All_DS.UserInfo)
        'Else
        '    dv = New DataView(All_DS.StuInfo)
        'End If

        'DataGrid1.DataSource = dv
        'DataGrid1.DataBind()
    End Sub

    Private Sub DataGrid1_ItemCommand(ByVal source As System.Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs)
        'Response.Write("123")
        'If (e.CommandSource = "btn") Then
        '    Response.Write("login.aspx")
        'End If

        'If (e.CommandName = "AddToCart") Then
        '    Response.Redirect("login.aspx")
        '    ' Add code here to add the item to the shopping cart.
        '    ' Use the value of e.Item.ItemIndex to find the data row
        '    ' in the data source.
        'End If

        If (CType(e.CommandSource, CheckBox)).ID = "AllowState" Then
            Response.Write("asdf")

        End If

        If (CType(e.CommandSource, Button)).CommandName = "AddToCart" Then
            Response.Write("asdf123")

        End If
    End Sub



    'Private Sub DataGrid2_ItemCommand(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridCommandEventArgs) Handles DataGrid2.ItemCommand
    '    If (CType(e.CommandSource, Button)).CommandName = "vvn" Then
    '        Response.Write("asdf123")

    '    End If

    'End Sub

    Private Sub DataGrid1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DataGrid1.SelectedIndexChanged

    End Sub

    Private Sub Mg_Object_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles Mg_Object.SelectedIndexChanged
        If Mg_Object.SelectedValue = 1 Then
            Response.Write("123")
        Else
            Response.Write("456")
        End If
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Mg_Object.SelectedIndex = 1
    End Sub
End Class
