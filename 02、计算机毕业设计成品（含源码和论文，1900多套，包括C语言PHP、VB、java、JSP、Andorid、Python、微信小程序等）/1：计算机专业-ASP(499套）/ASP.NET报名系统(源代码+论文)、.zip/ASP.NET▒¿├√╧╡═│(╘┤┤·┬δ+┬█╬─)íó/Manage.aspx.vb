Public Class Manage1
    Inherits System.Web.UI.Page

#Region " Web ������������ɵĴ��� "

    '�õ����� Web ���������������ġ�
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.InfoSConn = New System.Data.SqlClient.SqlConnection
        Me.SignUpSDA = New System.Data.SqlClient.SqlDataAdapter
        Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
        Me.TpDS1 = New WebApply.TpDS
        CType(Me.TpDS1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'InfoSConn
        '
        Me.InfoSConn.ConnectionString = "workstation id=C13;packet size=4096;user id=sa;initial catalog=info;persist secur" & _
        "ity info=True;password=sa"
        '
        'SignUpSDA
        '
        Me.SignUpSDA.DeleteCommand = Me.SqlDeleteCommand1
        Me.SignUpSDA.InsertCommand = Me.SqlInsertCommand1
        Me.SignUpSDA.SelectCommand = Me.SqlSelectCommand1
        Me.SignUpSDA.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "StuInfo", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("StuName", "StuName"), New System.Data.Common.DataColumnMapping("ID", "ID"), New System.Data.Common.DataColumnMapping("StuID", "StuID"), New System.Data.Common.DataColumnMapping("xibie", "xibie"), New System.Data.Common.DataColumnMapping("classNm", "classNm"), New System.Data.Common.DataColumnMapping("StuState", "StuState")})})
        Me.SignUpSDA.UpdateCommand = Me.SqlUpdateCommand1
        '
        'SqlDeleteCommand1
        '
        Me.SqlDeleteCommand1.CommandText = "DELETE FROM StuInfo WHERE (ID = @Original_ID) AND (StuID = @Original_StuID) AND (" & _
        "StuName = @Original_StuName) AND (StuState = @Original_StuState) AND (classNm = " & _
        "@Original_classNm) AND (xibie = @Original_xibie)"
        Me.SqlDeleteCommand1.Connection = Me.InfoSConn
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.VarChar, 18, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_StuID", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "StuID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_StuName", System.Data.SqlDbType.NVarChar, 6, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "StuName", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_StuState", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "StuState", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_classNm", System.Data.SqlDbType.NVarChar, 20, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "classNm", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_xibie", System.Data.SqlDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "xibie", System.Data.DataRowVersion.Original, Nothing))
        '
        'SqlInsertCommand1
        '
        Me.SqlInsertCommand1.CommandText = "INSERT INTO StuInfo(StuName, ID, StuID, xibie, classNm, StuState) VALUES (@StuNam" & _
        "e, @ID, @StuID, @xibie, @classNm, @StuState); SELECT StuName, ID, StuID, xibie, " & _
        "classNm, StuState FROM StuInfo WHERE (ID = @ID)"
        Me.SqlInsertCommand1.Connection = Me.InfoSConn
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuName", System.Data.SqlDbType.NVarChar, 6, "StuName"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.VarChar, 18, "ID"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuID", System.Data.SqlDbType.VarChar, 15, "StuID"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@xibie", System.Data.SqlDbType.VarChar, 8, "xibie"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@classNm", System.Data.SqlDbType.NVarChar, 20, "classNm"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuState", System.Data.SqlDbType.Bit, 1, "StuState"))
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT StuName, ID, StuID, xibie, classNm, StuState FROM StuInfo"
        Me.SqlSelectCommand1.Connection = Me.InfoSConn
        '
        'SqlUpdateCommand1
        '
        Me.SqlUpdateCommand1.CommandText = "UPDATE StuInfo SET StuName = @StuName, ID = @ID, StuID = @StuID, xibie = @xibie, " & _
        "classNm = @classNm, StuState = @StuState WHERE (ID = @Original_ID) AND (StuID = " & _
        "@Original_StuID) AND (StuName = @Original_StuName) AND (StuState = @Original_Stu" & _
        "State) AND (classNm = @Original_classNm) AND (xibie = @Original_xibie); SELECT S" & _
        "tuName, ID, StuID, xibie, classNm, StuState FROM StuInfo WHERE (ID = @ID)"
        Me.SqlUpdateCommand1.Connection = Me.InfoSConn
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuName", System.Data.SqlDbType.NVarChar, 6, "StuName"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@ID", System.Data.SqlDbType.VarChar, 18, "ID"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuID", System.Data.SqlDbType.VarChar, 15, "StuID"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@xibie", System.Data.SqlDbType.VarChar, 8, "xibie"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@classNm", System.Data.SqlDbType.NVarChar, 20, "classNm"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@StuState", System.Data.SqlDbType.Bit, 1, "StuState"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_ID", System.Data.SqlDbType.VarChar, 18, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "ID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_StuID", System.Data.SqlDbType.VarChar, 15, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "StuID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_StuName", System.Data.SqlDbType.NVarChar, 6, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "StuName", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_StuState", System.Data.SqlDbType.Bit, 1, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "StuState", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_classNm", System.Data.SqlDbType.NVarChar, 20, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "classNm", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_xibie", System.Data.SqlDbType.VarChar, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "xibie", System.Data.DataRowVersion.Original, Nothing))
        '
        'TpDS1
        '
        Me.TpDS1.DataSetName = "TpDS"
        Me.TpDS1.Locale = New System.Globalization.CultureInfo("zh-CN")
        CType(Me.TpDS1, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
    Protected WithEvents Mg_Object As System.Web.UI.WebControls.DropDownList
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents InfoSConn As System.Data.SqlClient.SqlConnection
    Protected WithEvents TpDS1 As WebApply.TpDS
    Protected WithEvents SignUpSDA As System.Data.SqlClient.SqlDataAdapter
    Protected WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox

    'ע��: ����ռλ�������� Web ���������������ġ�
    '��Ҫɾ�����ƶ�����
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: �˷��������� Web ����������������
        '��Ҫʹ�ô���༭���޸�����
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�ڴ˴����ó�ʼ��ҳ���û�����
        If IsPostBack Then
            TpDS1 = CType(Session("dataset"), TpDS)
        Else
            SignUpSDA.Fill(TpDS1)
            Session("dataset") = TpDS1
            DataBind()
        End If
    End Sub

   Private Sub DataGrid1_PageIndexChanged(ByVal source As Object, ByVal e As System.Web.UI.WebControls.DataGridPageChangedEventArgs) Handles DataGrid1.PageIndexChanged
        DataGrid1.CurrentPageIndex = e.NewPageIndex
        DataGrid1.DataBind()
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim i As Int16
        For i = 0 To DataGrid1.Items.Count - 1
            Dim cb As New CheckBox
            cb = CType(DataGrid1.Items(i).FindControl("CKBX"), CheckBox)
            Dim nr As DataRow = TpDS1.StuInfo.Rows(DataGrid1.CurrentPageIndex * DataGrid1.PageSize + i)
            If nr("StuState") <> cb.Checked Then
                nr.BeginEdit()
                nr("StuState") = cb.Checked
                nr.EndEdit()
            End If
        Next
        SignUpSDA.Update(TpDS1)
    End Sub

    Private Sub DataGrid1_SelectedIndexChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles DataGrid1.SelectedIndexChanged
        'Dim s As String
        's = DataGrid1.SelectedIndex
        'Response.Write(s)
    End Sub

   
End Class
