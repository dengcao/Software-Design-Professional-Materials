Imports System.Data.SqlClient
Imports System.Web.Security

Public Class regist
    Inherits System.Web.UI.Page

#Region " Web ������������ɵĴ��� "

    '�õ����� Web ���������������ġ�
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.USDA = New System.Data.SqlClient.SqlDataAdapter
        Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlConnection1 = New System.Data.SqlClient.SqlConnection
        Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
        Me.Uds1 = New WebApply.UDS
        CType(Me.Uds1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'USDA
        '
        Me.USDA.DeleteCommand = Me.SqlDeleteCommand1
        Me.USDA.InsertCommand = Me.SqlInsertCommand1
        Me.USDA.SelectCommand = Me.SqlSelectCommand1
        Me.USDA.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "UserInfo", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("UserName", "UserName"), New System.Data.Common.DataColumnMapping("UserID", "UserID")})})
        Me.USDA.UpdateCommand = Me.SqlUpdateCommand1
        '
        'SqlDeleteCommand1
        '
        Me.SqlDeleteCommand1.CommandText = "DELETE FROM UserInfo WHERE (UserID = @Original_UserID) AND (UserName = @Original_" & _
        "UserName)"
        Me.SqlDeleteCommand1.Connection = Me.SqlConnection1
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserName", System.Data.SqlDbType.NVarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserName", System.Data.DataRowVersion.Original, Nothing))
        '
        'SqlConnection1
        '
        Me.SqlConnection1.ConnectionString = "workstation id=C37;packet size=4096;user id=sa;initial catalog=info;persist secur" & _
        "ity info=True;password=sa"
        '
        'SqlInsertCommand1
        '
        Me.SqlInsertCommand1.CommandText = "INSERT INTO UserInfo(UserName) VALUES (@UserName); SELECT UserName, UserID FROM U" & _
        "serInfo WHERE (UserID = @@IDENTITY)"
        Me.SqlInsertCommand1.Connection = Me.SqlConnection1
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.NVarChar, 16, "UserName"))
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT UserName, UserID FROM UserInfo"
        Me.SqlSelectCommand1.Connection = Me.SqlConnection1
        '
        'SqlUpdateCommand1
        '
        Me.SqlUpdateCommand1.CommandText = "UPDATE UserInfo SET UserName = @UserName WHERE (UserID = @Original_UserID) AND (U" & _
        "serName = @Original_UserName); SELECT UserName, UserID FROM UserInfo WHERE (User" & _
        "ID = @UserID)"
        Me.SqlUpdateCommand1.Connection = Me.SqlConnection1
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.NVarChar, 16, "UserName"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserID", System.Data.SqlDbType.Int, 4, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserName", System.Data.SqlDbType.NVarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserName", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.Int, 4, "UserID"))
        '
        'Uds1
        '
        Me.Uds1.DataSetName = "UDS"
        Me.Uds1.Locale = New System.Globalization.CultureInfo("zh-CN")
        CType(Me.Uds1, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
    Protected WithEvents User_Name As System.Web.UI.WebControls.TextBox
    Protected WithEvents RequiredFieldValidator1 As System.Web.UI.WebControls.RequiredFieldValidator
    Protected WithEvents User_Password As System.Web.UI.WebControls.TextBox
    Protected WithEvents RequiredFieldValidator2 As System.Web.UI.WebControls.RequiredFieldValidator
    Protected WithEvents CompareValidator1 As System.Web.UI.WebControls.CompareValidator
    Protected WithEvents RequiredFieldValidator3 As System.Web.UI.WebControls.RequiredFieldValidator
    Protected WithEvents beizhu As System.Web.UI.WebControls.TextBox
    Protected WithEvents User_Password1 As System.Web.UI.HtmlControls.HtmlInputText
    Protected WithEvents Submit As System.Web.UI.WebControls.Button
    Protected WithEvents Cancer As System.Web.UI.WebControls.Button
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents USDA As System.Data.SqlClient.SqlDataAdapter
    Protected WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlConnection1 As System.Data.SqlClient.SqlConnection
    Protected WithEvents Uds1 As WebApply.UDS

    'ע��: ����ռλ�������� Web ���������������ġ�
    '��Ҫɾ�����ƶ�����
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: �˷��������� Web ����������������
        '��Ҫʹ�ô���༭���޸�����
        InitializeComponent()
    End Sub

#End Region

    Public Function AddUser(ByVal strUserName As String, ByVal strUserPassword As String) As String
        Dim conStrinfo As String = ConfigurationSettings.AppSettings("conStrinfo")
        Dim objConnection As SqlConnection = New SqlConnection(conStrinfo)
        Dim objCommand As SqlCommand = New SqlCommand("UserAdd", objConnection)

        objCommand.CommandType = CommandType.StoredProcedure

        Dim parameterUserName As SqlParameter = New SqlParameter("@UserName", SqlDbType.NVarChar, 16)
        parameterUserName.Value = strUserName
        objCommand.Parameters.Add(parameterUserName)

        Dim parameterUserPassword As SqlParameter = New SqlParameter("@UserPassword", SqlDbType.NVarChar, 25)
        parameterUserPassword.Value = strUserPassword
        objCommand.Parameters.Add(parameterUserPassword)

        Dim parameterUserID As SqlParameter = New SqlParameter("@UserID", SqlDbType.Int, 4)
        parameterUserID.Direction = ParameterDirection.Output
        objCommand.Parameters.Add(parameterUserID)


        Try
            objConnection.Open()
            objCommand.ExecuteNonQuery()
        Catch ex As Exception
            'Label9.Text = ex.ToString
        Finally
            If objConnection.State = ConnectionState.Open Then
                objConnection.Close()
            End If
        End Try
        Dim UserId As Integer
        UserId = CInt(parameterUserID.Value)
        Return UserId.ToString()
    End Function

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�ڴ˴����ó�ʼ��ҳ���û�����
    End Sub

    Private Sub Submit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Submit.Click
        If Page.IsValid Then
            Dim strUserId As String
            strUserId = AddUser(User_Name.Text, User_Password.Text)
            Session("UserID") = strUserId
            If (strUserId <> "") Then
                FormsAuthentication.SetAuthCookie(strUserId, False)
                Response.Redirect("user\userinfo.aspx")
            End If
        End If
    End Sub

    Private Sub Cancer_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancer.Click
        Response.Redirect("login.aspx")
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Dim r As UDS.UserInfoRow = Uds1.UserInfo.NewRow
        r = Uds1.UserInfo.FindByUserName(User_Name.Text.ToString)
        If r Is Nothing Then
            Response.Write("����ע��")
        End If
        RequiredFieldValidator2.Enabled = True
        RequiredFieldValidator2.Enabled = True
        RequiredFieldValidator3.Enabled = True
    End Sub
End Class
