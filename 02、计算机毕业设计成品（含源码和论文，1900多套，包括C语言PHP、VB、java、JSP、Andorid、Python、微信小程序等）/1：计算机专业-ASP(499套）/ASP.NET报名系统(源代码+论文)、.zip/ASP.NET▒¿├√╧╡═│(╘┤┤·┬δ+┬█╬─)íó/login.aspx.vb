Imports System.Web.Security

Public Class _default
    Inherits System.Web.UI.Page

#Region " Web ������������ɵĴ��� "

    '�õ����� Web ���������������ġ�
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents TextBox1 As System.Web.UI.WebControls.TextBox
    Protected WithEvents TextBox2 As System.Web.UI.WebControls.TextBox
    Protected WithEvents Login As System.Web.UI.WebControls.Button
    Protected WithEvents Cancer As System.Web.UI.WebControls.Button
    Protected WithEvents BtnForget As System.Web.UI.WebControls.Button
    Protected WithEvents BtnLogin As System.Web.UI.WebControls.Button
    Protected WithEvents userPassword As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents userName As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents lblInfo As System.Web.UI.WebControls.Label
    Protected WithEvents Panel1 As System.Web.UI.WebControls.Panel
    Protected WithEvents AdminLogin As System.Web.UI.WebControls.Button

    'ע��: ����ռλ�������� Web ���������������ġ�
    '��Ҫɾ�����ƶ�����
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: �˷��������� Web ����������������
        '��Ҫʹ�ô���༭���޸�����
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�ڴ˴����ó�ʼ��ҳ���û�����
    End Sub


    Private Sub BtnLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnLogin.Click
        'ID of an employee
        Dim strUserId As String
        Dim ULogin As New UserLogin
        'TODO Lab 16: Call the Login function
        'Attempt to Validate User Credentials using CustomersDB  
        strUserId = ULogin.Login(userName.Text, userPassword.Text)

        'TODO Lab 16: Login users and generate an auth. cookie
        If (strUserId <> "") Then

            'Redirect browser back to originating page and
            'creates a non-persistant authentication cookie
            'with strEmployeeID as a user.identity 

            FormsAuthentication.RedirectFromLoginPage(strUserId, False)

        Else 'Login failed

            lblInfo.Text = "Login Failed!"

        End If
    End Sub

    Private Sub BtnForget_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnForget.Click
        userName.Text = ""
        userPassword.Text = ""
    End Sub

    Private Sub AdminLogin_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AdminLogin.Click
        Response.Redirect("adminlogin.aspx")
    End Sub
End Class
