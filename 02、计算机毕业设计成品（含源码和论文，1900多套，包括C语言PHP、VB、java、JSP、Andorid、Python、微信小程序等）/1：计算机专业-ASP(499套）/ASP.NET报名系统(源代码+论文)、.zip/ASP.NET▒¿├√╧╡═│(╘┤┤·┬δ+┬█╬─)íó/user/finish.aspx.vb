Public Class difficulty
    Inherits System.Web.UI.Page

#Region " Web ������������ɵĴ��� "

    '�õ����� Web ���������������ġ�
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.StuSDA = New System.Data.SqlClient.SqlDataAdapter
        Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlConnection1 = New System.Data.SqlClient.SqlConnection
        Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
        Me.StuDS1 = New WebApply.StuDS
        CType(Me.StuDS1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'StuSDA
        '
        Me.StuSDA.DeleteCommand = Me.SqlDeleteCommand1
        Me.StuSDA.InsertCommand = Me.SqlInsertCommand1
        Me.StuSDA.SelectCommand = Me.SqlSelectCommand1
        Me.StuSDA.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "getstuinfo", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("allowID", "allowID"), New System.Data.Common.DataColumnMapping("stuName", "stuName"), New System.Data.Common.DataColumnMapping("stuID", "stuID"), New System.Data.Common.DataColumnMapping("stuPassword", "stuPassword")})})
        Me.StuSDA.UpdateCommand = Me.SqlUpdateCommand1
        '
        'SqlDeleteCommand1
        '
        Me.SqlDeleteCommand1.CommandText = "DELETE FROM getstuinfo WHERE (allowID = @Original_allowID) AND (stuID = @Original" & _
        "_stuID) AND (stuName = @Original_stuName) AND (stuPassword = @Original_stuPasswo" & _
        "rd)"
        Me.SqlDeleteCommand1.Connection = Me.SqlConnection1
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_allowID", System.Data.SqlDbType.BigInt, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "allowID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_stuID", System.Data.SqlDbType.NVarChar, 18, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "stuID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_stuName", System.Data.SqlDbType.NVarChar, 6, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "stuName", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_stuPassword", System.Data.SqlDbType.VarChar, 6, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "stuPassword", System.Data.DataRowVersion.Original, Nothing))
        '
        'SqlConnection1
        '
        Me.SqlConnection1.ConnectionString = "workstation id=C04;packet size=4096;user id=sa;initial catalog=info;persist secur" & _
        "ity info=True;password=sa"
        '
        'SqlInsertCommand1
        '
        Me.SqlInsertCommand1.CommandText = "INSERT INTO getstuinfo(stuName, stuID, stuPassword) VALUES (@stuName, @stuID, @st" & _
        "uPassword); SELECT allowID, stuName, stuID, stuPassword FROM getstuinfo WHERE (a" & _
        "llowID = @@IDENTITY)"
        Me.SqlInsertCommand1.Connection = Me.SqlConnection1
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@stuName", System.Data.SqlDbType.NVarChar, 6, "stuName"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@stuID", System.Data.SqlDbType.NVarChar, 18, "stuID"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@stuPassword", System.Data.SqlDbType.VarChar, 6, "stuPassword"))
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT allowID, stuName, stuID, stuPassword FROM getstuinfo WHERE (stuID = @stuID" & _
        ")"
        Me.SqlSelectCommand1.Connection = Me.SqlConnection1
        Me.SqlSelectCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@stuID", System.Data.SqlDbType.NVarChar, 18, "stuID"))
        '
        'SqlUpdateCommand1
        '
        Me.SqlUpdateCommand1.CommandText = "UPDATE getstuinfo SET stuName = @stuName, stuID = @stuID, stuPassword = @stuPassw" & _
        "ord WHERE (allowID = @Original_allowID) AND (stuID = @Original_stuID) AND (stuNa" & _
        "me = @Original_stuName) AND (stuPassword = @Original_stuPassword); SELECT allowI" & _
        "D, stuName, stuID, stuPassword FROM getstuinfo WHERE (allowID = @allowID)"
        Me.SqlUpdateCommand1.Connection = Me.SqlConnection1
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@stuName", System.Data.SqlDbType.NVarChar, 6, "stuName"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@stuID", System.Data.SqlDbType.NVarChar, 18, "stuID"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@stuPassword", System.Data.SqlDbType.VarChar, 6, "stuPassword"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_allowID", System.Data.SqlDbType.BigInt, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "allowID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_stuID", System.Data.SqlDbType.NVarChar, 18, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "stuID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_stuName", System.Data.SqlDbType.NVarChar, 6, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "stuName", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_stuPassword", System.Data.SqlDbType.VarChar, 6, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "stuPassword", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@allowID", System.Data.SqlDbType.BigInt, 8, "allowID"))
        '
        'StuDS1
        '
        Me.StuDS1.DataSetName = "StuDS"
        Me.StuDS1.Locale = New System.Globalization.CultureInfo("zh-CN")
        CType(Me.StuDS1, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
    Protected WithEvents DataGrid1 As System.Web.UI.WebControls.DataGrid
    Protected WithEvents StuSDA As System.Data.SqlClient.SqlDataAdapter
    Protected WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlConnection1 As System.Data.SqlClient.SqlConnection
    Protected WithEvents StuDS1 As WebApply.StuDS

    'ע��: ����ռλ�������� Web ���������������ġ�
    '��Ҫɾ�����ƶ�����
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: �˷��������� Web ����������������
        '��Ҫʹ�ô���༭���޸�����
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�ڴ˴����ó�ʼ��ҳ���û�����
        StuSDA.SelectCommand.Parameters("@stuID").Value() = Session("stuID")
        StuDS1.Clear()
        StuSDA.Fill(StuDS1)
        DataGrid1.DataSource = StuDS1
        DataGrid1.DataBind()
    End Sub

End Class
