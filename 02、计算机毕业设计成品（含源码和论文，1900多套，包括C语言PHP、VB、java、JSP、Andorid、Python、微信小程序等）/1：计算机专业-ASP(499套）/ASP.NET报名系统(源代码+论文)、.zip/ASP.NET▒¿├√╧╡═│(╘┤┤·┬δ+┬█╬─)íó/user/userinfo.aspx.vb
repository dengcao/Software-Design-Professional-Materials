Imports System.Web.Security

Public Class login
    Inherits System.Web.UI.Page

#Region " Web ������������ɵĴ��� "

    '�õ����� Web ���������������ġ�
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.UserSDA = New System.Data.SqlClient.SqlDataAdapter
        Me.SqlDeleteCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlConnection1 = New System.Data.SqlClient.SqlConnection
        Me.SqlInsertCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlSelectCommand1 = New System.Data.SqlClient.SqlCommand
        Me.SqlUpdateCommand1 = New System.Data.SqlClient.SqlCommand
        Me.UserDS1 = New WebApply.UserDS
        CType(Me.UserDS1, System.ComponentModel.ISupportInitialize).BeginInit()
        '
        'UserSDA
        '
        Me.UserSDA.DeleteCommand = Me.SqlDeleteCommand1
        Me.UserSDA.InsertCommand = Me.SqlInsertCommand1
        Me.UserSDA.SelectCommand = Me.SqlSelectCommand1
        Me.UserSDA.TableMappings.AddRange(New System.Data.Common.DataTableMapping() {New System.Data.Common.DataTableMapping("Table", "UserInfo", New System.Data.Common.DataColumnMapping() {New System.Data.Common.DataColumnMapping("UserName", "UserName"), New System.Data.Common.DataColumnMapping("UserPassword", "UserPassword"), New System.Data.Common.DataColumnMapping("UserID", "UserID")})})
        Me.UserSDA.UpdateCommand = Me.SqlUpdateCommand1
        '
        'SqlDeleteCommand1
        '
        Me.SqlDeleteCommand1.CommandText = "DELETE FROM UserInfo WHERE (UserID = @Original_UserID) AND (UserName = @Original_" & _
        "UserName) AND (UserPassword = @Original_UserPassword)"
        Me.SqlDeleteCommand1.Connection = Me.SqlConnection1
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserID", System.Data.SqlDbType.BigInt, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserName", System.Data.SqlDbType.NVarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserName", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlDeleteCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserPassword", System.Data.SqlDbType.NVarChar, 25, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserPassword", System.Data.DataRowVersion.Original, Nothing))
        '
        'SqlConnection1
        '
        Me.SqlConnection1.ConnectionString = "workstation id=C16;packet size=4096;user id=sa;initial catalog=info;persist secur" & _
        "ity info=True;password=sa"
        '
        'SqlInsertCommand1
        '
        Me.SqlInsertCommand1.CommandText = "INSERT INTO UserInfo(UserName, UserPassword) VALUES (@UserName, @UserPassword); S" & _
        "ELECT UserName, UserPassword, UserID FROM UserInfo WHERE (UserID = @@IDENTITY)"
        Me.SqlInsertCommand1.Connection = Me.SqlConnection1
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.NVarChar, 16, "UserName"))
        Me.SqlInsertCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserPassword", System.Data.SqlDbType.NVarChar, 25, "UserPassword"))
        '
        'SqlSelectCommand1
        '
        Me.SqlSelectCommand1.CommandText = "SELECT UserName, UserPassword, UserID FROM UserInfo WHERE (UserID = @UserID)"
        Me.SqlSelectCommand1.Connection = Me.SqlConnection1
        Me.SqlSelectCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.BigInt, 8, "UserID"))
        '
        'SqlUpdateCommand1
        '
        Me.SqlUpdateCommand1.CommandText = "UPDATE UserInfo SET UserName = @UserName, UserPassword = @UserPassword WHERE (Use" & _
        "rID = @Original_UserID) AND (UserName = @Original_UserName) AND (UserPassword = " & _
        "@Original_UserPassword); SELECT UserName, UserPassword, UserID FROM UserInfo WHE" & _
        "RE (UserID = @UserID)"
        Me.SqlUpdateCommand1.Connection = Me.SqlConnection1
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserName", System.Data.SqlDbType.NVarChar, 16, "UserName"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserPassword", System.Data.SqlDbType.NVarChar, 25, "UserPassword"))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserID", System.Data.SqlDbType.BigInt, 8, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserID", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserName", System.Data.SqlDbType.NVarChar, 16, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserName", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@Original_UserPassword", System.Data.SqlDbType.NVarChar, 25, System.Data.ParameterDirection.Input, False, CType(0, Byte), CType(0, Byte), "UserPassword", System.Data.DataRowVersion.Original, Nothing))
        Me.SqlUpdateCommand1.Parameters.Add(New System.Data.SqlClient.SqlParameter("@UserID", System.Data.SqlDbType.BigInt, 8, "UserID"))
        '
        'UserDS1
        '
        Me.UserDS1.DataSetName = "UserDS"
        Me.UserDS1.Locale = New System.Globalization.CultureInfo("zh-CN")
        CType(Me.UserDS1, System.ComponentModel.ISupportInitialize).EndInit()

    End Sub
    Protected WithEvents Button1 As System.Web.UI.WebControls.Button
    Protected WithEvents Button2 As System.Web.UI.WebControls.Button
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents userName As System.Web.UI.WebControls.Label
    Protected WithEvents userPassword As System.Web.UI.WebControls.Label
    Protected WithEvents Yes As System.Web.UI.WebControls.Button
    Protected WithEvents No As System.Web.UI.WebControls.Button
    Protected WithEvents SqlConnection1 As System.Data.SqlClient.SqlConnection
    Protected WithEvents UserSDA As System.Data.SqlClient.SqlDataAdapter
    Protected WithEvents SqlSelectCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlInsertCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlUpdateCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents SqlDeleteCommand1 As System.Data.SqlClient.SqlCommand
    Protected WithEvents UserDS1 As WebApply.UserDS

    'ע��: ����ռλ�������� Web ���������������ġ�
    '��Ҫɾ�����ƶ�����
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: �˷��������� Web ����������������
        '��Ҫʹ�ô���༭���޸�����
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�ڴ˴����ó�ʼ��ҳ���û�����
        UserSDA.SelectCommand.Parameters("@userID").Value() = Session("userID")
        UserDS1.Clear()
        UserSDA.Fill(UserDS1)
        userName.Text = UserDS1.UserInfo.Rows(0).Item(0)
        userPassword.Text = UserDS1.UserInfo.Rows(0).Item(1)
    End Sub

    Private Sub Yes_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Yes.Click
        Dim strUserId As String
        Dim ULogin As New UserLogin
        strUserId = ULogin.Login(userName.Text, userPassword.Text)
        If (strUserId <> "") Then
            FormsAuthentication.RedirectFromLoginPage(strUserId, False)
            Response.Redirect("..\default.aspx")
        Else
            ' lblInfo.Text = "Login Failed!"
        End If
    End Sub

    Private Sub No_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles No.Click
        Response.Redirect("..\login.aspx")
    End Sub
End Class
