Imports System
Imports System.IO
Imports System.Data
Imports System.Data.SqlClient
Imports System.Web.Security


Public Class signup
    Inherits System.Web.UI.Page

#Region " Web ������������ɵĴ��� "

    '�õ����� Web ���������������ġ�
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()

    End Sub
    Protected WithEvents Label2 As System.Web.UI.WebControls.Label
    Protected WithEvents Label1 As System.Web.UI.WebControls.Label
    Protected WithEvents StuName As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label3 As System.Web.UI.WebControls.Label
    Protected WithEvents Label4 As System.Web.UI.WebControls.Label
    Protected WithEvents Label5 As System.Web.UI.WebControls.Label
    Protected WithEvents Label6 As System.Web.UI.WebControls.Label
    Protected WithEvents Label7 As System.Web.UI.WebControls.Label
    Protected WithEvents Male As System.Web.UI.WebControls.RadioButton
    Protected WithEvents Female As System.Web.UI.WebControls.RadioButton
    Protected WithEvents Label8 As System.Web.UI.WebControls.Label
    Protected WithEvents Submit As System.Web.UI.WebControls.Button
    Protected WithEvents StuID As System.Web.UI.WebControls.TextBox
    Protected WithEvents XiBie As System.Web.UI.WebControls.DropDownList
    Protected WithEvents ClassName As System.Web.UI.WebControls.TextBox
    Protected WithEvents JiBie As System.Web.UI.WebControls.DropDownList
    Protected WithEvents _ID As System.Web.UI.WebControls.TextBox
    Protected WithEvents Label9 As System.Web.UI.WebControls.Label
    Protected WithEvents Label10 As System.Web.UI.WebControls.Label
    Protected WithEvents loFile As System.Web.UI.HtmlControls.HtmlInputFile
    Protected WithEvents UploadFile As System.Web.UI.WebControls.Button
    Protected WithEvents Photo As System.Web.UI.WebControls.Image

    'ע��: ����ռλ�������� Web ���������������ġ�
    '��Ҫɾ�����ƶ�����
    Private designerPlaceholderDeclaration As System.Object

    Private Sub Page_Init(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Init
        'CODEGEN: �˷��������� Web ����������������
        '��Ҫʹ�ô���༭���޸�����
        InitializeComponent()
    End Sub

#End Region

    Private Sub Page_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        '�ڴ˴����ó�ʼ��ҳ���û�����
        If Not Page.IsPostBack Then

        End If
    End Sub

#Region "����"

    Public Function AddStudent(ByVal strStuName As String, ByVal strID As String, ByVal strStuID As String, _
    ByVal strPassword As String, ByVal strSex As String, ByVal StrXibie As String, ByVal strClass As String, ByVal strJibie As String) As String
        Dim conStrinfo As String = ConfigurationSettings.AppSettings("conStrinfo")
        Dim objConnection As SqlConnection = New SqlConnection(conStrinfo)
        Dim objCommand As SqlCommand = New SqlCommand("StuAdd", objConnection)

        objCommand.CommandType = CommandType.StoredProcedure

        Dim parameterStuName As SqlParameter = New SqlParameter("@StuName", SqlDbType.NVarChar, 6)
        parameterStuName.Value = strStuName
        objCommand.Parameters.Add(parameterStuName)

        Dim parameterID As SqlParameter = New SqlParameter("@ID", SqlDbType.Char, 18)
        parameterID.Value = strID
        objCommand.Parameters.Add(parameterID)

        Dim parameterStuID As SqlParameter = New SqlParameter("@StuID", SqlDbType.Char, 15)
        parameterStuID.Value = strStuID
        objCommand.Parameters.Add(parameterStuID)

        Dim parameterAllowID As SqlParameter = New SqlParameter("@AllowID", SqlDbType.Int, 4)
        parameterAllowID.Direction = ParameterDirection.Output
        objCommand.Parameters.Add(parameterAllowID)

        Dim parameterStuPassword As SqlParameter = New SqlParameter("@StuPassword", SqlDbType.Char, 6)
        parameterStuPassword.Value = strPassword
        objCommand.Parameters.Add(parameterStuPassword)

        Dim parameterStuSex As SqlParameter = New SqlParameter("@sex", SqlDbType.Char, 2)
        parameterStuSex.Value = strSex
        objCommand.Parameters.Add(parameterStuSex)

        Dim parameterStuXibie As SqlParameter = New SqlParameter("@xibie", SqlDbType.Char, 8)
        parameterStuXibie.Value = StrXibie
        objCommand.Parameters.Add(parameterStuXibie)

        Dim parameterStuClass As SqlParameter = New SqlParameter("@ClassNm", SqlDbType.NVarChar, 20)
        parameterStuClass.Value = strClass
        objCommand.Parameters.Add(parameterStuClass)

        Dim parameterStuJibie As SqlParameter = New SqlParameter("@jibie", SqlDbType.Char, 4)
        parameterStuJibie.Value = strJibie
        objCommand.Parameters.Add(parameterStuJibie)


        Try
            objConnection.Open()
            objCommand.ExecuteNonQuery()
        Catch ex As Exception
            Label9.Text = ex.ToString
        Finally
            If objConnection.State = ConnectionState.Open Then
                objConnection.Close()
            End If
        End Try
        Dim StuId As Integer
        StuId = CInt(parameterAllowID.Value)
        Return StuId.ToString()
    End Function

    Private Sub Submit_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Submit.Click

        If Page.IsValid Then
            Randomize()
            Dim StuPassword As String
            StuPassword = CInt(1000000 * Rnd() + 999)
            Dim pwLength As Int16
            pwLength = 6 - StuPassword.Length
            Select Case pwLength
                Case 0
                Case 1
                    StuPassword = "0" & StuPassword
                Case 2
                    StuPassword = "00" & StuPassword
                Case 3
                    StuPassword = "000" & StuPassword
            End Select

            Dim strStuId As String
            Dim sex As String
            If Male.Checked Then
                sex = "��"
            Else
                sex = "Ů"
            End If
            strStuId = AddStudent(StuName.Text, _ID.Text, StuID.Text, StuPassword, sex, XiBie.SelectedItem.ToString, ClassName.Text, JiBie.SelectedItem.ToString)
            Session("ID") = _ID.Text
            If (strStuId <> "") Then
                FormsAuthentication.SetAuthCookie(strStuId, False)
                Response.Redirect("..\students\finish.aspx")
                ' Response.Redirect("..\students\waiting.aspx")
            End If
        End If

    End Sub

#End Region


#Region "�ϴ�ͼƬ"

    Sub UploadFile_Clicked(ByVal Sender As Object, ByVal e As EventArgs) Handles UploadFile.Click
        Dim lstrFileName As String
        Dim lstrFileNamePath As String
        Dim lstrFileFolder As String
        ' ����ϴ�Ŀ¼Ϊ�գ���ʹ��" c:\ "��Ϊȱʡ�ϴ�Ŀ¼ 
        ' ����ϴ�����������Ŀ¼����



        ' ����ļ����� 
        lstrFileName = loFile.PostedFile.FileName

        If lstrFileName = "" Then
            Response.Redirect("signup.aspx")
        Else
            lstrFileFolder = "c:\"
        End If

        Response.Write(lstrFileName)
        ' ע�� loFile.PostedFile.FileName ���ص���
        'ͨ���ļ��Ի���ѡ����ļ���(, ��֮�а������ļ���Ŀ¼��Ϣ)
        lstrFileName = Path.GetFileName(lstrFileName)
        ' ȥ��Ŀ¼��Ϣ�������ļ�����

        ' �ж��ϴ�Ŀ¼�Ƿ���ڣ������ھͽ��� 
        If (Not Directory.Exists(lstrFileFolder)) Then
            Directory.CreateDirectory(lstrFileFolder)
        End If


        '�ϴ��ļ��������� 
        lstrFileNamePath = lstrFileFolder & lstrFileName
        ' �õ��ϴ�Ŀ¼���ļ����� 

        loFile.PostedFile.SaveAs(lstrFileNamePath)

        Photo.ImageUrl = lstrFileNamePath

        ''' ��ò���ʾ�ϴ��ļ������� 
        ''FileName.Text = lstrFileName
        ''' ����ļ�����
        ''FileType.Text = loFile.PostedFile.ContentType
        ''' ����ļ�����
        ''FileLength.Text = CStr(loFile.PostedFile.ContentLength)
        ''' ����ļ�����
        ''FileUploadForm.visible = False
        ''AnswerMsg.visible = True
        ''' ��ʾ�ϴ��ļ�����
    End Sub

#End Region



End Class
