package com.form;

import java.sql.Date;

import com.tools.MySuperAction;

public class GoodsForm extends MySuperAction{
	public Integer id=null;
	public String car_id=null;
	public String customer_id=null;
	public String goods_id=null;
	public String goods_name=null;
	public String goods_tel=null;
	public String goods_address=null;
	public String goods_sure=null;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getCar_id() {
		return car_id;
	}
	public void setCar_id(String car_id) {
		this.car_id = car_id;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getGoods_id() {
		return goods_id;
	}
	public void setGoods_id(String goods_id) {
		this.goods_id = goods_id;
	}
	public String getGoods_name() {
		return goods_name;
	}
	public void setGoods_name(String goods_name) {
		this.goods_name = goods_name;
	}
	public String getGoods_tel() {
		return goods_tel;
	}
	public void setGoods_tel(String goods_tel) {
		this.goods_tel = goods_tel;
	}
	public String getGoods_address() {
		return goods_address;
	}
	public void setGoods_address(String goods_address) {
		this.goods_address = goods_address;
	}
	public String getGoods_sure() {
		return goods_sure;
	}
	public void setGoods_sure(String goods_sure) {
		this.goods_sure = goods_sure;
	}		
	

	
}


