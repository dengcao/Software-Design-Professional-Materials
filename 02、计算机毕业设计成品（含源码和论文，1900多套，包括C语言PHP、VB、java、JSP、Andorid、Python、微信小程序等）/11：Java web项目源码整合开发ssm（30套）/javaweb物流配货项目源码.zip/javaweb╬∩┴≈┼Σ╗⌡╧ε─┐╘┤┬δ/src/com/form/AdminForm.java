package com.form;


import com.tools.MySuperAction;

public class AdminForm extends MySuperAction {
	public String admin_user;
	public String admin_password;
	public String admin_repassword1;
	public String admin_repassword2;
	public String getAdmin_user() {
		return admin_user;
	}
	public void setAdmin_user(String admin_user) {
		this.admin_user = admin_user;
	}
	public String getAdmin_password() {
		return admin_password;
	}
	public void setAdmin_password(String admin_password) {
		this.admin_password = admin_password;
	}
	public String getAdmin_repassword1() {
		return admin_repassword1;
	}
	public void setAdmin_repassword1(String admin_repassword1) {
		this.admin_repassword1 = admin_repassword1;
	}
	public String getAdmin_repassword2() {
		return admin_repassword2;
	}
	public void setAdmin_repassword2(String admin_repassword2) {
		this.admin_repassword2 = admin_repassword2;
	}
	

	
}


