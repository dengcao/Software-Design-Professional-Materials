// Decompiled by Jad v1.5.7g. Copyright 2000 Pavel Kouznetsov.
// Jad home page: http://www.geocities.com/SiliconValley/Bridge/8617/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi 
// Source File Name:   bookelement.java

package beans;


public class bookelement
{

    public String ISBN;
    public float price;
    public int number;

    public bookelement()
    {
    }
}
