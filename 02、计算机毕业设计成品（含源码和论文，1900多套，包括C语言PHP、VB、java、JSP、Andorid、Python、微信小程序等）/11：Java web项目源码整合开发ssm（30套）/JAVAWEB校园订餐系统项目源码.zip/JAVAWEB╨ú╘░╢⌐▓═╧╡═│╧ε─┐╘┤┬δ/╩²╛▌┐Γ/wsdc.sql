/*
SQLyog 企业版 - MySQL GUI v8.14 
MySQL - 5.0.22-community-nt-log : Database - wsdc
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`wsdc` /*!40100 DEFAULT CHARACTER SET gb2312 */;

USE `wsdc`;

/*Table structure for table `admin` */

DROP TABLE IF EXISTS `admin`;

CREATE TABLE `admin` (
  `id` int(4) NOT NULL auto_increment,
  `username` varchar(50) default NULL,
  `password` varchar(50) default NULL,
  `creattime` datetime default NULL,
  `flag` int(4) default NULL,
  `isuse` int(4) default NULL,
  `logintimes` int(4) default NULL,
  `quanxian` varchar(1000) default NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;

/*Data for the table `admin` */

insert  into `admin`(`id`,`username`,`password`,`creattime`,`flag`,`isuse`,`logintimes`,`quanxian`) values (1,'admin','21232f297a57a5a743894a0e4a801fc3','0000-00-00 00:00:00',1,1,73,'1');

/*Table structure for table `adminlog` */

DROP TABLE IF EXISTS `adminlog`;

CREATE TABLE `adminlog` (
  `id` int(4) NOT NULL auto_increment,
  `username` varchar(50) default NULL,
  `password` varchar(50) default NULL,
  `logintime` datetime default NULL,
  `loginip` varchar(50) default NULL,
  `useros` varchar(255) default NULL,
  `ok` varchar(50) default NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;

/*Data for the table `adminlog` */

insert  into `adminlog`(`id`,`username`,`password`,`logintime`,`loginip`,`useros`,`ok`) values (52,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 11:40:50','Mozilla/4.0 (compatible','127.0.0.1','true'),(53,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 11:42:14','Mozilla/4.0 (compatible','127.0.0.1','true'),(54,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 11:43:16','Mozilla/4.0 (compatible','127.0.0.1','true'),(55,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 11:53:32','Mozilla/4.0 (compatible','127.0.0.1','true'),(56,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 11:54:02','Mozilla/4.0 (compatible','127.0.0.1','true'),(57,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 12:07:36','Mozilla/4.0 (compatible','127.0.0.1','true'),(58,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 12:13:53','Mozilla/4.0 (compatible','127.0.0.1','true'),(59,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 12:17:32','Mozilla/4.0 (compatible','127.0.0.1','true'),(60,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 16:29:14','Mozilla/4.0 (compatible','127.0.0.1','true'),(61,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 16:30:02','Mozilla/4.0 (compatible','127.0.0.1','true'),(62,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 16:30:11','Mozilla/4.0 (compatible','127.0.0.1','true'),(63,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 16:30:47','Mozilla/4.0 (compatible','127.0.0.1','true'),(64,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 16:31:24','Mozilla/4.0 (compatible','127.0.0.1','true'),(65,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 16:31:33','Mozilla/4.0 (compatible','127.0.0.1','true'),(66,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 18:23:16','Mozilla/4.0 (compatible','127.0.0.1','true'),(67,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 18:35:58','Mozilla/4.0 (compatible','127.0.0.1','true'),(68,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 20:58:23','Mozilla/4.0 (compatible','127.0.0.1','true'),(69,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 21:08:08','Mozilla/4.0 (compatible','127.0.0.1','true'),(70,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 21:14:55','Mozilla/4.0 (compatible','127.0.0.1','true'),(71,'admin','ae7783f0ae4cb82dfe39bb4ec4a53047','2011-03-19 21:17:47','Mozilla/4.0 (compatible','127.0.0.1','true'),(72,'admin','b206e95a4384298962649e58dc7b39d4','2012-03-10 03:34:52','Mozilla/4.0 (compatible','127.0.0.1','true'),(73,'admin','21232f297a57a5a743894a0e4a801fc3','2015-04-30 10:48:14','127.0.0.1','Mozilla/5.0 (Windows NT 6.1) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/41.0.2272.118 Safari/537.36','true');

/*Table structure for table `affiche` */

DROP TABLE IF EXISTS `affiche`;

CREATE TABLE `affiche` (
  `id` int(4) NOT NULL auto_increment,
  `title` varchar(100) default NULL,
  `content` varchar(200) default NULL,
  `addtime` varchar(30) default NULL,
  `adder` varchar(50) default NULL,
  `ifhide` int(4) default NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;

/*Data for the table `affiche` */

insert  into `affiche`(`id`,`title`,`content`,`addtime`,`adder`,`ifhide`) values (4,'娆㈣','娆㈣','2012-03-9 00:35:10','admin',1);

/*Table structure for table `dd` */

DROP TABLE IF EXISTS `dd`;

CREATE TABLE `dd` (
  `id` int(4) NOT NULL auto_increment,
  `ddid` varchar(50) default NULL,
  `member` varchar(50) default NULL,
  `zt` varchar(50) default NULL,
  `fkfs` varchar(50) default NULL,
  `addtime` datetime default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;

/*Data for the table `dd` */

insert  into `dd`(`id`,`ddid`,`member`,`zt`,`fkfs`,`addtime`) values (4,'1300528792906','xiaoqiang','宸插','','2011-03-19 00:00:00'),(5,'1300529721546','xiaoqiang','宸插','璐у','2011-03-19 00:00:00'),(6,'1331321551425','cody','','','2012-03-10 03:32:31'),(7,'1331321634077','cody','','','2012-03-10 03:33:54');

/*Table structure for table `guestbook` */

DROP TABLE IF EXISTS `guestbook`;

CREATE TABLE `guestbook` (
  `id` int(4) NOT NULL auto_increment,
  `nickname` varchar(100) default NULL,
  `pic` varchar(100) default NULL,
  `email` varchar(50) default NULL,
  `qq` varchar(50) default NULL,
  `weburl` varchar(50) default NULL,
  `blogurl` varchar(50) default NULL,
  `expressions` varchar(50) default NULL,
  `content` varchar(200) default NULL,
  `addtime` datetime default NULL,
  `ip` varchar(50) default NULL,
  `replay` int(4) default NULL,
  `ifhide` int(4) default NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;

/*Data for the table `guestbook` */

/*Table structure for table `guestvisit` */

DROP TABLE IF EXISTS `guestvisit`;

CREATE TABLE `guestvisit` (
  `id` int(4) NOT NULL auto_increment,
  `ip` varchar(50) default NULL,
  `vtime` varchar(50) default NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;

/*Data for the table `guestvisit` */

/*Table structure for table `member` */

DROP TABLE IF EXISTS `member`;

CREATE TABLE `member` (
  `id` int(4) NOT NULL auto_increment,
  `username` varchar(50) default NULL,
  `password` varchar(50) default NULL,
  `type` varchar(50) default NULL,
  `regtime` varchar(50) default NULL,
  `ifuse` int(4) default NULL,
  `logintimes` int(4) default NULL,
  `lasttime` datetime default NULL,
  `lastip` varchar(50) default NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;

/*Data for the table `member` */

insert  into `member`(`id`,`username`,`password`,`type`,`regtime`,`ifuse`,`logintimes`,`lasttime`,`lastip`) values (1,'xiaoqiang','96e79218965eb72c92a549dd5a330112','person','2011-03-17 17:51:48',1,18,'2011-03-19 17:59:47','127.0.0.1'),(2,'cody','b206e95a4384298962649e58dc7b39d4','person','2012-03-10 03:32:04',1,2,'2012-03-10 03:33:03','127.0.0.1');

/*Table structure for table `pmember` */

DROP TABLE IF EXISTS `pmember`;

CREATE TABLE `pmember` (
  `id` int(4) NOT NULL auto_increment,
  `mid` int(4) default NULL,
  `realname` varchar(100) default NULL,
  `sex` varchar(50) default NULL,
  `bir` varchar(50) default NULL,
  `sheng` varchar(50) default NULL,
  `city` varchar(50) default NULL,
  `telphone` varchar(50) default NULL,
  `email` varchar(50) default NULL,
  `question` varchar(100) default NULL,
  `answer` varchar(100) default NULL,
  `address` varchar(100) default NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;

/*Data for the table `pmember` */

insert  into `pmember`(`id`,`mid`,`realname`,`sex`,`bir`,`sheng`,`city`,`telphone`,`email`,`question`,`answer`,`address`) values (1,1,'xiaoqiang','m','1999-03-07','','澶╂按','02488888888','xiaoqiang@163.com','','灏','娴'),(2,2,'寮','m','2012-03-08','澶╂触','澶╂触','13899009876','1lo@163.com','123','123d','灞变');

/*Table structure for table `prep` */

DROP TABLE IF EXISTS `prep`;

CREATE TABLE `prep` (
  `id` int(4) NOT NULL auto_increment,
  `title` varchar(50) default NULL,
  `rs` int(4) default NULL,
  `sj` varchar(50) default NULL,
  `ts` varchar(50) default NULL,
  `lxr` varchar(50) default NULL,
  `lxfs` varchar(50) default NULL,
  `addtime` datetime default NULL,
  `member` varchar(50) default NULL,
  `zt` varchar(50) default NULL,
  `ddid` varchar(100) default NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;

/*Data for the table `prep` */

insert  into `prep`(`id`,`title`,`rs`,`sj`,`ts`,`lxr`,`lxfs`,`addtime`,`member`,`zt`,`ddid`) values (7,'',2,'3','','寮','13888888888','2011-03-19 00:00:00','xiaoqiang','宸叉','1300528792906'),(8,'',1,'3','','','88888888','2011-03-19 00:00:00','xiaoqiang','宸叉','1300528792906'),(9,'XO',5,'3','','','88888888','2011-03-19 00:00:00','xiaoqiang','宸叉','1300529721546'),(10,'',3,'涓','妗ュご','寮','141234213','2012-03-10 03:33:42','cody','宸叉','1331321634077');

/*Table structure for table `replay` */

DROP TABLE IF EXISTS `replay`;

CREATE TABLE `replay` (
  `id` int(4) NOT NULL auto_increment,
  `mid` int(4) default NULL,
  `replay` varchar(200) default NULL,
  `replayer` varchar(50) default NULL,
  `replaytime` datetime default NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;

/*Data for the table `replay` */

/*Table structure for table `sale` */

DROP TABLE IF EXISTS `sale`;

CREATE TABLE `sale` (
  `id` int(4) NOT NULL auto_increment,
  `title` varchar(50) default NULL,
  `url` varchar(200) default NULL,
  `dz` varchar(50) default NULL,
  `yb` varchar(50) default NULL,
  `dh` varchar(50) default NULL,
  `jd` varchar(50) default NULL,
  `content` text,
  `addtime` varchar(50) default NULL,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;

/*Data for the table `sale` */

insert  into `sale`(`id`,`title`,`url`,`dz`,`yb`,`dh`,`jd`,`content`,`addtime`) values (15,'绮介','/upload_file/sale/5.jpg','98','楦¤','','婀','<p><font color=\"#ff0000\">','2011-03-19 23:20:32'),(16,'XO','/upload_file/sale/4.jpg','105','','椴','娌?','<p><font color=\"#ff0000\">','2011-03-19 23:20:32'),(17,'','/upload_file/sale/3.jpg','58','绔ュ','瀛','浜?','<p><font color=\"#ff0000\">','2011-03-19 23:20:32'),(18,'','/upload_file/sale/2.jpg','120','椴ら奔','楹昏荆','杈借','<p><font color=\"#ff0000\">','2011-03-19 23:20:32'),(19,'','/upload_file/sale/1.jpg','49','','','椴','<p><font color=\"#ff0000\">','2011-03-19 23:20:32'),(20,'','/upload_file/sale/6.jpg','35','','椴','绮よ','<p><font color=\"#ff0000\">','2011-03-19 23:20:32');

/*Table structure for table `system` */

DROP TABLE IF EXISTS `system`;

CREATE TABLE `system` (
  `id` int(4) NOT NULL auto_increment,
  `sitename` varchar(100) default NULL,
  `url` varchar(100) default NULL,
  `keyword` varchar(100) default NULL,
  `description` varchar(100) default NULL,
  `email` varchar(100) default NULL,
  `state` varchar(100) default NULL,
  `reasons` varchar(100) default NULL,
  `dir` varchar(100) default NULL,
  `record` varchar(100) default NULL,
  `copyright` text,
  UNIQUE KEY `id` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=gb2312;

/*Data for the table `system` */

insert  into `system`(`id`,`sitename`,`url`,`keyword`,`description`,`email`,`state`,`reasons`,`dir`,`record`,`copyright`) values (1,'','admin','','','','open','','admin','','蹇?');

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
