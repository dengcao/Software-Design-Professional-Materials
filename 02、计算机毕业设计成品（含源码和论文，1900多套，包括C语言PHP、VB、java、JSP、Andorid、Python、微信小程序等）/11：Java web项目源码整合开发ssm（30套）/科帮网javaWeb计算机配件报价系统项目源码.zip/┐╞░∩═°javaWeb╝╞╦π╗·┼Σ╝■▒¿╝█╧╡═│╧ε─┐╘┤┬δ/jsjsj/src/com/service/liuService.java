package com.service;

import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.dao.DB;
import com.orm.Tsanjian;

public class liuService
{
	public static String getUserName(String id)
	{
		String name="";
		
		String sql="select * from t_user where id=?";
		Object[] params={id};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			rs.next();
			name=rs.getString("loginname");
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		return name;
	}
	

	public static List getSanjianList(int catelog_id)
	{
		List sanjianList=new ArrayList();
		
		String sql="select * from t_sanjian where del='no' and catelog_id=?";
		Object[] params={catelog_id};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
                Tsanjian sanjian=new Tsanjian();
				
				sanjian.setId(rs.getString("id"));
				sanjian.setCatelog_id(rs.getInt("catelog_id"));
				sanjian.setName(rs.getString("name"));
				sanjian.setFujian(rs.getString("fujian"));
				
				sanjian.setFujianYuanshiming(rs.getString("fujianYuanshiming"));
				sanjian.setJiage(rs.getInt("jiage"));
				sanjian.setPinpai(rs.getString("pinpai"));
				sanjian.setBeizhu(rs.getString("beizhu"));
				sanjian.setShijian(rs.getString("shijian"));
				sanjian.setDel(rs.getString("del"));
				
				sanjianList.add(sanjian);
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		System.out.println(sanjianList.size()+"^^^");
		if(sanjianList.size()>4)
		{
			sanjianList=sanjianList.subList(0, 4);
		}
		
		return sanjianList;
	}
}
