package com.action;

import java.io.IOException;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dao.DB;
import com.orm.TAdmin;
import com.orm.Tcatelog;
import com.orm.Tsanjian;

public class sanjian_servlet extends HttpServlet
{
	public void service(HttpServletRequest req,HttpServletResponse res)throws ServletException, IOException 
	{
        String type=req.getParameter("type");
		
		if(type.endsWith("sanjianMana"))
		{
			sanjianMana(req, res);
		}
		if(type.endsWith("sanjianAdd"))
		{
			sanjianAdd(req, res);
		}
		if(type.endsWith("sanjianDel"))
		{
			sanjianDel(req, res);
		}
		if(type.endsWith("sanjianDetail"))
		{
			sanjianDetail(req, res);
		}
		
		if(type.endsWith("sanjianDetailQian"))
		{
			sanjianDetailQian(req, res);
		}
		if(type.endsWith("sanjianAll"))
		{
			sanjianAll(req, res);
		}
		if(type.endsWith("sanjianSearch"))
		{
			sanjianSearch(req, res);
		}
	}
	
	
	public void sanjianAdd(HttpServletRequest req,HttpServletResponse res)
	{
		String id=String.valueOf(new Date().getTime());
		int catelog_id=Integer.parseInt(req.getParameter("catelog_id"));
		String name=req.getParameter("name");
		String fujian=req.getParameter("fujian");
		
		String fujianYuanshiming=req.getParameter("fujianYuanshiming");
		int jiage=Integer.parseInt(req.getParameter("jiage"));
		String pinpai=req.getParameter("pinpai");
		String beizhu=req.getParameter("beizhu");
		String shijian=req.getParameter("shijian");
		String del="no";
		
		
		
		String sql="insert into t_sanjian values(?,?,?,?,?,?,?,?,?,?)";
		Object[] params={id,catelog_id,name,fujian,fujianYuanshiming,jiage,pinpai,beizhu,shijian,del};
		DB mydb=new DB();
		mydb.doPstm(sql, params);
		mydb.closed();
		
		req.setAttribute("message", "�����ɹ�");
		req.setAttribute("path", "sanjian?type=sanjianMana");
		
        String targetURL = "/common/success.jsp";
		dispatch(targetURL, req, res);
	}
	
	public void sanjianDel(HttpServletRequest req,HttpServletResponse res)
	{
		String sql="update t_sanjian set del='yes' where id=?";
		Object[] params={req.getParameter("id")};
		DB mydb=new DB();
		mydb.doPstm(sql, params);
		mydb.closed();
		
		req.setAttribute("message", "�����ɹ�");
		req.setAttribute("path", "sanjian?type=sanjianMana");
		
        String targetURL = "/common/success.jsp";
		dispatch(targetURL, req, res);
	}

	public void sanjianMana(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		List sanjianList=new ArrayList();
		String sql="select * from t_sanjian where del='no'";
		Object[] params={};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				Tsanjian sanjian=new Tsanjian();
				
				sanjian.setId(rs.getString("id"));
				sanjian.setCatelog_id(rs.getInt("catelog_id"));
				sanjian.setName(rs.getString("name"));
				sanjian.setFujian(rs.getString("fujian"));
				
				sanjian.setFujianYuanshiming(rs.getString("fujianYuanshiming"));
				sanjian.setJiage(rs.getInt("jiage"));
				sanjian.setPinpai(rs.getString("pinpai"));
				sanjian.setBeizhu(rs.getString("beizhu"));
				sanjian.setShijian(rs.getString("shijian"));
				sanjian.setDel(rs.getString("del"));
				
				sanjianList.add(sanjian);
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		
		req.setAttribute("sanjianList", sanjianList);
		req.getRequestDispatcher("admin/sanjian/sanjianMana.jsp").forward(req, res);
	}
	
	
	public void sanjianDetail(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		Tsanjian sanjian=new Tsanjian();
		String sql="select * from t_sanjian where del='no' and id=?";
		Object[] params={req.getParameter("id")};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				sanjian.setId(rs.getString("id"));
				sanjian.setCatelog_id(rs.getInt("catelog_id"));
				sanjian.setName(rs.getString("name"));
				sanjian.setFujian(rs.getString("fujian"));
				
				sanjian.setFujianYuanshiming(rs.getString("fujianYuanshiming"));
				sanjian.setJiage(rs.getInt("jiage"));
				sanjian.setPinpai(rs.getString("pinpai"));
				sanjian.setBeizhu(rs.getString("beizhu"));
				sanjian.setShijian(rs.getString("shijian"));
				sanjian.setDel(rs.getString("del"));
				
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		
		req.setAttribute("sanjian", sanjian);
		req.getRequestDispatcher("admin/sanjian/sanjianDetail.jsp").forward(req, res);
	}
	
	public void sanjianDetailQian(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		Tsanjian sanjian=new Tsanjian();
		String sql="select * from t_sanjian where del='no' and id=?";
		Object[] params={req.getParameter("id")};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				sanjian.setId(rs.getString("id"));
				sanjian.setCatelog_id(rs.getInt("catelog_id"));
				sanjian.setName(rs.getString("name"));
				sanjian.setFujian(rs.getString("fujian"));
				
				sanjian.setFujianYuanshiming(rs.getString("fujianYuanshiming"));
				sanjian.setJiage(rs.getInt("jiage"));
				sanjian.setPinpai(rs.getString("pinpai"));
				sanjian.setBeizhu(rs.getString("beizhu"));
				sanjian.setShijian(rs.getString("shijian"));
				sanjian.setDel(rs.getString("del"));
				
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		
		req.setAttribute("sanjian", sanjian);
		req.getRequestDispatcher("qiantai/sanjian/sanjianDetailQian.jsp").forward(req, res);
	}
	
	public void sanjianAll(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		List sanjianList=new ArrayList();
		String sql="select * from t_sanjian where del='no' and catelog_id=?";
		Object[] params={Integer.parseInt(req.getParameter("catelog_id"))};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				Tsanjian sanjian=new Tsanjian();
				
				sanjian.setId(rs.getString("id"));
				sanjian.setCatelog_id(rs.getInt("catelog_id"));
				sanjian.setName(rs.getString("name"));
				sanjian.setFujian(rs.getString("fujian"));
				
				sanjian.setFujianYuanshiming(rs.getString("fujianYuanshiming"));
				sanjian.setJiage(rs.getInt("jiage"));
				sanjian.setPinpai(rs.getString("pinpai"));
				sanjian.setBeizhu(rs.getString("beizhu"));
				sanjian.setShijian(rs.getString("shijian"));
				sanjian.setDel(rs.getString("del"));
				
				sanjianList.add(sanjian);
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		
		req.setAttribute("sanjianList", sanjianList);
		req.getRequestDispatcher("qiantai/sanjian/sanjianAll.jsp").forward(req, res);
	}
	
	public void sanjianSearch(HttpServletRequest req,HttpServletResponse res) throws ServletException, IOException
	{
		String name=req.getParameter("name");
		String pinpai=req.getParameter("pinpai");
		System.out.println(req.getParameter("jiageSta")+"TTTTTTTT");
		int jiageSta=Integer.parseInt(req.getParameter("jiageSta"));
		int jiageEnd=Integer.parseInt(req.getParameter("jiageEnd"));
		
		List sanjianList=new ArrayList();
		String sql="select * from t_sanjian where del='no' and name like '%"+name+"%'"+" and pinpai like '%"+pinpai+"%'"+" and jiage>? and jiage<?";
		Object[] params={jiageSta,jiageEnd};
		DB mydb=new DB();
		try
		{
			mydb.doPstm(sql, params);
			ResultSet rs=mydb.getRs();
			while(rs.next())
			{
				Tsanjian sanjian=new Tsanjian();
				
				sanjian.setId(rs.getString("id"));
				sanjian.setCatelog_id(rs.getInt("catelog_id"));
				sanjian.setName(rs.getString("name"));
				sanjian.setFujian(rs.getString("fujian"));
				
				sanjian.setFujianYuanshiming(rs.getString("fujianYuanshiming"));
				sanjian.setJiage(rs.getInt("jiage"));
				sanjian.setPinpai(rs.getString("pinpai"));
				sanjian.setBeizhu(rs.getString("beizhu"));
				sanjian.setShijian(rs.getString("shijian"));
				sanjian.setDel(rs.getString("del"));
				
				sanjianList.add(sanjian);
		    }
			rs.close();
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		mydb.closed();
		
		req.setAttribute("sanjianList", sanjianList);
		req.getRequestDispatcher("qiantai/sanjian/sanjianAll.jsp").forward(req, res);
	}
	
	public void dispatch(String targetURI,HttpServletRequest request,HttpServletResponse response) 
	{
		RequestDispatcher dispatch = getServletContext().getRequestDispatcher(targetURI);
		try 
		{
		    dispatch.forward(request, response);
		    return;
		} 
		catch (ServletException e) 
		{
                    e.printStackTrace();
		} 
		catch (IOException e) 
		{
			
		    e.printStackTrace();
		}
	}
	public void init(ServletConfig config) throws ServletException 
	{
		super.init(config);
	}
	
	public void destroy() 
	{
		
	}
}
