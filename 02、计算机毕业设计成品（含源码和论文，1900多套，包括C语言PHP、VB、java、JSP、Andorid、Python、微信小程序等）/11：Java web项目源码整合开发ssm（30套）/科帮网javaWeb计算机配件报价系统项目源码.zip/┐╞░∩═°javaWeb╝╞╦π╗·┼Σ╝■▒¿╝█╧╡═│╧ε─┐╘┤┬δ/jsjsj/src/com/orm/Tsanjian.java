package com.orm;

public class Tsanjian
{
	private String id;
	private int catelog_id;
	private String name;
	private String fujian;
	
	private String fujianYuanshiming;
	private int jiage;
	private String pinpai;
	private String beizhu;
	
	private String shijian;
	private String del;
	
	
	public String getBeizhu()
	{
		return beizhu;
	}
	public void setBeizhu(String beizhu)
	{
		this.beizhu = beizhu;
	}
	public int getCatelog_id()
	{
		return catelog_id;
	}
	public void setCatelog_id(int catelog_id)
	{
		this.catelog_id = catelog_id;
	}
	public String getDel()
	{
		return del;
	}
	public void setDel(String del)
	{
		this.del = del;
	}
	public String getFujian()
	{
		return fujian;
	}
	
	public int getJiage()
	{
		return jiage;
	}
	public void setJiage(int jiage)
	{
		this.jiage = jiage;
	}
	public String getPinpai()
	{
		return pinpai;
	}
	public void setPinpai(String pinpai)
	{
		this.pinpai = pinpai;
	}
	public void setFujian(String fujian)
	{
		this.fujian = fujian;
	}
	public String getFujianYuanshiming()
	{
		return fujianYuanshiming;
	}
	public void setFujianYuanshiming(String fujianYuanshiming)
	{
		this.fujianYuanshiming = fujianYuanshiming;
	}
	public String getId()
	{
		return id;
	}
	public void setId(String id)
	{
		this.id = id;
	}
	public String getName()
	{
		return name;
	}
	public void setName(String name)
	{
		this.name = name;
	}
	public String getShijian()
	{
		return shijian;
	}
	public void setShijian(String shijian)
	{
		this.shijian = shijian;
	}
	
	
	

}
