package com.yxq.model;

public class AdminShowType {
	private String stateType;
	private String payforType;
	private int infoType;

	public String getPayforType() {
		return payforType;
	}
	public void setPayforType(String payforType) {
		this.payforType = payforType;
	}
	public String getStateType() {
		return stateType;
	}
	public void setStateType(String stateType) {
		this.stateType = stateType;
	}
	public int getInfoType() {
		return infoType;
	}
	public void setInfoType(int infoType) {
		this.infoType = infoType;
	}	
}
