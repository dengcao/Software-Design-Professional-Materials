package com.mingri.info;

public class SpinfoBean
{
  private String spname;//��Ʒ����
  private String jc;//���
  private String cd;//����
  private String dw;//��λ
  private String gg;//���
  private String bz;//��װ
  private String ph;//����
  private String pzwh;//��׼�ĺ�
  private String gysname;//��Ӧ��ȫ��
  private String memo;//��ע
  public String getSpname() {
    return spname;
  }
  public void setSpname(String spname) {
    this.spname = spname;
  }
  public String getJc() {
    return jc;
  }
  public void setJc(String jc) {
    this.jc = jc;
  }
  public String getCd() {
    return cd;
  }
  public void setCd(String cd) {
    this.cd = cd;
  }
  public String getDw() {
    return dw;
  }
  public void setDw(String dw) {
    this.dw = dw;
  }
  public String getGg() {
    return gg;
  }
  public void setGg(String gg) {
    this.gg = gg;
  }
  public String getBz() {
    return bz;
  }
  public void setBz(String bz) {
    this.bz = bz;
  }
  public String getPh() {
    return ph;
  }
  public void setPh(String ph) {
    this.ph = ph;
  }
  public String getPzwh() {
    return pzwh;
  }
  public void setPzwh(String pzwh) {
    this.pzwh = pzwh;
  }
  public String getGysname() {
    return gysname;
  }
  public void setGysname(String gysname) {
    this.gysname = gysname;
  }
  public String getMemo() {
    return memo;
  }
  public void setMemo(String memo) {
    this.memo = memo;
  }

}
