package com.mingri.info;

public class GysinfoBean
{
  private String gysname;//��Ӧ��ȫ��
  private String jc;//���
  private String address;//��ַ
  private String postcode;//��������
  private String tel;//�绰
  private String fax;//����
  private String lxr;//��ϵ��
  private String lxrtel;//��ϵ�˵绰
  private String khyh;//��������
  private String eamil;//�����ʼ�
  public String getGysname() {
    return gysname;
  }
  public void setGysname(String gysname) {
    this.gysname = gysname;
  }
  public String getJc() {
    return jc;
  }
  public void setJc(String jc) {
    this.jc = jc;
  }
  public String getAddress() {
    return address;
  }
  public void setAddress(String address) {
    this.address = address;
  }
  public String getPostcode() {
    return postcode;
  }
  public void setPostcode(String postcode) {
    this.postcode = postcode;
  }
  public String getTel() {
    return tel;
  }
  public void setTel(String tel) {
    this.tel = tel;
  }
  public String getFax() {
    return fax;
  }
  public void setFax(String fax) {
    this.fax = fax;
  }
  public String getLxr() {
    return lxr;
  }
  public void setLxr(String lxr) {
    this.lxr = lxr;
  }
  public String getLxrtel() {
    return lxrtel;
  }
  public void setLxrtel(String lxrtel) {
    this.lxrtel = lxrtel;
  }
  public String getKhyh() {
    return khyh;
  }
  public void setKhyh(String khyh) {
    this.khyh = khyh;
  }
  public String getEamil() {
    return eamil;
  }
  public void setEamil(String eamil) {
    this.eamil = eamil;
  }

}
