package com.mingri.info;

public class KhinfoBean {
	private String khname;// �ͻ�ȫ��
	private String khjc;// �ͻ����
	private String address;// ��ַ
	private String postcode;// ��������
	private String tel;// �绰
	private String fax;// ����
	private String lxr;// ��ϵ��
	private String lxrtel;// ��ϵ�˵绰
	private String email;// ��������
	private String khyh;// ��������
	private String yhzh;// �����ʺ�

	public String getKhname() {
		return khname;
	}

	public void setKhname(String khname) {
		this.khname = khname;
	}

	public String getKhjc() {
		return khjc;
	}

	public void setKhjc(String khjc) {
		this.khjc = khjc;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getPostcode() {
		return postcode;
	}

	public void setPostcode(String postcode) {
		this.postcode = postcode;
	}

	public String getTel() {
		return tel;
	}

	public void setTel(String tel) {
		this.tel = tel;
	}

	public String getFax() {
		return fax;
	}

	public void setFax(String fax) {
		this.fax = fax;
	}

	public String getLxr() {
		return lxr;
	}

	public void setLxr(String lxr) {
		this.lxr = lxr;
	}

	public String getLxrtel() {
		return lxrtel;
	}

	public void setLxrtel(String lxrtel) {
		this.lxrtel = lxrtel;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getKhyh() {
		return khyh;
	}

	public void setKhyh(String khyh) {
		this.khyh = khyh;
	}

	public String getYhzh() {
		return yhzh;
	}

	public void setYhzh(String yhzh) {
		this.yhzh = yhzh;
	}
}
