package cn.itcast.commons;

public class MyXxx {
	private String xxx;

	public String getXxx() {
		return xxx;
	}

	public void setXxx(String xxx) {
		this.xxx = xxx;
	}

	@Override
	public String toString() {
		return "MyXxx [xxx=" + xxx + "]";
	}
	
	
}
