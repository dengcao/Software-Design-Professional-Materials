package com.hiernate.persistence;

import java.sql.Date;

public class Qiye {
   private int id;
   private Date riqi;
   private String title;
   private String content;
   private String name1;
public String getContent() {
	return content;
}
public void setContent(String content) {
	this.content = content;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName1() {
	return name1;
}
public void setName1(String name1) {
	this.name1 = name1;
}
public Date getRiqi() {
	return riqi;
}
public void setRiqi(Date riqi) {
	this.riqi = riqi;
}
public String getTitle() {
	return title;
}
public void setTitle(String title) {
	this.title = title;
}
}
