package com.hiernate.persistence;

public class Tongxun {
  private int id;
  private String name1;
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}
public String getName1() {
	return name1;
}
public void setName1(String name1) {
	this.name1 = name1;
}
}
