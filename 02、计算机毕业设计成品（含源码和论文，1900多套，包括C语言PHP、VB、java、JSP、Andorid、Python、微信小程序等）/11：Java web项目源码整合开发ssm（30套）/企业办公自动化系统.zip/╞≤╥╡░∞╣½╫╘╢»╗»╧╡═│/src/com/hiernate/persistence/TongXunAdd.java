package com.hiernate.persistence;

import java.sql.Date;

public class TongXunAdd {
  private int id;
  private String name11;
  private Date birthday;
  private String Sex;
  private String hy;
  private String department;
  private String zw;
  private String cf;
  private String cs;
  private String phone;
  private String phone1;
  private String email;
  private String postcode;
  private String OICQ;
  private String family;
  private String address;
  private String remark;
  private int name1;
public String getAddress() {
	return address;
}
public void setAddress(String address) {
	this.address = address;
}
public Date getBirthday() {
	return birthday;
}
public void setBirthday(Date birthday) {
	this.birthday = birthday;
}
public String getCf() {
	return cf;
}
public void setCf(String cf) {
	this.cf = cf;
}
public String getCs() {
	return cs;
}
public void setCs(String cs) {
	this.cs = cs;
}
public String getDepartment() {
	return department;
}
public void setDepartment(String department) {
	this.department = department;
}
public String getEmail() {
	return email;
}
public void setEmail(String email) {
	this.email = email;
}
public String getFamily() {
	return family;
}
public void setFamily(String family) {
	this.family = family;
}
public String getHy() {
	return hy;
}
public void setHy(String hy) {
	this.hy = hy;
}
public int getId() {
	return id;
}
public void setId(int id) {
	this.id = id;
}

public int getName1() {
	return name1;
}
public void setName1(int name1) {
	this.name1 = name1;
}
public String getName11() {
	return name11;
}
public void setName11(String name11) {
	this.name11 = name11;
}
public String getOICQ() {
	return OICQ;
}
public void setOICQ(String oicq) {
	OICQ = oicq;
}
public String getPhone() {
	return phone;
}
public void setPhone(String phone) {
	this.phone = phone;
}
public String getPhone1() {
	return phone1;
}
public void setPhone1(String phone1) {
	this.phone1 = phone1;
}
public String getPostcode() {
	return postcode;
}
public void setPostcode(String postcode) {
	this.postcode = postcode;
}
public String getRemark() {
	return remark;
}
public void setRemark(String remark) {
	this.remark = remark;
}
public String getSex() {
	return Sex;
}
public void setSex(String sex) {
	Sex = sex;
}
public String getZw() {
	return zw;
}
public void setZw(String zw) {
	this.zw = zw;
}
}
