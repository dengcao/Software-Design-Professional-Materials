package com.actionForm;

public class StorageForm {
    private int id;
    private int number;
    private int goodsid;
    public int getId() {
        return id;
    }

    public int getNumber() {
        return number;
    }

    public int getGoodsid() {
        return goodsid;
    }

    public void setId(int id) {
        this.id = id;
    }

    public void setNumber(int number) {
        this.number = number;
    }

    public void setGoodsid(int goodsid) {
        this.goodsid = goodsid;
    }
}
