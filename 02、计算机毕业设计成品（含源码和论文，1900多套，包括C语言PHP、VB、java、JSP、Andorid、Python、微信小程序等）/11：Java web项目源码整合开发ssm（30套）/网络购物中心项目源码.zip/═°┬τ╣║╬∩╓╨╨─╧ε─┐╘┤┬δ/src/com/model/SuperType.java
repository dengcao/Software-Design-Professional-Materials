package com.model;

public class SuperType {
  private String typename="";
  public void SuperType() {
  }
  public String gettypename(){
    return typename;
  }
  public void settypename(String typename){
    this.typename=typename;
  }
}
