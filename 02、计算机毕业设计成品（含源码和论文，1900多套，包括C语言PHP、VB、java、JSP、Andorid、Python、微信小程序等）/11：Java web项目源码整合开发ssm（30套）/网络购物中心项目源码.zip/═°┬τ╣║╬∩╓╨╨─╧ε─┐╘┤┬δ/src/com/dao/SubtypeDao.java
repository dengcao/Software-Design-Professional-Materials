package com.dao;

import com.model.SubType;

public interface SubtypeDao {
   public int insert(SubType st);
}
