package com.dao;

import com.model.Placard;

public interface PlacardDao {
  public int insert(Placard p);
}
