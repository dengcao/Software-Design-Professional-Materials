package com.dao;

import com.model.SuperType;

public interface SupertypeDao {
  public int insert(SuperType spt);
}
