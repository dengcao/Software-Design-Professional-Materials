package com.valueBean;

public class ArtReviewSingle {
	private int id;
	private int artRRootId;
	private String artRAuthor;
	private String artRContent;
	private String artRTime;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}	
	public int getArtRRootId() {
		return artRRootId;
	}
	public void setArtRRootId(int artRRootId) {
		this.artRRootId = artRRootId;
	}
	public String getArtRAuthor() {
		return artRAuthor;
	}
	public void setArtRAuthor(String artRAuthor) {
		this.artRAuthor = artRAuthor;
	}
	public String getArtRContent() {
		return artRContent;
	}
	public void setArtRContent(String artRContent) {
		this.artRContent = artRContent;
	}
	public String getArtRTime() {
		return artRTime;
	}
	public void setArtRTime(String artRTime) {
		this.artRTime = artRTime;
	}
}
