package com.valueBean;

public class MediaRevSingle {
	private int id;
	private int mediaRRootId;
	private String mediaRAuthor;
	private String mediaRContent;
	private String mediaRTime;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public int getMediaRRootId() {
		return mediaRRootId;
	}
	public void setMediaRRootId(int mediaRRootId) {
		this.mediaRRootId = mediaRRootId;
	}
	public String getMediaRAuthor() {
		return mediaRAuthor;
	}
	public void setMediaRAuthor(String mediaRAuthor) {
		this.mediaRAuthor = mediaRAuthor;
	}
	public String getMediaRContent() {
		return mediaRContent;
	}
	public void setMediaRContent(String mediaRContent) {
		this.mediaRContent = mediaRContent;
	}
	public String getMediaRTime() {
		return mediaRTime;
	}
	public void setMediaRTime(String mediaRTime) {
		this.mediaRTime = mediaRTime;
	}
}
