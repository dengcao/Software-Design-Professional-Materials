var articleTypes = {
	'Java' : // 名称
	{
		id : 'Java',// id
		style : 'cursor:hand;',// 样式,
		src : 'images/top_02.gif',// 图片
		activeSrc : 'images/top2_02.gif',// 被激活时的图片
		width : 98,
		height : 35
	},
	'Java web' : {
		id : 'Java web',
		style : 'cursor:hand;',
		src : 'images/top_03.gif',
		activeSrc : 'images/top2_03.gif',
		width : 98,
		height : 35
	},
	'C#' : {
		id : 'C#',
		style : 'cursor:hand;',
		src : 'images/top_04.gif',
		activeSrc : 'images/top2_04.gif',
		width : 65,
		height : 35
	},
	'ASP.NET' : {
		id : 'ASP.NET',
		style : 'cursor:hand;',
		src : 'images/top_05.gif',
		activeSrc : 'images/top2_05.gif',
		width : 98,
		height : 35
	},
	'Visual Basic' : {
		id : 'Visual Basic',
		style : 'cursor:hand;',
		src : 'images/top_06.gif',
		activeSrc : 'images/top2_06.gif',
		width : 113,
		height : 35
	},
	'Visual C++' : {
		id : 'Visual C++',
		style : 'cursor:hand;',
		src : 'images/top_07.gif',
		activeSrc : 'images/top2_07.gif',
		width : 113,
		height : 35
	},
	'PHP' : {
		id : 'PHP',
		style : 'cursor:hand;',
		src : 'images/top_08.gif',
		activeSrc : 'images/top2_08.gif',
		width : 65,
		height : 35
	},
	'ASP' : {
		id : 'ASP',
		style : 'cursor:hand;',
		src : 'images/top_09.gif',
		activeSrc : 'images/top2_09.gif',
		width : 65,
		height : 35
	}
};