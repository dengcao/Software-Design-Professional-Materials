package com.hrl.action;

public class ActionConstant {
	public static String CUURUSER_SESSION_FLAG = "currUser";
	public static String FIRSTRESULT = "0";
	public static String MAXRESULTS = "20";
	public static String UNKNOW_USER_NAME = "未知用户"; // 未知用户
	public static String UNKNOW_USER_ID = "0"; // 未知用户主键id
}
