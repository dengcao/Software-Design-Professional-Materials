package com.hrl.dao;

import com.hrl.model.Reply;
import com.hrl.model.User;

public interface IReplyDao {
	public void addReply(Reply reply);

}
