package com.model;

/**
 * <p>Title: </p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2004</p>
 * <p>Company: MR</p>
 * @author BWM
 * @version 1.0
 */

public class Soft {
    private int sfid;
    private String name="��";
    private String edition;
    private float price;
    private String uptime;
    private String uid;
    private String iid;
    private int sid;
    private String environment;
    private int filesize;
    private int commend;
    private int loadnum;
    private int regular;
    private String introduce;
    private String path;
    private String resume;
    public Soft() {
    }
    public int getSfid() {
        return sfid;
    }
    public void setSfid(int sfid) {
        this.sfid = sfid;
    }
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    public String getEdition() {
        return edition;
    }
    public void setEdition(String edition) {
        this.edition = edition;
    }
    public float getPrice() {
        return price;
    }
    public void setPrice(float price) {
        this.price = price;
    }
    public String getUptime() {
        return uptime;
    }
    public void setUptime(String uptime) {
        this.uptime = uptime;
    }
    public String getUid() {
        return uid;
    }
    public void setUid(String uid) {
        this.uid = uid;
    }
    public String getIid() {
        return iid;
    }
    public void setIid(String iid) {
        this.iid = iid;
    }
    public int getSid() {
        return sid;
    }
    public void setSid(int sid) {
        this.sid = sid;
    }
    public String getEnvironment() {
        return environment;
    }
    public void setEnvironment(String environment) {
        this.environment = environment;
    }
    public int getFilesize() {
        return filesize;
    }
    public void setFilesize(int filesize) {
        this.filesize = filesize;
    }
    public int getCommend() {
        return commend;
    }
    public void setCommend(int commend) {
        this.commend = commend;
    }
    public int getLoadnum() {
        return loadnum;
    }
    public void setLoadnum(int loadnum) {
        this.loadnum = loadnum;
    }
    public int getRegular() {
        return regular;
    }
    public void setRegular(int regular) {
        this.regular = regular;
    }
    public String getIntroduce() {
        return introduce;
    }
    public void setIntroduce(String introduce) {
        this.introduce = introduce;
    }
    public String getPath() {
        return path;
    }
    public void setPath(String path) {
        this.path = path;
    }
    public String getResume() {
        return resume;
    }
    public void setResume(String resume) {
        this.resume = resume;
    }

}