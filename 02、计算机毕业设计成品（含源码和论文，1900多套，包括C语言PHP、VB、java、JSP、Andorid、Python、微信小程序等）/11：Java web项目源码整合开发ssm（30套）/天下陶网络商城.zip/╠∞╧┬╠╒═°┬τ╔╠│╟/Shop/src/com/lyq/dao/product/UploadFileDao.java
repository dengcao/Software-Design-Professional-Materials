package com.lyq.dao.product;

import com.lyq.dao.BaseDao;
import com.lyq.model.product.UploadFile;

public interface UploadFileDao extends BaseDao<UploadFile> {

}
