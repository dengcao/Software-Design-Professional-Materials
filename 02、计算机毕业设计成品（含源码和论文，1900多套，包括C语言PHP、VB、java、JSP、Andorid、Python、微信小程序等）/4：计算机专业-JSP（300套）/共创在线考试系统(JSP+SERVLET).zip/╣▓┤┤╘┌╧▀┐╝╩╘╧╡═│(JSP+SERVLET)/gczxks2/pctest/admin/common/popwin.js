function openpop(page) { //
  window.open(page,'popwindow','toolbar=no,menubar=no,location=no,scrollbars=yes,resizable=yes,left=25,top=25,width=520,height=450');
}


