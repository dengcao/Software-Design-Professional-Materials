generateGNBLayer('senior', subMenus_senior);
generateGNBLayer('junior', subMenus_junior);
generateGNBLayer('exercises', subMenus_exercises);
generateGNBLayer('community', subMenus_community);
generateGNBLayer('myjh', subMenus_myjh);
generateGNBLayer('help', subMenus_help);