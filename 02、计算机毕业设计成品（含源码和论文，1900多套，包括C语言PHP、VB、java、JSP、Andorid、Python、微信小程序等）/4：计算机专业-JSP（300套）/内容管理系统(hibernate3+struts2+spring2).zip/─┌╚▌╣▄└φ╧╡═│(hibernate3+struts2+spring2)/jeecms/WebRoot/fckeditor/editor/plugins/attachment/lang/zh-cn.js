﻿FCKLang.AttachmentInfoTab       = '附件';
FCKLang.AttachmentUpload        = '上传';
FCKLang.AttachmentBtn			= '插入/编辑附件' ;
FCKLang.AttachmentDlgTitle		= '附件属性' ;
FCKLang.AttachmentDlgName		= '附件名称' ;
FCKLang.AttachmentErrNoName	= '请输入附件名称' ;
