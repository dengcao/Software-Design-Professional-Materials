﻿FCKLang.AttachmentBtn			= 'Insert/Edit Attachment' ;
FCKLang.AttachmentDlgTitle		= 'Attachment Properties' ;
FCKLang.AttachmentDlgName		= 'Attachment Name' ;
FCKLang.AttachmentErrNoName	= 'Please type the attachment name' ;
