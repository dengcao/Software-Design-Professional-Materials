package com.jeecms.auxiliary.dao;

import com.jeecms.auxiliary.entity.AuxiConfig;
import com.jeecms.core.JeeCoreDao;

public interface AuxiConfigDao extends JeeCoreDao<AuxiConfig> {

}