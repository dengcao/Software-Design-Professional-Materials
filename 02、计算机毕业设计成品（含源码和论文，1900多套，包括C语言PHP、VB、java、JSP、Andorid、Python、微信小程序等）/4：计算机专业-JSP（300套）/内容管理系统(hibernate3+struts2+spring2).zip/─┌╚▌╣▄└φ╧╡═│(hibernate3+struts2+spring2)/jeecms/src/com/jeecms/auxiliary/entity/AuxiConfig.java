package com.jeecms.auxiliary.entity;

import com.jeecms.auxiliary.entity.base.BaseAuxiConfig;



public class AuxiConfig extends BaseAuxiConfig {
	private static final long serialVersionUID = 1L;

/*[CONSTRUCTOR MARKER BEGIN]*/
	public AuxiConfig () {
		super();
	}

	/**
	 * Constructor for primary key
	 */
	public AuxiConfig (java.lang.Long id) {
		super(id);
	}

/*[CONSTRUCTOR MARKER END]*/


}