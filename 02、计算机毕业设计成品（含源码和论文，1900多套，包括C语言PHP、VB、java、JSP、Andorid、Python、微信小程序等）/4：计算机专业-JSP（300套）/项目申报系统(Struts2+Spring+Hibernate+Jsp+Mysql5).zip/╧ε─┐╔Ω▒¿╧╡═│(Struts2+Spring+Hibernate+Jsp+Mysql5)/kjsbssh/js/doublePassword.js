function doublePassword(form){
	if(form.newpassword.value==""){
		alert("ysadfgdg");
		return false;

	}
	return true;
}