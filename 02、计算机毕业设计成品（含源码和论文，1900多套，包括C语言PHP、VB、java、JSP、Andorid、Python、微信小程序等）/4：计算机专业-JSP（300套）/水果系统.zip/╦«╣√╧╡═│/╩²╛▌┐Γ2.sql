/*
Navicat MySQL Data Transfer

Source Server         : 127.0.0.1
Source Server Version : 50168
Source Host           : 127.0.0.1:3306
Source Database       : hainengfruit

Target Server Type    : MYSQL
Target Server Version : 50168
File Encoding         : 65001

Date: 2016-12-19 19:44:23
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `t_admin`
-- ----------------------------
DROP TABLE IF EXISTS `t_admin`;
CREATE TABLE `t_admin` (
  `userId` int(11) NOT NULL,
  `userName` varchar(55) DEFAULT NULL,
  `userPw` varchar(55) DEFAULT NULL,
  PRIMARY KEY (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_admin
-- ----------------------------
INSERT INTO `t_admin` VALUES ('2', 'a', '1');

-- ----------------------------
-- Table structure for `t_content`
-- ----------------------------
DROP TABLE IF EXISTS `t_content`;
CREATE TABLE `t_content` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `content` varchar(2000) DEFAULT NULL,
  `goodsId` varchar(10) DEFAULT NULL,
  `addTime` varchar(20) DEFAULT NULL,
  `huiyuanId` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_content
-- ----------------------------
INSERT INTO `t_content` VALUES ('2', '不错的', '3', '2016-12-19 04:16:08', 'huxiao');
INSERT INTO `t_content` VALUES ('3', '不错的', '3', '2016-12-19 04:18:06', 'huxiao');
INSERT INTO `t_content` VALUES ('4', '不错的', '3', '2016-12-19 04:22:50', 'huxiao');
INSERT INTO `t_content` VALUES ('5', '不错的', '3', '2016-12-19 04:23:37', 'huxiao');
INSERT INTO `t_content` VALUES ('6', '不错的', '3', '2016-12-19 04:25:30', 'huxiao');
INSERT INTO `t_content` VALUES ('7', '不错的', '7', '2016-12-19 05:04:15', 'huxiao');
INSERT INTO `t_content` VALUES ('8', '不错的', '2', '2016-12-19 05:11:58', 'huxiao');
INSERT INTO `t_content` VALUES ('9', '不错的', '2', '2016-12-19 05:30:40', 'huxiao');
INSERT INTO `t_content` VALUES ('10', '不错的', '2', '2016-12-19 06:59:23', 'huxiao');
INSERT INTO `t_content` VALUES ('12', '不错的', '7', '2016-12-19 04:23:26', 'huxiao');
INSERT INTO `t_content` VALUES ('13', '不错的商品', '7', '2016-12-19 10:35:56', 'huxiao');

-- ----------------------------
-- Table structure for `t_goods`
-- ----------------------------
DROP TABLE IF EXISTS `t_goods`;
CREATE TABLE `t_goods` (
  `id` int(11) NOT NULL,
  `leibieId` int(11) DEFAULT NULL,
  `mingcheng` varchar(50) DEFAULT NULL,
  `jieshao` varchar(5000) DEFAULT NULL,
  `fujian` varchar(50) DEFAULT NULL,
  `jiage` int(11) DEFAULT NULL,
  `tejia` int(11) DEFAULT NULL,
  `shifoutejia` varchar(50) DEFAULT NULL,
  `del` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_goods
-- ----------------------------
INSERT INTO `t_goods` VALUES ('2', '1', '蜜橘', '【壮乡河谷】西林沙糖桔 蜜桔小橘子3斤新鲜特价水果蜜橘新鲜柑橘', '/upload/1386298639222.jpg', '12', '8', 'no', 'no');
INSERT INTO `t_goods` VALUES ('3', '1', '砂糖橘', '砂糖桔 广西新鲜热带水果 正宗砂糖橘 现摘新鲜砂糖橙橘子包邮', '/upload/1386298725928.jpg', '29', '12', 'no', 'no');
INSERT INTO `t_goods` VALUES ('4', '1', '甜橙', '湖南麻阳冰糖橙 赛永兴冰糖橙甜橙子农家自产超甜10斤包邮', '/upload/1386298769809.jpg', '32', '22', 'no', 'no');
INSERT INTO `t_goods` VALUES ('5', '2', '桃', '【喜人喜】周至猕猴桃新鲜水果绿心奇异果5斤包邮陕西弥猴桃大果', '/upload/1386298842449.jpg', '12', '12', 'no', 'no');
INSERT INTO `t_goods` VALUES ('6', '2', '大枣', '【宝珠山 红枣夹核桃仁葡萄干 500gX2袋】 大枣加核桃枣 抱抱果', '/upload/1386298897183.jpg', '23', '23', 'no', 'no');
INSERT INTO `t_goods` VALUES ('7', '3', '苹果', '红富士苹果陕西乾县农家自产新鲜脆甜中果10斤非烟台洛川水果包邮', '/upload/1386299227602.jpg', '12', '11', 'no', 'no');
INSERT INTO `t_goods` VALUES ('8', '3', '梨', '戈绿原高端水果沙漠密梨嫩甜香酥新疆丑八怪梨一级5斤', '/upload/1386299289047.jpg', '10', '3', 'no', 'no');
INSERT INTO `t_goods` VALUES ('9', '4', '草莓', '4盒草莓新鲜水果奶油牛奶巧克力草梅四川双流冬草莓种子顺丰包邮', '/upload/1386299366007.jpg', '23', '12', 'no', 'no');
INSERT INTO `t_goods` VALUES ('10', '1', '葡萄柚', '树果悦浓 台湾进口红心西柚 应季水果新鲜水果葡萄柚子6个装包邮', '/upload/1426928453562.jpg', '23', '15', 'no', 'no');
INSERT INTO `t_goods` VALUES ('11', '1', '柚子', '正宗玉环文旦特产楚门文旦柚子22斤鲜嫩多汁水果蜜柚全国多省包邮', '/upload/1426928938234.jpg', '32', '32', 'no', 'yes');
INSERT INTO `t_goods` VALUES ('12', '4', '水晶葡萄', '斤包邮云南新鲜水果水晶葡萄生态农场现摘水果云贵高原品质', '/upload/1426928938200.jpg', '11', '8', 'no', 'yes');

-- ----------------------------
-- Table structure for `t_huiyuan`
-- ----------------------------
DROP TABLE IF EXISTS `t_huiyuan`;
CREATE TABLE `t_huiyuan` (
  `id` int(11) NOT NULL DEFAULT '0',
  `loginname` varchar(50) DEFAULT NULL,
  `loginpw` varchar(50) DEFAULT NULL,
  `xingming` varchar(50) DEFAULT NULL,
  `xingbie` varchar(50) DEFAULT NULL,
  `nianling` varchar(50) DEFAULT NULL,
  `address` varchar(50) DEFAULT NULL,
  `dianhua` varchar(255) DEFAULT NULL,
  `yue` int(11) DEFAULT NULL,
  `del` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_huiyuan
-- ----------------------------
INSERT INTO `t_huiyuan` VALUES ('2', 'huxiao', '1', '胡晓', '男', '33', '北京路', '13666666666', '0', 'no');
INSERT INTO `t_huiyuan` VALUES ('5', 'dengfang', '1', '邓芳', '女', '20', '上海路', '13777777777', '0', 'no');
INSERT INTO `t_huiyuan` VALUES ('6', 'zs', 'zs', 'zs', '?', '25', '22222', '222222', '0', 'no');

-- ----------------------------
-- Table structure for `t_leibie`
-- ----------------------------
DROP TABLE IF EXISTS `t_leibie`;
CREATE TABLE `t_leibie` (
  `id` int(11) NOT NULL DEFAULT '0',
  `mingcheng` varchar(255) DEFAULT NULL,
  `del` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_leibie
-- ----------------------------
INSERT INTO `t_leibie` VALUES ('1', '柑橘类', 'no');
INSERT INTO `t_leibie` VALUES ('2', '核果类', 'no');
INSERT INTO `t_leibie` VALUES ('3', '仁果类', 'no');
INSERT INTO `t_leibie` VALUES ('4', '浆果类', 'no');

-- ----------------------------
-- Table structure for `t_mingxi`
-- ----------------------------
DROP TABLE IF EXISTS `t_mingxi`;
CREATE TABLE `t_mingxi` (
  `id` int(11) NOT NULL,
  `orderId` int(11) DEFAULT NULL,
  `goodsId` int(11) DEFAULT NULL,
  `goodsShuliang` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_mingxi
-- ----------------------------
INSERT INTO `t_mingxi` VALUES ('1', '1', '5', '1');
INSERT INTO `t_mingxi` VALUES ('2', '2', '3', '1');
INSERT INTO `t_mingxi` VALUES ('3', '3', '7', '1');
INSERT INTO `t_mingxi` VALUES ('4', '4', '2', '1');
INSERT INTO `t_mingxi` VALUES ('5', '5', '2', '3');
INSERT INTO `t_mingxi` VALUES ('6', '6', '7', '1');
INSERT INTO `t_mingxi` VALUES ('7', '6', '9', '1');

-- ----------------------------
-- Table structure for `t_order`
-- ----------------------------
DROP TABLE IF EXISTS `t_order`;
CREATE TABLE `t_order` (
  `id` int(11) NOT NULL,
  `bianhao` varchar(50) DEFAULT NULL,
  `xiadanshi` varchar(50) DEFAULT NULL,
  `zt` varchar(50) DEFAULT NULL,
  `songhuodizhi` varchar(50) DEFAULT NULL,
  `fukuanfangshi` varchar(255) DEFAULT NULL,
  `zongjia` int(11) DEFAULT NULL,
  `huiyuanId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of t_order
-- ----------------------------
INSERT INTO `t_order` VALUES ('3', '20150321050311', '2016-12-19 05:03:11', '已受理', '测试地址******', '货到付款', '100', '2');
INSERT INTO `t_order` VALUES ('4', '20150321051115', '2016-12-19 05:11:15', '已受理', '测试地址北京', '货到付款', '100', '2');
INSERT INTO `t_order` VALUES ('5', '20160404065823', '2016-12-19 06:58:23', '已受理', 'ceshi232333', '货到付款', '300', '2');
INSERT INTO `t_order` VALUES ('6', '20160404070045', '2016-12-19 07:00:45', '待受理', 'ces ces', '货到付款', '200', '2');

-- ----------------------------
-- Table structure for `t_sweetness`
-- ----------------------------
DROP TABLE IF EXISTS `t_sweetness`;
CREATE TABLE `t_sweetness` (
  `id` int(36) NOT NULL AUTO_INCREMENT,
  `name` varchar(36) COLLATE utf8_bin DEFAULT NULL,
  `degree` int(36) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

-- ----------------------------
-- Records of t_sweetness
-- ----------------------------
INSERT INTO `t_sweetness` VALUES ('1', '苹果', '19');
