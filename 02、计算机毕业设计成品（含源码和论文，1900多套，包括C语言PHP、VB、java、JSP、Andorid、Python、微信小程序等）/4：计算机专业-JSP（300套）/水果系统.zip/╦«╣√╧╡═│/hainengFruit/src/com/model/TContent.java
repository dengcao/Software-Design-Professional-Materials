package com.model;

/**
 * TOrder entity. @author MyEclipse Persistence Tools
 */

public class TContent implements java.io.Serializable
{


	private Integer id;
	private String content;
	private String goodsId;
	private String addTime;
	
	private String huiyuanId;

	public TContent() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getGoodsId() {
		return goodsId;
	}

	public void setGoodsId(String goodsId) {
		this.goodsId = goodsId;
	}

	public String getAddTime() {
		return addTime;
	}

	public void setAddTime(String addTime) {
		this.addTime = addTime;
	}

	public String getHuiyuanId() {
		return huiyuanId;
	}

	public void setHuiyuanId(String huiyuanId) {
		this.huiyuanId = huiyuanId;
	}

	public TContent(String content, String goodsId, String addTime,
			String huiyuanId) {
		super();
		this.content = content;
		this.goodsId = goodsId;
		this.addTime = addTime;
		this.huiyuanId = huiyuanId;
	}
	 
}