package com.action;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.apache.struts2.ServletActionContext;

import com.dao.FunctionDAOImpl;
import com.dao.TGoodsDAO;
import com.dao.TMingxiDAO;
import com.model.TContent;
import com.model.TGoods;
import com.model.THuiyuan;
import com.opensymphony.xwork2.ActionSupport;
import com.util.Cart;

public class goodsAction extends ActionSupport
{
	private Integer id;
	private Integer leibieId;
	private String mingcheng;
	private String jieshao;
	
	private String fujian;
	private Integer jiage;
	private Integer tejia;
	private String shifoutejia;
	
	private String del;
	
	private TGoodsDAO goodsDAO;
	private List<TContent> contentList;
	private TMingxiDAO mingxiDAO;
	
	public String goodsAdd()
	{
		TGoods goods=new TGoods();
		
		//goods.setId(id);
		goods.setLeibieId(leibieId);
		goods.setMingcheng(mingcheng);
		goods.setJieshao(jieshao);
		
		goods.setFujian(fujian);
		goods.setJiage(jiage);
		goods.setTejia(jiage);
		goods.setShifoutejia("no");
		
		goods.setDel("no");
		
		goodsDAO.save(goods);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("msg", "��Ϣ���ӳɹ�");
		return "msg";
	}
	
	
	public String goodsMana()
	{
		String sql="from TGoods where del='no' order by leibieId";
		List goodsList=goodsDAO.getHibernateTemplate().find(sql);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("goodsList", goodsList);
		return ActionSupport.SUCCESS;
	}
	
	public String goodsDel()
	{
		TGoods goods=goodsDAO.findById(id);
		goods.setDel("yes");
		
		goodsDAO.attachDirty(goods);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("msg", "��Ϣɾ���ɹ�");
		return "msg";
	}
	
	public String goodsNew()
	{
		String sql="from TGoods where del='no' order by id desc";
		List goodsList=goodsDAO.getHibernateTemplate().find(sql);
		if(goodsList.size()>6)
		{
			goodsList=goodsList.subList(0, 6);
		}
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("goodsList", goodsList);
		
		
		
		
		
		
		List goodsListpaihang=new ArrayList();
		sql="select sum(goodsShuliang),goodsId from TMingxi group by goodsId order by sum(goodsShuliang) desc";
		List list=mingxiDAO.getHibernateTemplate().find(sql);
		for(int i=0;i<list.size();i++)
		{
			Object[] b=(Object[])list.get(i);
			int goodsId=Integer.parseInt(b[1].toString());
			
			TGoods goods=goodsDAO.findById(goodsId);
			goodsListpaihang.add(goods);
		}
		if(goodsList.size()>4)
		{
			goodsList=goodsList.subList(0, 4);
		}
		request.put("goodsListpaihang", goodsListpaihang);
		
		
		
		return ActionSupport.SUCCESS;
	}
	
	
	public String goodsDetailQian()
	{
		TGoods goods=goodsDAO.findById(id);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		
		contentList=FunctionDAOImpl.findContentList("pingjia",id);
		
		
		request.put("goods", goods);
		return ActionSupport.SUCCESS;
	}
	
	
	
	public String goodspingjia()
	{
		
		HttpServletRequest request=ServletActionContext.getRequest();
		HttpSession session=request.getSession();
		
		THuiyuan huiyuan=(THuiyuan)session.getAttribute("huiyuan");
		
		TContent content= new TContent();
		content.setGoodsId(request.getParameter("id"));
		content.setAddTime(new SimpleDateFormat("yyyy-MM-dd hh:mm:ss").format(new Date()));
		content.setHuiyuanId(huiyuan.getLoginname());
		content.setContent(request.getParameter("content"));
		FunctionDAOImpl.insertUserPingjia(content);
		Map request1=(Map)ServletActionContext.getContext().get("request");
		request1.put("msg", "��Ʒ�������");
		return "msg";
	}
	
	
	
	
	public String goodsByLeibie()
	{
		String sql="from TGoods where del='no' and leibieId=?";
		Object[] con={leibieId};
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		List goodsList=goodsDAO.getHibernateTemplate().find(sql,con);
		request.put("goodsList", goodsList);
		
		System.out.println(goodsList.size()+"&&");
		
		return ActionSupport.SUCCESS;
	}


	public Integer getLeibieId()
	{
		return leibieId;
	}


	public void setLeibieId(Integer leibieId)
	{
		this.leibieId = leibieId;
	}


	public Integer getId()
	{
		return id;
	}


	public void setId(Integer id)
	{
		this.id = id;
	}


	public String getMingcheng()
	{
		return mingcheng;
	}


	public void setMingcheng(String mingcheng)
	{
		this.mingcheng = mingcheng;
	}


	public String getJieshao()
	{
		return jieshao;
	}


	public void setJieshao(String jieshao)
	{
		this.jieshao = jieshao;
	}


	public String getFujian()
	{
		return fujian;
	}


	public void setFujian(String fujian)
	{
		this.fujian = fujian;
	}


	public Integer getJiage()
	{
		return jiage;
	}


	public void setJiage(Integer jiage)
	{
		this.jiage = jiage;
	}


	public Integer getTejia()
	{
		return tejia;
	}


	public void setTejia(Integer tejia)
	{
		this.tejia = tejia;
	}


	public String getShifoutejia()
	{
		return shifoutejia;
	}


	public void setShifoutejia(String shifoutejia)
	{
		this.shifoutejia = shifoutejia;
	}


	public String getDel()
	{
		return del;
	}


	public void setDel(String del)
	{
		this.del = del;
	}


	public TGoodsDAO getGoodsDAO()
	{
		return goodsDAO;
	}


	public void setGoodsDAO(TGoodsDAO goodsDAO)
	{
		this.goodsDAO = goodsDAO;
	}


	public List<TContent> getContentList() {
		return contentList;
	}


	public void setContentList(List<TContent> contentList) {
		this.contentList = contentList;
	}


	public TMingxiDAO getMingxiDAO() {
		return mingxiDAO;
	}


	public void setMingxiDAO(TMingxiDAO mingxiDAO) {
		this.mingxiDAO = mingxiDAO;
	}
	
}
