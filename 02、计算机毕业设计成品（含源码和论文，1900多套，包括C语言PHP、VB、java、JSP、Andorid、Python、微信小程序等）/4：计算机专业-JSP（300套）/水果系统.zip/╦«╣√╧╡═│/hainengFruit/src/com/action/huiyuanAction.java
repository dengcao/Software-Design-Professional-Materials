package com.action;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.apache.struts2.ServletActionContext;

import com.dao.SweetnessDAO;
import com.dao.THuiyuanDAO;
import com.model.Sweetness;
import com.model.THuiyuan;
import com.opensymphony.xwork2.ActionSupport;
import com.util.JdbcUtils;

public class huiyuanAction extends ActionSupport
{
	private Integer id;
	private String loginname;
	private String loginpw;
	private String xingming;
	
	private String xingbie;
	private String nianling;
	private String address;
	private String dianhua;
	
	private Integer yue;
	private String del;
	
	private String message;
	private String path;
	
	private THuiyuanDAO huiyuanDAO;
	public SweetnessDAO sweetnessDAO;
	
	
	public String huiyuanReg()
	{
		HttpServletRequest request=ServletActionContext.getRequest();
		
		String sql="from THuiyuan where loginname=?";
		Object[] c={loginname.trim()};
		List huiyuanList=huiyuanDAO.getHibernateTemplate().find(sql,c);
		if(huiyuanList.size()>0)
		{
			this.setMessage("�˺��ѱ�ռ�ã�������ע��");
			this.setPath("site/userreg/userreg.jsp");
		}
		else
		{
			THuiyuan huiyuan=new THuiyuan();
			
			//huiyuan.setId(id);
			huiyuan.setLoginname(loginname);
			huiyuan.setLoginpw(loginname);
			huiyuan.setXingming(xingming);
			
			huiyuan.setXingbie(xingbie);
			huiyuan.setNianling(nianling);
			huiyuan.setAddress(address);
			huiyuan.setDianhua(dianhua);
			
			huiyuan.setYue(0);
			huiyuan.setDel("no");
			
			huiyuanDAO.save(huiyuan);
			
			this.setMessage("ע��ɹ������¼");
			this.setPath("site/userreg/userreg.jsp");
		}
		
		return "succeed";
	}
		
	

	public String huiyuanMana()
	{
		String sql="from THuiyuan where del='no'";
		List huiyuanList=huiyuanDAO.getHibernateTemplate().find(sql);
		
		Map request=(Map)ServletActionContext.getContext().get("request");
		request.put("huiyuanList", huiyuanList);
		return ActionSupport.SUCCESS;
	}
	
	public String huiyuanDel()
	{
		THuiyuan huiyuan=huiyuanDAO.findById(id);
		huiyuan.setDel("yes");
		huiyuanDAO.attachDirty(huiyuan);
		
		this.setMessage("ɾ���ɹ�");
		this.setPath("huiyuanMana.action");
		return "succeed";
	}
	
	
	public String sweetnessReg()
	{
		HttpServletRequest request=ServletActionContext.getRequest();
		String name=request.getParameter("name");
		String degree=request.getParameter("degree");
		
		String sql = "select * from t_sweetness where name=?";
		Connection conn = JdbcUtils.connSQL();
		Sweetness s = null;
		try {
			PreparedStatement pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, name);
			ResultSet rs = pstmt.executeQuery();
			while(rs.next()){
				s = new Sweetness();
				s.setName(rs.getString("name"));
				s.setDegree(rs.getInt("degree"));
				s.setId(rs.getInt("id"));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		
		if(s!=null){
			if(Integer.valueOf(degree)>s.getDegree()){
				request.getSession().setAttribute("msg", "��");
			}else{
				request.getSession().setAttribute("msg", "����");
			}
		}else{
			request.getSession().setAttribute("msg", "ˮ�������ڣ�");
		}
		request.getSession().setAttribute("name",name);
		request.getSession().setAttribute("degree", degree);
		this.setPath("sweetness/index.jsp");
		return "succeed";
	}
	
	
	

	public Integer getId()
	{
		return id;
	}

	public void setId(Integer id)
	{
		this.id = id;
	}

	public String getLoginname()
	{
		return loginname;
	}

	public void setLoginname(String loginname)
	{
		this.loginname = loginname;
	}

	public String getLoginpw()
	{
		return loginpw;
	}

	public void setLoginpw(String loginpw)
	{
		this.loginpw = loginpw;
	}

	public String getXingming()
	{
		return xingming;
	}

	public void setXingming(String xingming)
	{
		this.xingming = xingming;
	}

	public THuiyuanDAO getHuiyuanDAO()
	{
		return huiyuanDAO;
	}

	public void setHuiyuanDAO(THuiyuanDAO huiyuanDAO)
	{
		this.huiyuanDAO = huiyuanDAO;
	}

	public String getXingbie()
	{
		return xingbie;
	}

	public void setXingbie(String xingbie)
	{
		this.xingbie = xingbie;
	}

	public String getNianling()
	{
		return nianling;
	}

	public void setNianling(String nianling)
	{
		this.nianling = nianling;
	}

	public String getAddress()
	{
		return address;
	}

	public void setAddress(String address)
	{
		this.address = address;
	}

	public String getDianhua()
	{
		return dianhua;
	}

	public void setDianhua(String dianhua)
	{
		this.dianhua = dianhua;
	}

	public Integer getYue()
	{
		return yue;
	}

	public void setYue(Integer yue)
	{
		this.yue = yue;
	}

	public String getDel()
	{
		return del;
	}

	public void setDel(String del)
	{
		this.del = del;
	}

	public String getMessage()
	{
		return message;
	}

	public void setMessage(String message)
	{
		this.message = message;
	}

	public String getPath()
	{
		return path;
	}

	public void setPath(String path)
	{
		this.path = path;
	}



	public SweetnessDAO getSweetnessDAO() {
		return sweetnessDAO;
	}



	public void setSweetnessDAO(SweetnessDAO sweetnessDAO) {
		this.sweetnessDAO = sweetnessDAO;
	}

}
