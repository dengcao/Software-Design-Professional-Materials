package com.util;
import java.sql.Connection;  
import java.sql.DriverManager;  
import java.sql.PreparedStatement;  
import java.sql.ResultSet;  
import java.sql.SQLException;  
  
public class JdbcUtils {  
	public static Connection conn = null;  
	public static PreparedStatement statement = null;  
  
     public static Connection connSQL() {  
        String url = "jdbc:mysql://localhost:3306/hainengfruit?characterEncoding=UTF-8";  
        String username = "root";  
        String password = "root"; // 加载驱动程序以连接数据库   
        try {   
            Class.forName("com.mysql.jdbc.Driver" );   
            conn = DriverManager.getConnection( url,username, password );   
            }  
        //捕获加载驱动程序异常  
         catch ( ClassNotFoundException cnfex ) {  
             System.err.println(  
             "装载 JDBC/ODBC 驱动程序失败�?" );  
             cnfex.printStackTrace();   
         }   
         //捕获连接数据库异�?  
         catch ( SQLException sqlex ) {  
             System.err.println( "无法连接数据�?" );  
             sqlex.printStackTrace();   
         } 
         return conn;
    }  
  
     public static void deconnSQL(Connection conn) {  
        try {  
            if (conn != null)  
                conn.close();  
        } catch (Exception e) {  
            System.out.println("关闭数据库问�?");  
            e.printStackTrace();  
        }  
        try {  
            if (statement != null)  
            	statement.close();  
        } catch (Exception e) {  
            System.out.println("关闭数据库问�?");  
            e.printStackTrace();  
        }  
    }  
  
     public static ResultSet selectSQL(Connection conn,String sql) {  
        ResultSet rs = null;  
        try {  
            statement = conn.prepareStatement(sql);  
            rs = statement.executeQuery(sql);  
        } catch (SQLException e) {  
            e.printStackTrace();  
        }  
        return rs;  
    }  
  
     public static  boolean insertSQL(Connection conn,String sql) {  
        try { 
        	conn.setAutoCommit(false);
            statement = conn.prepareStatement(sql);  
            statement.executeUpdate();  
            statement.close();
			conn.commit();
            return true;  
        } catch (Exception e) {  
            System.out.println("插入数据库时出错");  
            try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
            e.printStackTrace();  
        }
        return false;  
    }  
     public static  boolean deleteSQL(Connection conn,String sql) {  
        try { 
        	conn.setAutoCommit(false);
            statement = conn.prepareStatement(sql);  
            statement.executeUpdate();  
            statement.close();
			conn.commit();
            return true;  
        } catch (Exception e) {  
            System.out.println("删除数据库时出错");
            try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
            e.printStackTrace();  
        }
        return false;  
    }  
     public static  boolean updateSQL(Connection conn,String sql) {  
        try {  
        	conn.setAutoCommit(false);
            statement = conn.prepareStatement(sql);  
            statement.executeUpdate();  
            statement.close();
			conn.commit();
            return true;  
        }  catch (Exception e) { 
        	try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
            System.out.println("更新时出�?");  
            e.printStackTrace();  
        }  
        return false;  
    }  
    
  
    public static void main(String args[]) {  
  
        JdbcUtils  h = new JdbcUtils();  
        h.connSQL();  
        String s = "select * from eshop_function";  
        ResultSet rs= selectSQL(conn,s);
        try {
			while(rs.next())
			{
			    System.out.println(rs.getObject(1)+""+rs.getObject(2));
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
        h.deconnSQL(conn);  
    }  
}  