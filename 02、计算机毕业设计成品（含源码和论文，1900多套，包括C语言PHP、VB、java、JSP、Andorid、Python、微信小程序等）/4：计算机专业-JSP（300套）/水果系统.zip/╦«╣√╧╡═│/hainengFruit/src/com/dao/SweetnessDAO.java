package com.dao;

import java.util.List;

import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.model.Sweetness;

/**
 * Data access object (DAO) for domain model class TAdmin.
 * 
 * @see com.model.TAdmin
 * @author MyEclipse Persistence Tools
 */

public class SweetnessDAO extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(SweetnessDAO.class);


	protected void initDao() {
		// do nothing
	}

	

	public Sweetness findBySweetness(String name) {
		try
		{
			String queryString = "from Sweetness as model where model.name= ?";
			List li=getHibernateTemplate().find(queryString, name);
			if(li.size()>0){
				return (Sweetness)li.get(0);
			}
			
		} catch (RuntimeException re){
			return null;
		}
		return null;
	}

	


	
	public static SweetnessDAO getFromApplicationContext(ApplicationContext ctx) {
		return (SweetnessDAO) ctx.getBean("SweetnessDAO");
	}
}