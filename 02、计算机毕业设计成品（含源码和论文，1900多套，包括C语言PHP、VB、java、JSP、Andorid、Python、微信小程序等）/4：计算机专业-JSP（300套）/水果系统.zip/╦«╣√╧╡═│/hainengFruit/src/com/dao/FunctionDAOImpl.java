package com.dao;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import com.model.TContent;
import com.util.JdbcUtils;
public class FunctionDAOImpl {
	public static void insertUserPingjia(TContent content ) {
		String sql="insert  into `t_content`(`content`,`goodsId`,`addTime`,`huiyuanId`) values ('"+content.getContent()+"','"+content.getGoodsId()+"','"+content.getAddTime()+"','"+content.getHuiyuanId()+"')";
		Connection conn = null;
			try{
				conn=JdbcUtils.connSQL();
				JdbcUtils.insertSQL(conn, sql);
			}catch (Exception e) {
				e.printStackTrace();
			}finally{
				if(conn!=null){
					JdbcUtils.deconnSQL(conn);
				}
			}
	}
	
	 
	
	public static List<TContent>  findContentList(String flag,Integer  goodsId){
		 Connection conn = null;
		 List<TContent> list=null;
			try{
				conn=JdbcUtils.connSQL();
				String sql="";
				if("pingjia".equals(flag)){
					sql=" SELECT t.`content`,t.`addTime`,t.`huiyuanId` FROM t_content t WHERE t.`goodsId`='"+goodsId+"' ORDER BY t.`id` DESC  ";
				}
			ResultSet rs= JdbcUtils.selectSQL(conn,sql);
			if(rs!=null){
				list=new  ArrayList<TContent>();
				 try {
						while(rs.next())
						{
							TContent vo=new TContent();
							vo.setContent(rs.getObject(1).toString()==null?"":rs.getObject(1).toString());
							vo.setAddTime(rs.getObject(2).toString()==null?"":rs.getObject(2).toString());
							vo.setHuiyuanId(rs.getObject(3).toString()==null?"":rs.getObject(3).toString());
							list.add(vo);
						}
					} catch (SQLException e) {
						e.printStackTrace();
					}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}finally{
			if(conn!=null){
				JdbcUtils.deconnSQL(conn);
			}
		}
		return list;
	}
}
