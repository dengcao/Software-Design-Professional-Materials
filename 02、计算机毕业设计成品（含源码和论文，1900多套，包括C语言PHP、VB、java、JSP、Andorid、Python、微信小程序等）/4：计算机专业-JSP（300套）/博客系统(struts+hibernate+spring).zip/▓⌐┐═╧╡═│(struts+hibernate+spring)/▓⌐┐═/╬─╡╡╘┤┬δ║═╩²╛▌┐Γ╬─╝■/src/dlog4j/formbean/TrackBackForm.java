/*
 *  This program is free software; you can redistribute it and/or modify
 *  it under the terms of the GNU General Public License as published by
 *  the Free Software Foundation; either version 2 of the License, or
 *  (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Library General Public License for more details.
 *
 *  You should have received a copy of the GNU General Public License
 *  along with this program; if not, write to the Free Software
 *  Foundation, Inc., 59 Temple Place - Suite 330, Boston, MA 02111-1307, USA.
 */
package dlog4j.formbean;

import java.util.Date;

/**
 * TrackBack��
 * @author Liudong
 */
public class TrackBackForm extends DlogActionForm {

    public final static String ERROR_KEY = "message";
    
    int id;
    String title;
    String excerpt;
    String url;
    String blog_name;
    String remoteAddr;
    Date refTime;
    LogForm log;
    
    public int getLog_id() {
        return (log!=null)?log.getId():-1;
    }
    public void setLog_id(int log_id) {
        if(log==null)
            log = new LogForm();
        log.setId(log_id);
    }
    
    public String getBlog_name() {
        return blog_name;
    }
    public void setBlog_name(String blog_name) {
        this.blog_name = blog_name;
    }
    public String getExcerpt() {
        return excerpt;
    }
    public void setExcerpt(String excerpt) {
        this.excerpt = excerpt;
    }
    public String getTitle() {
        return title;
    }
    public void setTitle(String title) {
        this.title = title;
    }
    public String getUrl() {
        return url;
    }
    public void setUrl(String url) {
        this.url = url;
    }
    public Date getRefTime() {
        return refTime;
    }
    public void setRefTime(Date refTime) {
        this.refTime = refTime;
    }
	public String getRemoteAddr() {
		return remoteAddr;
	}
	public void setRemoteAddr(String remoteAddr) {
		this.remoteAddr = remoteAddr;
	}
    public LogForm getLog() {
        return log;
    }
    public void setLog(LogForm log) {
        this.log = log;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
}
