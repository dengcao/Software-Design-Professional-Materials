function loadComment(){
	$("#verCode").val('');
	$("#commentsText").focus(function(){$("#showCode").css({display: "block"});});
	$("#commentsText").val("");
	var limitNum = 500;
	var pattern = 'Can enter ' + limitNum + ' Character'; 
	$('#commentsFontMsg').html(pattern); 
	$("#commentsText").keyup(function() {
	var result = limitNum -  getByteLen($(this).val());
	pattern = 'Can enter ' + result + ' Character';
	$('#commentsFontMsg').html(pattern); 
	if (result <0) {
		errorTip("#commentsFontMsg","Content-Length out of range");
	}});
}

function getByteLen(val) {    //传入一个字符串
    var len = 0;
    for (var i = 0; i < val.length; i++) {
        if (val[i].match(/[^\x00-\xff]/ig) != null) //全角 
            len += 2; //如果是全角，占用两个字节
        else
            len ++; //半角占用一个字节
    }
    return len;
 }    

function favorite(t,w,mId,nId,cId,s){
	if(confirm( "Confirm the collected?" ))
	{
		var url=window.location.href;
		url=url.substring(w.length+1,url.length);
		$.post(w+'/member/addMemberFavorite'+s, {
			"title" : t,
			"modelId" : mId,
			"nodeId" : nId,
			"contentId" : cId,
			"url" : url
		}, function(data) {
			if(data.status==1){
				alert('Collected Success');
			}else if(data.status==2) {
				alert('You have collected over the');
			}else{
				alert('Please sign in');
				javash_win('Sign in',w+'/member/login'+s+'?keepThis=true&TB_iframe=true&height=280&width=420');
			}
		}, "json");
	}
}

//替换页面中的表情代码为图片
function convertImg(val,url){
	//url=url+'/template/js/faceImg/';
	//return val.replace(/\[@/g, "<img src="+url).replace(/\@]/g, ".gif />");;
	//var s;
	//将字符串中如"[微笑]"类的表情代号替换为<img/>标签
	return $.expBlock.textFormat(val);
	
}

function htmlEncode(html)   
{   
	return html.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/\[br]/g,'<br />');
}   

function htmlDecode(html)   
{ 
	return html.replace('{//Quote','').replace('//}','').replace(/\<br>/g,'[br]').replace(/&amp;/g,'&').replace(/&lt;/g,'<').replace(/&gt;/g,'>');
}

function postForm(url,suffix){
   var u  = url+'/comments/add'+suffix;
   var contentId=$('input#contentId').val();
   var commentsText=$('textarea#commentsText').val();
   var verCode=$('input#verCode').val();
   commentsText= commentsText.replace(/<[ ]{0,}\/?[ ]{0,}(?:script|style|iframe|a|img)[ ]{0,}>/gi, ""); 
   
 // commentsText= commentsText.replace(/<.*?>/g,"");
  commentsText=convertImg(htmlEncode(commentsText),url);

   if($("#commentsText").val().length<1)
   {
   		$("#commentsText").focus(function(){$("#commentsText").val($("#commentsText").val());});  
 		$("#commentsText").focus(); 
    	errorTip("#commentsMsg","Comments can not be empty");
   		return false;
   }else{
   
   	if ($("#commentsText").val().length <10) {
		$("#commentsText").focus(function(){$("#commentsText").val($("#commentsText").val());});  
 		$("#commentsText").focus(); 
    	errorTip("#commentsMsg","Content is less than ten characters");
    	return false;
		}
   }

   if ($("#verCode").val().length <3) {
   		errorTip("#commentsMsg","Please enter the verification code");
   		$("#verCode").val('');
   		$("#verCode").focus();
   		return false;
   }
   //如果更改了评论分页数量请更改这里pageMax值，要对应,缓存需要的参数
	$.post(u, {
		"contentId" : contentId,
		"commentsText" : commentsText,
		"verCode" : verCode,
		"pageMax" : 8
	}, function(data) {
		if(data.status==0){
			$("#commentsMsg").html(data.message);
			$("#verCode").val('');
			$("#verCode").focus();
			kaptchaVerCode(url+'/admin/vercode'+suffix+'?');
			}else if(data.status==1){
				$("#commentsText").val('');
				$("#verCode").val('');
				$("#commentsMsg").html(data.message);
				var urls=location.href;
				if(urls.indexOf('?')=='-1'){
					$("#commentListContent").load(location.href+"?rnd="+(Math.ceil(Math.random()*1000))+" #commentListContent");
				}else{
					$("#commentListContent").load(location.href+"&rnd="+(Math.ceil(Math.random()*1000))+" #commentListContent");
				}
				
			  
			kaptchaVerCode(url+'/admin/vercode'+suffix+'?');
			}else if(data.status==2){
				$("#commentsMsg").html(data.message);
				javash_win('Sign in',url+'/member/login'+suffix+'?keepThis=true&TB_iframe=true&height=280&width=420');
			$("#verCode").val('');
			}else{
			$("#commentsMsg").html(data.message);
		}
	}, "json");
}


function postMemberFavorite(modelId,nodeId,contentId,url,suffix){
	url: url+'/member/addMemberFavorite'+suffix;
	$.post(url, {
		"modelId" : modelId,
		"nodeId" : nodeId,
		"contentId" : contentId
	}, function(data) {
		if(data.status==0){
			alert(data.message);
		}else if(data.status==1){
			alert(data.message);
			javash_win('Sign in',url+'/member/login'+suffix+'?keepThis=true&TB_iframe=true&height=280&width=420');
		}else{
			alert(data.message);
		}
	}, "json");
}

function openCommentsUrl(w,s,id){
	window.location.href=w+"/comments/id/"+id+s;
}