/**
 * @author ZhangHuihua@msn.com
 */
(function($){
	// jQuery validate
	$.extend($.validator.messages, {
		required: "campo obligatori",
		remote: "Por favor, corrija el campo",
		email: "por favor, introduzca un formato de correo electrónico válida",
		url: "por favor, introduzca una dirección válida",
		date: "por favor, introduzca una fecha válida",
		dateISO: "por favor, introduzca una fecha válida(ISO).",
		number: "por favor, introduzca un número válido",
		digits: "entrar sólo enteros",
		creditcard: "por favor, introduzca un número de tarjeta de crédito válida",
		equalTo: "por favor, vuelva a introducir el mismo valor",
		accept: "por favor, introduzca una cadena con una extensión legítima",
		maxlength: $.validator.format("longitud máxima de la cadena es {0}"),
		minlength: $.validator.format("cadena de longitud mínima es de {0}"),
		rangelength: $.validator.format("{0} y {1} cadena de longitud entre"),
		range: $.validator.format("por favor escribe a {0} y {1} rango de valores"),
		max: $.validator.format("por favor, introduzca un valor máximo de {0}"),
		min: $.validator.format("Por favor, introduzca un valor mínimo de {0}"),
		
		alphanumeric: "Sólo letras, números, guión",
		lettersonly: "debe ser una letra",
		phone: "Sólo el número, el espacio, entre paréntesis"
	});
	
	// DWZ regional
	$.setRegional("datepicker", {
		dayNames: ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'],
		monthNames: ['enero', 'febrero', 'marzo', 'abril', 'pueden', 'junio', 'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre']
	});
	$.setRegional("alertMsg", {
		title:{error:"error", info:"consejos", warn:"advertencia", correct:"éxito", confirm:"Confirmación consejos"},
		butMsg:{ok:"confirmar", yes:"sí", no:"no", cancel:"cancelar"}
	});
})(jQuery);