/**
 * @author ZhangHuihua@msn.com
 */
(function($){
	// jQuery validate
	$.extend($.validator.messages, {
		required: "このフィールドは必須です",
		remote: "フィールドを修正してください",
		email: "有効な電子メールの形式を入力してください",
		url: "有効なアドレスを入力してください",
		date: "有効な日付を入力してください",
		dateISO: "有効な日付（ISO）を入力してください.",
		number: "有効な番号を入力してください",
		digits: "整数のみを入力します。",
		creditcard: "有効なクレジットカード番号を入力してください",
		equalTo: "してください再同じ値を入力します",
		accept: "合法的な拡張子を持つ文字列を入力してください",
		maxlength: $.validator.format("文字列の最大長は、{0}です"),
		minlength: $.validator.format("文字列の最小の長さは{0}です"),
		rangelength: $.validator.format("{0}と{1}文字列の長さの間"),
		range: $.validator.format("値の{0}と{1}の範囲を入力してください"),
		max: $.validator.format("{0}の最大値を入力してください"),
		min: $.validator.format("{0}の最小値を入力してください"),
		alphanumeric: "唯一の文字、数字、アンダースコア",
		lettersonly: "文字でなければなりません",
		phone: "番号は、スペース、括弧"
	});
	
	// DWZ regional
	$.setRegional("datepicker", {
		dayNames: ['日曜', '月曜', '火曜', '水曜', '木曜', '金曜', '土曜'],
		monthNames: ['1月', '2月', '3月', '4月', '5月', '6月', '7月', '8月', '9月', '10月', '11月', '12月']
	});
	$.setRegional("alertMsg", {
		title:{error:"エラー", info:"ヒント", warn:"警告", correct:"成功", confirm:"確認のヒント"},
		butMsg:{ok:"確認", yes:"はい", no:"ノー", cancel:"取り消し"}
	});
})(jQuery);