if exists (select * from sysobjects where id = OBJECT_ID('[vj_consumption_record]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_consumption_record]
CREATE TABLE vj_consumption_record (
  [id]  char(32) NOT NULL,
  [memberId] char(32) DEFAULT NULL,
  [contentId] char(32)DEFAULT NULL,
  [nodeId] int DEFAULT NULL,
  [consumption] numeric(10,2) DEFAULT NULL,
  [consumptionTime] int DEFAULT NULL,
  [consumptionType] int DEFAULT NULL,
  [state] char(1) DEFAULT NULL,
  PRIMARY KEY ([id])
)

ALTER TABLE [vj_consumption_record] WITH NOCHECK ADD  CONSTRAINT [PK_vj_consumption_record] PRIMARY KEY  NONCLUSTERED ( [id] )
CREATE INDEX "IX_consumption_record_cId_nId" ON vj_consumption_record([contentId],[nodeId]);
GO

if exists (select * from sysobjects where id = OBJECT_ID('[vj_photos]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_photos]
CREATE TABLE [vj_photos] (
  [id] char(32) NOT NULL,
  [photoText] text DEFAULT (NULL),
  [style] char(1) DEFAULT (NULL)
)
ALTER TABLE [vj_photos] WITH NOCHECK ADD  CONSTRAINT [PK_vj_photos] PRIMARY KEY  NONCLUSTERED ( [id] )
GO

if exists (select * from sysobjects where id = OBJECT_ID('[vj_special_topic]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_special_topic]
CREATE TABLE [vj_special_topic] (
  [id] [int] NOT NULL,
  [nodeId] int DEFAULT (NULL),
  [title] varchar(255) DEFAULT (NULL),
  [titleImg] varchar(255) DEFAULT (NULL),
  [code] text DEFAULT (NULL),
  [createTime] int DEFAULT (NULL),
  [author] varchar(50) DEFAULT (NULL),
  [templatePath] varchar(255) DEFAULT (NULL),
  [description] varchar(1000) DEFAULT (NULL),
  [isStatic] char(1) DEFAULT NULL,
)
ALTER TABLE [vj_special_topic] WITH NOCHECK ADD  CONSTRAINT [PK_vj_special_topic] PRIMARY KEY  NONCLUSTERED ( [id] )
CREATE INDEX [IX_vj_special_topic_createTime] ON [vj_special_topic]([createTime])
CREATE INDEX [IX_vj_special_topic_title] ON [vj_special_topic]([title])
GO

if exists (select * from sysobjects where id = OBJECT_ID('[vj_keyword_history]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_keyword_history]
CREATE TABLE [vj_keyword_history] (
  [id] char(32) NOT NULL,
  [keyword] varchar(255) DEFAULT (NULL),
  [searchCount] int DEFAULT (NULL),
  [isContent] char(1) DEFAULT (NULL)
)
ALTER TABLE [vj_keyword_history] WITH NOCHECK ADD  CONSTRAINT [PK_vj_keyword_history] PRIMARY KEY  NONCLUSTERED ( [id] )
CREATE INDEX [IX_vj_keyword_history_keyword] ON [vj_keyword_history]([keyword])
GO

if exists (select * from sysobjects where id = OBJECT_ID('[vj_member_consume_record]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_member_consume_record]
CREATE TABLE [vj_member_consume_record] (
  [id] char(32) NOT NULL,
  [amount] [numeric](10,2) DEFAULT (NULL),
  [amountType] [int] DEFAULT (NULL),
  [action] [int] DEFAULT (NULL),
  [description] varchar(255) DEFAULT (NULL),
  [memberId] char(32) DEFAULT (NULL),
  [creationTime] int DEFAULT (NULL)
)
ALTER TABLE [vj_member_consume_record] WITH NOCHECK ADD  CONSTRAINT [PK_vj_member_consume_record] PRIMARY KEY  NONCLUSTERED ( [id] )
CREATE INDEX [IX_vj_member_consume_recore_creationTime] ON [vj_member_consume_record]([creationTime])
GO

if exists (select * from sysobjects where id = OBJECT_ID('[vj_email_validation]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_email_validation]
CREATE TABLE [vj_email_validation] (
  [id] [char](32) NOT NULL,
  [userId] [char](32) DEFAULT (NULL),
  [email] [varchar](150) DEFAULT (NULL),
  [keyValue] [char](32) DEFAULT (NULL),
  [recordTime] [int] DEFAULT (NULL),
  [inTime] [int] DEFAULT (NULL),
  [hit] [int] DEFAULT (NULL)
)
ALTER TABLE [vj_email_validation] WITH NOCHECK ADD  CONSTRAINT [PK_vj_email_validation] PRIMARY KEY  NONCLUSTERED ( [id] )
GO

if exists (select * from sysobjects where id = OBJECT_ID('[vj_pay_order]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_pay_order]
CREATE TABLE [vj_pay_order] (
  [id] [char](32) NOT NULL,
  [title] [varchar](200) DEFAULT (NULL),
  [orderNo] [char](32) DEFAULT (NULL),
  [payNo] [varchar](150) DEFAULT (NULL),
  [memberId] [char](32) DEFAULT (NULL),
  [payPrice] [numeric](10,2) DEFAULT (NULL),
  [quantity] [int] DEFAULT (NULL),
  [payType] [int] DEFAULT (NULL),
  [remark] [varchar](250) DEFAULT (NULL),
  [status] [int] DEFAULT (NULL),
  [creationTime] [int] DEFAULT (NULL),
  [payTime] [int] DEFAULT (NULL),
  [ConfirmTime] [int] DEFAULT (NULL),
  [ipAddress] [varchar](40) DEFAULT NULL
) 
ALTER TABLE [vj_pay_order] WITH NOCHECK ADD  CONSTRAINT [PK_vj_pay_order] PRIMARY KEY  NONCLUSTERED ( [id] )
CREATE INDEX [IX_vj_pay_order_creationTime] ON [vj_pay_order]([creationTime])
CREATE UNIQUE INDEX [IX_vj_pay_order_orderNo] ON [vj_pay_order]([orderNo])
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_oauth_config]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_oauth_config]
CREATE TABLE [vj_oauth_config] (
  [id] [int] NOT NULL,
  [name]  [varchar]  (20) NULL DEFAULT (NULL),
  [clientId] [varchar]  (150) NULL DEFAULT (NULL),
  [clientSecret] [varchar]  (150) NULL DEFAULT (NULL),
  [redirectUri] [varchar]  (150) NULL DEFAULT (NULL),
  [authorizeUrl] [varchar]  (150) NULL DEFAULT (NULL),
  [tokenUrl] [varchar]  (150) NULL DEFAULT (NULL),
  [meUrl][varchar]  (150) NULL DEFAULT (NULL)
)
ALTER TABLE [vj_oauth_config] WITH NOCHECK ADD  CONSTRAINT [PK_vj_oauth_config] PRIMARY KEY  NONCLUSTERED ( [id] )
CREATE UNIQUE INDEX [IX_vj_oauth_config_name] ON [vj_oauth_config]([name])
GO



if exists (select * from sysobjects where id = OBJECT_ID('[vj_oauth]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_oauth]
CREATE TABLE [vj_oauth] (
  [id] [char]  (32) NOT NULL,
  [openId] [varchar](100)  NULL DEFAULT (NULL),
  [memberId] [char](32)  NULL DEFAULT (NULL),
  [loginType] [int]  NULL DEFAULT (NULL)
)
ALTER TABLE [vj_oauth] WITH NOCHECK ADD  CONSTRAINT [PK_vj_oauth] PRIMARY KEY  NONCLUSTERED ( [id] )
CREATE UNIQUE INDEX [IX_vj_oauth_openId] ON [vj_oauth]([openId])
CREATE INDEX [IX_vj_oauth_memberId] ON [vj_oauth]([memberId])
GO

INSERT INTO [vj_oauth_config]([id],[name],[clientId],[clientSecret],[redirectUri],[authorizeUrl],[tokenUrl],[meUrl]) VALUES (1, N'qq', N'', N'', N'http://www.vijun.com/oauth/qq/authorizationCode.sh', N'https://graph.qq.com/oauth2.0/authorize', N'https://graph.qq.com/oauth2.0/token', N'https://graph.qq.com/oauth2.0/me')
INSERT INTO [vj_oauth_config]([id],[name],[clientId],[clientSecret],[redirectUri],[authorizeUrl],[tokenUrl],[meUrl]) VALUES (2, N'msn', N'', N'', N'http://www.vijun.com/oauth/msn/authorizationCode.sh', N'https://oauth.live.com/authorize', N'https://oauth.live.com/token', N'https://apis.live.net/v5.0/me')
INSERT INTO [vj_oauth_config]([id],[name],[clientId],[clientSecret],[redirectUri],[authorizeUrl],[tokenUrl],[meUrl]) VALUES (3, N'baidu', N'', N'', N'http://www.vijun.com/oauth/baidu/authorizationCode.sh', N'https://openapi.baidu.com/oauth/2.0/authorize', N'https://openapi.baidu.com/oauth/2.0/token', N'https://openapi.baidu.com/rest/2.0/passport/users/getInfo')
GO


if exists (select * from sysobjects where id = OBJECT_ID('[vj_admin_log]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_admin_log]

CREATE TABLE [vj_admin_log] (
[id] [char]  (32) NOT NULL,
[code] [smallint]  NULL DEFAULT (NULL),
[type] [char]  (1) NULL DEFAULT (NULL),
[userName] [varchar]  (100) NULL DEFAULT (NULL),
[ipAddress] [varchar]  (40) NULL DEFAULT (NULL),
[recordTime] [int]  NULL DEFAULT (NULL))
ALTER TABLE [vj_admin_log] WITH NOCHECK ADD  CONSTRAINT [PK_vj_admin_log] PRIMARY KEY  NONCLUSTERED ( [id] )
CREATE INDEX [IX_vj_admin_log_time] ON [vj_admin_log](recordTime desc)
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_admin_role]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_admin_role]
CREATE TABLE [vj_admin_role] (
[adminId] [char]  (32) NOT NULL,
[roleId] [int]  NOT NULL)

ALTER TABLE [vj_admin_role] WITH NOCHECK ADD  CONSTRAINT [PK_vj_admin_role] PRIMARY KEY  NONCLUSTERED ( [adminId],[roleId] )
GO
INSERT [vj_admin_role] ([adminId],[roleId]) VALUES ( N'402881e52bc4aa42012bc4b22fdd0004',0)
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_admins]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_admins]

CREATE TABLE [vj_admins] (
[adminId] [char]  (32) NOT NULL,
[username] [varchar]  (20) NULL DEFAULT (NULL),
[password] [char]  (56) NULL DEFAULT (NULL),
[accountExpired] [char]  (1) NULL DEFAULT (NULL),
[accountLocked] [char]  (1) NULL DEFAULT (NULL),
[credentialsExpired] [char]  (1) NULL DEFAULT (NULL),
[enable] [char]  (1) NULL DEFAULT (NULL),
[lastLoginIp] [varchar]  (40) NULL DEFAULT (NULL),
[lastLoginTime] [int]  NULL DEFAULT (NULL),
[lastUpdatePassWordTime] [int]  NULL DEFAULT (NULL),
[loginCount] [int]  NULL DEFAULT (NULL),
[loginErrorCount] [int]  NULL DEFAULT (NULL),
[registerTime] [int]  NULL DEFAULT (NULL),
[myTimeZone] [char]  (6) NULL DEFAULT (NULL),
[myLanguage] [smallint]  NULL DEFAULT (NULL),
[isPassExpire] [char]  (1) NULL DEFAULT (NULL),
[accountLockCount] [int]  NULL DEFAULT (NULL),
[isAccountExpire] [char]  (1) NULL DEFAULT (NULL),
[superPassword] [char]  (56) NULL DEFAULT (NULL),
[email] [varchar]  (250) NULL DEFAULT (NULL),
[question] [char]  (1) NULL DEFAULT (NULL),
[answer] [varchar]  (250) NULL DEFAULT (NULL),
[isAnswerLogin] [char]  (1) NULL DEFAULT (NULL))

ALTER TABLE [vj_admins] WITH NOCHECK ADD  CONSTRAINT [PK_vj_admins] PRIMARY KEY  NONCLUSTERED ( [adminId] )
CREATE UNIQUE INDEX [IX_vj_admins_username] ON [vj_admins]([username])
CREATE INDEX [IX_vj_admins_register] ON [vj_admins]([registerTime])
GO
INSERT [vj_admins] ([adminId],[username],[password],[accountExpired],[accountLocked],[credentialsExpired],[enable],[lastLoginIp],[lastLoginTime],[lastUpdatePassWordTime],[loginCount],[loginErrorCount],[registerTime],[myTimeZone],[myLanguage],[isPassExpire],[accountLockCount],[isAccountExpire],[superPassword],[email],[question],[answer],[isAnswerLogin]) VALUES ( N'402881e52bc4aa42012bc4b22fdd0004',N'admin',N'4ABE1307ADEEF96E9FA296BA39250C6FF6D764462B83DE8475BA94D2',N'F',N'F',N'F',N'F',N'192.168.244.1',1315092024,1299882271,815,0,1296952652,N'+08:00',0,N'F',0,N'F',N'5EF458ADD47610C4A4D0B0DEC1C608709AD303E771C45A594ABFDF14',N'458479@qq.com',N'0',N'd',N'F')
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_channel_model]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_channel_model]

CREATE TABLE [vj_channel_model] (
[modelId] [int]  NOT NULL,
[modelName] [varchar]  (50) NULL DEFAULT (NULL),
[type] [char]  (1) NULL DEFAULT (NULL),
[description] [varchar]  (250) NULL DEFAULT (NULL),
[enable] [char]  (1) NULL DEFAULT (NULL),
[language] [smallint]  NULL DEFAULT (NULL))

ALTER TABLE [vj_channel_model] WITH NOCHECK ADD  CONSTRAINT [PK_vj_channel_model] PRIMARY KEY  NONCLUSTERED ( [modelId] )
GO
INSERT [vj_channel_model] ([modelId],[modelName],[type],[description],[enable],[language]) VALUES ( 1,N'文章模型',N'0',N'文章模型',N'T',0)
INSERT [vj_channel_model] ([modelId],[modelName],[type],[description],[enable],[language]) VALUES ( 2,N'软件模型',N'0',N'软件模型',N'T',0)
INSERT [vj_channel_model] ([modelId],[modelName],[type],[description],[enable],[language]) VALUES ( 3,N'图片模型',N'0',N'图片模型',N'T',0)
INSERT [vj_channel_model] ([modelId],[modelName],[type],[description],[enable],[language]) VALUES ( 4,N'视频模型',N'0',N'视频模型',N'T',0)
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_cms_type]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_cms_type]

CREATE TABLE [vj_cms_type] (
[id] [int]  NOT NULL DEFAULT ('0'),
[name] [varchar]  (150) NULL DEFAULT (NULL),
[typeId] [int]  NULL DEFAULT (NULL),
[modelId] [int]  NULL DEFAULT (NULL),
[keyId] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_cms_type] WITH NOCHECK ADD  CONSTRAINT [PK_vj_cms_type] PRIMARY KEY  NONCLUSTERED ( [id] )
GO
INSERT [vj_cms_type] ([id],[name],[typeId],[modelId],[keyId]) VALUES ( 1,N'简体中文',1,2,1)
INSERT [vj_cms_type] ([id],[name],[typeId],[modelId],[keyId]) VALUES ( 2,N'繁体中文',1,2,2)
INSERT [vj_cms_type] ([id],[name],[typeId],[modelId],[keyId]) VALUES ( 3,N'英语',1,2,3)
INSERT [vj_cms_type] ([id],[name],[typeId],[modelId],[keyId]) VALUES ( 4,N'多国语言',1,2,4)
INSERT [vj_cms_type] ([id],[name],[typeId],[modelId],[keyId]) VALUES ( 5,N'exe',2,2,1)
INSERT [vj_cms_type] ([id],[name],[typeId],[modelId],[keyId]) VALUES ( 6,N'rar',2,2,2)
INSERT [vj_cms_type] ([id],[name],[typeId],[modelId],[keyId]) VALUES ( 7,N'zip',2,2,3)
INSERT [vj_cms_type] ([id],[name],[typeId],[modelId],[keyId]) VALUES ( 8,N'7z',2,2,4)
INSERT [vj_cms_type] ([id],[name],[typeId],[modelId],[keyId]) VALUES ( 9,N'iso',2,2,5)
INSERT [vj_cms_type] ([id],[name],[typeId],[modelId],[keyId]) VALUES ( 10,N'win xp/7/2008/2003/2000',3,2,1)
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_comments]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_comments]

CREATE TABLE [vj_comments] (
[commentsId] [char]  (32) NOT NULL,
[contentId] [char]  (32) NULL DEFAULT (NULL),
[commentsText] [varchar]  (500) NULL DEFAULT (NULL),
[support] [int]  NULL DEFAULT (NULL),
[against] [int]  NULL DEFAULT (NULL),
[commentsTime] [int]  NULL DEFAULT (NULL),
[ipAddress] [varchar]  (40) NULL DEFAULT (NULL),
[memberId] [char]  (32) NULL DEFAULT (NULL),
[status] [char]  (1) NULL DEFAULT (NULL),
[nodeId] [int]  NULL DEFAULT (NULL),
[modelId] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_comments] WITH NOCHECK ADD  CONSTRAINT [PK_vj_comments] PRIMARY KEY  NONCLUSTERED ( [commentsId] )
CREATE INDEX [IX_vj_comments_contentId] ON [vj_comments](contentId)
CREATE INDEX [IX_vj_comments_commentTime] ON [vj_comments](commentsTime)
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_content_text]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_content_text]

CREATE TABLE [vj_content_text] (
[id] [char]  (32) NOT NULL,
[detail] [varchar]  (MAX) NULL)

ALTER TABLE [vj_content_text] WITH NOCHECK ADD  CONSTRAINT [PK_vj_content_text] PRIMARY KEY  NONCLUSTERED ( [id] )
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_contents]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_contents]

CREATE TABLE [vj_contents] (
[id] [char]  (32) NOT NULL,
[title] [varchar]  (250) NULL DEFAULT (NULL),
[subTitle] [varchar]  (250) NULL DEFAULT (NULL),
[copyFrom] [varchar]  (50) NULL DEFAULT (NULL),
[authorName] [varchar]  (50) NULL DEFAULT (NULL),
[authorId] [char]  (32) NULL DEFAULT (NULL),
[keyword] [varchar]  (50) NULL DEFAULT (NULL),
[intro] [varchar]  (500) NULL DEFAULT (NULL),
[publishTime] [int]  NULL DEFAULT (NULL),
[status] [char]  (1) NULL DEFAULT (NULL),
[tags] [varchar]  (100) NULL DEFAULT (NULL),
[isTop] [char]  (1) NULL DEFAULT (NULL),
[isRecommend] [char]  (1) NULL DEFAULT (NULL),
[isPic] [char]  (1) NULL DEFAULT (NULL),
[isComment] [char]  (1) NULL DEFAULT (NULL),
[isFlash] [char]  (1) NULL DEFAULT (NULL),
[permissionLevel] [char]  (1) NULL DEFAULT (NULL),
[modelId] [int]  NULL DEFAULT (NULL),
[nodeId] [int]  NULL DEFAULT (NULL),
[urlRename] [varchar]  (250) NULL DEFAULT (NULL),
[titleImg] [varchar]  (250) NULL DEFAULT (NULL),
[costMoney] [int]  NULL DEFAULT (NULL),
[staticDir] [varchar]  (100) NULL DEFAULT (NULL))

ALTER TABLE [vj_contents] WITH NOCHECK ADD  CONSTRAINT [PK_vj_contents] PRIMARY KEY  NONCLUSTERED ( [id] )
CREATE INDEX [IX_vj_contents_urlRename] ON [vj_contents]([urlRename])
CREATE INDEX [IX_vj_contents_title] ON [vj_contents]([title])
CREATE INDEX [IX_vj_contents_publishTime] ON [vj_contents]([publishTime])
CREATE INDEX [IX_vj_contents_nodeId] ON [vj_contents]([nodeId])
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_cost_point_history]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_cost_point_history]

CREATE TABLE [vj_cost_point_history] (
[id] [char]  (32) NOT NULL DEFAULT (N''),
[itemId] [char]  (32) NULL DEFAULT (NULL),
[costPoint] [int]  NULL DEFAULT (NULL),
[memberId] [char]  (32) NULL DEFAULT (NULL),
[costTime] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_cost_point_history] WITH NOCHECK ADD  CONSTRAINT [PK_vj_cost_point_history] PRIMARY KEY  NONCLUSTERED ( [id] )
GO

if exists (select * from sysobjects where id = OBJECT_ID('[vj_dictionary]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_dictionary]

CREATE TABLE [vj_dictionary] (
[id] [int]  NOT NULL,
[name] [varchar]  (250) NULL DEFAULT (NULL),
[description] [varchar]  (250) NULL DEFAULT (NULL),
[language] [smallint]  NULL DEFAULT (NULL),
[modelId] [int]  NULL DEFAULT (NULL),
[contentId] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_dictionary] WITH NOCHECK ADD  CONSTRAINT [PK_vj_dictionary] PRIMARY KEY  NONCLUSTERED ( [id] )
GO
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1,N'内容模型',N'内容模型',0,0,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 2,N'内容管理',N'内容管理',0,0,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 3,N'文章列表',N'文章列表',0,0,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 4,N'软件列表',N'软件列表',0,0,4)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 5,N'内容功能',N'内容功能',0,0,5)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 6,N'标签管理',N'标签管理',0,0,6)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 7,N'评论管理',N'评论管理',0,0,7)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 8,N'生成静态文件',N'生成静态文件',0,0,8)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 9,N'索引管理',N'索引管理',0,0,9)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 10,N'用户模型',N'用户模型',0,0,10)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 11,N'前台用户',N'前台用户',0,0,11)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 12,N'会员列表',N'会员列表',0,0,12)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 13,N'会员组',N'会员组',0,0,13)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 14,N'后台用户',N'后台用户',0,0,14)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 15,N'管理员列表',N'管理员列表',0,0,15)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 16,N'角色列表',N'角色列表',0,0,16)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 17,N'权限管理',N'权限管理',0,0,17)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 18,N'登陆日志',N'登陆日志',0,0,18)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 19,N'在线管理员',N'在线管理员',0,0,19)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 20,N'系统模型',N'系统模型',0,0,20)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 21,N'系统设置',N'系统设置',0,0,21)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 22,N'站点设置',N'站点设置',0,0,22)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 23,N'安全设置',N'安全设置',0,0,23)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 24,N'导航设置',N'导航设置',0,0,24)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 25,N'水印设置',N'水印设置',0,0,25)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 26,N'邮件设置',N'邮件设置',0,0,26)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 27,N'系统功能',N'系统功能',0,0,27)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 28,N'备份数据',N'备份数据',0,0,28)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 29,N'国际化管理',N'国际化管理',0,0,29)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 30,N'文件管理',N'文件管理',0,0,30)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 31,N'发送邮件',N'发送邮件',0,0,31)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 32,N'模板设置',N'模板设置',0,0,32)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 33,N'模板标签设置',N'模板标签设置',0,0,33)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 34,N'友情链接',N'友情链接',0,0,34)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 35,N'下载网址过滤',N'下载网址过滤',0,0,35)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 36,N'系统变量设置',N'系统变量设置',0,0,36)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 37,N'栏目管理',N'栏目管理',0,0,37)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 38,N'频道模型管理',N'频道模型管理',0,0,38)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 39,N'Content Model',N'Content Model',1,0,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 40,N'Content Management',N'Content Management',1,0,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 41,N'Article List',N'Article List',1,0,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 42,N'Software List',N'Software List',1,0,4)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 43,N'Content Function',N'Content Function',1,0,5)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 44,N'Tag Management',N'Tag Management',1,0,6)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 45,N'Comment Management',N'Comment Management',1,0,7)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 46,N'Generate Static File',N'Generate Static File',1,0,8)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 47,N'Index Management',N'Index Management',1,0,9)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 48,N'User Model',N'User Model',1,0,10)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 49,N'Front User',N'Front User',1,0,11)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 50,N'Member List',N'Member List',1,0,12)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 51,N'Member Group',N'Member Group',1,0,13)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 52,N'Background User',N'Background User',1,0,14)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 53,N'Manager List',N'Manager List',1,0,15)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 54,N'Roles List',N'Roles List',1,0,16)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 55,N'Permission Management',N'Permission Management',1,0,17)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 56,N'Login Log',N'Login Log',1,0,18)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 57,N'Online Manager',N'Online Manager',1,0,19)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 58,N'System Model',N'System Model',1,0,20)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 59,N'System Setting',N'System Setting',1,0,21)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 60,N'Site Setting',N'Site Setting',1,0,22)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 61,N'Security Setting',N'Security Setting',1,0,23)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 62,N'Navigation Setting',N'Navigation Setting',1,0,24)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 63,N'Watermark Setting',N'Watermark Setting',1,0,25)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 64,N'Mail Setting',N'Mail Setting',1,0,26)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 65,N'System Function',N'System Function',1,0,27)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 66,N'Backup Data',N'Backup Data',1,0,28)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 67,N'I18n management',N'International management',1,0,29)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 68,N'File Management',N'File Management',1,0,30)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 69,N'Send Email',N'Send Email',1,0,31)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 70,N'Template Setting',N'Template Setting',1,0,32)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 71,N'Template Tag Setting',N'Template Tag Setting',1,0,33)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 72,N'Link',N'Link',1,0,34)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 73,N'Download URL Filter',N'Download URL Filter',1,0,35)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 74,N'System Variable Setting',N'System Variable Setting',1,0,36)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 75,N'Node Management',N'Node Management',1,0,37)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 76,N'Channel Model Management',N'Channel Model Management',1,0,38)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 77,N'Vote Management',N'Vote Management',1,0,39)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 78,N'内容模型',N'内容模型',2,0,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 79,N'内容管理',N'内容管理',2,0,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 80,N'文章列表',N'文章列表',2,0,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 81,N'軟件列表',N'軟件列表',2,0,4)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 82,N'内容功能',N'内容功能',2,0,5)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 83,N'標籤管理',N'標籤管理',2,0,6)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 84,N'評論管理',N'評論管理',2,0,7)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 85,N'生成靜態文件',N'生成靜態文件',2,0,8)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 86,N'索引管理',N'索引管理',2,0,9)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 87,N'用户模型',N'用户模型',2,0,10)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 88,N'前台用户',N'前台用户',2,0,11)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 89,N'會員列表',N'會員列表',2,0,12)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 90,N'會員組',N'會員組',2,0,13)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 91,N'後台用戶',N'後台用戶',2,0,14)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 92,N'管理員列表',N'管理員列表',2,0,15)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 93,N'角色列表',N'角色列表',2,0,16)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 94,N'權限管理',N'權限管理',2,0,17)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 95,N'登錄日誌',N'登錄日誌',2,0,18)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 96,N'在線管理員',N'在線管理員',2,0,19)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 97,N'系統模型',N'系統模型',2,0,20)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 98,N'系統設置',N'系統設置',2,0,21)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 99,N'站點設置',N'站點設置',2,0,22)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 100,N'安全設置',N'安全設置',2,0,23)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 101,N'導航設置',N'導航設置',2,0,24)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 102,N'水印設置',N'水印設置',2,0,25)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 103,N'郵件設置',N'郵件設置',2,0,26)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 104,N'系統功能',N'系統功能',2,0,27)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 105,N'備份數據',N'備份數據',2,0,28)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 106,N'國際化管理',N'國際化管理',2,0,29)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 107,N'文件管理',N'文件管理',2,0,30)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 108,N'發送郵件',N'發送郵件',2,0,31)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 109,N'模板設置',N'模板設置',2,0,32)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 110,N'模板標籤設置',N'模板標籤設置',2,0,33)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 111,N'友情鏈接',N'友情鏈接',2,0,34)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 112,N'下載網址過濾',N'下載網址過濾',2,0,35)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 113,N'系統變量設置',N'系統變量設置',2,0,36)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 114,N'欄目管理',N'欄目管理',2,0,37)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 115,N'頻道模型管理',N'頻道模型管理',2,0,38)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 116,N'投票管理',N'投票管理',2,0,39)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 117,N'コンテンツモデル',N'コンテンツモデル',3,0,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 118,N'コンテンツ管理',N'コンテンツ管理',3,0,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 119,N'記事一覧',N'記事一覧',3,0,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 120,N'ソフトウェア一覧',N'ソフトウェア一覧',3,0,4)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 121,N'コンテンツ関数',N'コンテンツ関数',3,0,5)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 122,N'タグ管',N'タグ管',3,0,6)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 123,N'コメント管理',N'コメント管理',3,0,7)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 124,N'を生成する静的ファイル',N'を生成する静的ファイル',3,0,8)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 125,N'インデックス管理',N'インデックス管理',3,0,9)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 126,N'ユーザーモデル',N'ユーザーモデル',3,0,10)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 127,N'フロントユーザー',N'フロントユーザー',3,0,11)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 128,N'メンバーリスト',N'メンバーリスト',3,0,12)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 129,N'会員グループ',N'会員グループ',3,0,13)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 130,N'背景ユーザー',N'背景ユーザー',3,0,14)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 131,N'マネージャのリスト',N'マネージャのリスト',3,0,15)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 132,N'ロールのリスト',N'ロールのリスト',3,0,16)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 133,N'パーミッション管理',N'パーミッション管理',3,0,17)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 134,N'ログレコード',N'ログレコード',3,0,18)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 135,N'オンラインマネージャ',N'オンラインマネージャ',3,0,19)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 136,N'システムモデル',N'システムモデル',3,0,20)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 137,N'システム設定',N'システム設定',3,0,21)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 138,N'サイトの設定',N'サイトの設定',3,0,22)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 139,N'セキュリティの設定',N'セキュリティの設定',3,0,23)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 140,N'ナビゲーション設定',N'ナビゲーション設定',3,0,24)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 141,N'透かし設定',N'透かし設定',3,0,25)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 142,N'メール設定',N'メール設定',3,0,26)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 143,N'システム関数',N'システム関数',3,0,27)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 144,N'バックアップデータ',N'バックアップデータ',3,0,28)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 145,N'国際管理',N'国際管理',3,0,29)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 146,N'ファイル管理',N'ファイル管理',3,0,30)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 147,N'電子メールを送信する',N'電子メールを送信する',3,0,31)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 148,N'テンプレートの設定',N'テンプレートの設定',3,0,32)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 149,N'テンプレートタグ設定',N'テンプレートタグ設定',3,0,33)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 150,N'リンク',N'リンク',3,0,34)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 151,N'ダウンロードURLフィルタリング',N'ダウンロードURLフィルタリング',3,0,35)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 152,N'システム設定変数',N'システム設定変数',3,0,36)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 153,N'ノード管理',N'ノード管理',3,0,37)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 154,N'チャネルモデルの管理',N'チャネルモデルの管理',3,0,38)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 155,N'投票管理',N'投票管理',3,0,39)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 156,N'Модель содержимого',N'Модель содержимого',4,0,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 157,N'Управление контентом',N'Управление контентом',4,0,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 158,N'Список статей',N'Список статей',4,0,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 159,N'Список программного обеспечения',N'Список программного обеспечения',4,0,4)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 160,N'Содержание функции',N'Содержание функции',4,0,5)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 161,N'Управление метками',N'Управление метками',4,0,6)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 162,N'Комментарий управления',N'Комментарий управления',4,0,7)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 163,N'Создание статических файлов',N'Создание статических файлов',4,0,8)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 164,N'Индекс управления',N'Индекс управления',4,0,9)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 165,N'Пользователь модели',N'Пользователь модели',4,0,10)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 166,N'Отдел пользователя',N'Отдел пользователя',4,0,11)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 167,N'Пользователи',N'Пользователи',4,0,12)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 168,N'Группа',N'Группа',4,0,13)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 169,N'Справочная пользователя',N'Справочная пользователя',4,0,14)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 170,N'Менеджер Список',N'Менеджер Список',4,0,15)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 171,N'Роль Список',N'Роль Список',4,0,16)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 172,N'Разрешение управления',N'Разрешение управления',4,0,17)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 173,N'Войти Вход',N'Войти Вход',4,0,18)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 174,N'Интернет Manager',N'Интернет Manager',4,0,19)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 175,N'Модель системы',N'Модель системы',4,0,20)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 176,N'Настройки системы',N'Настройки системы',4,0,21)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 177,N'Параметры сайта',N'Параметры сайта',4,0,22)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 178,N'Настройки безопасности',N'Настройки безопасности',4,0,23)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 179,N'Навигация настройки',N'Навигация настройки',4,0,24)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 180,N'Водяной знак Настройка',N'Водяной знак Настройка',4,0,25)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 181,N'Настройки почты',N'Настройки почты',4,0,26)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 182,N'Система функции',N'Система функции',4,0,27)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 183,N'Резервное копирование данных',N'Резервное копирование данных',4,0,28)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 184,N'Международный менеджмент',N'Международный менеджмент',4,0,29)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 185,N'Управление файлами',N'Управление файлами',4,0,30)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 186,N'Отправить по электронной почте',N'Отправить по электронной почте',4,0,31)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 187,N'Параметры шаблона',N'Параметры шаблона',4,0,32)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 188,N'Теги набор шаблонов',N'Теги набор шаблонов',4,0,33)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 189,N'Ссылки',N'Ссылки',4,0,34)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 190,N'Скачать URL фильтра',N'Скачать URL фильтра',4,0,35)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 191,N'Системная переменная Настройка',N'Системная переменная Настройка',4,0,36)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 192,N'Узел управления',N'Узел управления',4,0,37)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 193,N'Источник Model Management',N'Источник Model Management',4,0,38)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 194,N'Проголосовать управления',N'Проголосовать управления',4,0,39)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 195,N'Contenido del modelo de',N'Contenido del modelo de',5,0,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 196,N'Gestión de Contenidos',N'Gestión de Contenidos',5,0,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 197,N'Lista de artículos',N'Lista de artículos',5,0,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 198,N'Lista de software',N'Lista de software',5,0,4)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 199,N'Contenido de la función',N'Contenido de la función',5,0,5)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 200,N'Tag Management',N'Tag Management',5,0,6)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 201,N'Comentario de gestión',N'Comentario de gestión',5,0,7)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 202,N'Generar archivos estáticos',N'Generar archivos estáticos',5,0,8)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 203,N'índice de gestión',N'índice de gestión',5,0,9)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 204,N'Usuario modelo',N'Usuario modelo',5,0,10)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 205,N'Frente usuario',N'Frente usuario',5,0,11)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 206,N'Miembros de la lista',N'Miembros de la lista',5,0,12)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 207,N'Miembro del Grupo',N'Miembro del Grupo',5,0,13)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 208,N'Antecedentes usuario',N'Antecedentes usuario',5,0,14)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 209,N'Administrador de listas',N'Administrador de listas',5,0,15)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 210,N'Lista de papel',N'Lista de papel',5,0,16)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 211,N'Permiso de gestión',N'Permiso de gestión',5,0,17)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 212,N'Ingresar Registrarse',N'Ingresar Registrarse',5,0,18)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 213,N'Online Manager',N'Online Manager',5,0,19)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 214,N'Modelo del sistema',N'Modelo del sistema',5,0,20)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 215,N'Configuración del sistema',N'Configuración del sistema',5,0,21)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 216,N'Configuración del sitio',N'Configuración del sitio',5,0,22)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 217,N'Configuración de seguridad',N'Configuración de seguridad',5,0,23)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 218,N'Ajustes de navegación',N'Ajustes de navegación',5,0,24)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 219,N'Marca de agua Marco',N'Marca de agua Marco',5,0,25)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 220,N'Configuración del correo',N'Configuración del correo',5,0,26)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 221,N'La función del sistema',N'La función del sistema',5,0,27)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 222,N'Copia de seguridad de datos',N'Copia de seguridad de datos',5,0,28)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 223,N'Gestión internacional',N'Gestión internacional',5,0,29)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 224,N'Administración de Archivo',N'Administración de Archivo',5,0,30)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 225,N'Enviar por e-mail',N'Enviar por e-mail',5,0,31)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 226,N'Configuración de plantilla',N'Configuración de plantilla',5,0,32)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 227,N'Juego Etiquetas de Plantilla',N'Juego Etiquetas de Plantilla',5,0,33)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 228,N'Enlaces',N'Enlaces',5,0,34)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 229,N'Descargar Filtro de URL',N'Descargar Filtro de URL',5,0,35)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 230,N'Variable del Sistema Marco',N'Variable del Sistema Marco',5,0,36)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 231,N'El nodo de administración',N'El nodo de administración',5,0,37)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 232,N'Canal Modelo de Gestión',N'Canal Modelo de Gestión',5,0,38)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 233,N'Votación de Gestión',N'Votación de Gestión',5,0,39)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 234,N'内容模型',N'内容模型',0,1,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 235,N'内容管理',N'内容管理',0,1,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 236,N'文章列表',N'文章列表',0,1,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 237,N'添加表单',N'添加表单',0,1,4)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 238,N'添加',N'添加',0,1,5)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 239,N'删除',N'删除',0,1,6)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 240,N'修改表单',N'修改表单',0,1,7)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 241,N'修改',N'修改',0,1,8)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 242,N'软件列表',N'软件列表',0,1,9)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 243,N'添加表单',N'添加表单',0,1,10)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 244,N'添加',N'添加',0,1,11)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 245,N'删除',N'删除',0,1,12)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 246,N'修改表单',N'修改表单',0,1,13)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 247,N'修改',N'修改',0,1,14)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 248,N'内容功能',N'内容功能',0,1,15)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 249,N'删除静态文件',N'删除静态文件',0,1,16)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 250,N'生成静态文件',N'生成静态文件',0,1,17)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 251,N'生成索引文件',N'生成索引文件',0,1,18)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 252,N'标签管理',N'标签管理',0,1,19)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 253,N'删除',N'删除',0,1,20)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 254,N'评论管理',N'评论管理',0,1,21)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 255,N'删除',N'删除',0,1,22)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 256,N'修改表单',N'修改表单',0,1,23)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 257,N'修改',N'修改',0,1,24)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 258,N'管理静态文件',N'管理静态文件',0,1,25)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 259,N'添加',N'添加',0,1,26)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 260,N'索引管理',N'索引管理',0,1,27)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 261,N'添加',N'添加',0,1,28)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 262,N'删除表单',N'删除表单',0,1,29)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 263,N'删除',N'删除',0,1,30)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 264,N'更新表单',N'更新表单',0,1,31)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 265,N'更新',N'更新',0,1,32)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 266,N'栏目管理',N'栏目管理',0,1,33)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 267,N'添加表单',N'添加表单',0,1,34)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 268,N'添加',N'添加',0,1,35)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 269,N'删除',N'删除',0,1,36)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 270,N'修改表单',N'修改表单',0,1,37)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 271,N'修改',N'修改',0,1,38)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 272,N'用户模型',N'用户模型',0,1,39)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 273,N'前台用户',N'前台用户',0,1,40)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 274,N'会员列表',N'会员列表',0,1,41)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 275,N'添加表单',N'添加表单',0,1,42)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 276,N'添加',N'添加',0,1,43)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 277,N'删除',N'删除',0,1,44)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 278,N'修改表单',N'修改表单',0,1,45)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 279,N'修改',N'修改',0,1,46)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 280,N'查看',N'查看',0,1,47)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 281,N'会员组',N'会员组',0,1,48)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 282,N'添加表单',N'添加表单',0,1,49)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 283,N'添加',N'添加',0,1,50)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 284,N'删除',N'删除',0,1,51)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 285,N'修改表单',N'修改表单',0,1,52)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 286,N'修改',N'修改',0,1,53)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 287,N'后台用户',N'后台用户',0,1,54)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 288,N'管理员列表',N'管理员列表',0,1,55)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 289,N'添加管理员表单',N'添加管理员表单',0,1,56)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 290,N'添加管理员',N'添加管理员',0,1,57)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 291,N'删除管理员',N'删除管理员',0,1,58)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 292,N'修改管理员表单',N'修改管理员表单',0,1,59)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 293,N'修改管理员',N'修改管理员',0,1,60)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 294,N'修改角色表单',N'修改角色表单',0,1,61)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 295,N'修改角色',N'修改角色',0,1,62)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 296,N'查看管理员',N'查看管理员',0,1,63)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 297,N'角色列表',N'角色列表',0,1,64)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 298,N'添加角色表单',N'添加角色表单',0,1,65)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 299,N'添加角色',N'添加角色',0,1,66)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 300,N'删除角色',N'删除角色',0,1,67)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 301,N'修改表单',N'修改表单',0,1,68)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 302,N'修改角色',N'修改角色',0,1,69)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 303,N'修改角色权限表单',N'修改角色权限表单',0,1,70)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 304,N'修改角色权限',N'修改角色权限',0,1,71)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 305,N'修改角色导航表单',N'修改角色导航表单',0,1,72)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 306,N'修改角色导航',N'修改角色导航',0,1,73)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 307,N'权限管理',N'权限管理',0,1,74)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 308,N'添加表单',N'添加表单',0,1,75)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 309,N'添加',N'添加',0,1,76)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 310,N'删除',N'删除',0,1,77)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 311,N'修改表单',N'修改表单',0,1,78)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 312,N'修改',N'修改',0,1,79)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 313,N'刷新',N'刷新',0,1,80)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 314,N'登陆日志',N'登陆日志',0,1,81)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 315,N'删除',N'删除',0,1,82)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 316,N'在线管理员',N'在线管理员',0,1,83)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 317,N'删除',N'删除',0,1,84)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 318,N'系统模型',N'系统模型',0,1,85)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 319,N'系统设置',N'系统设置',0,1,86)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 320,N'站点设置',N'站点设置',0,1,87)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 321,N'修改站点',N'修改站点',0,1,88)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 322,N'安全设置',N'安全设置',0,1,89)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 323,N'修改',N'修改',0,1,90)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 324,N'导航设置',N'导航设置',0,1,91)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 325,N'添加表单',N'添加表单',0,1,92)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 326,N'添加',N'添加',0,1,93)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 327,N'删除',N'删除',0,1,94)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 328,N'修改表单',N'修改表单',0,1,95)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 329,N'修改',N'修改',0,1,96)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 330,N'水印设置',N'水印设置',0,1,97)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 331,N'修改',N'修改',0,1,98)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 332,N'邮件设置',N'邮件设置',0,1,99)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 333,N'修改',N'修改',0,1,100)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 334,N'模板设置',N'模板设置',0,1,101)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 335,N'修改',N'修改',0,1,102)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 336,N'模板标签设置',N'模板标签设置',0,1,103)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 337,N'添加表单',N'添加表单',0,1,104)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 338,N'添加',N'添加',0,1,105)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 339,N'删除',N'删除',0,1,106)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 340,N'修改表单',N'修改表单',0,1,107)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 341,N'修改',N'修改',0,1,108)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 342,N'系统变量设置',N'系统变量设置',0,1,109)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 343,N'添加表单',N'添加表单',0,1,110)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 344,N'添加',N'添加',0,1,111)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 345,N'删除',N'删除',0,1,112)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 346,N'修改表单',N'修改表单',0,1,113)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 347,N'修改',N'修改',0,1,114)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 348,N'系统功能',N'系统功能',0,1,115)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 349,N'备份数据',N'备份数据',0,1,116)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 350,N'备份和还原',N'备份和还原',0,1,117)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 351,N'国际化管理',N'国际化管理',0,1,118)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 352,N'添加表单',N'添加表单',0,1,119)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 353,N'添加',N'添加',0,1,120)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 354,N'删除',N'删除',0,1,121)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 355,N'修改表单',N'修改表单',0,1,122)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 356,N'修改',N'修改',0,1,123)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 357,N'文件管理',N'文件管理',0,1,124)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 358,N'上传文件表单',N'上传文件表单',0,1,125)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 359,N'上传文件',N'上传文件',0,1,126)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 360,N'修改文件名表单',N'修改文件名表单',0,1,127)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 361,N'修改文件名',N'修改文件名',0,1,128)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 362,N'修改文件数据表单',N'修改文件数据表单',0,1,129)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 363,N'修改文件数据',N'修改文件数据',0,1,130)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 364,N'删除文件',N'删除文件',0,1,131)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 365,N'创建文件目录',N'创建文件目录',0,1,132)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 366,N'发送邮件',N'发送邮件',0,1,133)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 367,N'发送',N'发送',0,1,134)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 368,N'友情链接',N'友情链接',0,1,135)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 369,N'添加表单',N'添加表单',0,1,136)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 370,N'添加',N'添加',0,1,137)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 371,N'删除',N'删除',0,1,138)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 372,N'修改表单',N'修改表单',0,1,139)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 373,N'修改',N'修改',0,1,140)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 374,N'下载网址过滤',N'下载网址过滤',0,1,141)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 375,N'添加表单',N'添加表单',0,1,142)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 376,N'添加',N'添加',0,1,143)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 377,N'删除',N'删除',0,1,144)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 378,N'修改表单',N'修改表单',0,1,145)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 379,N'修改',N'修改',0,1,146)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 380,N'频道模型管理',N'频道模型管理',0,1,147)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 381,N'添加表单',N'添加表单',0,1,148)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 382,N'添加',N'添加',0,1,149)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 383,N'删除',N'删除',0,1,150)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 384,N'修改表单',N'修改表单',0,1,151)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 385,N'修改',N'修改',0,1,152)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 386,N'投票管理',N'投票管理',0,1,153)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 387,N'添加表单',N'添加表单',0,1,154)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 388,N'添加',N'添加',0,1,155)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 389,N'删除',N'删除',0,1,156)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 390,N'修改表单',N'修改表单',0,1,157)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 391,N'修改',N'修改',0,1,158)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 392,N'后台首页',N'后台首页',0,1,159)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 393,N'Content Model',N'Content Model',1,1,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 394,N'Content Management',N'Content Management',1,1,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 395,N'Article list',N'Article list',1,1,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 396,N'Add Form',N'Add Form',1,1,4)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 397,N'Add',N'Add',1,1,5)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 398,N'Delete',N'Delete',1,1,6)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 399,N'Modified Form',N'Modified Form',1,1,7)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 400,N'Modify',N'Modify',1,1,8)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 401,N'Software List',N'Software List',1,1,9)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 402,N'Add Form',N'Add Form',1,1,10)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 403,N'Add',N'Add',1,1,11)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 404,N'Delete',N'Delete',1,1,12)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 405,N'Modified Form',N'Modified Form',1,1,13)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 406,N'Modify',N'Modify',1,1,14)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 407,N'Content Function',N'Content Function',1,1,15)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 408,N'Delete Static File',N'Delete Static File',1,1,16)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 409,N'Generate Static File',N'Generate Static File',1,1,17)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 410,N'Generate Index File',N'Generate Index File',1,1,18)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 411,N'Tag Management',N'Tag Management',1,1,19)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 412,N'Delete',N'Delete',1,1,20)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 413,N'Comment Management',N'Comment Management',1,1,21)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 414,N'Delete',N'Delete',1,1,22)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 415,N'Modified Form',N'Modified Form',1,1,23)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 416,N'Modify',N'Modify',1,1,24)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 417,N'Management Static File',N'Management Static File',1,1,25)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 418,N'Add',N'Add',1,1,26)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 419,N'Index Management',N'Index Management',1,1,27)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 420,N'Add',N'Add',1,1,28)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 421,N'Delete Form',N'Delete Form',1,1,29)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 422,N'Delete',N'Delete',1,1,30)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 423,N'Update Form',N'Update Form',1,1,31)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 424,N'Update',N'Update',1,1,32)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 425,N'Node Management',N'Node Management',1,1,33)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 426,N'Add Form',N'Add Form',1,1,34)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 427,N'Add',N'Add',1,1,35)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 428,N'Delete',N'Delete',1,1,36)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 429,N'Modified Form',N'Modified Form',1,1,37)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 430,N'Modify',N'Modify',1,1,38)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 431,N'User Model',N'User Model',1,1,39)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 432,N'Front Users',N'Front Users',1,1,40)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 433,N'Members List',N'Members List',1,1,41)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 434,N'Add Form',N'Add Form',1,1,42)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 435,N'Add',N'Add',1,1,43)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 436,N'Delete',N'Delete',1,1,44)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 437,N'Modified Form',N'Modified Form',1,1,45)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 438,N'Modify',N'Modify',1,1,46)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 439,N'View',N'View',1,1,47)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 440,N'Member Group',N'Member Group',1,1,48)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 441,N'Add Form',N'Add Form',1,1,49)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 442,N'Add',N'Add',1,1,50)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 443,N'Delete',N'Delete',1,1,51)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 444,N'Modified Form',N'Modified Form',1,1,52)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 445,N'Modify',N'Modify',1,1,53)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 446,N'Background User',N'Background User',1,1,54)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 447,N'Manager List',N'Manager List',1,1,55)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 448,N'Add Administrator Form',N'Add Administrator Form',1,1,56)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 449,N'Add Administrator',N'Add Administrator',1,1,57)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 450,N'Remove administrator',N'Remove administrator',1,1,58)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 451,N'Change administrator Form',N'Change administrator Form',1,1,59)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 452,N'Change administrator',N'Change administrator',1,1,60)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 453,N'Modify Role Form',N'Modify Role Form',1,1,61)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 454,N'Modify Role',N'Modify Role',1,1,62)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 455,N'View Manager',N'View Manager',1,1,63)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 456,N'Role List',N'Role List',1,1,64)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 457,N'Add Role Form',N'Add Role Form',1,1,65)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 458,N'Add Role',N'Add Role',1,1,66)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 459,N'Delete Role',N'Delete Role',1,1,67)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 460,N'Modified Form',N'Modified Form',1,1,68)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 461,N'Modify the role',N'Modify the role',1,1,69)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 462,N'Modify Role Permission Form',N'Modify Role Permission Form',1,1,70)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 463,N'Modify Role Permission',N'Modify Role Permission',1,1,71)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 464,N'Modify Role Navigation Form',N'Modify Role Navigation Form',1,1,72)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 465,N'Modify Role Navigation',N'Modify Role Navigation',1,1,73)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 466,N'Permission Management',N'Permission Management',1,1,74)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 467,N'Add Form',N'Add Form',1,1,75)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 468,N'Add',N'Add',1,1,76)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 469,N'Delete',N'Delete',1,1,77)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 470,N'Modified Form',N'Modified Form',1,1,78)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 471,N'Modify',N'Modify',1,1,79)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 472,N'Refresh',N'Refresh',1,1,80)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 473,N'Login Log',N'Login Log',1,1,81)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 474,N'Delete',N'Delete',1,1,82)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 475,N'Online Manager',N'Online Manager',1,1,83)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 476,N'Delete',N'Delete',1,1,84)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 477,N'System Model',N'System Model',1,1,85)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 478,N'System Setting',N'System Setting',1,1,86)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 479,N'Site Setting',N'Site Setting',1,1,87)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 480,N'Modify Site',N'Modify Site',1,1,88)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 481,N'Security Setting',N'Security Setting',1,1,89)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 482,N'Modify',N'Modify',1,1,90)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 483,N'Navigation settings',N'Navigation settings',1,1,91)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 484,N'Add Form',N'Add Form',1,1,92)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 485,N'Add',N'Add',1,1,93)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 486,N'Delete',N'Delete',1,1,94)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 487,N'Modified Form',N'Modified Form',1,1,95)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 488,N'Modify',N'Modify',1,1,96)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 489,N'Watermark',N'Watermark',1,1,97)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 490,N'Modify',N'Modify',1,1,98)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 491,N'Mail Setting',N'Mail Setting',1,1,99)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 492,N'Modify',N'Modify',1,1,100)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 493,N'Template Setting',N'Template Setting',1,1,101)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 494,N'Modify',N'Modify',1,1,102)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 495,N'Template Tag Setting',N'Template Tag Setting',1,1,103)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 496,N'Add Form',N'Add Form',1,1,104)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 497,N'Add',N'Add',1,1,105)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 498,N'Delete',N'Delete',1,1,106)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 499,N'Modified Form',N'Modified Form',1,1,107)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 500,N'Modify',N'Modify',1,1,108)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 501,N'System Variable Setting',N'System Variable Setting',1,1,109)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 502,N'Add Form',N'Add Form',1,1,110)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 503,N'Add',N'Add',1,1,111)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 504,N'Delete',N'Delete',1,1,112)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 505,N'Modified Form',N'Modified Form',1,1,113)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 506,N'Modify',N'Modify',1,1,114)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 507,N'System function',N'System function',1,1,115)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 508,N'Backup Data',N'Backup Data',1,1,116)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 509,N'Backup And Restore',N'Backup And Restore',1,1,117)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 510,N'International management',N'International management',1,1,118)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 511,N'Add Form',N'Add Form',1,1,119)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 512,N'Add',N'Add',1,1,120)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 513,N'Delete',N'Delete',1,1,121)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 514,N'Modified Form',N'Modified Form',1,1,122)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 515,N'Modify',N'Modify',1,1,123)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 516,N'Document Management',N'Document Management',1,1,124)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 517,N'Upload Form',N'Upload Form',1,1,125)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 518,N'Upload File',N'Upload File',1,1,126)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 519,N'Modify File Name Form',N'Modify File Name Form',1,1,127)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 520,N'Modify File Name',N'Modify File Name',1,1,128)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 521,N'Modify File Data Form',N'Modify File Data Form',1,1,129)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 522,N'Modify File Data',N'Modify File Data',1,1,130)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 523,N'Delete File',N'Delete File',1,1,131)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 524,N'Create File Directory',N'Create File Directory',1,1,132)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 525,N'Send e-mail',N'Send e-mail',1,1,133)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 526,N'Send',N'Send',1,1,134)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 527,N'Link',N'Link',1,1,135)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 528,N'Add Form',N'Add Form',1,1,136)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 529,N'Add',N'Add',1,1,137)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 530,N'Delete',N'Delete',1,1,138)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 531,N'Modified Form',N'Modified Form',1,1,139)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 532,N'Modify',N'Modify',1,1,140)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 533,N'Download URL filter',N'Download URL filter',1,1,141)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 534,N'Add Form',N'Add Form',1,1,142)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 535,N'Add',N'Add',1,1,143)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 536,N'Delete',N'Delete',1,1,144)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 537,N'Modified Form',N'Modified Form',1,1,145)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 538,N'Modify',N'Modify',1,1,146)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 539,N'Channel Model Management',N'Channel Model Management',1,1,147)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 540,N'Add Form',N'Add Form',1,1,148)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 541,N'Add',N'Add',1,1,149)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 542,N'Delete',N'Delete',1,1,150)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 543,N'Modified Form',N'Modified Form',1,1,151)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 544,N'Modify',N'Modify',1,1,152)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 545,N'Vote Management',N'Vote Management',1,1,153)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 546,N'Add Form',N'Add Form',1,1,154)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 547,N'Add',N'Add',1,1,155)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 548,N'Delete',N'Delete',1,1,156)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 549,N'Modified Form',N'Modified Form',1,1,157)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 550,N'Modify',N'Modify',1,1,158)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 551,N'Background Home',N'Background Home',1,1,159)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 552,N'?內容模型',N'?內容模型',2,1,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 553,N'內容管理',N'內容管理',2,1,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 554,N'文章列表',N'文章列表',2,1,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 555,N'添加表單',N'添加表單',2,1,4)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 556,N'添加',N'添加',2,1,5)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 557,N'刪除',N'刪除',2,1,6)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 558,N'修改表單',N'修改表單',2,1,7)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 559,N'修改',N'修改',2,1,8)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 560,N'軟件列表',N'軟件列表',2,1,9)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 561,N'添加表單',N'添加表單',2,1,10)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 562,N'添加',N'添加',2,1,11)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 563,N'刪除',N'刪除',2,1,12)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 564,N'修改表單',N'修改表單',2,1,13)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 565,N'修改',N'修改',2,1,14)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 566,N'內容功能',N'內容功能',2,1,15)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 567,N'刪除靜態文件',N'刪除靜態文件',2,1,16)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 568,N'生成靜態文件',N'生成靜態文件',2,1,17)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 569,N'生成索引文件',N'生成索引文件',2,1,18)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 570,N'標籤管理',N'標籤管理',2,1,19)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 571,N'刪除',N'刪除',2,1,20)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 572,N'評論管理',N'評論管理',2,1,21)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 573,N'刪除',N'刪除',2,1,22)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 574,N'修改表單',N'修改表單',2,1,23)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 575,N'修改',N'修改',2,1,24)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 576,N'管理靜態文件',N'管理靜態文件',2,1,25)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 577,N'添加',N'添加',2,1,26)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 578,N'索引管理',N'索引管理',2,1,27)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 579,N'添加',N'添加',2,1,28)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 580,N'刪除表單',N'刪除表單',2,1,29)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 581,N'刪除',N'刪除',2,1,30)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 582,N'更新表單',N'更新表單',2,1,31)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 583,N'更新',N'更新',2,1,32)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 584,N'欄目管理',N'欄目管理',2,1,33)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 585,N'添加表單',N'添加表單',2,1,34)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 586,N'添加',N'添加',2,1,35)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 587,N'刪除',N'刪除',2,1,36)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 588,N'修改表單',N'修改表單',2,1,37)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 589,N'修改',N'修改',2,1,38)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 590,N'用戶模型',N'用戶模型',2,1,39)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 591,N'前台用戶',N'前台用戶',2,1,40)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 592,N'會員列表',N'會員列表',2,1,41)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 593,N'添加表單',N'添加表單',2,1,42)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 594,N'添加',N'添加',2,1,43)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 595,N'刪除',N'刪除',2,1,44)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 596,N'修改表單',N'修改表單',2,1,45)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 597,N'修改',N'修改',2,1,46)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 598,N'查看',N'查看',2,1,47)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 599,N'會員組',N'會員組',2,1,48)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 600,N'添加表單',N'添加表單',2,1,49)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 601,N'添加',N'添加',2,1,50)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 602,N'刪除',N'刪除',2,1,51)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 603,N'修改表單',N'修改表單',2,1,52)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 604,N'修改',N'修改',2,1,53)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 605,N'後台用戶',N'後台用戶',2,1,54)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 606,N'管理員列表',N'管理員列表',2,1,55)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 607,N'添加管理員表單',N'添加管理員表單',2,1,56)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 608,N'添加管理員',N'添加管理員',2,1,57)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 609,N'刪除管理員',N'刪除管理員',2,1,58)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 610,N'修改管理員表單',N'修改管理員表單',2,1,59)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 611,N'修改管理員',N'修改管理員',2,1,60)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 612,N'修改角色表單',N'修改角色表單',2,1,61)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 613,N'修改角色',N'修改角色',2,1,62)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 614,N'查看管理員',N'查看管理員',2,1,63)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 615,N'角色列表',N'角色列表',2,1,64)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 616,N'添加角色表單',N'添加角色表單',2,1,65)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 617,N'添加角色',N'添加角色',2,1,66)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 618,N'刪除角色',N'刪除角色',2,1,67)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 619,N'修改表單',N'修改表單',2,1,68)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 620,N'修改角色',N'修改角色',2,1,69)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 621,N'修改角色權限表單',N'修改角色權限表單',2,1,70)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 622,N'修改角色權限',N'修改角色權限',2,1,71)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 623,N'修改角色導航表單',N'修改角色導航表單',2,1,72)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 624,N'修改角色導航',N'修改角色導航',2,1,73)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 625,N'權限管理',N'權限管理',2,1,74)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 626,N'添加表單',N'添加表單',2,1,75)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 627,N'添加',N'添加',2,1,76)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 628,N'刪除',N'刪除',2,1,77)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 629,N'修改表單',N'修改表單',2,1,78)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 630,N'修改',N'修改',2,1,79)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 631,N'刷新',N'刷新',2,1,80)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 632,N'登陸日誌',N'登陸日誌',2,1,81)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 633,N'刪除',N'刪除',2,1,82)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 634,N'在線管理員',N'在線管理員',2,1,83)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 635,N'刪除',N'刪除',2,1,84)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 636,N'系統模型',N'系統模型',2,1,85)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 637,N'系統設置',N'系統設置',2,1,86)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 638,N'站點設置',N'站點設置',2,1,87)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 639,N'修改站點',N'修改站點',2,1,88)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 640,N'安全設置',N'安全設置',2,1,89)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 641,N'修改',N'修改',2,1,90)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 642,N'導航設置',N'導航設置',2,1,91)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 643,N'添加表單',N'添加表單',2,1,92)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 644,N'添加',N'添加',2,1,93)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 645,N'刪除',N'刪除',2,1,94)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 646,N'修改表單',N'修改表單',2,1,95)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 647,N'修改',N'修改',2,1,96)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 648,N'水印設置',N'水印設置',2,1,97)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 649,N'修改',N'修改',2,1,98)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 650,N'郵件設置',N'郵件設置',2,1,99)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 651,N'修改',N'修改',2,1,100)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 652,N'模板設置',N'模板設置',2,1,101)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 653,N'修改',N'修改',2,1,102)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 654,N'模板標籤設置',N'模板標籤設置',2,1,103)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 655,N'添加表單',N'添加表單',2,1,104)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 656,N'添加',N'添加',2,1,105)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 657,N'刪除',N'刪除',2,1,106)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 658,N'修改表單',N'修改表單',2,1,107)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 659,N'修改',N'修改',2,1,108)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 660,N'系統變量設置',N'系統變量設置',2,1,109)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 661,N'添加表單',N'添加表單',2,1,110)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 662,N'添加',N'添加',2,1,111)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 663,N'刪除',N'刪除',2,1,112)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 664,N'修改表單',N'修改表單',2,1,113)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 665,N'修改',N'修改',2,1,114)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 666,N'系統功能',N'系統功能',2,1,115)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 667,N'備份數據',N'備份數據',2,1,116)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 668,N'備份和還原',N'備份和還原',2,1,117)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 669,N'國際化管理',N'國際化管理',2,1,118)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 670,N'添加表單',N'添加表單',2,1,119)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 671,N'添加',N'添加',2,1,120)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 672,N'刪除',N'刪除',2,1,121)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 673,N'修改表單',N'修改表單',2,1,122)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 674,N'修改',N'修改',2,1,123)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 675,N'文件管理',N'文件管理',2,1,124)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 676,N'上傳文件表單',N'上傳文件表單',2,1,125)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 677,N'上傳文件',N'上傳文件',2,1,126)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 678,N'修改文件名表單',N'修改文件名表單',2,1,127)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 679,N'修改文件名',N'修改文件名',2,1,128)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 680,N'修改文件數據表單',N'修改文件數據表單',2,1,129)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 681,N'修改文件數據',N'修改文件數據',2,1,130)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 682,N'刪除文件',N'刪除文件',2,1,131)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 683,N'創建文件目錄',N'創建文件目錄',2,1,132)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 684,N'發送郵件',N'發送郵件',2,1,133)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 685,N'發送',N'發送',2,1,134)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 686,N'友情鏈接',N'友情鏈接',2,1,135)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 687,N'添加表單',N'添加表單',2,1,136)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 688,N'添加',N'添加',2,1,137)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 689,N'刪除',N'刪除',2,1,138)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 690,N'修改表單',N'修改表單',2,1,139)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 691,N'修改',N'修改',2,1,140)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 692,N'下載網址過濾',N'下載網址過濾',2,1,141)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 693,N'添加表單',N'添加表單',2,1,142)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 694,N'添加',N'添加',2,1,143)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 695,N'刪除',N'刪除',2,1,144)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 696,N'修改表單',N'修改表單',2,1,145)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 697,N'修改',N'修改',2,1,146)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 698,N'頻道模型管理',N'頻道模型管理',2,1,147)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 699,N'添加表單',N'添加表單',2,1,148)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 700,N'添加',N'添加',2,1,149)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 701,N'刪除',N'刪除',2,1,150)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 702,N'修改表單',N'修改表單',2,1,151)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 703,N'修改',N'修改',2,1,152)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 704,N'投票管理',N'投票管理',2,1,153)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 705,N'添加表單',N'添加表單',2,1,154)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 706,N'添加',N'添加',2,1,155)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 707,N'刪除',N'刪除',2,1,156)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 708,N'修改表單',N'修改表單',2,1,157)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 709,N'修改',N'修改',2,1,158)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 710,N'後台首頁',N'後台首頁',2,1,159)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 711,N'?コンテンツモデル',N'?コンテンツモデル',3,1,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 712,N'コンテンツ管理',N'コンテンツ管理',3,1,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 713,N'記事一覧',N'記事一覧',3,1,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 714,N'形成するに追加',N'形成するに追加',3,1,4)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 715,N'追加',N'追加',3,1,5)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 716,N'削除',N'削除',3,1,6)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 717,N'変更フォーム',N'変更フォーム',3,1,7)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 718,N'変更',N'変更',3,1,8)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 719,N'ソフトウェア一覧',N'ソフトウェア一覧',3,1,9)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 720,N'形成するに追加',N'形成するに追加',3,1,10)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 721,N'追加',N'追加',3,1,11)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 722,N'削除',N'削除',3,1,12)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 723,N'変更フォーム',N'変更フォーム',3,1,13)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 724,N'変更',N'変更',3,1,14)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 725,N'コンテンツ関数',N'コンテンツ関数',3,1,15)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 726,N'削除する静的ファイル',N'削除する静的ファイル',3,1,16)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 727,N'を生成する静的ファイル',N'を生成する静的ファイル',3,1,17)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 728,N'を生成するインデックスファイル',N'を生成するインデックスファイル',3,1,18)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 729,N'タグ管理',N'タグ管理',3,1,19)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 730,N'削除',N'削除',3,1,20)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 731,N'コメント管理',N'コメント管理',3,1,21)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 732,N'削除',N'削除',3,1,22)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 733,N'変更フォーム',N'変更フォーム',3,1,23)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 734,N'変更',N'変更',3,1,24)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 735,N'管理静的ファイル',N'管理静的ファイル',3,1,25)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 736,N'追加',N'追加',3,1,26)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 737,N'インデックス管理',N'インデックス管理',3,1,27)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 738,N'追加',N'追加',3,1,28)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 739,N'削除フォーム',N'削除フォーム',3,1,29)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 740,N'削除',N'削除',3,1,30)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 741,N'更新フォーム',N'更新フォーム',3,1,31)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 742,N'更新',N'更新',3,1,32)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 743,N'ローカル管理',N'ローカル管理',3,1,33)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 744,N'形成するに追加',N'形成するに追加',3,1,34)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 745,N'追加',N'追加',3,1,35)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 746,N'削除',N'削除',3,1,36)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 747,N'変更フォーム',N'変更フォーム',3,1,37)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 748,N'変更',N'変更',3,1,38)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 749,N'ユーザーモデル',N'ユーザーモデル',3,1,39)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 750,N'フロントユーザー',N'フロントユーザー',3,1,40)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 751,N'メンバーリスト',N'メンバーリスト',3,1,41)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 752,N'形成するに追加',N'形成するに追加',3,1,42)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 753,N'追加',N'追加',3,1,43)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 754,N'削除',N'削除',3,1,44)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 755,N'変更フォーム',N'変更フォーム',3,1,45)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 756,N'変更',N'変更',3,1,46)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 757,N'友達',N'友達',3,1,47)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 758,N'会員グループ',N'会員グループ',3,1,48)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 759,N'形成するに追加',N'形成するに追加',3,1,49)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 760,N'追加',N'追加',3,1,50)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 761,N'削除',N'削除',3,1,51)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 762,N'変更フォーム',N'変更フォーム',3,1,52)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 763,N'変更',N'変更',3,1,53)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 764,N'背景ユーザー',N'背景ユーザー',3,1,54)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 765,N'マネージャのリスト',N'マネージャのリスト',3,1,55)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 766,N'管理者の追加フォーム',N'管理者の追加フォーム',3,1,56)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 767,N'管理者の追加',N'管理者の追加',3,1,57)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 768,N'管理者を削除する',N'管理者を削除する',3,1,58)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 769,N'管理フォームを変更します。',N'管理フォームを変更します。',3,1,59)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 770,N'管理者を変更する',N'管理者を変更する',3,1,60)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 771,N'フォームの変更の役割',N'フォームの変更の役割',3,1,61)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 772,N'変更の役割',N'変更の役割',3,1,62)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 773,N'ビューマネージャ',N'ビューマネージャ',3,1,63)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 774,N'ロールのリスト',N'ロールのリスト',3,1,64)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 775,N'役割の追加フォーム',N'役割の追加フォーム',3,1,65)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 776,N'役割の追加',N'役割の追加',3,1,66)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 777,N'削除する役割',N'削除する役割',3,1,67)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 778,N'変更フォーム',N'変更フォーム',3,1,68)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 779,N'変更の役割',N'変更の役割',3,1,69)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 780,N'変更ロール権限が形成さ',N'変更ロール権限が形成さ',3,1,70)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 781,N'変更ロール権限',N'変更ロール権限',3,1,71)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 782,N'ナビゲーションフォームの変更の役割',N'ナビゲーションフォームの変更の役割',3,1,72)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 783,N'ナビゲーションの変更の役割',N'ナビゲーションの変更の役割',3,1,73)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 784,N'パーミッション管理',N'パーミッション管理',3,1,74)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 785,N'形成するに追加',N'形成するに追加',3,1,75)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 786,N'追加',N'追加',3,1,76)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 787,N'削除',N'削除',3,1,77)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 788,N'変更フォーム',N'変更フォーム',3,1,78)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 789,N'変更',N'変更',3,1,79)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 790,N'リフレッシュ',N'リフレッシュ',3,1,80)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 791,N'ログログ',N'ログログ',3,1,81)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 792,N'削除',N'削除',3,1,82)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 793,N'オンラインマネージャ',N'オンラインマネージャ',3,1,83)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 794,N'削除',N'削除',3,1,84)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 795,N'システムモデル',N'システムモデル',3,1,85)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 796,N'システム設定',N'システム設定',3,1,86)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 797,N'サイトの設定',N'サイトの設定',3,1,87)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 798,N'変更サイト',N'変更サイト',3,1,88)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 799,N'セキュリティの設定',N'セキュリティの設定',3,1,89)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 800,N'変更',N'変更',3,1,90)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 801,N'ナビゲーション設定',N'ナビゲーション設定',3,1,91)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 802,N'形成するに追加',N'形成するに追加',3,1,92)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 803,N'追加',N'追加',3,1,93)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 804,N'削除',N'削除',3,1,94)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 805,N'変更フォーム',N'変更フォーム',3,1,95)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 806,N'変更',N'変更',3,1,96)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 807,N'透かし',N'透かし',3,1,97)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 808,N'変更',N'変更',3,1,98)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 809,N'メール設定',N'メール設定',3,1,99)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 810,N'変更',N'変更',3,1,100)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 811,N'テンプレートの設定',N'テンプレートの設定',3,1,101)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 812,N'変更',N'変更',3,1,102)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 813,N'設定テンプレートタグ',N'設定テンプレートタグ',3,1,103)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 814,N'形成するに追加',N'形成するに追加',3,1,104)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 815,N'追加',N'追加',3,1,105)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 816,N'削除',N'削除',3,1,106)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 817,N'変更フォーム',N'変更フォーム',3,1,107)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 818,N'変更',N'変更',3,1,108)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 819,N'システム変数が設定されている',N'システム変数が設定されている',3,1,109)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 820,N'形成するに追加',N'形成するに追加',3,1,110)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 821,N'追加',N'追加',3,1,111)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 822,N'削除',N'削除',3,1,112)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 823,N'変更フォーム',N'変更フォーム',3,1,113)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 824,N'変更',N'変更',3,1,114)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 825,N'システム関数',N'システム関数',3,1,115)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 826,N'バックアップデータ',N'バックアップデータ',3,1,116)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 827,N'バックアップと復元',N'バックアップと復元',3,1,117)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 828,N'国際管理',N'国際管理',3,1,118)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 829,N'形成するに追加',N'形成するに追加',3,1,119)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 830,N'追加',N'追加',3,1,120)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 831,N'削除',N'削除',3,1,121)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 832,N'変更フォーム',N'変更フォーム',3,1,122)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 833,N'変更',N'変更',3,1,123)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 834,N'ドキュメント管理',N'ドキュメント管理',3,1,124)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 835,N'アップロードフォーム',N'アップロードフォーム',3,1,125)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 836,N'ファイルをアップロード',N'ファイルをアップロード',3,1,126)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 837,N'修正ファイル名の形式',N'修正ファイル名の形式',3,1,127)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 838,N'修正ファイル名',N'修正ファイル名',3,1,128)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 839,N'修正ファイルのデータが形成さ',N'修正ファイルのデータが形成さ',3,1,129)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 840,N'ファイルを変更しデータ',N'ファイルを変更しデータ',3,1,130)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 841,N'ファイルを削除する',N'ファイルを削除する',3,1,131)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 842,N'ファイルのディレクトリを作成します。',N'ファイルのディレクトリを作成します。',3,1,132)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 843,N'電子メールを送信する',N'電子メールを送信する',3,1,133)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 844,N'送信',N'送信',3,1,134)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 845,N'リンク',N'リンク',3,1,135)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 846,N'形成するに追加',N'形成するに追加',3,1,136)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 847,N'追加',N'追加',3,1,137)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 848,N'削除',N'削除',3,1,138)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 849,N'変更フォーム',N'変更フォーム',3,1,139)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 850,N'変更',N'変更',3,1,140)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 851,N'ダウンロードURLフィルタリング',N'ダウンロードURLフィルタリング',3,1,141)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 852,N'形成するに追加',N'形成するに追加',3,1,142)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 853,N'追加',N'追加',3,1,143)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 854,N'削除',N'削除',3,1,144)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 855,N'変更フォーム',N'変更フォーム',3,1,145)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 856,N'変更',N'変更',3,1,146)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 857,N'チャネルモデルの管理',N'チャネルモデルの管理',3,1,147)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 858,N'形成するに追加',N'形成するに追加',3,1,148)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 859,N'追加',N'追加',3,1,149)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 860,N'削除',N'削除',3,1,150)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 861,N'変更フォーム',N'変更フォーム',3,1,151)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 862,N'変更',N'変更',3,1,152)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 863,N'投票管理',N'投票管理',3,1,153)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 864,N'形成するに追加',N'形成するに追加',3,1,154)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 865,N'追加',N'追加',3,1,155)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 866,N'削除',N'削除',3,1,156)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 867,N'変更フォーム',N'変更フォーム',3,1,157)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 868,N'変更',N'変更',3,1,158)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 869,N'背景ホーム',N'背景ホーム',3,1,159)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 870,N'?Модель содержимого',N'?Модель содержимого',4,1,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 871,N'Управление контентом',N'Управление контентом',4,1,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 872,N'Список статей',N'Список статей',4,1,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 873,N'Добавить форме',N'Добавить форме',4,1,4)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 874,N'Добавить',N'Добавить',4,1,5)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 875,N'Удалить',N'Удалить',4,1,6)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 876,N'Измененном виде',N'Измененном виде',4,1,7)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 877,N'Изменить',N'Изменить',4,1,8)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 878,N'Список программного обеспечения',N'Список программного обеспечения',4,1,9)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 879,N'Добавить форме',N'Добавить форме',4,1,10)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 880,N'Добавить',N'Добавить',4,1,11)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 881,N'Удалить',N'Удалить',4,1,12)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 882,N'Измененном виде',N'Измененном виде',4,1,13)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 883,N'Изменить',N'Изменить',4,1,14)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 884,N'Содержание особенности',N'Содержание особенности',4,1,15)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 885,N'Удалить статических файлов',N'Удалить статических файлов',4,1,16)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 886,N'Создание статических файлов',N'Создание статических файлов',4,1,17)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 887,N'Создание индексных файлов',N'Создание индексных файлов',4,1,18)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 888,N'Управление метками',N'Управление метками',4,1,19)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 889,N'Удалить',N'Удалить',4,1,20)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 890,N'Комментарий управления',N'Комментарий управления',4,1,21)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 891,N'Удалить',N'Удалить',4,1,22)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 892,N'Измененном виде',N'Измененном виде',4,1,23)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 893,N'Изменить',N'Изменить',4,1,24)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 894,N'Управление статического файла',N'Управление статического файла',4,1,25)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 895,N'Добавить',N'Добавить',4,1,26)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 896,N'Индекс управления',N'Индекс управления',4,1,27)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 897,N'Добавить',N'Добавить',4,1,28)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 898,N'Удалить вид',N'Удалить вид',4,1,29)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 899,N'Удалить',N'Удалить',4,1,30)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 900,N'Обновление формы',N'Обновление формы',4,1,31)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 901,N'Обновление',N'Обновление',4,1,32)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 902,N'Местное управление',N'Местное управление',4,1,33)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 903,N'Добавить форме',N'Добавить форме',4,1,34)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 904,N'Добавить',N'Добавить',4,1,35)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 905,N'Удалить',N'Удалить',4,1,36)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 906,N'Измененном виде',N'Измененном виде',4,1,37)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 907,N'Изменить',N'Изменить',4,1,38)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 908,N'Пользователь модели',N'Пользователь модели',4,1,39)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 909,N'Отдел пользователя',N'Отдел пользователя',4,1,40)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 910,N'Пользователи',N'Пользователи',4,1,41)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 911,N'Добавить форме',N'Добавить форме',4,1,42)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 912,N'Добавить',N'Добавить',4,1,43)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 913,N'Удалить',N'Удалить',4,1,44)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 914,N'Измененном виде',N'Измененном виде',4,1,45)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 915,N'Изменить',N'Изменить',4,1,46)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 916,N'Открыть',N'Открыть',4,1,47)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 917,N'Группа',N'Группа',4,1,48)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 918,N'Добавить форме',N'Добавить форме',4,1,49)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 919,N'Добавить',N'Добавить',4,1,50)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 920,N'Удалить',N'Удалить',4,1,51)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 921,N'Измененном виде',N'Измененном виде',4,1,52)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 922,N'Изменить',N'Изменить',4,1,53)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 923,N'Справочная пользователя',N'Справочная пользователя',4,1,54)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 924,N'Менеджер Список',N'Менеджер Список',4,1,55)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 925,N'Добавить администратора форме',N'Добавить администратора форме',4,1,56)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 926,N'Добавить администратора',N'Добавить администратора',4,1,57)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 927,N'Удалить администратора',N'Удалить администратора',4,1,58)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 928,N'Изменение формы администратора',N'Изменение формы администратора',4,1,59)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 929,N'Изменение администратора',N'Изменение администратора',4,1,60)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 930,N'Изменить роль формы',N'Изменить роль формы',4,1,61)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 931,N'Изменить роль',N'Изменить роль',4,1,62)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 932,N'View Manager',N'View Manager',4,1,63)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 933,N'Список ролей',N'Список ролей',4,1,64)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 934,N'Добавить Роль формы',N'Добавить Роль формы',4,1,65)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 935,N'Добавить роль',N'Добавить роль',4,1,66)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 936,N'Удалить роль',N'Удалить роль',4,1,67)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 937,N'Измененном виде',N'Измененном виде',4,1,68)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 938,N'Изменить роль',N'Изменить роль',4,1,69)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 939,N'Изменить разрешения роль формы',N'Изменить разрешения роль формы',4,1,70)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 940,N'разрешения Изменить роль',N'разрешения Изменить роль',4,1,71)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 941,N'Изменить роль навигации форме',N'Изменить роль навигации форме',4,1,72)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 942,N'Изменить роль навигации',N'Изменить роль навигации',4,1,73)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 943,N'Управление правами',N'Управление правами',4,1,74)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 944,N'Добавить форме',N'Добавить форме',4,1,75)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 945,N'Добавить',N'Добавить',4,1,76)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 946,N'Удалить',N'Удалить',4,1,77)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 947,N'Измененном виде',N'Измененном виде',4,1,78)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 948,N'Изменить',N'Изменить',4,1,79)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 949,N'Обновить',N'Обновить',4,1,80)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 950,N'Вход Вход',N'Вход Вход',4,1,81)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 951,N'Удалить',N'Удалить',4,1,82)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 952,N'Интернет Manager',N'Интернет Manager',4,1,83)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 953,N'Удалить',N'Удалить',4,1,84)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 954,N'Модель системы',N'Модель системы',4,1,85)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 955,N'Настройки системы',N'Настройки системы',4,1,86)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 956,N'Параметры сайта',N'Параметры сайта',4,1,87)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 957,N'Изменить сайт',N'Изменить сайт',4,1,88)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 958,N'Настройки безопасности',N'Настройки безопасности',4,1,89)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 959,N'Изменить',N'Изменить',4,1,90)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 960,N'Навигация настройки',N'Навигация настройки',4,1,91)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 961,N'Добавить форме',N'Добавить форме',4,1,92)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 962,N'Добавить',N'Добавить',4,1,93)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 963,N'Удалить',N'Удалить',4,1,94)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 964,N'Измененном виде',N'Измененном виде',4,1,95)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 965,N'Изменить',N'Изменить',4,1,96)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 966,N'Водяной знак',N'Водяной знак',4,1,97)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 967,N'Изменить',N'Изменить',4,1,98)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 968,N'Настройки почты',N'Настройки почты',4,1,99)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 969,N'Изменить',N'Изменить',4,1,100)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 970,N'Параметры шаблона',N'Параметры шаблона',4,1,101)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 971,N'Изменить',N'Изменить',4,1,102)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 972,N'Теги набор шаблонов',N'Теги набор шаблонов',4,1,103)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 973,N'Добавить форме',N'Добавить форме',4,1,104)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 974,N'Добавить',N'Добавить',4,1,105)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 975,N'Удалить',N'Удалить',4,1,106)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 976,N'Измененном виде',N'Измененном виде',4,1,107)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 977,N'Изменить',N'Изменить',4,1,108)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 978,N'Система переменная установлена',N'Система переменная установлена',4,1,109)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 979,N'Добавить форме',N'Добавить форме',4,1,110)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 980,N'Добавить',N'Добавить',4,1,111)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 981,N'Удалить',N'Удалить',4,1,112)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 982,N'Измененном виде',N'Измененном виде',4,1,113)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 983,N'Изменить',N'Изменить',4,1,114)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 984,N'Система функции',N'Система функции',4,1,115)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 985,N'Резервное копирование данных',N'Резервное копирование данных',4,1,116)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 986,N'Резервное копирование и восстановление',N'Резервное копирование и восстановление',4,1,117)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 987,N'Международный менеджмент',N'Международный менеджмент',4,1,118)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 988,N'Добавить форме',N'Добавить форме',4,1,119)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 989,N'Добавить',N'Добавить',4,1,120)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 990,N'Удалить',N'Удалить',4,1,121)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 991,N'Измененном виде',N'Измененном виде',4,1,122)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 992,N'Изменить',N'Изменить',4,1,123)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 993,N'Управление документами',N'Управление документами',4,1,124)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 994,N'Форма для закачки',N'Форма для закачки',4,1,125)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 995,N'Загрузить файл',N'Загрузить файл',4,1,126)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 996,N'Изменить форму названия файла',N'Изменить форму названия файла',4,1,127)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 997,N'Изменить имя файла',N'Изменить имя файла',4,1,128)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 998,N'Внесите изменения в файл данных формы',N'Внесите изменения в файл данных формы',4,1,129)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 999,N'Изменить файл данных',N'Изменить файл данных',4,1,130)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1000,N'Удаление файлов',N'Удаление файлов',4,1,131)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1001,N'Создайте файл каталога',N'Создайте файл каталога',4,1,132)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1002,N'Отправить по электронной почте',N'Отправить по электронной почте',4,1,133)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1003,N'Отправить',N'Отправить',4,1,134)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1004,N'Ссылки',N'Ссылки',4,1,135)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1005,N'Добавить форме',N'Добавить форме',4,1,136)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1006,N'Добавить',N'Добавить',4,1,137)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1007,N'Удалить',N'Удалить',4,1,138)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1008,N'Измененном виде',N'Измененном виде',4,1,139)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1009,N'Изменить',N'Изменить',4,1,140)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1010,N'Скачать URL фильтра',N'Скачать URL фильтра',4,1,141)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1011,N'Добавить форме',N'Добавить форме',4,1,142)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1012,N'Добавить',N'Добавить',4,1,143)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1013,N'Удалить',N'Удалить',4,1,144)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1014,N'Измененном виде',N'Измененном виде',4,1,145)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1015,N'Изменить',N'Изменить',4,1,146)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1016,N'Источник Model Management',N'Источник Model Management',4,1,147)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1017,N'Добавить форме',N'Добавить форме',4,1,148)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1018,N'Добавить',N'Добавить',4,1,149)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1019,N'Удалить',N'Удалить',4,1,150)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1020,N'Измененном виде',N'Измененном виде',4,1,151)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1021,N'Изменить',N'Изменить',4,1,152)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1022,N'Проголосовать управления',N'Проголосовать управления',4,1,153)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1023,N'Добавить форме',N'Добавить форме',4,1,154)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1024,N'Добавить',N'Добавить',4,1,155)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1025,N'Удалить',N'Удалить',4,1,156)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1026,N'Измененном виде',N'Измененном виде',4,1,157)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1027,N'Изменить',N'Изменить',4,1,158)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1028,N'Справочная Главная',N'Справочная Главная',4,1,159)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1029,N'?Contenido del modelo de',N'?Contenido del modelo de',5,1,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1030,N'Gestión de Contenidos',N'Gestión de Contenidos',5,1,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1031,N'Lista de artículos',N'Lista de artículos',5,1,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1032,N'Agregar formulario',N'Agregar formulario',5,1,4)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1033,N'Agregar',N'Agregar',5,1,5)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1034,N'Eliminar',N'Eliminar',5,1,6)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1035,N'Formulario de actualización',N'Formulario de actualización',5,1,7)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1036,N'Modificar',N'Modificar',5,1,8)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1037,N'Lista de software',N'Lista de software',5,1,9)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1038,N'Agregar formulario',N'Agregar formulario',5,1,10)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1039,N'Agregar',N'Agregar',5,1,11)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1040,N'Eliminar',N'Eliminar',5,1,12)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1041,N'Formulario de actualización',N'Formulario de actualización',5,1,13)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1042,N'Modificar',N'Modificar',5,1,14)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1043,N'Contenido de la función',N'Contenido de la función',5,1,15)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1044,N'Eliminar archivo estático',N'Eliminar archivo estático',5,1,16)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1045,N'Generar archivo estático',N'Generar archivo estático',5,1,17)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1046,N'Generar archivo de índice',N'Generar archivo de índice',5,1,18)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1047,N'Tag Management',N'Tag Management',5,1,19)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1048,N'Eliminar',N'Eliminar',5,1,20)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1049,N'Comentario de gestión',N'Comentario de gestión',5,1,21)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1050,N'Eliminar',N'Eliminar',5,1,22)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1051,N'Formulario de actualización',N'Formulario de actualización',5,1,23)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1052,N'Modificar',N'Modificar',5,1,24)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1053,N'Gestión de archivos estáticos',N'Gestión de archivos estáticos',5,1,25)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1054,N'Agregar',N'Agregar',5,1,26)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1055,N'índice de gestión',N'índice de gestión',5,1,27)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1056,N'Agregar',N'Agregar',5,1,28)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1057,N'Forma Eliminar',N'Forma Eliminar',5,1,29)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1058,N'Eliminar',N'Eliminar',5,1,30)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1059,N'Formulario de actualización',N'Formulario de actualización',5,1,31)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1060,N'Actualizar',N'Actualizar',5,1,32)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1061,N'Gestión Local',N'Gestión Local',5,1,33)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1062,N'Agregar formulario',N'Agregar formulario',5,1,34)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1063,N'Agregar',N'Agregar',5,1,35)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1064,N'Eliminar',N'Eliminar',5,1,36)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1065,N'Formulario de actualización',N'Formulario de actualización',5,1,37)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1066,N'Modificar',N'Modificar',5,1,38)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1067,N'Modelo de Usuario',N'Modelo de Usuario',5,1,39)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1068,N'Frente usuario',N'Frente usuario',5,1,40)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1069,N'Miembros de la lista',N'Miembros de la lista',5,1,41)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1070,N'Agregar formulario',N'Agregar formulario',5,1,42)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1071,N'Agregar',N'Agregar',5,1,43)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1072,N'Eliminar',N'Eliminar',5,1,44)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1073,N'Formulario de actualización',N'Formulario de actualización',5,1,45)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1074,N'Modificar',N'Modificar',5,1,46)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1075,N'Ver',N'Ver',5,1,47)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1076,N'Miembro del Grupo',N'Miembro del Grupo',5,1,48)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1077,N'Agregar formulario',N'Agregar formulario',5,1,49)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1078,N'Agregar',N'Agregar',5,1,50)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1079,N'Eliminar',N'Eliminar',5,1,51)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1080,N'Formulario de actualización',N'Formulario de actualización',5,1,52)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1081,N'Modificar',N'Modificar',5,1,53)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1082,N'Antecedentes del usuario',N'Antecedentes del usuario',5,1,54)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1083,N'Administrador de listas',N'Administrador de listas',5,1,55)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1084,N'Agregar formulario de administrador',N'Agregar formulario de administrador',5,1,56)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1085,N'Agregar administrador',N'Agregar administrador',5,1,57)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1086,N'Quitar administrador',N'Quitar administrador',5,1,58)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1087,N'Formulario de cambio de administrador',N'Formulario de cambio de administrador',5,1,59)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1088,N'Cambio de administrador',N'Cambio de administrador',5,1,60)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1089,N'Modificar el formulario papel',N'Modificar el formulario papel',5,1,61)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1090,N'Modificar papel',N'Modificar papel',5,1,62)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1091,N'Administrador de vistas',N'Administrador de vistas',5,1,63)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1092,N'Lista de papel',N'Lista de papel',5,1,64)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1093,N'Agregar formulario papel',N'Agregar formulario papel',5,1,65)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1094,N'A?adir Papel',N'A?adir Papel',5,1,66)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1095,N'Eliminar papel',N'Eliminar papel',5,1,67)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1096,N'Formulario de actualización',N'Formulario de actualización',5,1,68)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1097,N'Modificar el papel',N'Modificar el papel',5,1,69)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1098,N'Papel Modificar Formulario de Permiso',N'Papel Modificar Formulario de Permiso',5,1,70)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1099,N'Modificar permisos papel',N'Modificar permisos papel',5,1,71)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1100,N'Función de navegación Modificar Formulario',N'Función de navegación Modificar Formulario',5,1,72)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1101,N'Modificar Navegación Papel',N'Modificar Navegación Papel',5,1,73)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1102,N'Permiso de gestión',N'Permiso de gestión',5,1,74)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1103,N'Agregar formulario',N'Agregar formulario',5,1,75)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1104,N'Agregar',N'Agregar',5,1,76)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1105,N'Eliminar',N'Eliminar',5,1,77)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1106,N'Formulario de actualización',N'Formulario de actualización',5,1,78)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1107,N'Modificar',N'Modificar',5,1,79)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1108,N'Actualizar',N'Actualizar',5,1,80)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1109,N'Ingresar Registrarse',N'Ingresar Registrarse',5,1,81)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1110,N'Eliminar',N'Eliminar',5,1,82)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1111,N'Online Manager',N'Online Manager',5,1,83)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1112,N'Eliminar',N'Eliminar',5,1,84)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1113,N'Modelo del sistema',N'Modelo del sistema',5,1,85)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1114,N'Configuración del sistema',N'Configuración del sistema',5,1,86)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1115,N'Sitio Marco',N'Sitio Marco',5,1,87)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1116,N'Modificar sitio',N'Modificar sitio',5,1,88)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1117,N'Configuración de seguridad',N'Configuración de seguridad',5,1,89)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1118,N'Modificar',N'Modificar',5,1,90)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1119,N'Ajustes de navegación',N'Ajustes de navegación',5,1,91)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1120,N'Agregar formulario',N'Agregar formulario',5,1,92)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1121,N'Agregar',N'Agregar',5,1,93)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1122,N'Eliminar',N'Eliminar',5,1,94)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1123,N'Formulario de actualización',N'Formulario de actualización',5,1,95)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1124,N'Modificar',N'Modificar',5,1,96)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1125,N'Filigrana',N'Filigrana',5,1,97)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1126,N'Modificar',N'Modificar',5,1,98)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1127,N'Correo Marco',N'Correo Marco',5,1,99)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1128,N'Modificar',N'Modificar',5,1,100)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1129,N'Plantilla Marco',N'Plantilla Marco',5,1,101)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1130,N'Modificar',N'Modificar',5,1,102)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1131,N'Marco de código de plantilla',N'Marco de código de plantilla',5,1,103)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1132,N'Agregar formulario',N'Agregar formulario',5,1,104)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1133,N'Agregar',N'Agregar',5,1,105)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1134,N'Eliminar',N'Eliminar',5,1,106)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1135,N'Formulario de actualización',N'Formulario de actualización',5,1,107)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1136,N'Modificar',N'Modificar',5,1,108)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1137,N'Variable del Sistema Marco',N'Variable del Sistema Marco',5,1,109)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1138,N'Agregar formulario',N'Agregar formulario',5,1,110)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1139,N'Agregar',N'Agregar',5,1,111)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1140,N'Eliminar',N'Eliminar',5,1,112)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1141,N'Formulario de actualización',N'Formulario de actualización',5,1,113)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1142,N'Modificar',N'Modificar',5,1,114)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1143,N'La función del sistema',N'La función del sistema',5,1,115)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1144,N'Copia de seguridad de datos',N'Copia de seguridad de datos',5,1,116)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1145,N'Copia de seguridad y restauración',N'Copia de seguridad y restauración',5,1,117)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1146,N'Gestión internacional',N'Gestión internacional',5,1,118)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1147,N'Agregar formulario',N'Agregar formulario',5,1,119)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1148,N'Agregar',N'Agregar',5,1,120)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1149,N'Eliminar',N'Eliminar',5,1,121)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1150,N'Formulario de actualización',N'Formulario de actualización',5,1,122)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1151,N'Modificar',N'Modificar',5,1,123)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1152,N'Gestión Documental',N'Gestión Documental',5,1,124)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1153,N'Cargar el formulario',N'Cargar el formulario',5,1,125)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1154,N'Subir Archivo',N'Subir Archivo',5,1,126)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1155,N'Modificar archivo Nombre del formulario',N'Modificar archivo Nombre del formulario',5,1,127)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1156,N'Modificar nombre de archivo',N'Modificar nombre de archivo',5,1,128)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1157,N'Modificar datos Presente el Formulario',N'Modificar datos Presente el Formulario',5,1,129)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1158,N'Modificar archivo de datos',N'Modificar archivo de datos',5,1,130)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1159,N'Eliminar archivos',N'Eliminar archivos',5,1,131)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1160,N'Crear directorio de archivos',N'Crear directorio de archivos',5,1,132)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1161,N'Enviar por e-mail',N'Enviar por e-mail',5,1,133)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1162,N'Enviar',N'Enviar',5,1,134)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1163,N'Enlace',N'Enlace',5,1,135)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1164,N'Agregar formulario',N'Agregar formulario',5,1,136)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1165,N'Agregar',N'Agregar',5,1,137)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1166,N'Eliminar',N'Eliminar',5,1,138)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1167,N'Formulario de actualización',N'Formulario de actualización',5,1,139)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1168,N'Modificar',N'Modificar',5,1,140)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1169,N'Descargar filtro de URL',N'Descargar filtro de URL',5,1,141)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1170,N'Agregar formulario',N'Agregar formulario',5,1,142)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1171,N'Agregar',N'Agregar',5,1,143)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1172,N'Eliminar',N'Eliminar',5,1,144)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1173,N'Formulario de actualización',N'Formulario de actualización',5,1,145)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1174,N'Modificar',N'Modificar',5,1,146)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1175,N'Canal Modelo de Gestión',N'Canal Modelo de Gestión',5,1,147)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1176,N'Agregar formulario',N'Agregar formulario',5,1,148)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1177,N'Agregar',N'Agregar',5,1,149)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1178,N'Eliminar',N'Eliminar',5,1,150)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1179,N'Formulario de actualización',N'Formulario de actualización',5,1,151)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1180,N'Modificar',N'Modificar',5,1,152)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1181,N'Votación de Gestión',N'Votación de Gestión',5,1,153)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1182,N'Agregar formulario',N'Agregar formulario',5,1,154)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1183,N'Agregar',N'Agregar',5,1,155)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1184,N'Eliminar',N'Eliminar',5,1,156)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1185,N'Formulario de actualización',N'Formulario de actualización',5,1,157)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1186,N'Modificar',N'Modificar',5,1,158)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1187,N'Antecedentes Inicio',N'Antecedentes Inicio',5,1,159)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1188,N'超级管理员',N'超级管理员',0,2,0)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1189,N'Super Admin',N'Super Admin',1,2,0)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1190,N'超級管理員',N'超級管理員',2,2,0)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1191,N'スーパー管理者',N'スーパー管理者',3,2,0)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1192,N'Super Admin',N'Super Admin',4,2,0)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1193,N'Super Admin',N'Super Admin',5,2,0)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1194,N'文章模型',N'文章模型',0,3,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1195,N'Article Model',N'Article Model',1,3,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1196,N'文章模型',N'文章模型',2,3,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1197,N'ペーパーモデル',N'ペーパーモデル',3,3,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1198,N'Бумажная модель',N'Бумажная модель',4,3,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1199,N'Modelo de Article',N'Modelo de Article',5,3,1)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1200,N'软件模型',N'软件模型',0,3,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1201,N'Software Model',N'Software Model',1,3,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1202,N'軟件模型',N'軟件模型',2,3,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1203,N'ソフトウェアモデル',N'ソフトウェアモデル',3,3,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1204,N'программная модель',N'программная модель',4,3,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1205,N'software de modelo',N'software de modelo',5,3,2)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1206,N'图片模型',N'图片模型',0,3,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1207,N'Image Model',N'Image Model',1,3,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1208,N'圖片模型',N'圖片模型',2,3,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1209,N'イメージモデル',N'イメージモデル',3,3,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1210,N'Изображение модели',N'Изображение модели',4,3,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1211,N'Imagen del modelo',N'Imagen del modelo',5,3,3)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1212,N'专题列表',N'专题列表',0,0,40)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1213,N'Special Topic List',N'Special Topic List',1,0,40)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1214,N'專題列表',N'專題列表',2,0,40)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1215,N'特別なトピックのリスト',N'特別なトピックのリスト',3,0,40)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1216,N'Специальный список тему',N'Специальный список тему',4,0,40)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1217,N'Lista de temas Especial',N'Lista de temas Especial',5,0,40)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1218,N'视频列表',N'视频列表',0,0,41)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1219,N'Video List',N'Video List',1,0,41)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1220,N'視頻列表',N'視頻列表',2,0,41)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1221,N'ビデオのリスト',N'ビデオのリスト',3,0,41)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1222,N'Видео Список',N'Видео Список',4,0,41)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1223,N'Lista de vídeo',N'Lista de vídeo',5,0,41)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1224,N'CMS类型列表',N'CMS类型列表',0,0,42)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1225,N'CMS Type List',N'CMS Type List',1,0,42)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1226,N'CMS類型列表',N'CMS類型列表',2,0,42)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1227,N'CMSの種類の一覧',N'CMSの種類の一覧',3,0,42)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1228,N'CMS Список типов',N'CMS Список типов',4,0,42)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1229,N'CMS lista de tipos',N'CMS lista de tipos',5,0,42)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1230,N'专题列表',N'专题列表',0,1,160)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1231,N'Special Topic List',N'Special Topic List',1,1,160)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1232,N'專題列表',N'專題列表',2,1,160)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1233,N'特別なトピックのリスト',N'特別なトピックのリスト',3,1,160)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1234,N'Специальный список тему',N'Специальный список тему',4,1,160)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1235,N'Lista de temas Especial',N'Lista de temas Especial',5,1,160)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1236,N'添加表单',N'添加表单',0,1,161)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1237,N'Add Form',N'Add Form',1,1,161)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1238,N'添加表單',N'添加表單',2,1,161)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1239,N'フォームを追加します。',N'フォームを追加します。',3,1,161)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1240,N'Добавить форму',N'Добавить форму',4,1,161)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1241,N'Agregar formulario',N'Agregar formulario',5,1,161)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1242,N'添加',N'添加',0,1,162)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1243,N'Add',N'Add',1,1,162)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1244,N'添加',N'添加',2,1,162)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1245,N'追加',N'追加',3,1,162)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1246,N'добавлять',N'добавлять',4,1,162)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1247,N'a?adir',N'a?adir',5,1,162)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1248,N'修改表单',N'修改表单',0,1,163)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1249,N'Modified Form',N'Modified Form',1,1,163)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1250,N'修改表單',N'修改表單',2,1,163)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1251,N'変更フォーム',N'変更フォーム',3,1,163)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1252,N'Изменить С',N'Изменить С',4,1,163)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1253,N'De modificar',N'De modificar',5,1,163)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1254,N'修改',N'修改',0,1,164)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1255,N'Modify',N'Modify',1,1,164)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1256,N'修改',N'修改',2,1,164)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1257,N'変更',N'変更',3,1,164)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1258,N'модифицировать',N'модифицировать',4,1,164)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1259,N'modificar',N'modificar',5,1,164)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1260,N'删除',N'删除',0,1,165)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1261,N'Delete',N'Delete',1,1,165)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1262,N'刪除',N'刪除',2,1,165)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1263,N'削除',N'削除',3,1,165)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1264,N'удалять',N'удалять',4,1,165)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1265,N'borrar',N'borrar',5,1,165)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1266,N'视频列表',N'视频列表',0,1,166)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1267,N'Video List',N'Video List',1,1,166)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1268,N'視頻列表',N'視頻列表',2,1,166)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1269,N'ビデオのリスト',N'ビデオのリスト',3,1,166)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1270,N'Видео Список',N'Видео Список',4,1,166)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1271,N'Lista de vídeo',N'Lista de vídeo',5,1,166)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1272,N'添加表单',N'添加表单',0,1,167)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1273,N'Add Form',N'Add Form',1,1,167)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1274,N'添加表單',N'添加表單',2,1,167)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1275,N'フォームを追加します。',N'フォームを追加します。',3,1,167)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1276,N'Добавить форму',N'Добавить форму',4,1,167)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1277,N'Agregar formulario',N'Agregar formulario',5,1,167)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1278,N'添加',N'添加',0,1,168)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1279,N'Add',N'Add',1,1,168)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1280,N'添加',N'添加',2,1,168)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1281,N'追加',N'追加',3,1,168)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1282,N'добавлять',N'добавлять',4,1,168)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1283,N'a?adir',N'a?adir',5,1,168)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1284,N'修改表单',N'修改表单',0,1,169)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1285,N'Modified Form',N'Modified Form',1,1,169)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1286,N'修改表單',N'修改表單',2,1,169)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1287,N'変更フォーム',N'変更フォーム',3,1,169)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1288,N'Изменить С',N'Изменить С',4,1,169)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1289,N'De modificar',N'De modificar',5,1,169)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1290,N'修改',N'修改',0,1,170)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1291,N'Modify',N'Modify',1,1,170)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1292,N'修改',N'修改',2,1,170)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1293,N'変更',N'変更',3,1,170)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1294,N'модифицировать',N'модифицировать',4,1,170)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1295,N'modificar',N'modificar',5,1,170)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1296,N'删除',N'删除',0,1,171)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1297,N'Delete',N'Delete',1,1,171)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1298,N'刪除',N'刪除',2,1,171)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1299,N'削除',N'削除',3,1,171)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1300,N'удалять',N'удалять',4,1,171)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1301,N'borrar',N'borrar',5,1,171)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1302,N'CMS类型列表',N'CMS类型列表',0,1,172)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1303,N'CMS Type List',N'CMS Type List',1,1,172)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1304,N'CMS類型列表',N'CMS類型列表',2,1,172)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1305,N'CMSの種類の一覧',N'CMSの種類の一覧',3,1,172)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1306,N'CMS Список типов',N'CMS Список типов',4,1,172)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1307,N'CMS lista de tipos',N'CMS lista de tipos',5,1,172)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1308,N'添加表单',N'添加表单',0,1,173)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1309,N'Add Form',N'Add Form',1,1,173)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1310,N'添加表單',N'添加表單',2,1,173)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1311,N'フォームを追加します。',N'フォームを追加します。',3,1,173)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1312,N'Добавить форму',N'Добавить форму',4,1,173)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1313,N'Agregar formulario',N'Agregar formulario',5,1,173)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1314,N'添加',N'添加',0,1,174)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1315,N'Add',N'Add',1,1,174)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1316,N'添加',N'添加',2,1,174)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1317,N'追加',N'追加',3,1,174)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1318,N'добавлять',N'добавлять',4,1,174)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1319,N'a?adir',N'a?adir',5,1,174)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1320,N'修改表单',N'修改表单',0,1,175)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1321,N'Modified Form',N'Modified Form',1,1,175)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1322,N'修改表單',N'修改表單',2,1,175)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1323,N'変更フォーム',N'変更フォーム',3,1,175)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1324,N'Изменить С',N'Изменить С',4,1,175)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1325,N'De modificar',N'De modificar',5,1,175)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1326,N'修改',N'修改',0,1,176)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1327,N'Modify',N'Modify',1,1,176)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1328,N'修改',N'修改',2,1,176)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1329,N'変更',N'変更',3,1,176)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1330,N'модифицировать',N'модифицировать',4,1,176)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1331,N'modificar',N'modificar',5,1,176)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1332,N'删除',N'删除',0,1,177)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1333,N'Delete',N'Delete',1,1,177)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1334,N'刪除',N'刪除',2,1,177)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1335,N'削除',N'削除',3,1,177)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1336,N'удалять',N'удалять',4,1,177)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1337,N'borrar',N'borrar',5,1,177)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1338,N'文章移动表单',N'文章移动表单',0,1,178)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1339,N'article move form',N'article move form',1,1,178)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1340,N'文章移動表單',N'文章移動表單',2,1,178)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1341,N'記事の移動形態',N'記事の移動形態',3,1,178)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1342,N'форма статье двигаться',N'форма статье двигаться',4,1,178)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1343,N'artículo forma se mueven',N'artículo forma se mueven',5,1,178)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1344,N'文章移动',N'文章移动',0,1,179)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1345,N'article move',N'article move',1,1,179)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1346,N'文章移動',N'文章移動',2,1,179)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1347,N'記事の移動',N'記事の移動',3,1,179)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1348,N'Статья двигаться',N'Статья двигаться',4,1,179)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1349,N'artículo se mueven',N'artículo se mueven',5,1,179)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1350,N'软件移动表单',N'软件移动表单',0,1,180)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1351,N'software move form',N'software move form',1,1,180)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1352,N'軟件移動表單',N'軟件移動表單',2,1,180)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1353,N'ソフトウェアの移動形態',N'ソフトウェアの移動形態',3,1,180)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1354,N'форме программного обеспечения перемещения',N'форме программного обеспечения перемещения',4,1,180)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1355,N'software de forma avanzar',N'software de forma avanzar',5,1,180)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1356,N'软件移动',N'软件移动',0,1,181)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1357,N'software move',N'software move',1,1,181)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1358,N'軟件移動',N'軟件移動',2,1,181)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1359,N'ソフトウェアの動き',N'ソフトウェアの動き',3,1,181)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1360,N'программное обеспечение двигаться',N'программное обеспечение двигаться',4,1,181)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1361,N'software se mueven',N'software se mueven',5,1,181)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1362,N'设置账号表单',N'设置账号表单',0,1,182)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1363,N'set account form',N'set account form',1,1,182)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1364,N'設置賬號表單',N'設置賬號表單',2,1,182)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1365,N'アカウントフォームを設定する',N'アカウントフォームを設定する',3,1,182)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1366,N'набор форма счета',N'набор форма счета',4,1,182)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1367,N'conjunto de formularios en cuenta',N'conjunto de formularios en cuenta',5,1,182)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1368,N'修改',N'修改',0,1,183)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1369,N'Modify',N'Modify',1,1,183)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1370,N'修改',N'修改',2,1,183)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1371,N'変更',N'変更',3,1,183)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1372,N'модифицировать',N'модифицировать',4,1,183)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1373,N'modificar',N'modificar',5,1,183)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1374, N'会员登录设置', N'会员登录设置', 0, 1, 184)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1375, N'修改', N'修改会员登录配置', 0, 1, 185)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1376, N'会员登录设置', N'会员登录设置', 0, 0, 43)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1377, N'Member login settings', N'Member login settings', 1, 1, 184)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1378, N'Modify', N'Login to modify the configuration', 1, 1, 185)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1379, N'Member login settings', N'Member login settings', 1, 0, 43)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1380, N'會員登錄設置', N'會員登錄設置', 2, 1, 184)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1381, N'修改', N'修改會員登錄配置', 2, 1, 185)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1382, N'會員登錄設置', N'會員登錄設置', 2, 0, 43)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1383, N'メンバーのログイン設定', N'メンバーのログイン設定', 3, 1, 184)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1384, N'変更', N'設定を変更するには、ログイン', 3, 1, 185)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1385, N'メンバーのログイン設定', N'メンバーのログイン設定', 3, 0, 43)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1386, N'Настройки Вход для зарегистрированных пользователей', N'Настройки Вход для зарегистрированных пользователей', 4, 1, 184)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1387, N'изменять', N'Войти, чтобы изменить конфигурацию', 4, 1, 185)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1388, N'Настройки Вход для зарегистрированных пользователей', N'Настройки Вход для зарегистрированных пользователей', 4, 0, 43)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1389, N'Configuración miembro de inicio de sesión', N'Configuración miembro de inicio de sesión', 5, 1, 184)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1390, N'modificar', N'Inicie sesión para modificar la configuración', 5, 1, 185)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1391, N'Configuración miembro de inicio de sesión', N'Configuración miembro de inicio de sesión', 5, 0, 43)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1392, N'生成静态文件', N'生成静态文件', 0, 1, 186)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1393, N'删除静态文件', N'删除静态文件', 0, 1, 187)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1394, N'Generate static file', N'Generate static file', 1, 1, 186)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1395, N'Delete static file', N'Delete static file', 1, 1, 187)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1396, N'生成靜態文件', N'生成靜態文件', 2, 1, 186)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1397, N'删除靜態文件', N'删除靜態文件', 2, 1, 187)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1398, N'静的ファイルを生成する', N'静的ファイルを生成する', 3, 1, 186)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1399, N'静的なファイルを削除します。', N'静的なファイルを削除します。', 3, 1, 187)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1400, N'Создание статических файлов', N'Создание статических файлов', 4, 1, 186)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1401, N'Удаление статических файлов', N'Удаление статических файлов', 4, 1, 187)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1402, N'Generan archivos estáticos', N'Generan archivos estáticos', 5, 1, 186)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1403, N'Eliminar archivos estáticos', N'Eliminar archivos estáticos', 5, 1, 187)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1404,N'Oauth登录设置',N'Oauth登录设置', 0, 0, 44)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1405,N'关键字历史列表',N'关键字历史列表', 0, 0, 45)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1406,N'支付订单列表',N'支付订单列表', 0, 0, 46)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1407,N'Oauth login settings',N'Oauth login settings', 1, 0, 44)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1408,N'Keyword history list',N'Keyword history list', 1, 0, 45)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1409,N'The list of payment orders',N'The list of payment orders', 1, 0, 46)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1410,N'Oauth登錄設置',N'Oauth登錄設置', 2, 0, 44)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1411,N'關鍵字歷史列表',N'關鍵字歷史列表', 2, 0, 45)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1412,N'支付訂單列表',N'支付訂單列表', 2, 0, 46)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1413,N'OAuthのログイン設定',N'OAuthのログイン設定', 3, 0, 44)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1414,N'キーワードの履歴リスト',N'キーワードの履歴リスト', 3, 0, 45)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1415,N'支払指図のリスト',N'支払指図のリスト', 3, 0, 46)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1416,N'OAuth параметры входа',N'OAuth параметры входа', 4, 0, 44)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1417,N'Список ключевых слов история',N'Список ключевых слов история', 4, 0, 45)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1418,N'Список платежных поручений',N'Список платежных поручений', 4, 0, 46)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1419,N'OAuth configuración de inicio de sesión',N'OAuth configuración de inicio de sesión', 5, 0, 44)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1420,N'Palabra lista de la historia',N'Palabra lista de la historia', 5, 0, 45)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1421,N'La lista de órdenes de pago',N'La lista de órdenes de pago', 5, 0, 46)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1422,N'上传图片表单',N'上传图片表单', 0, 1, 188)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1423,N'上传图片',N'上传图片', 0, 1, 189)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1424,N'上传附件表单',N'上传附件表单', 0, 1, 190)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1425,N'上传附件',N'上传附件', 0, 1, 191)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1426,N'评论审核',N'评论审核', 0, 1, 192)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1427,N'关键字历史列表',N'关键字历史列表', 0, 1, 193)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1428,N'删除',N'删除', 0, 1, 194)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1429,N'Oauth登录设置',N'Oauth登录设置', 0, 1, 195)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1430,N'添加表单',N'添加表单', 0, 1, 196)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1431,N'添加',N'添加', 0, 1, 197)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1432,N'修改表单',N'修改表单', 0, 1, 198)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1433,N'修改',N'修改', 0, 1, 199)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1434,N'删除',N'删除', 0, 1, 200)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1435,N'支付订单列表',N'支付订单列表', 0, 1, 201)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1436,N'已付款',N'已付款', 0, 1, 202)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1437,N'删除',N'删除', 0, 1, 203)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1438,N'Upload pictures form',N'Upload pictures form', 1, 1, 188)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1439,N'Upload pictures',N'Upload pictures', 1, 1, 189)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1440,N'Upload attachment form',N'Upload attachment form', 1, 1, 190)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1441,N'Post attachments',N'Post attachments', 1, 1, 191)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1442,N'Comment Moderation',N'Comment Moderation', 1, 1, 192)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1443,N'Keyword history list',N'Keyword history list', 1, 1, 193)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1444,N'Delete',N'Delete', 1, 1, 194)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1445,N'Oauth login settings',N'Oauth login settings', 1, 1, 195)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1446,N'Add form',N'Add form', 1, 1, 196)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1447,N'Add',N'Add', 1, 1, 197)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1448,N'Modify the form',N'Modify the form', 1, 1, 198)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1449,N'Modify',N'Modify', 1, 1, 199)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1450,N'Delete',N'Delete', 1, 1, 200)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1451,N'The list of payment orders',N'The list of payment orders', 1, 1, 201)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1452,N'Paid',N'Paid', 1, 1, 202)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1453,N'Delete',N'Delete', 1, 1, 203)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1454,N'上傳圖片表單',N'上傳圖片表單', 2, 1, 188)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1455,N'上傳圖片',N'上傳圖片', 2, 1, 189)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1456,N'上傳附件表單',N'上傳附件表單', 2, 1, 190)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1457,N'上傳附件',N'上傳附件', 2, 1, 191)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1458,N'評論審核',N'評論審核', 2, 1, 192)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1459,N'關鍵字歷史列表',N'關鍵字歷史列表', 2, 1, 193)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1460,N'刪除',N'刪除', 2, 1, 194)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1461,N'Oauth登錄設置',N'Oauth登錄設置', 2, 1, 195)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1462,N'添加表單',N'添加表單', 2, 1, 196)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1463,N'添加',N'添加', 2, 1, 197)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1464,N'修改表單',N'修改表單', 2, 1, 198)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1465,N'修改',N'修改', 2, 1, 199)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1466,N'刪除',N'刪除', 2, 1, 200)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1467,N'支付訂單列表',N'支付訂單列表', 2, 1, 201)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1468,N'已付款',N'已付款', 2, 1, 202)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1469,N'刪除',N'刪除', 2, 1, 203)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1470,N'写真のアップロードフォーム',N'写真のアップロードフォーム', 3, 1, 188)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1471,N'写真をアップロード',N'写真をアップロード', 3, 1, 189)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1472,N'添付ファイルのアップロードフォーム',N'添付ファイルのアップロードフォーム', 3, 1, 190)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1473,N'添付ファイルを投稿する',N'添付ファイルを投稿する', 3, 1, 191)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1474,N'コメントモデレーション',N'コメントモデレーション', 3, 1, 192)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1475,N'キーワードの履歴リスト',N'キーワードの履歴リスト', 3, 1, 193)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1476,N'削除する',N'削除する', 3, 1, 194)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1477,N'OAuthのログイン設定',N'OAuthのログイン設定', 3, 1, 195)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1478,N'フォームを追加する',N'フォームを追加する', 3, 1, 196)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1479,N'加える',N'加える', 3, 1, 197)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1480,N'フォームを変更',N'フォームを変更', 3, 1, 198)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1481,N'修正する',N'修正する', 3, 1, 199)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1482,N'削除する',N'削除する', 3, 1, 200)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1483,N'支払指図のリスト',N'支払指図のリスト', 3, 1, 201)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1484,N'有料',N'有料', 3, 1, 202)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1485,N'削除する',N'削除する', 3, 1, 203)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1486,N'Загрузить фото форме',N'Загрузить фото форме', 4, 1, 188)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1487,N'Загрузить фото',N'Загрузить фото', 4, 1, 189)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1488,N'Загрузите приложение форме',N'Загрузите приложение форме', 4, 1, 190)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1489,N'Сообщение вложения',N'Сообщение вложения', 4, 1, 191)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1490,N'Комментарий умеренности',N'Комментарий умеренности', 4, 1, 192)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1491,N'Список ключевых слов история',N'Список ключевых слов история', 4, 1, 193)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1492,N'удалять',N'удалять', 4, 1, 194)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1493,N'OAuth параметры входа',N'OAuth параметры входа', 4, 1, 195)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1494,N'Добавить форме',N'Добавить форме', 4, 1, 196)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1495,N'добавлять',N'добавлять', 4, 1, 197)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1496,N'Измените форму',N'Измените форму', 4, 1, 198)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1497,N'изменять',N'изменять', 4, 1, 199)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1498,N'удалять',N'удалять', 4, 1, 200)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1499,N'Список платежных поручений',N'Список платежных поручений', 4, 1, 201)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1500,N'оплачиваемый',N'оплачиваемый', 4, 1, 202)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1501,N'удалять',N'удалять', 4, 1, 203)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1502,N'Subir imágenes de forma',N'Subir imágenes de forma', 5, 1, 188)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1503,N'Subir imágenes',N'Subir imágenes', 5, 1, 189)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1504,N'Transferir el formulario adjunto',N'Transferir el formulario adjunto', 5, 1, 190)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1505,N'Enviar archivos adjuntos',N'Enviar archivos adjuntos', 5, 1, 191)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1506,N'comentario moderación',N'comentario moderación', 5, 1, 192)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1507,N'Palabra lista de la historia',N'Palabra lista de la historia', 5, 1, 193)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1508,N'borrar',N'borrar', 5, 1, 194)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1509,N'OAuth configuración de inicio de sesión',N'OAuth configuración de inicio de sesión', 5, 1, 195)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1510,N'Agregar la forma',N'Agregar la forma', 5, 1, 196)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1511,N'añadir',N'añadir', 5, 1, 197)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1512,N'Modificar el formulario',N'Modificar el formulario', 5, 1, 198)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1513,N'modificar',N'modificar', 5, 1, 199)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1514,N'borrar',N'borrar', 5, 1, 200)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1515,N'La lista de órdenes de pago',N'La lista de órdenes de pago', 5, 1, 201)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1516,N'pagado',N'pagado', 5, 1, 202)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1517,N'borrar',N'borrar', 5, 1, 203)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1518,N'专题搜索', '专题搜索', 0, 1, 204) 
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1519,N'Special Topic Search', N'Special Topic Search', 1, 1, 204) 
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1520,N'專題搜索', N'專題搜索', 2, 1, 204) 
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1521,N'特別なトピックの検索', N'特別なトピックの検索', 3, 1, 204) 
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1522,N'Специальный поиск темы', N'Специальный поиск темы', 4, 1, 204) 
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1523,N'Buscar Tema Especial', N'Buscar Tema Especial', 5 ,1, 204) 
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1524,N'图片列表', N'图片列表', 0, 0, 47)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1525,N'List Of Images', N'List Of Images', 1, 0, 47)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1526,N'圖片列表', N'圖片列表', 2, 0, 47)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1527,N'イメージのリスト', N'イメージのリスト', 3, 0, 47)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1528,N'Список изображений', N'Список изображений', 4, 0, 47)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1529,N'Lista de imágenes', N'Lista de imágenes', 5, 0, 47)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1530,N'移动表单', N'视频移动表单', 0, 1, 205)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1531,N'Move Form', N'Move Form', 1, 1, 205)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1532,N'移動表單', N'視頻移動表單', 2, 1, 205)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1533,N'フォームを移動', N'フォームを移動', 3, 1, 205)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1534,N'перемещать форму', N'перемещать форму', 4, 1, 205)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1535,N'mover la forma', N'mover la forma', 5, 1, 205)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1536,N'移动提交', N'移动提交', 0, 1, 206)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1537,N'Move Submit', N'Move Submit', 1, 1, 206)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1538,N'移動提交', N'移動提交', 2, 1, 206)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1539,N'提出移動', N'提出移動', 3, 1, 206)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1540,N'двигаться представить', N'двигаться представить', 4, 1, 206)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1541,N'se mueven presente', N'se mueven presente', 5, 1, 206)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1542,N'图片列表', N'图片列表', 0, 1, 207)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1543,N'List Of Images', N'List Of Images', 1, 1, 207)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1544,N'圖片列表', N'圖片列表', 2, 1, 207)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1545,N'イメージのリスト', N'イメージのリスト', 3, 1, 207)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1546,N'Список изображений', N'Список изображений', 4, 1, 207)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1547,N'Lista de imágenes', N'Lista de imágenes', 5, 1, 207)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1548,N'添加表单', N'添加表单', 0, 1, 208)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1549,N'Add Form', N'Add Form', 1, 1, 208)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1550,N'添加表單', N'添加表單', 2, 1, 208)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1551,N'フォームを追加します。', N'フォームを追加します。', 3, 1, 208)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1552,N'Добавить форму', N'Добавить форму', 4, 1, 208)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1553,N'Agregar formulario', N'Agregar formulario', 5, 1, 208)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1554,N'添加', N'添加', 0, 1, 209)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1555,N'Add', N'Add', 1, 1, 209)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1556,N'添加', N'添加', 2, 1, 209)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1557,N'追加', N'追加', 3, 1, 209)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1558,N'добавлять', N'добавлять', 4, 1, 209)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1559,N'a?adir', N'a?adir', 5, 1, 209)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1560,N'修改表单', N'修改表单', 0, 1, 210)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1561,N'Modified Form', N'Modified Form', 1, 1, 210)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1562,N'修改表單', N'修改表單', 2, 1, 210)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1563,N'変更フォーム', N'変更フォーム', 3, 1, 210)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1564,N'Изменить С', N'Изменить С', 4, 1, 210)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1565,N'De modificar', N'De modificar', 5, 1, 210)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1566,N'修改', N'修改', 0, 1, 211)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1567,N'Modify', N'Modify', 1, 1, 211)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1568,N'修改', N'修改', 2, 1, 211)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1569,N'変更', N'変更', 3, 1, 211)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1570,N'модифицировать', N'модифицировать', 4, 1, 211)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1571,N'modificar', N'modificar', 5, 1, 211)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1572,N'删除', N'删除', 0, 1, 212)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1573,N'Delete', N'Delete', 1, 1, 212)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1574,N'刪除', N'刪除', 2, 1, 212)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1575,N'削除', N'削除', 3, 1, 212)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1576,N'удалять', N'удалять', 4, 1, 212)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1577,N'borrar', N'borrar', 5, 1, 212)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1578,N'移动表单', N'图片移动表单', 0, 1, 213)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1579,N'Move Form', N'Move Form', 1, 1, 213)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1580,N'移動表單', N'圖片移動表單', 2, 1, 213)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1581,N'フォームを移動', N'フォームを移動', 3, 1, 213)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1582,N'перемещать форму', N'перемещать форму', 4, 1, 213)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1583,N'mover la forma', N'mover la forma', 5, 1, 213)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1584,N'移动提交', N'图片移动提交', 0, 1, 214)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1585,N'Move Submit', N'Move Submit', 1, 1, 214)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1586,N'移動提交', N'圖片移動提交', 2, 1, 214)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1587,N'提出移動', N'提出移動', 3, 1, 214)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1588,N'двигаться представить', N'двигаться представить', 4, 1, 214)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1589,N'se mueven presente', N'se mueven presente', 5, 1, 214)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1590,N'上传表单', N'上传表单', 0, 1, 215)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1591,N'Upload Form', N'Upload Form', 1, 1, 215)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1592,N'上傳表單', N'上傳表單', 2, 1, 215)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1593,N'フォームをアップロードする', N'フォームをアップロードする', 3, 1, 215)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1594,N'Загрузите форму', N'Загрузите форму', 4, 1, 215)
INSERT [vj_dictionary] ([id],[name],[description],[language],[modelId],[contentId]) VALUES ( 1595,N'formulario de carga', N'formulario de carga', 5, 1, 215)
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_email_config]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_email_config]

CREATE TABLE [vj_email_config] (
[configId] [int]  NOT NULL,
[sender] [varchar]  (50) NULL DEFAULT (NULL),
[email] [varchar]  (250) NULL DEFAULT (NULL),
[smtpAddress] [varchar]  (250) NULL DEFAULT (NULL),
[isHtml] [char]  (1) NULL DEFAULT (NULL),
[isEsmtp] [char]  (1) NULL DEFAULT (NULL),
[isAttachment] [char]  (1) NULL DEFAULT (NULL),
[emailPort] [int]  NULL DEFAULT (NULL),
[retry] [int]  NULL DEFAULT (NULL),
[emailInterval] [int]  NULL DEFAULT (NULL),
[timeOut] [int]  NULL DEFAULT (NULL),
[userName] [varchar]  (50) NULL DEFAULT (NULL),
[password] [varchar]  (50) NULL DEFAULT (NULL))

ALTER TABLE [vj_email_config] WITH NOCHECK ADD  CONSTRAINT [PK_vj_email_config] PRIMARY KEY  NONCLUSTERED ( [configId] )
GO
INSERT [vj_email_config] ([configId],[sender],[email],[smtpAddress],[isHtml],[isEsmtp],[isAttachment],[emailPort],[retry],[emailInterval],[timeOut],[userName],[password]) VALUES ( 1,N'微骏邮件系统',N'system@java.sh',N'smtp.qq.com',N'T',N'T',N'F',25,10,3000,30000,N'system@java.sh',N'4711433')
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_filter_url]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_filter_url]

CREATE TABLE [vj_filter_url] (
[urlId] [int]  NOT NULL,
[name] [varchar]  (50) NULL DEFAULT (NULL),
[url] [varchar]  (250) NULL DEFAULT (NULL),
[type] [char]  (1) NULL DEFAULT (NULL))

ALTER TABLE [vj_filter_url] WITH NOCHECK ADD  CONSTRAINT [PK_vj_filter_url] PRIMARY KEY  NONCLUSTERED ( [urlId] )
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_hit]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_hit]

CREATE TABLE [vj_hit] (
[id] [char]  (32) NOT NULL,
[modelId] [int]  NULL DEFAULT (NULL),
[nodeId] [int]  NULL DEFAULT (NULL),
[click] [int]  NULL DEFAULT (NULL),
[clickDay] [int]  NULL DEFAULT (NULL),
[clickWeek] [int]  NULL DEFAULT (NULL),
[clickMonth] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_hit] WITH NOCHECK ADD  CONSTRAINT [PK_vj_hit] PRIMARY KEY  NONCLUSTERED ( [id] )
GO

if exists (select * from sysobjects where id = OBJECT_ID('[vj_links]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_links]

CREATE TABLE [vj_links] (
[linkId] [char]  (32) NOT NULL,
[name] [varchar]  (50) NULL DEFAULT (NULL),
[url] [varchar]  (250) NULL DEFAULT (NULL),
[type] [char]  (1) NULL DEFAULT (NULL),
[description] [varchar]  (250) NULL DEFAULT (NULL),
[logo] [varchar]  (250) NULL DEFAULT (NULL),
[display] [char]  (1) NULL DEFAULT (NULL))

ALTER TABLE [vj_links] WITH NOCHECK ADD  CONSTRAINT [PK_vj_links] PRIMARY KEY  NONCLUSTERED ( [linkId] )
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_member_favorite]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_member_favorite]

CREATE TABLE [vj_member_favorite] (
[favoriteId] [char]  (32) NOT NULL,
[modelId] [int]  NULL DEFAULT (NULL),
[nodeId] [int]  NULL DEFAULT (NULL),
[contentId] [char]  (32) NULL DEFAULT (NULL),
[memberId] [char]  (32) NULL DEFAULT (NULL))

ALTER TABLE [vj_member_favorite] WITH NOCHECK ADD  CONSTRAINT [PK_vj_member_favorite] PRIMARY KEY  NONCLUSTERED ( [favoriteId] )
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_member_funds]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_member_funds]

CREATE TABLE [vj_member_funds] (
[memberId] [char]  (32) NOT NULL,
[memberMoney] [numeric] (10,2) NULL DEFAULT (NULL),
[payPassword] [char]  (56) NULL DEFAULT (NULL),
[memberPoint] [int]  NULL DEFAULT (NULL),
[costMoney] [numeric] (10,2) NULL DEFAULT (NULL),
[costPoint] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_member_funds] WITH NOCHECK ADD  CONSTRAINT [PK_vj_member_funds] PRIMARY KEY  NONCLUSTERED ( [memberId] )
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_member_group]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_member_group]

CREATE TABLE [vj_member_group] (
[groupId] [int]  NOT NULL,
[groupName] [varchar]  (50) NULL DEFAULT (NULL),
[fileSize] [int]  NULL DEFAULT (NULL),
[fileSuffix] [varchar]  (50) NULL DEFAULT (NULL),
[upgradeExp] [int]  NULL DEFAULT (NULL),
[description] [varchar]  (45) NULL DEFAULT (NULL),
[language] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_member_group] WITH NOCHECK ADD  CONSTRAINT [PK_vj_member_group] PRIMARY KEY  NONCLUSTERED ( [groupId] )
GO
INSERT [vj_member_group] ([groupId],[groupName],[fileSize],[fileSuffix],[upgradeExp],[language]) VALUES ( 1,N'初级会员',50,N'zip,rar',1000,0)
INSERT [vj_member_group] ([groupId],[groupName],[fileSize],[fileSuffix],[upgradeExp],[language]) VALUES ( 2,N'收费会员',50,N'zip,rar',5000,0)
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_member_info]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_member_info]

CREATE TABLE [vj_member_info] (
[memberId] [char]  (32) NOT NULL,
[netName] [varchar]  (50) NULL DEFAULT (NULL),
[trueName] [varchar]  (50) NULL DEFAULT (NULL),
[sex] [char]  (1) NULL DEFAULT (NULL),
[country] [varchar]  (50) NULL DEFAULT (NULL),
[city] [varchar]  (50) NULL DEFAULT (NULL),
[address] [varchar]  (250) NULL DEFAULT (NULL),
[phone] [int]  NULL DEFAULT (NULL),
[mobile] [int]  NULL DEFAULT (NULL),
[postCount] [int]  NULL DEFAULT (NULL),
[face] [varchar]  (250) NULL DEFAULT (NULL),
[sign] [varchar]  (250) NULL DEFAULT (NULL),
[privacySet] [char]  (1) NULL DEFAULT (NULL),
[integral] [int]  NULL DEFAULT (NULL),
[diskCapacity] [int]  NULL DEFAULT (NULL),
[useCapacity] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_member_info] WITH NOCHECK ADD  CONSTRAINT [PK_vj_member_info] PRIMARY KEY  NONCLUSTERED ( [memberId] )
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_members]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_members]

CREATE TABLE [vj_members] (
[memberId] [char]  (32) NOT NULL,
[groupId] [smallint]  NULL DEFAULT (NULL),
[memberType] [char]  (1) NULL DEFAULT (NULL),
[loginId] [varchar]  (20) NULL DEFAULT (NULL),
[password] [char]  (56) NULL DEFAULT (NULL),
[email] [varchar]  (150) NULL DEFAULT (NULL),
[registerTime] [int]  NULL DEFAULT (NULL),
[myTimeZone] [char]  (6) NULL DEFAULT (NULL),
[myLanguage] [smallint]  NULL DEFAULT (NULL),
[lastLoginIp] [varchar]  (40) NULL DEFAULT (NULL),
[lastLoginTime] [int]  NULL DEFAULT (NULL),
[loginCount] [int]  NULL DEFAULT (NULL),
[loginErrorCount] [int]  NULL DEFAULT (NULL),
[answerErrorCount] [int]  NULL DEFAULT (NULL),
[accountExpired] [char]  (1) NULL DEFAULT (NULL),
[accountLocked] [char]  (1) NULL DEFAULT (NULL),
[credentialsExpired] [char]  (1) NULL DEFAULT (NULL),
[status] [char]  (1) NULL DEFAULT (NULL),
[lastUpdatePassWordTime] [int]  NULL DEFAULT (NULL),
[isPassExpire] [char]  (1) NULL DEFAULT (NULL),
[isAccountExpire] [char]  (1) NULL DEFAULT (NULL),
[isAnswerLogin] [char]  (1) NULL DEFAULT (NULL),
[question] [char]  (1) NULL DEFAULT (NULL),
[answer] [varchar]  (250) NULL DEFAULT (NULL),
[accountLockCount] [int] NULL DEFAULT (NULL),
[accountLockTime] [int] NULL DEFAULT (NULL))

ALTER TABLE [vj_members] WITH NOCHECK ADD  CONSTRAINT [PK_vj_members] PRIMARY KEY  NONCLUSTERED ( [memberId] )
CREATE UNIQUE INDEX [IX_vj_members_loginId] ON [vj_members]([loginId])
CREATE UNIQUE INDEX [IX_vj_members_email] ON [vj_members]([email])
CREATE INDEX [IX_vj_members_registerTime] ON [vj_members]([registerTime])
GO

if exists (select * from sysobjects where id = OBJECT_ID('[vj_navigate]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_navigate]

CREATE TABLE [vj_navigate] (
[navigateId] [int]  NOT NULL,
[title] [varchar]  (100) NULL DEFAULT (NULL),
[url] [varchar]  (250) NULL DEFAULT (NULL),
[ico] [varchar]  (50) NULL DEFAULT (NULL),
[parentId] [int]  NULL DEFAULT (NULL),
[nodeLevel] [smallint]  NULL DEFAULT (NULL),
[nodeSort] [int]  NULL DEFAULT (NULL),
[language] [smallint]  NULL DEFAULT (NULL),
[display] [char](1) NULL DEFAULT (NULL))

ALTER TABLE [vj_navigate] WITH NOCHECK ADD  CONSTRAINT [PK_vj_navigate] PRIMARY KEY  NONCLUSTERED ( [navigateId] )
GO
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 1,N'内容模型',N'#',N'1.gif',0,0,0,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 2,N'内容管理',N'#',N'1.gif',1,1,1,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 3,N'文章列表',N'listsFunctionArticle',N'1.gif',2,2,2,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 4,N'软件列表',N'listsFunctionSoft',N'1.gif',2,2,3,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 5,N'内容功能',N'#',N'1.gif',1,1,4,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 6,N'标签管理',N'listsFunctionTagList',N'1.gif',5,2,5,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 7,N'评论管理',N'listsFunctionComment',N'1.gif',5,2,6,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 8,N'生成静态文件',N'listsFunctionStaticFile',N'1.gif',5,2,7,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 9,N'索引管理',N'listsFunctionLuceneContent',N'1.gif',5,2,8,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 10,N'用户模型',N'#',N'1.gif',0,0,9,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 11,N'前台用户',N'#',N'1.gif',10,1,10,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 12,N'会员列表',N'listsUserMember',N'1.gif',11,2,11,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 13,N'会员组',N'listsUserMemberGroup',N'1.gif',11,2,12,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 14,N'后台用户',N'#',N'1.gif',10,1,13,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 15,N'管理员列表',N'listsUserAdmin',N'1.gif',14,2,14,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 16,N'角色列表',N'listsPopedomRole',N'1.gif',14,2,15,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 17,N'权限管理',N'listsPopedomResource',N'1.gif',14,2,16,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 18,N'登录日志',N'listsUserAdminLog',N'1.gif',14,2,17,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 19,N'在线管理员',N'listsOnlineUserAdmin',N'1.gif',14,2,18,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 20,N'系统模型',N'#',N'1.gif',0,0,19,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 21,N'系统设置',N'#',N'1.gif',20,1,20,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 22,N'站点设置',N'listsFunctionWebSite',N'1.gif',21,2,21,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 23,N'安全设置',N'listsPopedomSafeConfig',N'1.gif',21,2,22,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 24,N'导航设置',N'listsPopedomNavigate',N'1.gif',21,2,23,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 25,N'水印设置',N'listsFunctionWatermark',N'1.gif',21,2,24,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 26,N'邮件设置',N'listsFunctionEmailConfig',N'1.gif',21,2,25,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 27,N'系统功能',N'#',N'1.gif',20,1,26,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 28,N'备份数据',N'listsFunctionDatabase',N'1.gif',27,2,27,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 29,N'国际化管理',N'listsFunctionDictionary',N'1.gif',27,2,28,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 30,N'文件管理',N'listsFunctionFileManage',N'1.gif',27,2,29,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 31,N'发送邮件',N'listsSendSystemEmail',N'1.gif',27,2,30,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 32,N'模板设置',N'listsFunctionTemplateConfig',N'1.gif',21,2,31,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 33,N'模板标签设置',N'listsFunctionTemplateTag',N'1.gif',21,2,32,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 34,N'友情链接',N'listsFunctionLink',N'1.gif',27,2,33,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 35,N'下载网址过滤',N'listsPopedomFilterUrl',N'1.gif',27,2,34,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 36,N'系统变量设置',N'listsFunctionSystemConfig',N'1.gif',21,2,35,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 37,N'栏目管理',N'listsFunctionNode',N'1.gif',5,2,36,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 38,N'频道模型管理',N'listsFunctionChannelModel',N'1.gif',27,2,37,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 39,N'投票管理',N'listsFunctionVote',N'1.gif',27,2,38,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 40,N'专题列表',N'listsFunctionSpecialTopic',N'1.gif',5,2,39,0,N'F')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 41,N'视频列表',N'listsFunctionVideo',N'1.gif',2,2,40,0,N'F')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 42,N'CMS类型列表',N'listsFunctionCmsType',N'1.gif',2,2,41,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 43,N'会员登录设置',N'listsMemberPopedomSafeConfig',N'1.gif',21,2,42,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 44,N'Oauth登录设置',N'listsFunctionOauthConfig',N'1.gif',21,2,43,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 45,N'关键字历史列表',N'listsFunctionKeywordHistory',N'1.gif',5,2,44,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 46,N'支付订单列表',N'listsFunctionPayOrder',N'1.gif',11,2,45,0,N'T')
INSERT [vj_navigate] ([navigateId],[title],[url],[ico],[parentId],[nodeLevel],[nodeSort],[language],[display]) VALUES ( 47,N'图片列表',N'listsFunctionPhoto',N'1.gif',2,2,46,0,N'T')

GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_nodes]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_nodes]

CREATE TABLE [vj_nodes] (
[nodeId] [int]  NOT NULL,
[nodeName] [varchar]  (100) NULL DEFAULT (NULL),
[modelId] [int]  NULL DEFAULT (NULL),
[nodeType] [int]  NULL DEFAULT (NULL),
[nodeSort] [int]  NULL DEFAULT (NULL),
[parentId] [int]  NULL DEFAULT (NULL),
[keyword] [varchar]  (250) NULL DEFAULT (NULL),
[description] [varchar]  (250) NULL DEFAULT (NULL),
[isShowMap] [char]  (1) NULL DEFAULT (NULL),
[isSubDomain] [char]  (1) NULL DEFAULT (NULL),
[isCreateList] [char]  (1) NULL DEFAULT (NULL),
[isCreateContent] [char]  (1) NULL DEFAULT (NULL),
[isContribute] [char]  (1) NULL DEFAULT (NULL),
[subDomain] [varchar]  (250) NULL DEFAULT (NULL),
[listNameRule] [varchar]  (250) NULL DEFAULT (NULL),
[contentNameRule] [int]  NULL DEFAULT (NULL),
[nodePopedom] [char]  (1) NULL DEFAULT (NULL),
[nodeDir] [varchar]  (250) NULL DEFAULT (NULL),
[parentDir] [varchar]  (250) NULL DEFAULT (NULL),
[nodeUrl] [varchar]  (250) NULL DEFAULT (NULL),
[indexTemplate] [varchar]  (250) NULL DEFAULT (NULL),
[listTemplate] [varchar]  (250) NULL DEFAULT (NULL),
[contentTemplate] [varchar]  (250) NULL DEFAULT (NULL),
[nodeLevel] [int]  NULL DEFAULT (NULL),
[staticCount] [int]  NULL DEFAULT (NULL),
[fileCount] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_nodes] WITH NOCHECK ADD  CONSTRAINT [PK_vj_nodes] PRIMARY KEY  NONCLUSTERED ( [nodeId] )
GO
INSERT [vj_nodes] ([nodeId],[nodeName],[modelId],[nodeType],[nodeSort],[parentId],[keyword],[isShowMap],[isSubDomain],[isCreateList],[isCreateContent],[isContribute],[listNameRule],[contentNameRule],[nodePopedom],[nodeDir],[parentDir],[indexTemplate],[listTemplate],[contentTemplate],[nodeLevel],[staticCount],[fileCount]) VALUES ( 1,N'默认栏目',1,1,0,0,N'默认栏目',N'T',N'F',N'F',N'F',N'F',N'index',0,N'0',N'/test',N'/test',N'article_index.html',N'article_list.html',N'article_page.html',0,8,0)
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_online_admin]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_online_admin]

CREATE TABLE [vj_online_admin] (
[id] [char]  (32) NOT NULL,
[userName] [varchar]  (50) NULL DEFAULT (NULL),
[address] [varchar]  (40) NULL DEFAULT (NULL),
[roleName] [varchar]  (50) NULL DEFAULT (NULL),
[loginTime] [int]  NULL DEFAULT (NULL),
[sessionId] [char]  (32) NULL DEFAULT (NULL))


GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_password_recovery]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_password_recovery]

CREATE TABLE [vj_password_recovery] (
[id] [char]  (32) NOT NULL,
[userId] [char]  (32) NULL DEFAULT (NULL),
[recordTime] [int]  NULL DEFAULT (NULL),
[keyValue] [char]  (32) NULL DEFAULT (NULL),
[hit] [int]  NULL DEFAULT (NULL),
[inTime] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_password_recovery] WITH NOCHECK ADD  CONSTRAINT [PK_vj_password_recovery] PRIMARY KEY  NONCLUSTERED ( [id] )
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_password_recovery_history]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_password_recovery_history]

CREATE TABLE [vj_password_recovery_history] (
[id] [char]  (32) NOT NULL,
[userId] [char]  (32) NULL DEFAULT (NULL),
[hit] [int]  NULL DEFAULT (NULL),
[recordTime] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_password_recovery_history] WITH NOCHECK ADD  CONSTRAINT [PK_vj_password_recovery_history] PRIMARY KEY  NONCLUSTERED ( [id] )
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_resources]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_resources]

CREATE TABLE [vj_resources] (
[resourceId] [int]  NOT NULL,
[description] [varchar]  (250) NULL DEFAULT (NULL),
[expressionDesc] [varchar]  (150) NULL DEFAULT (NULL),
[resourceName] [varchar]  (50) NULL DEFAULT (NULL),
[resourceType] [char]  (1) NULL DEFAULT (NULL),
[nodeSort] [int]  NULL DEFAULT (NULL),
[parentId] [int]  NULL DEFAULT (NULL),
[language] [smallint]  NULL DEFAULT (NULL))

ALTER TABLE [vj_resources] WITH NOCHECK ADD  CONSTRAINT [PK_vj_resources] PRIMARY KEY  NONCLUSTERED ( [resourceId] )
GO
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 1,N'内容模型',N'#',N'内容模型',N'n',0,0,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 2,N'内容管理',N'#',N'内容管理',N'n',1,1,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 3,N'文章管理列表',N'/admin/listsFunctionArticle.**',N'文章列表',N'u',2,2,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 4,N'访问添加文章表单内容',N'/admin/addFormFunctionArticle.**',N'添加表单',N'u',3,3,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 5,N'添加文章内容',N'/admin/addFunctionArticle.**',N'添加',N'u',4,3,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 6,N'删除文章内容',N'/admin/deleteFunctionArticle.**',N'删除',N'u',5,3,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 7,N'修改文章表单',N'/admin/modifyFormFunctionArticle.**',N'修改表单',N'u',6,3,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 8,N'修改文章内容',N'/admin/updateFunctionArticle.**',N'修改',N'u',7,3,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 9,N'软件列表',N'/admin/listsFunctionSoft.**',N'软件列表',N'u',8,2,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 10,N'添加软件表单',N'/admin/addFormFunctionSoft.**',N'添加表单',N'u',9,9,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 11,N'添加软件内容',N'/admin/addFunctionSoft.**',N'添加',N'u',10,9,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 12,N'删除软件内容',N'/admin/deleteFunctionSoft.**',N'删除',N'u',11,9,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 13,N'修改软件表单',N'/admin/modifyFormFunctionSoft.**',N'修改表单',N'u',12,9,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 14,N'修改软件内容',N'/admin/updateFunctionSoft.**',N'修改',N'u',13,9,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 15,N'内容模块功能',N'#',N'内容功能',N'n',14,1,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 16,N'删除内容列表的静态文件',N'/admin/deletePageFunctionStaticFile.**',N'删除静态文件',N'u',15,15,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 17,N'生成内容列表的静态文件',N'/admin/genPageFunctionStaticFile.**',N'生成静态文件',N'u',16,15,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 18,N'生成内容列表的索引文件',N'/admin/genpageFunctionLuceneContent.**',N'生成索引文件',N'u',17,15,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 19,N'标签管理',N'/admin/listsFunctionTagList.**',N'标签管理',N'u',18,15,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 20,N'删除内容标签',N'/admin/deleteFunctionTagList.**',N'删除',N'u',19,19,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 21,N'评论管理',N'/admin/listsFunctionComment.**',N'评论管理',N'u',20,15,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 22,N'删除评论',N'/admin/deleteFunctionComment.**',N'删除',N'u',21,21,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 23,N'修改评论表单',N'/admin/modifyFormFunctionComment.**',N'修改表单',N'u',22,21,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 24,N'修改评论',N'/admin/updateFunctionCommen.**',N'修改',N'u',23,21,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 25,N'生成静态管理页面',N'/admin/listsFunctionStaticFile.**',N'管理静态文件',N'u',24,15,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 26,N'添加静态文件',N'/admin/addFunctionStaticFile.**',N'添加',N'u',25,25,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 27,N'索引管理',N'/admin/listsFunctionLuceneContent.**',N'索引管理',N'u',26,15,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 28,N'添加索引',N'/admin/addFunctionLuceneContent.**',N'添加',N'u',27,27,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 29,N'删除索引表单',N'/admin/deleteFormFunctionLuceneContent.**',N'删除表单',N'u',28,27,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 30,N'删除索引',N'/admin/deleteFunctionLuceneContent.**',N'删除',N'u',29,27,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 31,N'更新索引表单',N'/admin/modifyFormFunctionLuceneContent.**',N'更新表单',N'u',30,27,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 32,N'更新索引',N'/admin/updateFunctionLuceneContent.**',N'更新',N'u',31,27,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 33,N'栏目管理',N'/admin/listsFunctionNode.**',N'栏目管理',N'u',32,15,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 34,N'添加栏目表单',N'/admin/addFormFunctionNode.**',N'添加表单',N'u',33,33,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 35,N'添加栏目',N'/admin/addFunctionNode.**',N'添加',N'u',34,33,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 36,N'删除栏目',N'/admin/deleteFunctionNode.**',N'删除',N'u',35,33,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 37,N'修改栏目表单',N'/admin/modifyFormFunctionNode.**',N'修改表单',N'u',36,33,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 38,N'修改栏目',N'/admin/updateFunctionNode.**',N'修改',N'u',37,33,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 39,N'用户模型',N'#',N'用户模型',N'n',38,0,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 40,N'前台用户',N'#',N'前台用户',N'n',39,39,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 41,N'会员列表',N'/admin/listsUserMember.**',N'会员列表',N'u',40,40,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 42,N'添加会员表单',N'/admin/addFormUserMember.**',N'添加表单',N'u',41,41,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 43,N'添加会员',N'/admin/addUserMember.**',N'添加',N'u',42,41,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 44,N'删除会员',N'/admin/deleteUserMember.**',N'删除',N'u',43,41,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 45,N'修改会员表单',N'/admin/modifyFormUserMember.**',N'修改表单',N'u',44,41,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 46,N'修改会员',N'/admin/updateUserMember.**',N'修改',N'u',45,41,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 47,N'查看会员',N'/admin/findUserMember.**',N'查看',N'u',46,41,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 48,N'会员组',N'/admin/listsUserMemberGroup.**',N'会员组',N'u',47,40,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 49,N'添加会员组表单',N'/admin/addFormUserMemberGroup.**',N'添加表单',N'u',48,48,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 50,N'添加会员组',N'/admin/addUserMemberGroup.**',N'添加',N'u',49,48,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 51,N'删除会员组',N'/admin/deleteUserMemberGroup.**',N'删除',N'u',50,48,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 52,N'修改会员组表单',N'/admin/modifyFormUserMemberGroup.**',N'修改表单',N'u',51,48,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 53,N'修改会员组',N'/admin/updateUserMemberGroup.**',N'修改',N'u',52,48,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 54,N'后台用户管理',N'#',N'后台用户',N'n',53,39,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 55,N'管理员列表',N'/admin/listsUserAdmin.**',N'管理员列表',N'u',54,54,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 56,N'添加管理员表单',N'/admin/addFormUserAdmin.**',N'添加管理员表单',N'u',55,55,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 57,N'添加管理员',N'/admin/addUserAdmin.**',N'添加管理员',N'u',56,55,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 58,N'删除管理员',N'/admin/deleteUserAdmin.**',N'删除管理员',N'u',57,55,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 59,N'修改管理员表单',N'/admin/modifyFormUserAdmin.**',N'修改管理员表单',N'u',58,55,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 60,N'修改管理员',N'/admin/updateUserAdmin.**',N'修改管理员',N'u',59,55,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 61,N'修改管理员角色表单',N'/admin/modifyRoleFormUserAdmin.**',N'修改角色表单',N'u',60,55,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 62,N'修改管理员角色',N'/admin/updateRoleUserAdmin.**',N'修改角色',N'u',61,55,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 63,N'查看管理员',N'/admin/findUserAdmin.**',N'查看管理员',N'u',62,55,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 64,N'角色列表',N'/admin/listsPopedomRole.**',N'角色列表',N'u',63,54,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 65,N'添加角色表单',N'/admin/addFormPopedomRole.**',N'添加角色表单',N'u',64,64,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 66,N'添加角色',N'/admin/addPopedomRole.**',N'添加角色',N'u',65,64,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 67,N'删除角色',N'/admin/deletePopedomRole.**',N'删除角色',N'u',66,64,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 68,N'修改角色表单',N'/admin/modifyFormPopedomRole.**',N'修改表单',N'u',67,64,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 69,N'修改角色',N'/admin/updatePopedomRole.**',N'修改角色',N'u',68,64,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 70,N'修改角色权限表单',N'/admin/findPopedomRole.**',N'修改角色权限表单',N'u',69,64,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 71,N'修改角色权限',N'/admin/modifyResourcePopedomRole.**',N'修改角色权限',N'u',70,64,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 72,N'修改角色菜单表单',N'/admin/findNavigatePopedomRole.**',N'修改角色导航表单',N'u',71,64,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 73,N'修改角色菜单',N'/admin/modifyNavigatePopedomRole.**',N'修改角色导航',N'u',72,64,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 74,N'权限管理',N'/admin/listsPopedomResource.**',N'权限管理',N'u',73,54,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 75,N'添加权限表单',N'/admin/addFormPopedomResource.**',N'添加表单',N'u',74,74,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 76,N'添加权限',N'/admin/addPopedomResource.**',N'添加',N'u',75,74,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 77,N'删除权限',N'/admin/deletePopedomResource.**',N'删除',N'u',76,74,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 78,N'修改权限表单',N'/admin/modifyFormPopedomResource.**',N'修改表单',N'u',77,74,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 79,N'修改权限',N'/admin/updatePopedomResource.**',N'修改',N'u',78,74,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 80,N'刷新权限',N'/admin/refreshPopedomResource.**',N'刷新',N'u',79,74,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 81,N'登陆日志列表',N'/admin/listsUserAdminLog.**',N'登陆日志',N'u',80,54,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 82,N'删除日志',N'/admin/deleteUserAdminLog.**',N'删除',N'u',81,81,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 83,N'在线管理员',N'/admin/listsOnlineUserAdmin.**',N'在线管理员',N'u',82,54,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 84,N'删除在线管理员',N'/admin/deleteOnlineUserAdmin.**',N'删除',N'u',83,83,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 85,N'系统模型',N'#',N'系统模型',N'n',84,0,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 86,N'系统设置',N'#',N'系统设置',N'n',85,85,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 87,N'站点设置表单',N'/admin/listsFunctionWebSite.**',N'站点设置',N'u',86,86,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 88,N'修改站点',N'/admin/updateFunctionWebSite.**',N'修改站点',N'u',87,87,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 89,N'安全设置',N'/admin/listsPopedomSafeConfig.**',N'安全设置',N'u',88,86,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 90,N'修改安全设置',N'/admin/updatePopedomSafeConfig.**',N'修改',N'u',89,89,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 91,N'菜单设置列表',N'/admin/listsPopedomNavigate.**',N'导航设置',N'u',90,86,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 92,N'添加导航表单',N'/admin/addFormPopedomNavigate.**',N'添加表单',N'u',91,91,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 93,N'添加导航',N'/admin/addPopedomNavigate.**',N'添加',N'u',92,91,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 94,N'删除导航',N'/admin/deletePopedomNavigate.**',N'删除',N'u',93,91,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 95,N'修改导航表单',N'/admin/modifyFormPopedomNavigate.**',N'修改表单',N'u',94,91,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 96,N'修改导航',N'/admin/updatePopedomNavigate.**',N'修改',N'u',95,91,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 97,N'水印设置',N'/admin/listsFunctionWatermark.**',N'水印设置',N'u',96,86,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 98,N'修改水印',N'/admin/updateFunctionWatermark.**',N'修改',N'u',97,97,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 99,N'邮件设置',N'/admin/listsFunctionEmailConfig.**',N'邮件设置',N'u',98,86,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 100,N'修改邮件',N'/admin/updateFunctionEmailConfig.**',N'修改',N'u',99,99,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 101,N'模板设置',N'/admin/listsFunctionTemplateConfig.**',N'模板设置',N'u',100,86,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 102,N'修改模板',N'/admin/updateFunctionTemplateConfig.**',N'修改',N'u',101,101,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 103,N'模板标签设置列表',N'/admin/listsFunctionTemplateTag.**',N'模板标签设置',N'u',102,86,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 104,N'添加模板标签表单',N'/admin/addFormFunctionTemplateTag.**',N'添加表单',N'u',103,103,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 105,N'添加模板标签',N'/admin/addFunctionTemplateTag.**',N'添加',N'u',104,103,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 106,N'删除模板标签',N'/admin/deleteFunctionTemplateTag.**',N'删除',N'u',105,103,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 107,N'修改模板标签表单',N'/admin/modifyFormFunctionTemplateTag.**',N'修改表单',N'u',106,103,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 108,N'修改模板标签',N'/admin/updateFunctionTemplateTag.**',N'修改',N'u',107,103,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 109,N'系统变量设置',N'/admin/listsFunctionSystemConfig.**',N'系统变量设置',N'u',108,86,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 110,N'添加系统变量表单',N'/admin/addFormFunctionSystemConfig.**',N'添加表单',N'u',109,109,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 111,N'添加系统变量',N'/admin/addFunctionSystemConfig.**',N'添加',N'u',110,109,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 112,N'删除系统变量',N'/admin/deleteFunctionSystemConfig.**',N'删除',N'u',111,109,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 113,N'修改系统变量表单',N'/admin/modifyFormFunctionSystemConfig.**',N'修改表单',N'u',112,109,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 114,N'修改系统变量',N'/admin/updateFunctionSystemConfig.**',N'修改',N'u',113,109,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 115,N'系统功能',N'#',N'系统功能',N'n',114,85,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 116,N'备份数据',N'/admin/listsFunctionDatabase.**',N'备份数据',N'u',115,115,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 117,N'备份和还原',N'/admin/executeFunctionDatabase.**',N'备份和还原',N'u',116,116,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 118,N'国际化管理',N'/admin/listsFunctionDictionary.**',N'国际化管理',N'u',117,115,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 119,N'添加国际化表单',N'/admin/addFormFunctionDictionary.**',N'添加表单',N'u',118,118,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 120,N'添加国际化',N'/admin/addFunctionDictionary.**',N'添加',N'u',119,118,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 121,N'删除国际化',N'/admin/deleteFunctionDictionary.**',N'删除',N'u',120,118,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 122,N'修改国际化表单',N'/admin/modifyFormFunctionDictionary.**',N'修改表单',N'u',121,118,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 123,N'修改国际化',N'/admin/updateFunctionDictionary.**',N'修改',N'u',122,118,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 124,N'文件管理',N'/admin/listsFunctionFileManage.**',N'文件管理',N'u',123,115,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 125,N'上传文件表单',N'/admin/addFormFunctionFileManage.**',N'上传文件表单',N'u',124,124,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 126,N'上传文件',N'/admin/uploadFunctionFileManage.**',N'上传文件',N'u',125,124,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 127,N'重命文件名表单',N'/admin/renameFormFunctionFileManage.**',N'修改文件名表单',N'u',126,124,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 128,N'修改文件名',N'/admin/updateRenameFunctionFileManage.**',N'修改文件名',N'u',127,124,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 129,N'修改文件数据表单',N'/admin/modifyFormFunctionFileManage.**',N'修改文件数据表单',N'u',128,124,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 130,N'修改文件数据',N'/admin/updateFunctionFileManage.**',N'修改文件数据',N'u',129,124,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 131,N'删除文件',N'/admin/deleteFunctionFileManage.**',N'删除文件',N'u',130,124,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 132,N'创建文件目录',N'/admin/createDirFunctionFileManage.**',N'创建文件目录',N'u',131,124,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 133,N'发送邮件',N'/admin/listsSendSystemEmail.**',N'发送邮件',N'u',132,115,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 134,N'发送邮件',N'/admin/sendSystemEmail.**',N'发送',N'u',133,133,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 135,N'友情链接',N'/admin/listsFunctionLink.**',N'友情链接',N'u',134,115,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 136,N'添加友情链接表单',N'/admin/addFormFunctionLink.**',N'添加表单',N'u',135,135,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 137,N'添加友情链接',N'/admin/addFunctionLink.**',N'添加',N'u',136,135,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 138,N'删除友情链接',N'/admin/deleteFunctionLink.**',N'删除',N'u',137,135,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 139,N'修改友情链接表单',N'/admin/modifyFormFunctionLink.**',N'修改表单',N'u',138,135,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 140,N'修改友情链接',N'/admin/updateFunctionLink.**',N'修改',N'u',139,135,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 141,N'下载网址过滤',N'/admin/listsPopedomFilterUrl.**',N'下载网址过滤',N'u',140,115,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 142,N'添加下载网址过滤表单',N'/admin/addFormPopedomFilterUrl.**',N'添加表单',N'u',141,141,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 143,N'添加下载网址过滤',N'/admin/addPopedomFilterUrl.**',N'添加',N'u',142,141,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 144,N'删除下载网址过滤',N'/admin/deletePopedomFilterUrl.**',N'删除',N'u',143,141,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 145,N'下载网址过滤的修改表单',N'/admin/modifyFormPopedomFilterUrl.**',N'修改表单',N'u',144,141,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 146,N'修改下载网址过滤',N'/admin/updatePopedomFilterUrl.**',N'修改',N'u',145,141,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 147,N'频道模型管理',N'/admin/listsFunctionChannelModel.**',N'频道模型管理',N'u',146,115,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 148,N'添加频道模型表单',N'/admin/addFormFunctionChannelModel.**',N'添加表单',N'u',147,147,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 149,N'添加频道模型',N'/admin/addFunctionChannelModel.**',N'添加',N'u',148,147,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 150,N'删除频道模型',N'/admin/deleteFunctionChannelModel.**',N'删除',N'u',149,147,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 151,N'修改频道模型表单',N'/admin/modifyFormFunctionChannelModel.**',N'修改表单',N'u',150,147,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 152,N'修改频道模型',N'/admin/updateFunctionChannelModel.**',N'修改',N'u',151,147,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 153,N'投票管理',N'/admin/listsFunctionVote.**',N'投票管理',N'u',152,115,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 154,N'添加投票表单',N'/admin/addFormFunctionVote.**',N'添加表单',N'u',153,153,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 155,N'添加投票',N'/admin/addFunctionVote.**',N'添加',N'u',154,153,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 156,N'删除投票',N'/admin/deleteFunctionVote.**',N'删除',N'u',155,153,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 157,N'修改投票表单',N'/admin/modifyFormFunctionVote.**',N'修改表单',N'u',156,153,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 158,N'修改投票',N'/admin/updateFunctionVote.**',N'修改',N'u',157,153,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 159,N'后台首页',N'/admin/index.**',N'后台首页',N'u',158,115,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 160,N'专题列表',N'/admin/listsFunctionSpecialTopic.**',N'专题列表',N'u',159,2,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 161,N'添加专题表单',N'/admin/addFormFunctionSpecialTopic.**',N'添加表单',N'u',160,160,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 162,N'添加专题',N'/admin/addFunctionSpecialTopic.**',N'添加',N'u',161,160,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 163,N'修改专题表单',N'/admin/modifyFormFunctionSpecialTopic.**',N'修改表单',N'u',162,160,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 164,N'修改专题',N'/admin/updateFunctionSpecialTopic.**',N'修改',N'u',163,160,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 165,N'删除专题',N'/admin/deleteFunctionSpecialTopic.**',N'删除',N'u',164,160,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 166,N'视频列表',N'/admin/listsFunctionVideo.**',N'视频列表',N'u',165,2,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 167,N'添加视频表单',N'/admin/addFormFunctionVideo.**',N'添加表单',N'u',166,166,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 168,N'添加视频',N'/admin/addFunctionVideo.**',N'添加',N'u',167,166,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 169,N'修改视频表单',N'/admin/modifyFormFunctionVideo.**',N'修改表单',N'u',168,166,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 170,N'修改视频',N'/admin/updateFunctionVideo.**',N'修改',N'u',169,166,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 171,N'删除视频',N'/admin/deleteFunctionVideo.**',N'删除',N'u',170,166,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 172,N'CMS类型列表',N'/admin/listsFunctionCmsType.**',N'CMS类型列表',N'u',171,2,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 173,N'添加CMS类型表单',N'/admin/addFormFunctionCmsType.**',N'添加表单',N'u',172,172,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 174,N'添加CMS类型',N'/admin/addFunctionCmsType.**',N'添加',N'u',173,172,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 175,N'修改CMS类型表单',N'/admin/modifyFormFunctionCmsType.**',N'修改表单',N'u',174,172,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 176,N'修改CMS类型',N'/admin/updateFunctionCmsType.**',N'修改',N'u',175,172,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 177,N'删除CMS类型',N'/admin/deleteFunctionCmsType.**',N'删除',N'u',176,172,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 178,N'文章移动表单',N'/admin/moveFormFunctionArticle.**',N'移动表单',N'u',177,3,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 179,N'文章移动',N'/admin/moveSubmitFunctionArticle.**',N'移动提交',N'u',178,3,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 180,N'软件移动表单',N'/admin/moveFormFunctionSoft.**',N'移动表单',N'u',179,9,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 181,N'软件移动',N'/admin/moveSubmitFunctionSoft.**',N'移动提交',N'u',180,9,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 182,N'设置我的账号表单',N'/admin/myModifyFormUserAdmin.**',N'设置账号',N'u',181,54,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 183,N'修改我的资料',N'/admin/myUpdateUserAdmin.**',N'修改',N'u',182,182,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 184,N'会员登录设置',N'/admin/listsMemberPopedomSafeConfig.**',N'会员登录设置',N'u',183,86,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 185,N'修改会员登录配置',N'/admin/updateMemberPopedomSafeConfig.**',N'修改',N'u',184,184,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 186,N'生成静态文件',N'/admin/genNodeFunctionStaticFile.**',N'生成静态文件',N'u',185,33,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES ( 187,N'删除静态文件',N'/admin/deleteNodeFunctionStaticFile.**',N'删除静态文件',N'u',186,33,0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (188,N'上传图片表单',N'/admin/uploadImageForm.**',N'上传图片表单',N'u', 187, 15, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (189,N'上传图片','/admin/uploadImageFile.**',N'上传图片',N'u', 188, 188, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (190,N'上传附件表单',N'/admin/uploadAttachmentForm.**',N'上传附件表单',N'u', 189, 15, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (191,N'上传附件',N'/admin/uploadAttachmentFile.**',N'上传附件',N'u', 190, 190, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (192,N'评论审核',N'/admin/auditFunctionComment.**',N'评论审核',N'u', 191, 21, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (193,N'关键字历史列表',N'/admin/listsFunctionKeywordHistory.**',N'关键字历史列表',N'u', 192, 15, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (194,N'删除关键字',N'/admin/deleteFunctionKeywordHistory.**',N'删除',N'u', 193, 193, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (195,N'Oauth登录设置',N'/admin/listsFunctionOauthConfig.**',N'Oauth登录设置',N'u', 194, 86, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (196,N'添加表单',N'/admin/addFormFunctionOauthConfig.**',N'添加表单',N'u', 195, 195, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (197,N'添加',N'/admin/addFunctionOauthConfig.**',N'添加',N'u', 196, 195, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (198,N'修改表单',N'/admin/modifyFormFunctionOauthConfig.**',N'修改表单',N'u', 197, 195, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (199,N'修改',N'/admin/updateFunctionOauthConfig.**',N'修改',N'u', 198, 195, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (200,N'删除',N'/admin/deleteFunctionOauthConfig.**',N'删除',N'u', 199, 195, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (201,N'支付订单列表',N'/admin/listsFunctionPayOrder.**',N'支付订单列表',N'u', 200, 40, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (202,N'已付款',N'/admin/confirmFunctionPayOrder.**',N'已付款',N'u', 201, 201, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES  (203,N'删除',N'/admin/deleteFunctionPayOrder.**',N'删除',N'u', 202, 201, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES (204,N'专题搜索',N'/admin/selectFromScpecialTopicContent.**', N'专题搜索', 'u', 203, 160, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES (205,N'移动表单',N'/admin/moveFormFunctionVideo.**', N'移动表单', 'u', 204, 166, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES (206,N'移动提交',N'/admin/moveSubmitFunctionVideo.**', N'移动提交', 'u', 205, 166, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES (207,N'图片列表',N'/admin/listsFunctionPhoto.**', N'图片列表', 'u', 206, 2, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES (208,N'添加表单',N'/admin/addFormFunctionPhoto.**', N'添加表单', 'u', 207, 207, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES (209,N'添加', N'/admin/addFunctionPhoto.**', '添加', N'u', 208, 207, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES (210,N'修改表单',N'/admin/modifyFormFunctionPhoto.**', N'修改表单', 'u', 209, 207, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES (211,N'修改图片',N'/admin/updateFunctionPhoto.**', N'修改', 'u', 210, 207, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES (212,N'删除图片',N'/admin/deleteFunctionPhoto.**', N'删除', 'u', 211, 207, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES (213,N'移动表单',N'/admin/moveFormFunctionPhoto.**', N'移动表单', 'u', 212, 207, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES (214,N'移动提交',N'/admin/moveSubmitFunctionPhoto.**', N'移动提交', 'u', 213, 207, 0)
INSERT [vj_resources] ([resourceId],[description],[expressionDesc],[resourceName],[resourceType],[nodeSort],[parentId],[language]) VALUES (215,N'上传表单',N'/admin/uploadFormFunctionPhoto.**', n'上传表单', 'u', 214, 207, 0)
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_role_navigate]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_role_navigate]

CREATE TABLE [vj_role_navigate] (
[roleId] [int]  NOT NULL,
[navigateId] [int]  NOT NULL)

ALTER TABLE [vj_role_navigate] WITH NOCHECK ADD  CONSTRAINT [PK_vj_role_navigate] PRIMARY KEY  NONCLUSTERED ( [roleId],[navigateId] )
GO

if exists (select * from sysobjects where id = OBJECT_ID('[vj_role_resource]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_role_resource]

CREATE TABLE [vj_role_resource] (
[roleId] [int]  NOT NULL,
[resourceId] [int]  NOT NULL)

ALTER TABLE [vj_role_resource] WITH NOCHECK ADD  CONSTRAINT [PK_vj_role_resource] PRIMARY KEY  NONCLUSTERED ( [roleId],[resourceId] )
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_roles]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_roles]

CREATE TABLE [vj_roles] (
[roleId] [int]  NOT NULL,
[description] [varchar]  (250) NULL DEFAULT (NULL),
[roleName] [varchar]  (50) NULL DEFAULT (NULL),
[language] [smallint]  NULL DEFAULT (NULL))

ALTER TABLE [vj_roles] WITH NOCHECK ADD  CONSTRAINT [PK_vj_roles] PRIMARY KEY  NONCLUSTERED ( [roleId] )
GO
INSERT [vj_roles] ([roleId],[description],[roleName],[language]) VALUES ( 0,N'超级管理员',N'超级管理员',0)
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_safe_config]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_safe_config]

CREATE TABLE [vj_safe_config] (
[configId] [char]  (1) NOT NULL,
[isAccountExpire] [char]  (1) NULL DEFAULT (NULL),
[isVerCode] [char]  (1) NULL DEFAULT (NULL),
[isLockAccount] [char]  (1) NULL DEFAULT (NULL),
[isPassExpire] [char]  (1) NULL DEFAULT (NULL),
[isEnable] [char]  (1) NULL DEFAULT (NULL),
[isAutoRelieve] [char]  (1) NULL DEFAULT (NULL),
[accountLockTime] [int]  NULL DEFAULT (NULL),
[accountExpireTime] [int]  NULL DEFAULT (NULL),
[disableCount] [int]  NULL DEFAULT (NULL),
[passwordExpireTime] [int]  NULL DEFAULT (NULL),
[passwordErrorCount] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_safe_config] WITH NOCHECK ADD  CONSTRAINT [PK_vj_safe_config] PRIMARY KEY  NONCLUSTERED ( [configId] )
GO
INSERT [vj_safe_config] ([configId],[isAccountExpire],[isVerCode],[isLockAccount],[isPassExpire],[isEnable],[isAutoRelieve],[accountLockTime],[accountExpireTime],[disableCount],[passwordExpireTime],[passwordErrorCount]) VALUES ( N'1',N'T',N'F',N'T',N'T',N'T',N'T',2,20,3,33,3)
INSERT [vj_safe_config] ([configId],[isAccountExpire],[isVerCode],[isLockAccount],[isPassExpire],[isEnable],[isAutoRelieve],[accountLockTime],[accountExpireTime],[disableCount],[passwordExpireTime],[passwordErrorCount]) VALUES ( N'2',N'T',N'F',N'T',N'T',N'T',N'T',2,20,3,33,3)
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_softs]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_softs]

CREATE TABLE [vj_softs] (
[id] [char]  (32) NOT NULL,
[fileType] [int]  NULL DEFAULT (NULL),
[fileSize] [varchar]  (50) NULL DEFAULT (NULL),
[star] [char]  (1) NULL DEFAULT (NULL),
[runSystem] [int]  NULL DEFAULT (NULL),
[website] [varchar]  (250) NULL DEFAULT (NULL),
[language] [int]  NULL DEFAULT (NULL),
[authorize] [varchar]  (50) NULL DEFAULT (NULL),
[email] [varchar]  (250) NULL DEFAULT (NULL),
[downloadUrl] [varchar]  (MAX) NULL)

ALTER TABLE [vj_softs] WITH NOCHECK ADD  CONSTRAINT [PK_vj_softs] PRIMARY KEY  NONCLUSTERED ( [id] )
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_system_config]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_system_config]

CREATE TABLE [vj_system_config] (
[id] [int]  NOT NULL,
[varName] [varchar]  (150) NULL DEFAULT (NULL),
[description] [varchar]  (250) NULL DEFAULT (NULL),
[type] [int]  NULL DEFAULT (NULL),
[value] [varchar]  (250) NULL DEFAULT (NULL),
[modelId] [int]  NULL DEFAULT (NULL),
[status] [char]  (1) NULL DEFAULT (NULL))

ALTER TABLE [vj_system_config] WITH NOCHECK ADD  CONSTRAINT [PK_vj_system_config] PRIMARY KEY  NONCLUSTERED ( [id] )
CREATE UNIQUE INDEX [IX_vj_system_config_varName] ON [vj_system_config]([varName])
GO
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 1,N'core_isAdminLog',N'是否开启管理员日志',2,N'T',0,N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 2,N'cms_register_welcome',N'是否发送注册欢迎信',2,N'F',0,N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 3,N'cms_memberUpgradeCosts',N'升级会员费用',4,N'100',0,N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 4,N'cms_installDirectory',N'CMS安装目录',0,N'/',0,N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 5,N'cms_imageUrl',N'图片域名地址',0,N'http://localhost/cms',0,N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 6,N'cms_imageUploadDirectory',N'图片上传目录',0,N'/upload/image/',0,N'F')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 7,N'core_coding',N'系统编码',0,N'utf-8',0,N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 8,N'core_staticSuffix',N'静态后缀',0,N'.html',0,N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 9,N'core_dynamicSuffix',N'动态后缀',0,N'.jhtml',0,N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 10,N'core_folderStyle',N'1(年月日)2(年月)3(年)格式',1,N'2',0,N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 11,N'cms_softUploadDirectory',N'软件路径',0,N'/upload/soft/',0,N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 12,N'cms_softAddress',N'软件下载地址',0,N'http://localhost/cms',0,N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 13,N'cms_isSha1',N'T真,F假',2,N'T',0,N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 14,N'cms_isContentLucene',N'全文搜索',2,N'T',0,N'F')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 15,N'cms_memberFaceUploadDirectory',N'会员头像上传路径',0,N'/upload/face/',0,N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 16,N'cms_alipayInfo',N'支付宝信息',0,N'partner,prestrKey,sellerEmail',0,N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 17,N'cms_memberSubmission', N'会员登录投稿', 2, N'F', 0, N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 18,N'cms_isAuditComment', N'评论审核', 2, N'F', 0, N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 19,N'cms_thumbnails_width', N'略缩图宽度', 1, N'120', 0, N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 20,N'cms_thumbnails_height', N'略缩图度度', 1, N'120', 0, N'T')
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 21,N'cms_aliyun_oss_config',N'阿里云OSS配置信息(ID,Secret,URL)',0,N'ID,Secret,URL',0,N'T');
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 22,N'cms_aliyun_oss_bucketName',N'阿里云OSS的bucketName值',0,N'vijun',0,N'T');
INSERT [vj_system_config] ([id],[varName],[description],[type],[value],[modelId],[status]) VALUES ( 23,N'cms_user_init_capacity', N'用户初始网盘容量(MB/单位)', 1, N'50', 0, N'T');
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_tag_list]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_tag_list]

CREATE TABLE [vj_tag_list] (
[tagId] [char]  (32) NOT NULL,
[contentId] [char]  (32) NULL DEFAULT (NULL),
[nodeId] [int]  NULL DEFAULT (NULL),
[tagName] [varchar]  (20) NULL DEFAULT (NULL),
[tagTime] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_tag_list] WITH NOCHECK ADD  CONSTRAINT [PK_vj_tag_list] PRIMARY KEY  NONCLUSTERED ( [tagId] )
CREATE INDEX [IX_vj_tag_list_tagName] ON [vj_tag_list]([tagName])
CREATE INDEX [IX_vj_tag_list_contentId] ON [vj_tag_list]([contentId])
CREATE INDEX [IX_vj_tag_list_tagTime] ON [vj_tag_list]([tagTime])
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_template_config]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_template_config]

CREATE TABLE [vj_template_config] (
[id] [int]  NOT NULL,
[templateLocale] [int]  NULL DEFAULT (NULL),
[dateTimeFormat] [varchar]  (50) NULL DEFAULT (NULL),
[dateFormat] [varchar]  (50) NULL DEFAULT (NULL),
[timeFormat] [varchar]  (50) NULL DEFAULT (NULL),
[numberFormat] [varchar]  (50) NULL DEFAULT (NULL),
[tagSyntax] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_template_config] WITH NOCHECK ADD  CONSTRAINT [PK_vj_template_config] PRIMARY KEY  NONCLUSTERED ( [id] )
GO
INSERT [vj_template_config] ([id],[templateLocale],[dateTimeFormat],[dateFormat],[timeFormat],[numberFormat],[tagSyntax]) VALUES ( 1,0,N'yyyy-MM-dd HH:mm:ss',N'yyyy-MM-dd',N'HH:mm:ss',N'0.######',2)
if exists (select * from sysobjects where id = OBJECT_ID('[vj_template_tag]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_template_tag]

CREATE TABLE [vj_template_tag] (
[tagId] [int]  NOT NULL,
[tagName] [varchar]  (50) NULL DEFAULT (NULL),
[tagClass] [varchar]  (250) NULL DEFAULT (NULL),
[description] [varchar]  (250) NULL DEFAULT (NULL),
[status] [char]  (1) NULL DEFAULT (NULL))

ALTER TABLE [vj_template_tag] WITH NOCHECK ADD  CONSTRAINT [PK_vj_template_tag] PRIMARY KEY  NONCLUSTERED ( [tagId] )
GO
INSERT [vj_template_tag] ([tagId],[tagName],[tagClass],[description],[status]) VALUES ( 1,N'sys_list_c',N'com.vijun.cms.util.freemarker.directive.ContentListDirective',N'内容列表',N'1')
INSERT [vj_template_tag] ([tagId],[tagName],[tagClass],[description],[status]) VALUES ( 2,N'sys_cut',N'com.vijun.cms.util.freemarker.directive.CutDirective',N'文本剪切',N'1')
INSERT [vj_template_tag] ([tagId],[tagName],[tagClass],[description],[status]) VALUES ( 3,N'sys_list',N'com.vijun.cms.util.freemarker.directive.NodeListDirective',N'栏目列表',N'1')
INSERT [vj_template_tag] ([tagId],[tagName],[tagClass],[description],[status]) VALUES ( 4,N'sys_list_cp',N'com.vijun.cms.util.freemarker.directive.ContentListByCountDirective',N'内容列表带分页',N'1')
INSERT [vj_template_tag] ([tagId],[tagName],[tagClass],[description],[status]) VALUES ( 5,N'sys_pagination',N'com.vijun.cms.util.freemarker.directive.PaginationDirective',N'分页标签',N'1')
INSERT [vj_template_tag] ([tagId],[tagName],[tagClass],[description],[status]) VALUES ( 6,N'sys_member',N'com.vijun.cms.util.freemarker.directive.MemberDirective',N'会员内容',N'1')
INSERT [vj_template_tag] ([tagId],[tagName],[tagClass],[description],[status]) VALUES ( 7,N'sys_search',N'com.vijun.cms.util.freemarker.directive.SearchDirective',N'搜索内容',N'1')
INSERT [vj_template_tag] ([tagId],[tagName],[tagClass],[description],[status]) VALUES ( 8,N'sys_lucene',N'com.vijun.cms.util.freemarker.directive.LuceneSearchDirective',N'全文搜索',N'1')
INSERT [vj_template_tag] ([tagId],[tagName],[tagClass],[description],[status]) VALUES ( 9,N'sys_timeZone',N'com.vijun.cms.util.freemarker.directive.TimeZoneDirective',N'时区',N'1')
INSERT [vj_template_tag] ([tagId],[tagName],[tagClass],[description],[status]) VALUES ( 10,N'sys_sql',N'com.vijun.cms.util.freemarker.directive.SqlDirective',N'sql标签',N'1')
INSERT [vj_template_tag] ([tagId],[tagName],[tagClass],[description],[status]) VALUES ( 11,N'sys_format',N'com.vijun.cms.util.freemarker.directive.TextFormatDirective',N'内容格式',N'1')
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_video]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_video]

CREATE TABLE [vj_video] (
[id] [char]  (32) NOT NULL DEFAULT (N''),
[title] [varchar]  (255) NULL DEFAULT (NULL),
[playerUrl] [varchar]  (255) NULL DEFAULT (NULL),
[videoTime] [varchar]  (50) NULL DEFAULT (NULL),
[language] [varchar]  (50) NULL DEFAULT (NULL))

ALTER TABLE [vj_video] WITH NOCHECK ADD  CONSTRAINT [PK_vj_video] PRIMARY KEY  NONCLUSTERED ( [id] )
GO

if exists (select * from sysobjects where id = OBJECT_ID('[vj_vote]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_vote]

CREATE TABLE [vj_vote] (
[id] [int]  NOT NULL,
[subject] [varchar]  (250) NULL DEFAULT (NULL),
[startTime] [int]  NULL DEFAULT (NULL),
[endTime] [int]  NULL DEFAULT (NULL),
[hit] [int]  NULL DEFAULT (NULL),
[status] [char]  (1) NULL DEFAULT (NULL))

ALTER TABLE [vj_vote] WITH NOCHECK ADD  CONSTRAINT [PK_vj_vote] PRIMARY KEY  NONCLUSTERED ( [id] )
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_vote_topic]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_vote_topic]

CREATE TABLE [vj_vote_topic] (
[id] [char]  (32) NOT NULL,
[title] [varchar]  (250) NULL DEFAULT (NULL),
[voteCount] [int]  NULL DEFAULT (NULL),
[voteId] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_vote_topic] WITH NOCHECK ADD  CONSTRAINT [PK_vj_vote_topic] PRIMARY KEY  NONCLUSTERED ( [id] )
CREATE INDEX [IX_vj_vote_topic_voteId] ON [vj_vote_topic]([voteId])
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_watermark]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_watermark]

CREATE TABLE [vj_watermark] (
[watermarkId] [char]  (1) NOT NULL,
[watermarkPath] [varchar]  (250) NULL DEFAULT (NULL),
[alpha] [char]  (3) NULL DEFAULT (NULL),
[watermarkPosition] [int]  NULL DEFAULT (NULL),
[spacingX] [int]  NULL DEFAULT (NULL),
[spacingY] [int]  NULL DEFAULT (NULL),
[watermarkText] [varchar]  (250) NULL DEFAULT (NULL),
[fontPath] [varchar]  (250) NULL DEFAULT (NULL),
[fontColor] [char]  (6) NULL DEFAULT (NULL),
[fontSize] [int]  NULL DEFAULT (NULL),
[watermarkType] [char]  (1) NULL DEFAULT (NULL),
[width] [int]  NULL DEFAULT (NULL),
[height] [int]  NULL DEFAULT (NULL))

ALTER TABLE [vj_watermark] WITH NOCHECK ADD  CONSTRAINT [PK_vj_watermark] PRIMARY KEY  NONCLUSTERED ( [watermarkId] )
GO
INSERT [vj_watermark] ([watermarkId],[watermarkPath],[alpha],[watermarkPosition],[spacingX],[spacingY],[watermarkText],[fontPath],[fontColor],[fontSize],[watermarkType],[width],[height]) VALUES ( N'1',N'/template/images/mark.png',N'0.5',9,-20,1,N'技术网',N'/template/font/1.ttf',N'B22222',20,N'1',300,200)
GO
if exists (select * from sysobjects where id = OBJECT_ID('[vj_web_config]') and OBJECTPROPERTY(id, 'IsUserTable') = 1) 
DROP TABLE [vj_web_config]

CREATE TABLE [vj_web_config] (
[configId] [char]  (1) NOT NULL,
[websiteName] [varchar]  (250) NULL DEFAULT (NULL),
[publicityTitle] [varchar]  (250) NULL DEFAULT (NULL),
[url] [varchar]  (250) NULL DEFAULT (NULL),
[templateDir] [varchar]  (250) NULL DEFAULT (NULL),
[keyword] [varchar]  (250) NULL DEFAULT (NULL),
[description] [varchar]  (250) NULL DEFAULT (NULL),
[recordNumber] [varchar]  (50) NULL DEFAULT (NULL),
[powerby] [varchar]  (2000) NULL DEFAULT (NULL),
[systemVersion] [varchar]  (50) NULL DEFAULT (NULL))

ALTER TABLE [vj_web_config] WITH NOCHECK ADD  CONSTRAINT [PK_vj_web_config] PRIMARY KEY  NONCLUSTERED ( [configId] )
GO
INSERT [vj_web_config] ([configId],[websiteName],[publicityTitle],[url],[templateDir],[keyword],[description],[recordNumber],[powerby],[systemVersion]) VALUES ( N'1',N'微骏技术网',N'努力做好java技术平台',N'http://www.vijun.com',N'/WEB-INF/cms/template/default/zh_CN/',N'java',N'微骏技术网',N'沪ICP备12006519号-1',N'Copyright  2012 vijun.com All Rights Reserved.',N'1.0 Release')
GO