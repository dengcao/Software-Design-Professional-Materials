CREATE TABLE vj_consumption_record (
  id  character(32) NOT NULL,
  memberId character(32),
  contentId character(32),
  nodeId integer,
  consumption decimal(10,2),
  consumptionTime integer,
  consumptionType integer,
  state character(1),
  PRIMARY KEY (id)
);
CREATE INDEX "IX_consumption_record_cId_nId" ON vj_consumption_record(contentId,nodeId);

CREATE TABLE vj_photos (
  id  character(32) NOT NULL,
  photoText clob,
  style character(1),
  PRIMARY KEY (id)
);

CREATE TABLE vj_special_topic (
  id integer NOT NULL,
  nodeId integer,
  title varchar(255),
  titleImg varchar(255),
  code clob,
  createTime integer,
  author varchar(50),
  templatePath varchar(255),
  description varchar(1000),
  isStatic character(1),
  PRIMARY KEY (id)
);
CREATE INDEX "IX_vj_special_topic_createTime" ON vj_special_topic(createTime);
CREATE INDEX "IX_vj_special_topic_title" ON vj_special_topic(title);

CREATE TABLE vj_keyword_history (
  id  character(32) NOT NULL,
  keyword varchar(255),
  searchCount integer,
  isContent character(1),
  PRIMARY KEY (id)
);
CREATE INDEX "IX_vj_keyword_history_keyword" ON vj_keyword_history(keyword);

CREATE TABLE vj_member_consume_record (
  id character(32) NOT NULL,
  amount decimal(10,2),
  amountType integer,
  action integer,
  description varchar(255),
  memberId character(32),
  creationTime integer,
  PRIMARY KEY (id)
);
CREATE INDEX "IX_vj_member_consume_recore_creationTime" ON vj_member_consume_record(creationTime);

CREATE TABLE vj_email_validation (
  id  character(32) NOT NULL,
  userId character(32),
  email varchar(150),
  keyValue character(32),
  recordTime integer,
  inTime integer,
  hit integer,
  PRIMARY KEY (id)
);
CREATE TABLE vj_pay_order (
  id character(32) NOT NULL,
  title varchar(200),
  orderNo character(32),
  payNo varchar(150),
  memberId character(32),
  payPrice decimal(10,2),
  quantity integer,
  payType integer,
  remark varchar(250),
  status integer,
  creationTime integer,
  payTime integer,
  ConfirmTime integer,
  ipAddress varchar(40),
  PRIMARY KEY (id)
);
CREATE INDEX "IX_vj_pay_order_creationTime" ON vj_pay_order(creationTime);
CREATE UNIQUE INDEX "IX_vj_pay_order_orderNo" ON vj_pay_order(orderNo);

CREATE TABLE vj_oauth_config (
  id integer NOT NULL,
  name varchar(20),
  clientId varchar(150),
  clientSecret varchar(150),
  redirectUri varchar(150),
  authorizeUrl varchar(150),
  tokenUrl varchar(150),
  meUrl varchar(150),
  PRIMARY KEY (id)
);

CREATE UNIQUE INDEX "IX_vj_oauth_config_name" ON vj_oauth_config(name);


CREATE TABLE vj_oauth (
  id character(32) NOT NULL,
  openId varchar(100),
  memberId character(32),
  loginType integer,
  PRIMARY KEY (id)
);

CREATE UNIQUE INDEX "IX_vj_oauth_openId" ON vj_oauth(openId);
CREATE INDEX "IX_vj_oauth_memberId" ON vj_oauth(memberId);

INSERT INTO vj_oauth_config(id,name,clientId,clientSecret,redirectUri,authorizeUrl,tokenUrl,meUrl) VALUES (1, 'qq', '', '', 'http://www.vijun.com/oauth/qq/authorizationCode.sh', 'https://graph.qq.com/oauth2.0/authorize', 'https://graph.qq.com/oauth2.0/token', 'https://graph.qq.com/oauth2.0/me');
INSERT INTO vj_oauth_config(id,name,clientId,clientSecret,redirectUri,authorizeUrl,tokenUrl,meUrl) VALUES (2, 'msn', '', '', 'http://www.vijun.com/oauth/msn/authorizationCode.sh', 'https://oauth.live.com/authorize', 'https://oauth.live.com/token', 'https://apis.live.net/v5.0/me');
INSERT INTO vj_oauth_config(id,name,clientId,clientSecret,redirectUri,authorizeUrl,tokenUrl,meUrl) VALUES (3, 'baidu', '', '', 'http://www.vijun.com/oauth/baidu/authorizationCode.sh', 'https://openapi.baidu.com/oauth/2.0/authorize', 'https://openapi.baidu.com/oauth/2.0/token', 'https://openapi.baidu.com/rest/2.0/passport/users/getInfo');

CREATE TABLE vj_admin_log
(
   id character(32) not null, 
   code integer, 
   type character(1), 
   userName varchar(100), 
   ipAddress varchar(40), 
   recordTime integer, 
    PRIMARY KEY (id)
);
CREATE INDEX "IX_vj_admin_log_time" ON vj_admin_log(recordTime desc);
CREATE TABLE vj_admin_role
(
   adminId character(32) not null, 
   roleId integer not null,
    PRIMARY KEY (adminId, roleId)
);
CREATE TABLE vj_admins (
  adminId character(32) not null,
  username varchar(20), 
  password character(56),
  accountExpired character(1),
  accountLocked character(1),
  credentialsExpired character(1),
  enable character(1),
  lastLoginIp varchar(40), 
  lastLoginTime integer,
  lastUpdatePassWordTime integer,
  loginCount integer,
  loginErrorCount integer,
  registerTime integer,
  myTimeZone character(6),
  myLanguage integer,
  isPassExpire character(1),
  accountLockCount integer,
  isAccountExpire character(1),
  superPassword character(56),
  email varchar(250),
  question character(1),
  answer varchar(250),
  isAnswerLogin character(1),
  PRIMARY KEY (adminId)
);
CREATE UNIQUE INDEX "IX_vj_admins_username" ON vj_admins(username);
CREATE INDEX "IX_vj_admins_register" ON vj_admins(registerTime);
CREATE TABLE vj_channel_model (
  modelId integer not null,
  modelName varchar(50),
  type character(1),
  description varchar(250),
  enable character(1),
  language integer,
  PRIMARY KEY (modelId)
);
CREATE TABLE vj_cms_type (
  id integer not null,
  name varchar(150),
  typeId integer,
  modelId integer,
  keyId integer,
  PRIMARY KEY (id) 
);
CREATE TABLE vj_comments (
  commentsId character(32) not null,
  contentId character(32),
  commentsText varchar(500),
  support integer,
  against integer,
  commentsTime integer,
  ipAddress varchar(40),
  memberId character(32),
  status character(1),
  nodeId integer,
  modelId integer,
  PRIMARY KEY (commentsId)
);
CREATE INDEX "IX_vj_comments_contentId" ON vj_comments(contentId);
CREATE INDEX "IX_vj_comments_commentTime" ON vj_comments(commentsTime);
CREATE TABLE vj_content_text (
  id character(32) not null,
  detail clob,
  PRIMARY KEY (id)
);
CREATE TABLE vj_contents (
  id character(32) not null,
  title varchar(250),
  subTitle varchar(250),
  copyFrom varchar(50),
  authorName varchar(50),
  authorId character(32),
  keyword varchar(50),
  intro varchar(500),
  publishTime integer,
  status character(1),
  tags varchar(100),
  isTop character(1),
  isRecommend character(1),
  isPic character(1),
  isComment character(1),
  isFlash character(1),
  permissionLevel character(1),
  modelId integer,
  nodeId integer,
  urlRename varchar(250),
  titleImg varchar(250),
  costMoney integer,
  staticDir varchar(100),
  PRIMARY KEY (id)
);
CREATE INDEX "IX_vj_contents_urlRename" ON vj_contents(urlRename);
CREATE INDEX "IX_vj_contents_title" ON vj_contents(title);
CREATE INDEX "IX_vj_contents_publishTime" ON vj_contents(publishTime);
CREATE INDEX "IX_vj_contents_nodeId" ON vj_contents(nodeId);
CREATE TABLE vj_cost_point_history (
  id character(32) not null,
  itemId character(32),
  costPoint integer,
  memberId character(32),
  costTime integer,
  PRIMARY KEY (id)
);
CREATE TABLE vj_dictionary (
  id integer not null,
  name varchar(250),
  description varchar(250),
  language integer,
  modelId integer,
  contentId integer,
  PRIMARY KEY (id) 
);
CREATE TABLE vj_email_config (
  configId integer not null,
  sender varchar(50),
  email varchar(250),
  smtpAddress varchar(250),
  subject varchar(250),
  contents clob,
  isHtml character(1),
  isEsmtp character(1),
  isAttachment character(1),
  emailPort integer,
  retry integer,
  emailInterval integer,
  timeOut integer,
  userName varchar(50),
  password varchar(50),
  PRIMARY KEY (configId)
);
CREATE TABLE vj_filter_url (
  urlId integer not null,
  name varchar(50),
  url varchar(250),
  type character(1),
  PRIMARY KEY (urlId)
);
CREATE TABLE vj_hit (
  id character(32) not null,
  modelId integer,
  nodeId integer,
  click integer,
  clickDay integer,
  clickWeek integer,
  clickMonth integer,
  PRIMARY KEY (id)
);
CREATE TABLE vj_links (
  linkId character(32) not null,
  name varchar(50),
  url varchar(250),
  type character(1),
  description varchar(250),
  logo varchar(250),
  display character(1),
  PRIMARY KEY (linkId)
);
CREATE TABLE vj_member_favorite (
  favoriteId character(32) not null,
  modelId integer,
  nodeId integer,
  contentId character(32),
  memberId character(32),
  PRIMARY KEY (favoriteId)
);
CREATE TABLE vj_member_funds (
  memberId character(32) not null,
  memberMoney numeric(10,2),
  payPassword character(56),
  memberPoint integer,
  costMoney numeric(10,2),
  costPoint integer,
  PRIMARY KEY (memberId) 
);
CREATE TABLE vj_member_group (
  groupId integer not null,
  groupName varchar(50),
  fileSize integer,
  fileSuffix varchar(50),
  upgradeExp integer,
  description varchar(45),
  language integer,
  PRIMARY KEY (groupId)
);
CREATE TABLE vj_member_info (
  memberId character(32) not null,
  netName varchar(50),
  trueName varchar(50),
  sex character(1),
  country varchar(50),
  city varchar(50),
  address varchar(250),
  phone integer,
  mobile integer,
  postCount integer,
  face varchar(250),
  sign varchar(250),
  privacySet character(1),
  integral integer,
  diskCapacity integer,
  useCapacity integer,
  PRIMARY KEY (memberId)
);
CREATE TABLE vj_members (
  memberId character(32) not null,
  groupId integer,
  memberType character(1),
  loginId varchar(20),
  password character(56),
  email varchar(150),
  registerTime integer,
  myTimeZone character(6),
  myLanguage integer,
  lastLoginIp varchar(40),
  lastLoginTime integer,
  loginCount integer,
  loginErrorCount integer,
  answerErrorCount integer,
  accountExpired character(1),
  accountLocked character(1),
  credentialsExpired character(1),
  status character(1),
  lastUpdatePassWordTime integer,
  isPassExpire character(1),
  isAccountExpire character(1),
  isAnswerLogin character(1),
  question character(1),
  answer varchar(250),
  accountLockCount integer,
  accountLockTime integer,
  PRIMARY KEY (memberId)
);
CREATE UNIQUE INDEX "IX_vj_members_loginId" ON vj_members(loginId);
CREATE UNIQUE INDEX "IX_vj_members_email" ON vj_members(email);
CREATE INDEX "IX_vj_members_registerTime" ON vj_members(registerTime);

CREATE TABLE vj_navigate (
  navigateId integer not null,
  title varchar(100),
  url varchar(250),
  ico varchar(50),
  parentId integer,
  nodeLevel integer,
  nodeSort integer,
  language integer,
  display character(1),
  PRIMARY KEY (navigateId)
);
CREATE TABLE vj_nodes (
  nodeId integer not null,
  nodeName varchar(100),
  modelId integer,
  nodeType integer,
  nodeSort integer,
  parentId integer,
  keyword varchar(250),
  description varchar(250),
  isShowMap character(1),
  isSubDomain character(1),
  isCreateList character(1),
  isCreateContent character(1),
  isContribute character(1),
  subDomain varchar(250),
  listNameRule varchar(250),
  contentNameRule integer,
  nodePopedom character(1),
  nodeDir varchar(250),
  parentDir varchar(250),
  nodeUrl varchar(250),
  indexTemplate varchar(250),
  listTemplate varchar(250),
  contentTemplate varchar(250),
  nodeLevel integer,
  staticCount integer,
  fileCount integer,
  PRIMARY KEY (nodeId)
);
CREATE TABLE vj_online_admin (
  id character(32) not null,
  userName varchar(50),
  address varchar(40),
  roleName varchar(50),
  loginTime integer,
  sessionId character(32),
  PRIMARY KEY (id)
);
CREATE TABLE vj_password_recovery (
  id character(32) not null,
  userId character(32),
  recordTime integer,
  keyValue character(32),
  hit integer,
  inTime integer,
  PRIMARY KEY (id)
);
CREATE TABLE vj_password_recovery_history (
  id character(32) not null,
  userId character(32),
  hit integer,
  recordTime integer,
  PRIMARY KEY (id)
);
CREATE TABLE vj_resources (
  resourceId integer not null,
  description varchar(250),
  expressionDesc varchar(150),
  resourceName varchar(50),
  resourceType character(1),
  nodeSort integer,
  parentId integer,
  language integer,
  PRIMARY KEY (resourceId)
);
CREATE TABLE vj_role_navigate (
  roleId integer not null,
  navigateId integer not null,
  PRIMARY KEY (roleId,navigateId)
);
CREATE TABLE vj_role_resource (
  roleId integer not null,
  resourceId integer not null,
  PRIMARY KEY (roleId,resourceId)
);
CREATE TABLE vj_roles (
  roleId integer not null,
  description varchar(250),
  roleName varchar(50),
  language integer,
  PRIMARY KEY (roleId)
);
CREATE TABLE vj_safe_config (
  configId character(1) not null,
  isAccountExpire character(1),
  isVerCode character(1),
  isLockAccount character(1),
  isPassExpire character(1),
  isEnable character(1),
  isAutoRelieve character(1),
  accountLockTime integer,
  accountExpireTime integer,
  disableCount integer,
  passwordExpireTime integer,
  passwordErrorCount integer,
  PRIMARY KEY (configId)
);
CREATE TABLE vj_softs (
  id character(32) not null,
  fileType integer,
  fileSize varchar(50),
  star character(1),
  runSystem integer,
  website varchar(250),
  language integer,
  authorize varchar(50),
  email varchar(250),
  downloadUrl clob,
  PRIMARY KEY (id)
);
CREATE TABLE vj_system_config (
  id integer not null,
  varName varchar(150),
  description varchar(250),
  type integer,
  value varchar(250),
  modelId integer,
  status character(1),
  PRIMARY KEY (id) 
);
CREATE UNIQUE INDEX "IX_vj_system_config_varName" ON vj_system_config(varName);
CREATE TABLE vj_tag_list (
  tagId character(32) not null,
  contentId character(32),
  nodeId integer,
  tagName varchar(20),
  tagTime integer,
  PRIMARY KEY (tagId)
);
CREATE INDEX "IX_vj_tag_list_tagName" ON vj_tag_list(tagName);
CREATE INDEX "IX_vj_tag_list_contentId" ON vj_tag_list(contentId);
CREATE INDEX "IX_vj_tag_list_tagTime" ON vj_tag_list(tagTime);
CREATE TABLE vj_template_config (
  id integer not null,
  templateLocale integer,
  dateTimeFormat varchar(50),
  dateFormat varchar(50),
  timeFormat varchar(50),
  numberFormat varchar(50),
  tagSyntax integer,
  PRIMARY KEY (id)
);
CREATE TABLE vj_template_tag (
  tagId integer not null,
  tagName varchar(50),
  tagClass varchar(250),
  description varchar(250),
  status character(1),
  PRIMARY KEY (tagId)
);
CREATE TABLE vj_video (
  id character(32) not null,
  title varchar(255),
  playerUrl varchar(255),
  videoTime varchar(50),
  language varchar(50),
  PRIMARY KEY (id)
);

CREATE TABLE vj_vote (
  id integer not null,
  subject varchar(250),
  startTime integer,
  endTime integer,
  hit integer,
  status character(1),
  PRIMARY KEY (id)
);
CREATE TABLE vj_vote_topic (
  id character(32) not null,
  title varchar(250),
  voteCount integer,
  voteId integer,
  PRIMARY KEY (id)
);
CREATE INDEX "IX_vj_vote_topic_voteId" ON vj_vote_topic(voteId);
CREATE TABLE vj_watermark (
  watermarkId character(1) not null,
  watermarkPath varchar(250),
  alpha character(3),
  watermarkPosition integer,
  spacingX integer,
  spacingY integer,
  watermarkText varchar(250),
  fontPath varchar(250),
  fontColor character(6),
  fontSize integer,
  watermarkType character(1),
  width integer,
  height integer,
  PRIMARY KEY (watermarkId)
);
CREATE TABLE vj_web_config (
  configId character(1) not null,
  websiteName varchar(250),
  publicityTitle varchar(250),
  url varchar(250),
  templateDir varchar(250),
  keyword varchar(250),
  description varchar(250),
  recordNumber varchar(50),
  powerby varchar(2000),
  systemVersion varchar(50),
  PRIMARY KEY (configId) 
);
INSERT INTO vj_admin_role (adminId,roleId) VALUES ( '402881e52bc4aa42012bc4b22fdd0004',0);

INSERT INTO vj_admins (adminId,username,password,accountExpired,accountLocked,credentialsExpired,enable,lastLoginIp,lastLoginTime,lastUpdatePassWordTime,loginCount,loginErrorCount,registerTime,myTimeZone,myLanguage,isPassExpire,accountLockCount,isAccountExpire,superPassword,email,question,answer,isAnswerLogin) VALUES ( '402881e52bc4aa42012bc4b22fdd0004','admin','4ABE1307ADEEF96E9FA296BA39250C6FF6D764462B83DE8475BA94D2','F','F','F','F','192.168.244.1',1315092024,1299882271,815,0,1296952652,'+08:00',0,'F',0,'F','5EF458ADD47610C4A4D0B0DEC1C608709AD303E771C45A594ABFDF14','458479@qq.com','0','d','F');

INSERT INTO vj_channel_model (modelId,modelName,type,description,enable,language) VALUES ( 1,'文章模型','0','文章模型','T',0);
INSERT INTO vj_channel_model (modelId,modelName,type,description,enable,language) VALUES ( 2,'软件模型','0','软件模型','T',0);
INSERT INTO vj_channel_model (modelId,modelName,type,description,enable,language) VALUES ( 3,'图片模型','0','图片模型','T',0);
INSERT INTO vj_channel_model (modelId,modelName,type,description,enable,language) VALUES ( 4,'视频模型','0','视频模型','T',0);

INSERT INTO vj_cms_type (id,name,typeId,modelId,keyId) VALUES ( 1,'简体中文',1,2,1);
INSERT INTO vj_cms_type (id,name,typeId,modelId,keyId) VALUES ( 2,'繁体中文',1,2,2);
INSERT INTO vj_cms_type (id,name,typeId,modelId,keyId) VALUES ( 3,'英语',1,2,3);
INSERT INTO vj_cms_type (id,name,typeId,modelId,keyId) VALUES ( 4,'多国语言',1,2,4);
INSERT INTO vj_cms_type (id,name,typeId,modelId,keyId) VALUES ( 5,'exe',2,2,1);
INSERT INTO vj_cms_type (id,name,typeId,modelId,keyId) VALUES ( 6,'rar',2,2,2);
INSERT INTO vj_cms_type (id,name,typeId,modelId,keyId) VALUES ( 7,'zip',2,2,3);
INSERT INTO vj_cms_type (id,name,typeId,modelId,keyId) VALUES ( 8,'7z',2,2,4);
INSERT INTO vj_cms_type (id,name,typeId,modelId,keyId) VALUES ( 9,'iso',2,2,5);
INSERT INTO vj_cms_type (id,name,typeId,modelId,keyId) VALUES ( 10,'win xp/7/2008/2003/2000',3,2,1);

INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 35,'下载网址过滤','下载网址过滤',0,0,35);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 34,'友情链接','友情链接',0,0,34);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 33,'模板标签设置','模板标签设置',0,0,33);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 32,'模板设置','模板设置',0,0,32);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 31,'发送邮件','发送邮件',0,0,31);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 30,'文件管理','文件管理',0,0,30);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 29,'国际化管理','国际化管理',0,0,29);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 28,'备份数据','备份数据',0,0,28);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 27,'系统功能','系统功能',0,0,27);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 26,'邮件设置','邮件设置',0,0,26);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 25,'水印设置','水印设置',0,0,25);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 24,'导航设置','导航设置',0,0,24);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 23,'安全设置','安全设置',0,0,23);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 22,'站点设置','站点设置',0,0,22);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 21,'系统设置','系统设置',0,0,21);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 20,'系统模型','系统模型',0,0,20);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 19,'在线管理员','在线管理员',0,0,19);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 18,'登陆日志','登陆日志',0,0,18);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 17,'权限管理','权限管理',0,0,17);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 16,'角色列表','角色列表',0,0,16);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 15,'管理员列表','管理员列表',0,0,15);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 14,'后台用户','后台用户',0,0,14);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 13,'会员组','会员组',0,0,13);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 12,'会员列表','会员列表',0,0,12);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 11,'前台用户','前台用户',0,0,11);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 10,'用户模型','用户模型',0,0,10);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 9,'索引管理','索引管理',0,0,9);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 8,'生成静态文件','生成静态文件',0,0,8);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 7,'评论管理','评论管理',0,0,7);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 6,'标签管理','标签管理',0,0,6);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 5,'内容功能','内容功能',0,0,5);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 4,'软件列表','软件列表',0,0,4);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 3,'文章列表','文章列表',0,0,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 2,'内容管理','内容管理',0,0,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1,'内容模型','内容模型',0,0,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 36,'系统变量设置','系统变量设置',0,0,36);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 37,'栏目管理','栏目管理',0,0,37);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 38,'频道模型管理','频道模型管理',0,0,38);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 39,'Content Model','Content Model',1,0,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 40,'Content Management','Content Management',1,0,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 41,'Article List','Article List',1,0,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 42,'Software List','Software List',1,0,4);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 43,'Content Function','Content Function',1,0,5);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 44,'Tag Management','Tag Management',1,0,6);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 45,'Comment Management','Comment Management',1,0,7);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 46,'Generate Static File','Generate Static File',1,0,8);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 47,'Index Management','Index Management',1,0,9);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 48,'User Model','User Model',1,0,10);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 49,'Front User','Front User',1,0,11);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 50,'Member List','Member List',1,0,12);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 51,'Member Group','Member Group',1,0,13);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 52,'Background User','Background User',1,0,14);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 53,'Manager List','Manager List',1,0,15);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 54,'Roles List','Roles List',1,0,16);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 55,'Permission Management','Permission Management',1,0,17);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 56,'Login Log','Login Log',1,0,18);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 57,'Online Manager','Online Manager',1,0,19);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 58,'System Model','System Model',1,0,20);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 59,'System Setting','System Setting',1,0,21);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 60,'Site Setting','Site Setting',1,0,22);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 61,'Security Setting','Security Setting',1,0,23);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 62,'Navigation Setting','Navigation Setting',1,0,24);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 63,'Watermark Setting','Watermark Setting',1,0,25);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 64,'Mail Setting','Mail Setting',1,0,26);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 65,'System Function','System Function',1,0,27);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 66,'Backup Data','Backup Data',1,0,28);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 67,'I18n management','International management',1,0,29);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 68,'File Management','File Management',1,0,30);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 69,'Send Email','Send Email',1,0,31);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 70,'Template Setting','Template Setting',1,0,32);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 71,'Template Tag Setting','Template Tag Setting',1,0,33);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 72,'Link','Link',1,0,34);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 73,'Download URL Filter','Download URL Filter',1,0,35);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 74,'System Variable Setting','System Variable Setting',1,0,36);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 75,'Node Management','Node Management',1,0,37);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 76,'Channel Model Management','Channel Model Management',1,0,38);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 77,'Vote Management','Vote Management',1,0,39);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 78,'内容模型','内容模型',2,0,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 79,'内容管理','内容管理',2,0,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 80,'文章列表','文章列表',2,0,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 81,'軟件列表','軟件列表',2,0,4);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 82,'内容功能','内容功能',2,0,5);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 83,'標籤管理','標籤管理',2,0,6);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 84,'評論管理','評論管理',2,0,7);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 85,'生成靜態文件','生成靜態文件',2,0,8);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 86,'索引管理','索引管理',2,0,9);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 87,'用户模型','用户模型',2,0,10);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 88,'前台用户','前台用户',2,0,11);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 89,'會員列表','會員列表',2,0,12);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 90,'會員組','會員組',2,0,13);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 91,'後台用戶','後台用戶',2,0,14);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 92,'管理員列表','管理員列表',2,0,15);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 93,'角色列表','角色列表',2,0,16);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 94,'權限管理','權限管理',2,0,17);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 95,'登錄日誌','登錄日誌',2,0,18);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 96,'在線管理員','在線管理員',2,0,19);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 97,'系統模型','系統模型',2,0,20);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 98,'系統設置','系統設置',2,0,21);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 99,'站點設置','站點設置',2,0,22);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 100,'安全設置','安全設置',2,0,23);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 101,'導航設置','導航設置',2,0,24);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 102,'水印設置','水印設置',2,0,25);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 103,'郵件設置','郵件設置',2,0,26);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 104,'系統功能','系統功能',2,0,27);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 105,'備份數據','備份數據',2,0,28);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 106,'國際化管理','國際化管理',2,0,29);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 107,'文件管理','文件管理',2,0,30);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 108,'發送郵件','發送郵件',2,0,31);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 109,'模板設置','模板設置',2,0,32);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 110,'模板標籤設置','模板標籤設置',2,0,33);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 111,'友情鏈接','友情鏈接',2,0,34);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 112,'下載網址過濾','下載網址過濾',2,0,35);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 113,'系統變量設置','系統變量設置',2,0,36);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 114,'欄目管理','欄目管理',2,0,37);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 115,'頻道模型管理','頻道模型管理',2,0,38);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 116,'投票管理','投票管理',2,0,39);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 117,'コンテンツモデル','コンテンツモデル',3,0,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 118,'コンテンツ管理','コンテンツ管理',3,0,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 119,'記事一覧','記事一覧',3,0,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 120,'ソフトウェア一覧','ソフトウェア一覧',3,0,4);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 121,'コンテンツ関数','コンテンツ関数',3,0,5);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 122,'タグ管','タグ管',3,0,6);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 123,'コメント管理','コメント管理',3,0,7);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 124,'を生成する静的ファイル','を生成する静的ファイル',3,0,8);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 125,'インデックス管理','インデックス管理',3,0,9);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 126,'ユーザーモデル','ユーザーモデル',3,0,10);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 127,'フロントユーザー','フロントユーザー',3,0,11);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 128,'メンバーリスト','メンバーリスト',3,0,12);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 129,'会員グループ','会員グループ',3,0,13);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 130,'背景ユーザー','背景ユーザー',3,0,14);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 131,'マネージャのリスト','マネージャのリスト',3,0,15);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 132,'ロールのリスト','ロールのリスト',3,0,16);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 133,'パーミッション管理','パーミッション管理',3,0,17);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 134,'ログレコード','ログレコード',3,0,18);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 135,'オンラインマネージャ','オンラインマネージャ',3,0,19);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 136,'システムモデル','システムモデル',3,0,20);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 137,'システム設定','システム設定',3,0,21);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 138,'サイトの設定','サイトの設定',3,0,22);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 139,'セキュリティの設定','セキュリティの設定',3,0,23);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 140,'ナビゲーション設定','ナビゲーション設定',3,0,24);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 141,'透かし設定','透かし設定',3,0,25);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 142,'メール設定','メール設定',3,0,26);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 143,'システム関数','システム関数',3,0,27);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 144,'バックアップデータ','バックアップデータ',3,0,28);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 145,'国際管理','国際管理',3,0,29);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 146,'ファイル管理','ファイル管理',3,0,30);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 147,'電子メールを送信する','電子メールを送信する',3,0,31);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 148,'テンプレートの設定','テンプレートの設定',3,0,32);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 149,'テンプレートタグ設定','テンプレートタグ設定',3,0,33);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 150,'リンク','リンク',3,0,34);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 151,'ダウンロードURLフィルタリング','ダウンロードURLフィルタリング',3,0,35);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 152,'システム設定変数','システム設定変数',3,0,36);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 153,'ノード管理','ノード管理',3,0,37);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 154,'チャネルモデルの管理','チャネルモデルの管理',3,0,38);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 155,'投票管理','投票管理',3,0,39);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 156,'Модель содержимого','Модель содержимого',4,0,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 157,'Управление контентом','Управление контентом',4,0,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 158,'Список статей','Список статей',4,0,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 159,'Список программного обеспечения','Список программного обеспечения',4,0,4);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 160,'Содержание функции','Содержание функции',4,0,5);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 161,'Управление метками','Управление метками',4,0,6);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 162,'Комментарий управления','Комментарий управления',4,0,7);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 163,'Создание статических файлов','Создание статических файлов',4,0,8);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 164,'Индекс управления','Индекс управления',4,0,9);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 165,'Пользователь модели','Пользователь модели',4,0,10);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 166,'Отдел пользователя','Отдел пользователя',4,0,11);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 167,'Пользователи','Пользователи',4,0,12);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 168,'Группа','Группа',4,0,13);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 169,'Справочная пользователя','Справочная пользователя',4,0,14);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 170,'Менеджер Список','Менеджер Список',4,0,15);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 171,'Роль Список','Роль Список',4,0,16);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 172,'Разрешение управления','Разрешение управления',4,0,17);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 173,'Войти Вход','Войти Вход',4,0,18);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 174,'Интернет Manager','Интернет Manager',4,0,19);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 175,'Модель системы','Модель системы',4,0,20);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 176,'Настройки системы','Настройки системы',4,0,21);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 177,'Параметры сайта','Параметры сайта',4,0,22);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 178,'Настройки безопасности','Настройки безопасности',4,0,23);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 179,'Навигация настройки','Навигация настройки',4,0,24);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 180,'Водяной знак Настройка','Водяной знак Настройка',4,0,25);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 181,'Настройки почты','Настройки почты',4,0,26);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 182,'Система функции','Система функции',4,0,27);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 183,'Резервное копирование данных','Резервное копирование данных',4,0,28);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 184,'Международный менеджмент','Международный менеджмент',4,0,29);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 185,'Управление файлами','Управление файлами',4,0,30);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 186,'Отправить по электронной почте','Отправить по электронной почте',4,0,31);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 187,'Параметры шаблона','Параметры шаблона',4,0,32);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 188,'Теги набор шаблонов','Теги набор шаблонов',4,0,33);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 189,'Ссылки','Ссылки',4,0,34);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 190,'Скачать URL фильтра','Скачать URL фильтра',4,0,35);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 191,'Системная переменная Настройка','Системная переменная Настройка',4,0,36);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 192,'Узел управления','Узел управления',4,0,37);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 193,'Источник Model Management','Источник Model Management',4,0,38);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 194,'Проголосовать управления','Проголосовать управления',4,0,39);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 195,'Contenido del modelo de','Contenido del modelo de',5,0,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 196,'Gestión de Contenidos','Gestión de Contenidos',5,0,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 197,'Lista de artículos','Lista de artículos',5,0,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 198,'Lista de software','Lista de software',5,0,4);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 199,'Contenido de la función','Contenido de la función',5,0,5);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 200,'Tag Management','Tag Management',5,0,6);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 201,'Comentario de gestión','Comentario de gestión',5,0,7);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 202,'Generar archivos estáticos','Generar archivos estáticos',5,0,8);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 203,'índice de gestión','índice de gestión',5,0,9);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 204,'Usuario modelo','Usuario modelo',5,0,10);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 205,'Frente usuario','Frente usuario',5,0,11);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 206,'Miembros de la lista','Miembros de la lista',5,0,12);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 207,'Miembro del Grupo','Miembro del Grupo',5,0,13);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 208,'Antecedentes usuario','Antecedentes usuario',5,0,14);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 209,'Administrador de listas','Administrador de listas',5,0,15);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 210,'Lista de papel','Lista de papel',5,0,16);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 211,'Permiso de gestión','Permiso de gestión',5,0,17);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 212,'Ingresar Registrarse','Ingresar Registrarse',5,0,18);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 213,'Online Manager','Online Manager',5,0,19);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 214,'Modelo del sistema','Modelo del sistema',5,0,20);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 215,'Configuración del sistema','Configuración del sistema',5,0,21);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 216,'Configuración del sitio','Configuración del sitio',5,0,22);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 217,'Configuración de seguridad','Configuración de seguridad',5,0,23);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 218,'Ajustes de navegación','Ajustes de navegación',5,0,24);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 219,'Marca de agua Marco','Marca de agua Marco',5,0,25);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 220,'Configuración del correo','Configuración del correo',5,0,26);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 221,'La función del sistema','La función del sistema',5,0,27);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 222,'Copia de seguridad de datos','Copia de seguridad de datos',5,0,28);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 223,'Gestión internacional','Gestión internacional',5,0,29);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 224,'Administración de Archivo','Administración de Archivo',5,0,30);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 225,'Enviar por e-mail','Enviar por e-mail',5,0,31);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 226,'Configuración de plantilla','Configuración de plantilla',5,0,32);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 227,'Juego Etiquetas de Plantilla','Juego Etiquetas de Plantilla',5,0,33);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 228,'Enlaces','Enlaces',5,0,34);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 229,'Descargar Filtro de URL','Descargar Filtro de URL',5,0,35);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 230,'Variable del Sistema Marco','Variable del Sistema Marco',5,0,36);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 231,'El nodo de administración','El nodo de administración',5,0,37);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 232,'Canal Modelo de Gestión','Canal Modelo de Gestión',5,0,38);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 233,'Votación de Gestión','Votación de Gestión',5,0,39);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 234,'内容模型','内容模型',0,1,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 235,'内容管理','内容管理',0,1,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 236,'文章列表','文章列表',0,1,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 237,'添加表单','添加表单',0,1,4);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 238,'添加','添加',0,1,5);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 239,'删除','删除',0,1,6);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 240,'修改表单','修改表单',0,1,7);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 241,'修改','修改',0,1,8);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 242,'软件列表','软件列表',0,1,9);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 243,'添加表单','添加表单',0,1,10);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 244,'添加','添加',0,1,11);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 245,'删除','删除',0,1,12);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 246,'修改表单','修改表单',0,1,13);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 247,'修改','修改',0,1,14);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 248,'内容功能','内容功能',0,1,15);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 249,'删除静态文件','删除静态文件',0,1,16);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 250,'生成静态文件','生成静态文件',0,1,17);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 251,'生成索引文件','生成索引文件',0,1,18);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 252,'标签管理','标签管理',0,1,19);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 253,'删除','删除',0,1,20);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 254,'评论管理','评论管理',0,1,21);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 255,'删除','删除',0,1,22);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 256,'修改表单','修改表单',0,1,23);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 257,'修改','修改',0,1,24);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 258,'管理静态文件','管理静态文件',0,1,25);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 259,'添加','添加',0,1,26);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 260,'索引管理','索引管理',0,1,27);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 261,'添加','添加',0,1,28);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 262,'删除表单','删除表单',0,1,29);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 263,'删除','删除',0,1,30);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 264,'更新表单','更新表单',0,1,31);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 265,'更新','更新',0,1,32);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 266,'栏目管理','栏目管理',0,1,33);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 267,'添加表单','添加表单',0,1,34);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 268,'添加','添加',0,1,35);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 269,'删除','删除',0,1,36);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 270,'修改表单','修改表单',0,1,37);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 271,'修改','修改',0,1,38);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 272,'用户模型','用户模型',0,1,39);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 273,'前台用户','前台用户',0,1,40);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 274,'会员列表','会员列表',0,1,41);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 275,'添加表单','添加表单',0,1,42);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 276,'添加','添加',0,1,43);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 277,'删除','删除',0,1,44);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 278,'修改表单','修改表单',0,1,45);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 279,'修改','修改',0,1,46);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 280,'查看','查看',0,1,47);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 281,'会员组','会员组',0,1,48);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 282,'添加表单','添加表单',0,1,49);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 283,'添加','添加',0,1,50);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 284,'删除','删除',0,1,51);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 285,'修改表单','修改表单',0,1,52);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 286,'修改','修改',0,1,53);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 287,'后台用户','后台用户',0,1,54);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 288,'管理员列表','管理员列表',0,1,55);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 289,'添加管理员表单','添加管理员表单',0,1,56);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 290,'添加管理员','添加管理员',0,1,57);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 291,'删除管理员','删除管理员',0,1,58);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 292,'修改管理员表单','修改管理员表单',0,1,59);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 293,'修改管理员','修改管理员',0,1,60);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 294,'修改角色表单','修改角色表单',0,1,61);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 295,'修改角色','修改角色',0,1,62);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 296,'查看管理员','查看管理员',0,1,63);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 297,'角色列表','角色列表',0,1,64);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 298,'添加角色表单','添加角色表单',0,1,65);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 299,'添加角色','添加角色',0,1,66);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 300,'删除角色','删除角色',0,1,67);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 301,'修改表单','修改表单',0,1,68);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 302,'修改角色','修改角色',0,1,69);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 303,'修改角色权限表单','修改角色权限表单',0,1,70);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 304,'修改角色权限','修改角色权限',0,1,71);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 305,'修改角色导航表单','修改角色导航表单',0,1,72);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 306,'修改角色导航','修改角色导航',0,1,73);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 307,'权限管理','权限管理',0,1,74);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 308,'添加表单','添加表单',0,1,75);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 309,'添加','添加',0,1,76);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 310,'删除','删除',0,1,77);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 311,'修改表单','修改表单',0,1,78);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 312,'修改','修改',0,1,79);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 313,'刷新','刷新',0,1,80);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 314,'登陆日志','登陆日志',0,1,81);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 315,'删除','删除',0,1,82);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 316,'在线管理员','在线管理员',0,1,83);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 317,'删除','删除',0,1,84);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 318,'系统模型','系统模型',0,1,85);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 319,'系统设置','系统设置',0,1,86);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 320,'站点设置','站点设置',0,1,87);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 321,'修改站点','修改站点',0,1,88);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 322,'安全设置','安全设置',0,1,89);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 323,'修改','修改',0,1,90);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 324,'导航设置','导航设置',0,1,91);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 325,'添加表单','添加表单',0,1,92);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 326,'添加','添加',0,1,93);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 327,'删除','删除',0,1,94);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 328,'修改表单','修改表单',0,1,95);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 329,'修改','修改',0,1,96);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 330,'水印设置','水印设置',0,1,97);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 331,'修改','修改',0,1,98);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 332,'邮件设置','邮件设置',0,1,99);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 333,'修改','修改',0,1,100);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 334,'模板设置','模板设置',0,1,101);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 335,'修改','修改',0,1,102);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 336,'模板标签设置','模板标签设置',0,1,103);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 337,'添加表单','添加表单',0,1,104);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 338,'添加','添加',0,1,105);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 339,'删除','删除',0,1,106);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 340,'修改表单','修改表单',0,1,107);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 341,'修改','修改',0,1,108);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 342,'系统变量设置','系统变量设置',0,1,109);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 343,'添加表单','添加表单',0,1,110);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 344,'添加','添加',0,1,111);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 345,'删除','删除',0,1,112);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 346,'修改表单','修改表单',0,1,113);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 347,'修改','修改',0,1,114);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 348,'系统功能','系统功能',0,1,115);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 349,'备份数据','备份数据',0,1,116);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 350,'备份和还原','备份和还原',0,1,117);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 351,'国际化管理','国际化管理',0,1,118);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 352,'添加表单','添加表单',0,1,119);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 353,'添加','添加',0,1,120);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 354,'删除','删除',0,1,121);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 355,'修改表单','修改表单',0,1,122);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 356,'修改','修改',0,1,123);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 357,'文件管理','文件管理',0,1,124);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 358,'上传文件表单','上传文件表单',0,1,125);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 359,'上传文件','上传文件',0,1,126);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 360,'修改文件名表单','修改文件名表单',0,1,127);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 361,'修改文件名','修改文件名',0,1,128);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 362,'修改文件数据表单','修改文件数据表单',0,1,129);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 363,'修改文件数据','修改文件数据',0,1,130);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 364,'删除文件','删除文件',0,1,131);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 365,'创建文件目录','创建文件目录',0,1,132);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 366,'发送邮件','发送邮件',0,1,133);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 367,'发送','发送',0,1,134);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 368,'友情链接','友情链接',0,1,135);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 369,'添加表单','添加表单',0,1,136);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 370,'添加','添加',0,1,137);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 371,'删除','删除',0,1,138);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 372,'修改表单','修改表单',0,1,139);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 373,'修改','修改',0,1,140);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 374,'下载网址过滤','下载网址过滤',0,1,141);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 375,'添加表单','添加表单',0,1,142);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 376,'添加','添加',0,1,143);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 377,'删除','删除',0,1,144);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 378,'修改表单','修改表单',0,1,145);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 379,'修改','修改',0,1,146);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 380,'频道模型管理','频道模型管理',0,1,147);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 381,'添加表单','添加表单',0,1,148);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 382,'添加','添加',0,1,149);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 383,'删除','删除',0,1,150);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 384,'修改表单','修改表单',0,1,151);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 385,'修改','修改',0,1,152);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 386,'投票管理','投票管理',0,1,153);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 387,'添加表单','添加表单',0,1,154);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 388,'添加','添加',0,1,155);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 389,'删除','删除',0,1,156);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 390,'修改表单','修改表单',0,1,157);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 391,'修改','修改',0,1,158);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 392,'后台首页','后台首页',0,1,159);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 393,'Content Model','Content Model',1,1,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 394,'Content Management','Content Management',1,1,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 395,'Article list','Article list',1,1,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 396,'Add Form','Add Form',1,1,4);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 397,'Add','Add',1,1,5);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 398,'Delete','Delete',1,1,6);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 399,'Modified Form','Modified Form',1,1,7);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 400,'Modify','Modify',1,1,8);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 401,'Software List','Software List',1,1,9);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 402,'Add Form','Add Form',1,1,10);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 403,'Add','Add',1,1,11);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 404,'Delete','Delete',1,1,12);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 405,'Modified Form','Modified Form',1,1,13);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 406,'Modify','Modify',1,1,14);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 407,'Content Function','Content Function',1,1,15);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 408,'Delete Static File','Delete Static File',1,1,16);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 409,'Generate Static File','Generate Static File',1,1,17);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 410,'Generate Index File','Generate Index File',1,1,18);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 411,'Tag Management','Tag Management',1,1,19);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 412,'Delete','Delete',1,1,20);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 413,'Comment Management','Comment Management',1,1,21);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 414,'Delete','Delete',1,1,22);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 415,'Modified Form','Modified Form',1,1,23);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 416,'Modify','Modify',1,1,24);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 417,'Management Static File','Management Static File',1,1,25);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 418,'Add','Add',1,1,26);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 419,'Index Management','Index Management',1,1,27);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 420,'Add','Add',1,1,28);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 421,'Delete Form','Delete Form',1,1,29);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 422,'Delete','Delete',1,1,30);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 423,'Update Form','Update Form',1,1,31);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 424,'Update','Update',1,1,32);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 425,'Node Management','Node Management',1,1,33);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 426,'Add Form','Add Form',1,1,34);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 427,'Add','Add',1,1,35);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 428,'Delete','Delete',1,1,36);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 429,'Modified Form','Modified Form',1,1,37);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 430,'Modify','Modify',1,1,38);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 431,'User Model','User Model',1,1,39);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 432,'Front Users','Front Users',1,1,40);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 433,'Members List','Members List',1,1,41);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 434,'Add Form','Add Form',1,1,42);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 435,'Add','Add',1,1,43);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 436,'Delete','Delete',1,1,44);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 437,'Modified Form','Modified Form',1,1,45);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 438,'Modify','Modify',1,1,46);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 439,'View','View',1,1,47);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 440,'Member Group','Member Group',1,1,48);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 441,'Add Form','Add Form',1,1,49);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 442,'Add','Add',1,1,50);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 443,'Delete','Delete',1,1,51);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 444,'Modified Form','Modified Form',1,1,52);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 445,'Modify','Modify',1,1,53);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 446,'Background User','Background User',1,1,54);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 447,'Manager List','Manager List',1,1,55);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 448,'Add Administrator Form','Add Administrator Form',1,1,56);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 449,'Add Administrator','Add Administrator',1,1,57);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 450,'Remove administrator','Remove administrator',1,1,58);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 451,'Change administrator Form','Change administrator Form',1,1,59);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 452,'Change administrator','Change administrator',1,1,60);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 453,'Modify Role Form','Modify Role Form',1,1,61);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 454,'Modify Role','Modify Role',1,1,62);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 455,'View Manager','View Manager',1,1,63);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 456,'Role List','Role List',1,1,64);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 457,'Add Role Form','Add Role Form',1,1,65);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 458,'Add Role','Add Role',1,1,66);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 459,'Delete Role','Delete Role',1,1,67);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 460,'Modified Form','Modified Form',1,1,68);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 461,'Modify the role','Modify the role',1,1,69);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 462,'Modify Role Permission Form','Modify Role Permission Form',1,1,70);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 463,'Modify Role Permission','Modify Role Permission',1,1,71);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 464,'Modify Role Navigation Form','Modify Role Navigation Form',1,1,72);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 465,'Modify Role Navigation','Modify Role Navigation',1,1,73);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 466,'Permission Management','Permission Management',1,1,74);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 467,'Add Form','Add Form',1,1,75);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 468,'Add','Add',1,1,76);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 469,'Delete','Delete',1,1,77);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 470,'Modified Form','Modified Form',1,1,78);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 471,'Modify','Modify',1,1,79);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 472,'Refresh','Refresh',1,1,80);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 473,'Login Log','Login Log',1,1,81);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 474,'Delete','Delete',1,1,82);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 475,'Online Manager','Online Manager',1,1,83);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 476,'Delete','Delete',1,1,84);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 477,'System Model','System Model',1,1,85);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 478,'System Setting','System Setting',1,1,86);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 479,'Site Setting','Site Setting',1,1,87);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 480,'Modify Site','Modify Site',1,1,88);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 481,'Security Setting','Security Setting',1,1,89);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 482,'Modify','Modify',1,1,90);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 483,'Navigation settings','Navigation settings',1,1,91);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 484,'Add Form','Add Form',1,1,92);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 485,'Add','Add',1,1,93);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 486,'Delete','Delete',1,1,94);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 487,'Modified Form','Modified Form',1,1,95);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 488,'Modify','Modify',1,1,96);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 489,'Watermark','Watermark',1,1,97);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 490,'Modify','Modify',1,1,98);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 491,'Mail Setting','Mail Setting',1,1,99);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 492,'Modify','Modify',1,1,100);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 493,'Template Setting','Template Setting',1,1,101);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 494,'Modify','Modify',1,1,102);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 495,'Template Tag Setting','Template Tag Setting',1,1,103);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 496,'Add Form','Add Form',1,1,104);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 497,'Add','Add',1,1,105);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 498,'Delete','Delete',1,1,106);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 499,'Modified Form','Modified Form',1,1,107);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 500,'Modify','Modify',1,1,108);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 501,'System Variable Setting','System Variable Setting',1,1,109);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 502,'Add Form','Add Form',1,1,110);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 503,'Add','Add',1,1,111);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 504,'Delete','Delete',1,1,112);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 505,'Modified Form','Modified Form',1,1,113);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 506,'Modify','Modify',1,1,114);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 507,'System function','System function',1,1,115);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 508,'Backup Data','Backup Data',1,1,116);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 509,'Backup And Restore','Backup And Restore',1,1,117);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 510,'International management','International management',1,1,118);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 511,'Add Form','Add Form',1,1,119);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 512,'Add','Add',1,1,120);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 513,'Delete','Delete',1,1,121);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 514,'Modified Form','Modified Form',1,1,122);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 515,'Modify','Modify',1,1,123);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 516,'Document Management','Document Management',1,1,124);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 517,'Upload Form','Upload Form',1,1,125);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 518,'Upload File','Upload File',1,1,126);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 519,'Modify File Name Form','Modify File Name Form',1,1,127);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 520,'Modify File Name','Modify File Name',1,1,128);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 521,'Modify File Data Form','Modify File Data Form',1,1,129);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 522,'Modify File Data','Modify File Data',1,1,130);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 523,'Delete File','Delete File',1,1,131);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 524,'Create File Directory','Create File Directory',1,1,132);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 525,'Send e-mail','Send e-mail',1,1,133);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 526,'Send','Send',1,1,134);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 527,'Link','Link',1,1,135);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 528,'Add Form','Add Form',1,1,136);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 529,'Add','Add',1,1,137);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 530,'Delete','Delete',1,1,138);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 531,'Modified Form','Modified Form',1,1,139);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 532,'Modify','Modify',1,1,140);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 533,'Download URL filter','Download URL filter',1,1,141);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 534,'Add Form','Add Form',1,1,142);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 535,'Add','Add',1,1,143);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 536,'Delete','Delete',1,1,144);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 537,'Modified Form','Modified Form',1,1,145);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 538,'Modify','Modify',1,1,146);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 539,'Channel Model Management','Channel Model Management',1,1,147);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 540,'Add Form','Add Form',1,1,148);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 541,'Add','Add',1,1,149);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 542,'Delete','Delete',1,1,150);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 543,'Modified Form','Modified Form',1,1,151);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 544,'Modify','Modify',1,1,152);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 545,'Vote Management','Vote Management',1,1,153);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 546,'Add Form','Add Form',1,1,154);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 547,'Add','Add',1,1,155);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 548,'Delete','Delete',1,1,156);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 549,'Modified Form','Modified Form',1,1,157);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 550,'Modify','Modify',1,1,158);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 551,'Background Home','Background Home',1,1,159);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 552,'內容模型','內容模型',2,1,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 553,'內容管理','內容管理',2,1,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 554,'文章列表','文章列表',2,1,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 555,'添加表單','添加表單',2,1,4);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 556,'添加','添加',2,1,5);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 557,'刪除','刪除',2,1,6);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 558,'修改表單','修改表單',2,1,7);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 559,'修改','修改',2,1,8);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 560,'軟件列表','軟件列表',2,1,9);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 561,'添加表單','添加表單',2,1,10);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 562,'添加','添加',2,1,11);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 563,'刪除','刪除',2,1,12);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 564,'修改表單','修改表單',2,1,13);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 565,'修改','修改',2,1,14);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 566,'內容功能','內容功能',2,1,15);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 567,'刪除靜態文件','刪除靜態文件',2,1,16);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 568,'生成靜態文件','生成靜態文件',2,1,17);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 569,'生成索引文件','生成索引文件',2,1,18);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 570,'標籤管理','標籤管理',2,1,19);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 571,'刪除','刪除',2,1,20);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 572,'評論管理','評論管理',2,1,21);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 573,'刪除','刪除',2,1,22);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 574,'修改表單','修改表單',2,1,23);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 575,'修改','修改',2,1,24);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 576,'管理靜態文件','管理靜態文件',2,1,25);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 577,'添加','添加',2,1,26);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 578,'索引管理','索引管理',2,1,27);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 579,'添加','添加',2,1,28);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 580,'刪除表單','刪除表單',2,1,29);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 581,'刪除','刪除',2,1,30);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 582,'更新表單','更新表單',2,1,31);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 583,'更新','更新',2,1,32);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 584,'欄目管理','欄目管理',2,1,33);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 585,'添加表單','添加表單',2,1,34);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 586,'添加','添加',2,1,35);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 587,'刪除','刪除',2,1,36);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 588,'修改表單','修改表單',2,1,37);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 589,'修改','修改',2,1,38);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 590,'用戶模型','用戶模型',2,1,39);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 591,'前台用戶','前台用戶',2,1,40);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 592,'會員列表','會員列表',2,1,41);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 593,'添加表單','添加表單',2,1,42);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 594,'添加','添加',2,1,43);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 595,'刪除','刪除',2,1,44);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 596,'修改表單','修改表單',2,1,45);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 597,'修改','修改',2,1,46);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 598,'查看','查看',2,1,47);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 599,'會員組','會員組',2,1,48);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 600,'添加表單','添加表單',2,1,49);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 601,'添加','添加',2,1,50);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 602,'刪除','刪除',2,1,51);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 603,'修改表單','修改表單',2,1,52);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 604,'修改','修改',2,1,53);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 605,'後台用戶','後台用戶',2,1,54);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 606,'管理員列表','管理員列表',2,1,55);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 607,'添加管理員表單','添加管理員表單',2,1,56);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 608,'添加管理員','添加管理員',2,1,57);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 609,'刪除管理員','刪除管理員',2,1,58);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 610,'修改管理員表單','修改管理員表單',2,1,59);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 611,'修改管理員','修改管理員',2,1,60);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 612,'修改角色表單','修改角色表單',2,1,61);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 613,'修改角色','修改角色',2,1,62);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 614,'查看管理員','查看管理員',2,1,63);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 615,'角色列表','角色列表',2,1,64);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 616,'添加角色表單','添加角色表單',2,1,65);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 617,'添加角色','添加角色',2,1,66);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 618,'刪除角色','刪除角色',2,1,67);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 619,'修改表單','修改表單',2,1,68);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 620,'修改角色','修改角色',2,1,69);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 621,'修改角色權限表單','修改角色權限表單',2,1,70);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 622,'修改角色權限','修改角色權限',2,1,71);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 623,'修改角色導航表單','修改角色導航表單',2,1,72);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 624,'修改角色導航','修改角色導航',2,1,73);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 625,'權限管理','權限管理',2,1,74);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 626,'添加表單','添加表單',2,1,75);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 627,'添加','添加',2,1,76);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 628,'刪除','刪除',2,1,77);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 629,'修改表單','修改表單',2,1,78);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 630,'修改','修改',2,1,79);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 631,'刷新','刷新',2,1,80);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 632,'登陸日誌','登陸日誌',2,1,81);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 633,'刪除','刪除',2,1,82);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 634,'在線管理員','在線管理員',2,1,83);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 635,'刪除','刪除',2,1,84);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 636,'系統模型','系統模型',2,1,85);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 637,'系統設置','系統設置',2,1,86);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 638,'站點設置','站點設置',2,1,87);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 639,'修改站點','修改站點',2,1,88);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 640,'安全設置','安全設置',2,1,89);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 641,'修改','修改',2,1,90);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 642,'導航設置','導航設置',2,1,91);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 643,'添加表單','添加表單',2,1,92);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 644,'添加','添加',2,1,93);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 645,'刪除','刪除',2,1,94);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 646,'修改表單','修改表單',2,1,95);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 647,'修改','修改',2,1,96);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 648,'水印設置','水印設置',2,1,97);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 649,'修改','修改',2,1,98);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 650,'郵件設置','郵件設置',2,1,99);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 651,'修改','修改',2,1,100);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 652,'模板設置','模板設置',2,1,101);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 653,'修改','修改',2,1,102);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 654,'模板標籤設置','模板標籤設置',2,1,103);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 655,'添加表單','添加表單',2,1,104);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 656,'添加','添加',2,1,105);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 657,'刪除','刪除',2,1,106);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 658,'修改表單','修改表單',2,1,107);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 659,'修改','修改',2,1,108);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 660,'系統變量設置','系統變量設置',2,1,109);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 661,'添加表單','添加表單',2,1,110);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 662,'添加','添加',2,1,111);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 663,'刪除','刪除',2,1,112);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 664,'修改表單','修改表單',2,1,113);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 665,'修改','修改',2,1,114);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 666,'系統功能','系統功能',2,1,115);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 667,'備份數據','備份數據',2,1,116);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 668,'備份和還原','備份和還原',2,1,117);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 669,'國際化管理','國際化管理',2,1,118);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 670,'添加表單','添加表單',2,1,119);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 671,'添加','添加',2,1,120);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 672,'刪除','刪除',2,1,121);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 673,'修改表單','修改表單',2,1,122);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 674,'修改','修改',2,1,123);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 675,'文件管理','文件管理',2,1,124);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 676,'上傳文件表單','上傳文件表單',2,1,125);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 677,'上傳文件','上傳文件',2,1,126);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 678,'修改文件名表單','修改文件名表單',2,1,127);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 679,'修改文件名','修改文件名',2,1,128);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 680,'修改文件數據表單','修改文件數據表單',2,1,129);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 681,'修改文件數據','修改文件數據',2,1,130);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 682,'刪除文件','刪除文件',2,1,131);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 683,'創建文件目錄','創建文件目錄',2,1,132);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 684,'發送郵件','發送郵件',2,1,133);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 685,'發送','發送',2,1,134);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 686,'友情鏈接','友情鏈接',2,1,135);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 687,'添加表單','添加表單',2,1,136);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 688,'添加','添加',2,1,137);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 689,'刪除','刪除',2,1,138);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 690,'修改表單','修改表單',2,1,139);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 691,'修改','修改',2,1,140);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 692,'下載網址過濾','下載網址過濾',2,1,141);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 693,'添加表單','添加表單',2,1,142);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 694,'添加','添加',2,1,143);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 695,'刪除','刪除',2,1,144);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 696,'修改表單','修改表單',2,1,145);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 697,'修改','修改',2,1,146);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 698,'頻道模型管理','頻道模型管理',2,1,147);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 699,'添加表單','添加表單',2,1,148);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 700,'添加','添加',2,1,149);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 701,'刪除','刪除',2,1,150);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 702,'修改表單','修改表單',2,1,151);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 703,'修改','修改',2,1,152);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 704,'投票管理','投票管理',2,1,153);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 705,'添加表單','添加表單',2,1,154);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 706,'添加','添加',2,1,155);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 707,'刪除','刪除',2,1,156);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 708,'修改表單','修改表單',2,1,157);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 709,'修改','修改',2,1,158);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 710,'後台首頁','後台首頁',2,1,159);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 711,'コンテンツモデル','コンテンツモデル',3,1,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 712,'コンテンツ管理','コンテンツ管理',3,1,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 713,'記事一覧','記事一覧',3,1,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 714,'形成するに追加','形成するに追加',3,1,4);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 715,'追加','追加',3,1,5);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 716,'削除','削除',3,1,6);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 717,'変更フォーム','変更フォーム',3,1,7);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 718,'変更','変更',3,1,8);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 719,'ソフトウェア一覧','ソフトウェア一覧',3,1,9);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 720,'形成するに追加','形成するに追加',3,1,10);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 721,'追加','追加',3,1,11);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 722,'削除','削除',3,1,12);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 723,'変更フォーム','変更フォーム',3,1,13);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 724,'変更','変更',3,1,14);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 725,'コンテンツ関数','コンテンツ関数',3,1,15);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 726,'削除する静的ファイル','削除する静的ファイル',3,1,16);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 727,'を生成する静的ファイル','を生成する静的ファイル',3,1,17);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 728,'を生成するインデックスファイル','を生成するインデックスファイル',3,1,18);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 729,'タグ管理','タグ管理',3,1,19);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 730,'削除','削除',3,1,20);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 731,'コメント管理','コメント管理',3,1,21);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 732,'削除','削除',3,1,22);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 733,'変更フォーム','変更フォーム',3,1,23);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 734,'変更','変更',3,1,24);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 735,'管理静的ファイル','管理静的ファイル',3,1,25);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 736,'追加','追加',3,1,26);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 737,'インデックス管理','インデックス管理',3,1,27);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 738,'追加','追加',3,1,28);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 739,'削除フォーム','削除フォーム',3,1,29);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 740,'削除','削除',3,1,30);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 741,'更新フォーム','更新フォーム',3,1,31);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 742,'更新','更新',3,1,32);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 743,'ローカル管理','ローカル管理',3,1,33);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 744,'形成するに追加','形成するに追加',3,1,34);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 745,'追加','追加',3,1,35);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 746,'削除','削除',3,1,36);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 747,'変更フォーム','変更フォーム',3,1,37);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 748,'変更','変更',3,1,38);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 749,'ユーザーモデル','ユーザーモデル',3,1,39);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 750,'フロントユーザー','フロントユーザー',3,1,40);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 751,'メンバーリスト','メンバーリスト',3,1,41);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 752,'形成するに追加','形成するに追加',3,1,42);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 753,'追加','追加',3,1,43);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 754,'削除','削除',3,1,44);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 755,'変更フォーム','変更フォーム',3,1,45);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 756,'変更','変更',3,1,46);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 757,'友達','友達',3,1,47);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 758,'会員グループ','会員グループ',3,1,48);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 759,'形成するに追加','形成するに追加',3,1,49);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 760,'追加','追加',3,1,50);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 761,'削除','削除',3,1,51);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 762,'変更フォーム','変更フォーム',3,1,52);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 763,'変更','変更',3,1,53);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 764,'背景ユーザー','背景ユーザー',3,1,54);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 765,'マネージャのリスト','マネージャのリスト',3,1,55);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 766,'管理者の追加フォーム','管理者の追加フォーム',3,1,56);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 767,'管理者の追加','管理者の追加',3,1,57);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 768,'管理者を削除する','管理者を削除する',3,1,58);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 769,'管理フォームを変更します。','管理フォームを変更します。',3,1,59);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 770,'管理者を変更する','管理者を変更する',3,1,60);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 771,'フォームの変更の役割','フォームの変更の役割',3,1,61);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 772,'変更の役割','変更の役割',3,1,62);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 773,'ビューマネージャ','ビューマネージャ',3,1,63);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 774,'ロールのリスト','ロールのリスト',3,1,64);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 775,'役割の追加フォーム','役割の追加フォーム',3,1,65);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 776,'役割の追加','役割の追加',3,1,66);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 777,'削除する役割','削除する役割',3,1,67);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 778,'変更フォーム','変更フォーム',3,1,68);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 779,'変更の役割','変更の役割',3,1,69);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 780,'変更ロール権限が形成さ','変更ロール権限が形成さ',3,1,70);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 781,'変更ロール権限','変更ロール権限',3,1,71);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 782,'ナビゲーションフォームの変更の役割','ナビゲーションフォームの変更の役割',3,1,72);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 783,'ナビゲーションの変更の役割','ナビゲーションの変更の役割',3,1,73);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 784,'パーミッション管理','パーミッション管理',3,1,74);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 785,'形成するに追加','形成するに追加',3,1,75);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 786,'追加','追加',3,1,76);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 787,'削除','削除',3,1,77);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 788,'変更フォーム','変更フォーム',3,1,78);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 789,'変更','変更',3,1,79);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 790,'リフレッシュ','リフレッシュ',3,1,80);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 791,'ログログ','ログログ',3,1,81);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 792,'削除','削除',3,1,82);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 793,'オンラインマネージャ','オンラインマネージャ',3,1,83);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 794,'削除','削除',3,1,84);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 795,'システムモデル','システムモデル',3,1,85);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 796,'システム設定','システム設定',3,1,86);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 797,'サイトの設定','サイトの設定',3,1,87);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 798,'変更サイト','変更サイト',3,1,88);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 799,'セキュリティの設定','セキュリティの設定',3,1,89);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 800,'変更','変更',3,1,90);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 801,'ナビゲーション設定','ナビゲーション設定',3,1,91);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 802,'形成するに追加','形成するに追加',3,1,92);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 803,'追加','追加',3,1,93);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 804,'削除','削除',3,1,94);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 805,'変更フォーム','変更フォーム',3,1,95);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 806,'変更','変更',3,1,96);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 807,'透かし','透かし',3,1,97);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 808,'変更','変更',3,1,98);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 809,'メール設定','メール設定',3,1,99);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 810,'変更','変更',3,1,100);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 811,'テンプレートの設定','テンプレートの設定',3,1,101);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 812,'変更','変更',3,1,102);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 813,'設定テンプレートタグ','設定テンプレートタグ',3,1,103);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 814,'形成するに追加','形成するに追加',3,1,104);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 815,'追加','追加',3,1,105);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 816,'削除','削除',3,1,106);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 817,'変更フォーム','変更フォーム',3,1,107);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 818,'変更','変更',3,1,108);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 819,'システム変数が設定されている','システム変数が設定されている',3,1,109);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 820,'形成するに追加','形成するに追加',3,1,110);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 821,'追加','追加',3,1,111);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 822,'削除','削除',3,1,112);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 823,'変更フォーム','変更フォーム',3,1,113);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 824,'変更','変更',3,1,114);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 825,'システム関数','システム関数',3,1,115);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 826,'バックアップデータ','バックアップデータ',3,1,116);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 827,'バックアップと復元','バックアップと復元',3,1,117);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 828,'国際管理','国際管理',3,1,118);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 829,'形成するに追加','形成するに追加',3,1,119);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 830,'追加','追加',3,1,120);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 831,'削除','削除',3,1,121);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 832,'変更フォーム','変更フォーム',3,1,122);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 833,'変更','変更',3,1,123);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 834,'ドキュメント管理','ドキュメント管理',3,1,124);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 835,'アップロードフォーム','アップロードフォーム',3,1,125);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 836,'ファイルをアップロード','ファイルをアップロード',3,1,126);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 837,'修正ファイル名の形式','修正ファイル名の形式',3,1,127);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 838,'修正ファイル名','修正ファイル名',3,1,128);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 839,'修正ファイルのデータが形成さ','修正ファイルのデータが形成さ',3,1,129);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 840,'ファイルを変更しデータ','ファイルを変更しデータ',3,1,130);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 841,'ファイルを削除する','ファイルを削除する',3,1,131);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 842,'ファイルのディレクトリを作成します。','ファイルのディレクトリを作成します。',3,1,132);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 843,'電子メールを送信する','電子メールを送信する',3,1,133);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 844,'送信','送信',3,1,134);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 845,'リンク','リンク',3,1,135);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 846,'形成するに追加','形成するに追加',3,1,136);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 847,'追加','追加',3,1,137);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 848,'削除','削除',3,1,138);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 849,'変更フォーム','変更フォーム',3,1,139);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 850,'変更','変更',3,1,140);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 851,'ダウンロードURLフィルタリング','ダウンロードURLフィルタリング',3,1,141);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 852,'形成するに追加','形成するに追加',3,1,142);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 853,'追加','追加',3,1,143);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 854,'削除','削除',3,1,144);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 855,'変更フォーム','変更フォーム',3,1,145);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 856,'変更','変更',3,1,146);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 857,'チャネルモデルの管理','チャネルモデルの管理',3,1,147);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 858,'形成するに追加','形成するに追加',3,1,148);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 859,'追加','追加',3,1,149);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 860,'削除','削除',3,1,150);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 861,'変更フォーム','変更フォーム',3,1,151);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 862,'変更','変更',3,1,152);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 863,'投票管理','投票管理',3,1,153);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 864,'形成するに追加','形成するに追加',3,1,154);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 865,'追加','追加',3,1,155);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 866,'削除','削除',3,1,156);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 867,'変更フォーム','変更フォーム',3,1,157);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 868,'変更','変更',3,1,158);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 869,'背景ホーム','背景ホーム',3,1,159);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 870,'Модель содержимого','Модель содержимого',4,1,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 871,'Управление контентом','Управление контентом',4,1,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 872,'Список статей','Список статей',4,1,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 873,'Добавить форме','Добавить форме',4,1,4);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 874,'Добавить','Добавить',4,1,5);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 875,'Удалить','Удалить',4,1,6);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 876,'Измененном виде','Измененном виде',4,1,7);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 877,'Изменить','Изменить',4,1,8);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 878,'Список программного обеспечения','Список программного обеспечения',4,1,9);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 879,'Добавить форме','Добавить форме',4,1,10);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 880,'Добавить','Добавить',4,1,11);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 881,'Удалить','Удалить',4,1,12);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 882,'Измененном виде','Измененном виде',4,1,13);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 883,'Изменить','Изменить',4,1,14);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 884,'Содержание особенности','Содержание особенности',4,1,15);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 885,'Удалить статических файлов','Удалить статических файлов',4,1,16);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 886,'Создание статических файлов','Создание статических файлов',4,1,17);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 887,'Создание индексных файлов','Создание индексных файлов',4,1,18);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 888,'Управление метками','Управление метками',4,1,19);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 889,'Удалить','Удалить',4,1,20);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 890,'Комментарий управления','Комментарий управления',4,1,21);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 891,'Удалить','Удалить',4,1,22);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 892,'Измененном виде','Измененном виде',4,1,23);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 893,'Изменить','Изменить',4,1,24);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 894,'Управление статического файла','Управление статического файла',4,1,25);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 895,'Добавить','Добавить',4,1,26);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 896,'Индекс управления','Индекс управления',4,1,27);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 897,'Добавить','Добавить',4,1,28);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 898,'Удалить вид','Удалить вид',4,1,29);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 899,'Удалить','Удалить',4,1,30);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 900,'Обновление формы','Обновление формы',4,1,31);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 901,'Обновление','Обновление',4,1,32);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 902,'Местное управление','Местное управление',4,1,33);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 903,'Добавить форме','Добавить форме',4,1,34);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 904,'Добавить','Добавить',4,1,35);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 905,'Удалить','Удалить',4,1,36);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 906,'Измененном виде','Измененном виде',4,1,37);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 907,'Изменить','Изменить',4,1,38);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 908,'Пользователь модели','Пользователь модели',4,1,39);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 909,'Отдел пользователя','Отдел пользователя',4,1,40);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 910,'Пользователи','Пользователи',4,1,41);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 911,'Добавить форме','Добавить форме',4,1,42);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 912,'Добавить','Добавить',4,1,43);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 913,'Удалить','Удалить',4,1,44);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 914,'Измененном виде','Измененном виде',4,1,45);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 915,'Изменить','Изменить',4,1,46);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 916,'Открыть','Открыть',4,1,47);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 917,'Группа','Группа',4,1,48);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 918,'Добавить форме','Добавить форме',4,1,49);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 919,'Добавить','Добавить',4,1,50);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 920,'Удалить','Удалить',4,1,51);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 921,'Измененном виде','Измененном виде',4,1,52);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 922,'Изменить','Изменить',4,1,53);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 923,'Справочная пользователя','Справочная пользователя',4,1,54);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 924,'Менеджер Список','Менеджер Список',4,1,55);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 925,'Добавить администратора форме','Добавить администратора форме',4,1,56);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 926,'Добавить администратора','Добавить администратора',4,1,57);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 927,'Удалить администратора','Удалить администратора',4,1,58);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 928,'Изменение формы администратора','Изменение формы администратора',4,1,59);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 929,'Изменение администратора','Изменение администратора',4,1,60);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 930,'Изменить роль формы','Изменить роль формы',4,1,61);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 931,'Изменить роль','Изменить роль',4,1,62);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 932,'View Manager','View Manager',4,1,63);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 933,'Список ролей','Список ролей',4,1,64);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 934,'Добавить Роль формы','Добавить Роль формы',4,1,65);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 935,'Добавить роль','Добавить роль',4,1,66);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 936,'Удалить роль','Удалить роль',4,1,67);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 937,'Измененном виде','Измененном виде',4,1,68);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 938,'Изменить роль','Изменить роль',4,1,69);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 939,'Изменить разрешения роль формы','Изменить разрешения роль формы',4,1,70);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 940,'разрешения Изменить роль','разрешения Изменить роль',4,1,71);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 941,'Изменить роль навигации форме','Изменить роль навигации форме',4,1,72);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 942,'Изменить роль навигации','Изменить роль навигации',4,1,73);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 943,'Управление правами','Управление правами',4,1,74);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 944,'Добавить форме','Добавить форме',4,1,75);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 945,'Добавить','Добавить',4,1,76);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 946,'Удалить','Удалить',4,1,77);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 947,'Измененном виде','Измененном виде',4,1,78);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 948,'Изменить','Изменить',4,1,79);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 949,'Обновить','Обновить',4,1,80);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 950,'Вход Вход','Вход Вход',4,1,81);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 951,'Удалить','Удалить',4,1,82);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 952,'Интернет Manager','Интернет Manager',4,1,83);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 953,'Удалить','Удалить',4,1,84);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 954,'Модель системы','Модель системы',4,1,85);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 955,'Настройки системы','Настройки системы',4,1,86);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 956,'Параметры сайта','Параметры сайта',4,1,87);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 957,'Изменить сайт','Изменить сайт',4,1,88);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 958,'Настройки безопасности','Настройки безопасности',4,1,89);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 959,'Изменить','Изменить',4,1,90);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 960,'Навигация настройки','Навигация настройки',4,1,91);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 961,'Добавить форме','Добавить форме',4,1,92);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 962,'Добавить','Добавить',4,1,93);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 963,'Удалить','Удалить',4,1,94);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 964,'Измененном виде','Измененном виде',4,1,95);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 965,'Изменить','Изменить',4,1,96);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 966,'Водяной знак','Водяной знак',4,1,97);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 967,'Изменить','Изменить',4,1,98);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 968,'Настройки почты','Настройки почты',4,1,99);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 969,'Изменить','Изменить',4,1,100);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 970,'Параметры шаблона','Параметры шаблона',4,1,101);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 971,'Изменить','Изменить',4,1,102);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 972,'Теги набор шаблонов','Теги набор шаблонов',4,1,103);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 973,'Добавить форме','Добавить форме',4,1,104);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 974,'Добавить','Добавить',4,1,105);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 975,'Удалить','Удалить',4,1,106);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 976,'Измененном виде','Измененном виде',4,1,107);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 977,'Изменить','Изменить',4,1,108);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 978,'Система переменная установлена','Система переменная установлена',4,1,109);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 979,'Добавить форме','Добавить форме',4,1,110);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 980,'Добавить','Добавить',4,1,111);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 981,'Удалить','Удалить',4,1,112);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 982,'Измененном виде','Измененном виде',4,1,113);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 983,'Изменить','Изменить',4,1,114);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 984,'Система функции','Система функции',4,1,115);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 985,'Резервное копирование данных','Резервное копирование данных',4,1,116);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 986,'Резервное копирование и восстановление','Резервное копирование и восстановление',4,1,117);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 987,'Международный менеджмент','Международный менеджмент',4,1,118);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 988,'Добавить форме','Добавить форме',4,1,119);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 989,'Добавить','Добавить',4,1,120);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 990,'Удалить','Удалить',4,1,121);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 991,'Измененном виде','Измененном виде',4,1,122);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 992,'Изменить','Изменить',4,1,123);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 993,'Управление документами','Управление документами',4,1,124);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 994,'Форма для закачки','Форма для закачки',4,1,125);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 995,'Загрузить файл','Загрузить файл',4,1,126);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 996,'Изменить форму названия файла','Изменить форму названия файла',4,1,127);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 997,'Изменить имя файла','Изменить имя файла',4,1,128);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 998,'Внесите изменения в файл данных формы','Внесите изменения в файл данных формы',4,1,129);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 999,'Изменить файл данных','Изменить файл данных',4,1,130);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1000,'Удаление файлов','Удаление файлов',4,1,131);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1001,'Создайте файл каталога','Создайте файл каталога',4,1,132);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1002,'Отправить по электронной почте','Отправить по электронной почте',4,1,133);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1003,'Отправить','Отправить',4,1,134);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1004,'Ссылки','Ссылки',4,1,135);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1005,'Добавить форме','Добавить форме',4,1,136);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1006,'Добавить','Добавить',4,1,137);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1007,'Удалить','Удалить',4,1,138);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1008,'Измененном виде','Измененном виде',4,1,139);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1009,'Изменить','Изменить',4,1,140);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1010,'Скачать URL фильтра','Скачать URL фильтра',4,1,141);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1011,'Добавить форме','Добавить форме',4,1,142);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1012,'Добавить','Добавить',4,1,143);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1013,'Удалить','Удалить',4,1,144);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1014,'Измененном виде','Измененном виде',4,1,145);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1015,'Изменить','Изменить',4,1,146);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1016,'Источник Model Management','Источник Model Management',4,1,147);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1017,'Добавить форме','Добавить форме',4,1,148);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1018,'Добавить','Добавить',4,1,149);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1019,'Удалить','Удалить',4,1,150);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1020,'Измененном виде','Измененном виде',4,1,151);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1021,'Изменить','Изменить',4,1,152);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1022,'Проголосовать управления','Проголосовать управления',4,1,153);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1023,'Добавить форме','Добавить форме',4,1,154);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1024,'Добавить','Добавить',4,1,155);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1025,'Удалить','Удалить',4,1,156);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1026,'Измененном виде','Измененном виде',4,1,157);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1027,'Изменить','Изменить',4,1,158);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1028,'Справочная Главная','Справочная Главная',4,1,159);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1029,'Contenido del modelo de','Contenido del modelo de',5,1,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1030,'Gestión de Contenidos','Gestión de Contenidos',5,1,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1031,'Lista de artículos','Lista de artículos',5,1,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1032,'Agregar formulario','Agregar formulario',5,1,4);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1033,'Agregar','Agregar',5,1,5);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1034,'Eliminar','Eliminar',5,1,6);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1035,'Formulario de actualización','Formulario de actualización',5,1,7);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1036,'Modificar','Modificar',5,1,8);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1037,'Lista de software','Lista de software',5,1,9);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1038,'Agregar formulario','Agregar formulario',5,1,10);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1039,'Agregar','Agregar',5,1,11);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1040,'Eliminar','Eliminar',5,1,12);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1041,'Formulario de actualización','Formulario de actualización',5,1,13);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1042,'Modificar','Modificar',5,1,14);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1043,'Contenido de la función','Contenido de la función',5,1,15);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1044,'Eliminar archivo estático','Eliminar archivo estático',5,1,16);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1045,'Generar archivo estático','Generar archivo estático',5,1,17);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1046,'Generar archivo de índice','Generar archivo de índice',5,1,18);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1047,'Tag Management','Tag Management',5,1,19);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1048,'Eliminar','Eliminar',5,1,20);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1049,'Comentario de gestión','Comentario de gestión',5,1,21);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1050,'Eliminar','Eliminar',5,1,22);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1051,'Formulario de actualización','Formulario de actualización',5,1,23);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1052,'Modificar','Modificar',5,1,24);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1053,'Gestión de archivos estáticos','Gestión de archivos estáticos',5,1,25);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1054,'Agregar','Agregar',5,1,26);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1055,'índice de gestión','índice de gestión',5,1,27);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1056,'Agregar','Agregar',5,1,28);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1057,'Forma Eliminar','Forma Eliminar',5,1,29);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1058,'Eliminar','Eliminar',5,1,30);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1059,'Formulario de actualización','Formulario de actualización',5,1,31);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1060,'Actualizar','Actualizar',5,1,32);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1061,'Gestión Local','Gestión Local',5,1,33);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1062,'Agregar formulario','Agregar formulario',5,1,34);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1063,'Agregar','Agregar',5,1,35);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1064,'Eliminar','Eliminar',5,1,36);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1065,'Formulario de actualización','Formulario de actualización',5,1,37);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1066,'Modificar','Modificar',5,1,38);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1067,'Modelo de Usuario','Modelo de Usuario',5,1,39);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1068,'Frente usuario','Frente usuario',5,1,40);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1069,'Miembros de la lista','Miembros de la lista',5,1,41);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1070,'Agregar formulario','Agregar formulario',5,1,42);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1071,'Agregar','Agregar',5,1,43);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1072,'Eliminar','Eliminar',5,1,44);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1073,'Formulario de actualización','Formulario de actualización',5,1,45);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1074,'Modificar','Modificar',5,1,46);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1075,'Ver','Ver',5,1,47);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1076,'Miembro del Grupo','Miembro del Grupo',5,1,48);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1077,'Agregar formulario','Agregar formulario',5,1,49);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1078,'Agregar','Agregar',5,1,50);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1079,'Eliminar','Eliminar',5,1,51);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1080,'Formulario de actualización','Formulario de actualización',5,1,52);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1081,'Modificar','Modificar',5,1,53);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1082,'Antecedentes del usuario','Antecedentes del usuario',5,1,54);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1083,'Administrador de listas','Administrador de listas',5,1,55);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1084,'Agregar formulario de administrador','Agregar formulario de administrador',5,1,56);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1085,'Agregar administrador','Agregar administrador',5,1,57);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1086,'Quitar administrador','Quitar administrador',5,1,58);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1087,'Formulario de cambio de administrador','Formulario de cambio de administrador',5,1,59);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1088,'Cambio de administrador','Cambio de administrador',5,1,60);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1089,'Modificar el formulario papel','Modificar el formulario papel',5,1,61);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1090,'Modificar papel','Modificar papel',5,1,62);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1091,'Administrador de vistas','Administrador de vistas',5,1,63);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1092,'Lista de papel','Lista de papel',5,1,64);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1093,'Agregar formulario papel','Agregar formulario papel',5,1,65);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1094,'A?adir Papel','A?adir Papel',5,1,66);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1095,'Eliminar papel','Eliminar papel',5,1,67);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1096,'Formulario de actualización','Formulario de actualización',5,1,68);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1097,'Modificar el papel','Modificar el papel',5,1,69);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1098,'Papel Modificar Formulario de Permiso','Papel Modificar Formulario de Permiso',5,1,70);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1099,'Modificar permisos papel','Modificar permisos papel',5,1,71);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1100,'Función de navegación Modificar Formulario','Función de navegación Modificar Formulario',5,1,72);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1101,'Modificar Navegación Papel','Modificar Navegación Papel',5,1,73);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1102,'Permiso de gestión','Permiso de gestión',5,1,74);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1103,'Agregar formulario','Agregar formulario',5,1,75);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1104,'Agregar','Agregar',5,1,76);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1105,'Eliminar','Eliminar',5,1,77);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1106,'Formulario de actualización','Formulario de actualización',5,1,78);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1107,'Modificar','Modificar',5,1,79);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1108,'Actualizar','Actualizar',5,1,80);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1109,'Ingresar Registrarse','Ingresar Registrarse',5,1,81);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1110,'Eliminar','Eliminar',5,1,82);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1111,'Online Manager','Online Manager',5,1,83);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1112,'Eliminar','Eliminar',5,1,84);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1113,'Modelo del sistema','Modelo del sistema',5,1,85);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1114,'Configuración del sistema','Configuración del sistema',5,1,86);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1115,'Sitio Marco','Sitio Marco',5,1,87);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1116,'Modificar sitio','Modificar sitio',5,1,88);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1117,'Configuración de seguridad','Configuración de seguridad',5,1,89);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1118,'Modificar','Modificar',5,1,90);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1119,'Ajustes de navegación','Ajustes de navegación',5,1,91);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1120,'Agregar formulario','Agregar formulario',5,1,92);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1121,'Agregar','Agregar',5,1,93);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1122,'Eliminar','Eliminar',5,1,94);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1123,'Formulario de actualización','Formulario de actualización',5,1,95);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1124,'Modificar','Modificar',5,1,96);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1125,'Filigrana','Filigrana',5,1,97);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1126,'Modificar','Modificar',5,1,98);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1127,'Correo Marco','Correo Marco',5,1,99);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1128,'Modificar','Modificar',5,1,100);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1129,'Plantilla Marco','Plantilla Marco',5,1,101);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1130,'Modificar','Modificar',5,1,102);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1131,'Marco de código de plantilla','Marco de código de plantilla',5,1,103);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1132,'Agregar formulario','Agregar formulario',5,1,104);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1133,'Agregar','Agregar',5,1,105);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1134,'Eliminar','Eliminar',5,1,106);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1135,'Formulario de actualización','Formulario de actualización',5,1,107);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1136,'Modificar','Modificar',5,1,108);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1137,'Variable del Sistema Marco','Variable del Sistema Marco',5,1,109);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1138,'Agregar formulario','Agregar formulario',5,1,110);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1139,'Agregar','Agregar',5,1,111);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1140,'Eliminar','Eliminar',5,1,112);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1141,'Formulario de actualización','Formulario de actualización',5,1,113);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1142,'Modificar','Modificar',5,1,114);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1143,'La función del sistema','La función del sistema',5,1,115);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1144,'Copia de seguridad de datos','Copia de seguridad de datos',5,1,116);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1145,'Copia de seguridad y restauración','Copia de seguridad y restauración',5,1,117);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1146,'Gestión internacional','Gestión internacional',5,1,118);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1147,'Agregar formulario','Agregar formulario',5,1,119);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1148,'Agregar','Agregar',5,1,120);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1149,'Eliminar','Eliminar',5,1,121);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1150,'Formulario de actualización','Formulario de actualización',5,1,122);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1151,'Modificar','Modificar',5,1,123);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1152,'Gestión Documental','Gestión Documental',5,1,124);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1153,'Cargar el formulario','Cargar el formulario',5,1,125);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1154,'Subir Archivo','Subir Archivo',5,1,126);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1155,'Modificar archivo Nombre del formulario','Modificar archivo Nombre del formulario',5,1,127);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1156,'Modificar nombre de archivo','Modificar nombre de archivo',5,1,128);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1157,'Modificar datos Presente el Formulario','Modificar datos Presente el Formulario',5,1,129);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1158,'Modificar archivo de datos','Modificar archivo de datos',5,1,130);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1159,'Eliminar archivos','Eliminar archivos',5,1,131);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1160,'Crear directorio de archivos','Crear directorio de archivos',5,1,132);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1161,'Enviar por e-mail','Enviar por e-mail',5,1,133);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1162,'Enviar','Enviar',5,1,134);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1163,'Enlace','Enlace',5,1,135);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1164,'Agregar formulario','Agregar formulario',5,1,136);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1165,'Agregar','Agregar',5,1,137);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1166,'Eliminar','Eliminar',5,1,138);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1167,'Formulario de actualización','Formulario de actualización',5,1,139);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1168,'Modificar','Modificar',5,1,140);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1169,'Descargar filtro de URL','Descargar filtro de URL',5,1,141);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1170,'Agregar formulario','Agregar formulario',5,1,142);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1171,'Agregar','Agregar',5,1,143);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1172,'Eliminar','Eliminar',5,1,144);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1173,'Formulario de actualización','Formulario de actualización',5,1,145);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1174,'Modificar','Modificar',5,1,146);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1175,'Canal Modelo de Gestión','Canal Modelo de Gestión',5,1,147);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1176,'Agregar formulario','Agregar formulario',5,1,148);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1177,'Agregar','Agregar',5,1,149);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1178,'Eliminar','Eliminar',5,1,150);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1179,'Formulario de actualización','Formulario de actualización',5,1,151);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1180,'Modificar','Modificar',5,1,152);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1181,'Votación de Gestión','Votación de Gestión',5,1,153);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1182,'Agregar formulario','Agregar formulario',5,1,154);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1183,'Agregar','Agregar',5,1,155);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1184,'Eliminar','Eliminar',5,1,156);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1185,'Formulario de actualización','Formulario de actualización',5,1,157);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1186,'Modificar','Modificar',5,1,158);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1187,'Antecedentes Inicio','Antecedentes Inicio',5,1,159);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1191,'スーパー管理者','スーパー管理者',3,2,0);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1188,'超级管理员','超级管理员',0,2,0);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1189,'Super Admin','Super Admin',1,2,0);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1190,'超級管理員','超級管理員',2,2,0);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1192,'Super Admin','Super Admin',4,2,0);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1193,'Super Admin','Super Admin',5,2,0);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1194,'文章模型','文章模型',0,3,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1195,'Article Model','Article Model',1,3,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1196,'文章模型','文章模型',2,3,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1197,'ペーパーモデル','ペーパーモデル',3,3,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1198,'Бумажная модель','Бумажная модель',4,3,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1199,'Modelo de Article','Modelo de Article',5,3,1);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1200,'软件模型','软件模型',0,3,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1201,'Software Model','Software Model',1,3,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1202,'軟件模型','軟件模型',2,3,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1203,'ソフトウェアモデル','ソフトウェアモデル',3,3,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1204,'программная модель','программная модель',4,3,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1205,'software de modelo','software de modelo',5,3,2);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1206,'图片模型','图片模型',0,3,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1207,'Image Model','Image Model',1,3,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1208,'圖片模型','圖片模型',2,3,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1209,'イメージモデル','イメージモデル',3,3,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1210,'Изображение модели','Изображение модели',4,3,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1211,'Imagen del modelo','Imagen del modelo',5,3,3);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1212,'专题列表','专题列表',0,0,40);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1213,'Special Topic List','Special Topic List',1,0,40);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1214,'專題列表','專題列表',2,0,40);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1215,'特別なトピックのリスト','特別なトピックのリストム',3,0,40);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1216,'Специальный список тему','Специальный список тему',4,0,40);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1217,'Lista de temas Especial','Lista de temas Especial',5,0,40);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1218,'视频列表','视频列表',0,0,41);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1219,'Video List','Video List',1,0,41);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1220,'視頻列表','視頻列表',2,0,41);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1221,'ビデオのリスト','ビデオのリスト',3,0,41);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1222,'Видео Список','Видео Список',4,0,41);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1223,'Lista de vídeo','Lista de vídeo',5,0,41);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1224,'CMS类型列表','CMS类型列表',0,0,42);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1225,'CMS Type List','CMS Type List',1,0,42);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1226,'CMS類型列表','CMS類型列表',2,0,42);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1227,'CMSの種類の一覧','CMSの種類の一覧',3,0,42);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1228,'CMS Список типов','CMS Список типов',4,0,42);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1229,'CMS lista de tipos','CMS lista de tipos',5,0,42);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1230,'专题列表','专题列表',0,1,160);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1231,'Special Topic List','Special Topic List',1,1,160);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1232,'專題列表','專題列表',2,1,160);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1233,'特別なトピックのリスト','特別なトピックのリスト',3,1,160);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1234,'Специальный список тему','Специальный список тему',4,1,160);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1235,'Lista de temas Especial','Lista de temas Especial',5,1,160);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1236,'添加表单','添加表单',0,1,161);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1237,'Add Form','Add Form',1,1,161);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1238,'添加表單','添加表單',2,1,161);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1239,'フォームを追加します。','フォームを追加します。',3,1,161);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1240,'Добавить форму','Добавить форму',4,1,161);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1241,'Agregar formulario','Agregar formulario',5,1,161);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1242,'添加','添加',0,1,162);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1243,'Add','Add',1,1,162);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1244,'添加','添加',2,1,162);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1245,'追加','追加',3,1,162);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1246,'добавлять','добавлять',4,1,162);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1247,'a?adir','a?adir',5,1,162);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1248,'修改表单','修改表单',0,1,163);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1249,'Modified Form','Modified Form',1,1,163);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1250,'修改表單','修改表單',2,1,163);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1251,'変更フォーム','変更フォーム',3,1,163);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1252,'Изменить С','Изменить С',4,1,163);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1253,'De modificar','De modificar',5,1,163);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1254,'修改','修改',0,1,164);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1255,'Modify','Modify',1,1,164);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1256,'修改','修改',2,1,164);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1257,'変更','変更',3,1,164);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1258,'модифицировать','модифицировать',4,1,164);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1259,'modificar','modificar',5,1,164);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1260,'删除','删除',0,1,165);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1261,'Delete','Delete',1,1,165);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1262,'刪除','刪除',2,1,165);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1266,'视频列表','视频列表',0,1,166);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1263,'削除','削除',3,1,165);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1264,'удалять','удалять',4,1,165);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1265,'borrar','borrar',5,1,165);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1267,'Video List','Video List',1,1,166);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1268,'視頻列表','視頻列表',2,1,166);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1269,'ビデオのリスト','ビデオのリスト',3,1,166);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1270,'Видео Список','Видео Список',4,1,166);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1271,'Lista de vídeo','Lista de vídeo',5,1,166);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1272,'添加表单','添加表单',0,1,167);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1273,'Add Form','Add Form',1,1,167);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1274,'添加表單','添加表單',2,1,167);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1275,'フォームを追加します。','フォームを追加します。',3,1,167);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1276,'Добавить форму','Добавить форму',4,1,167);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1277,'Agregar formulario','Agregar formulario',5,1,167);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1278,'添加','添加',0,1,168);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1279,'Add','Add',1,1,168);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1280,'添加','添加',2,1,168);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1281,'追加','追加',3,1,168);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1282,'добавлять','добавлять',4,1,168);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1283,'a?adir','a?adir',5,1,168);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1284,'修改表单','修改表单',0,1,169);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1285,'Modified Form','Modified Form',1,1,169);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1286,'修改表單','修改表單',2,1,169);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1287,'変更フォーム','変更フォーム',3,1,169);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1288,'Изменить С','Изменить С',4,1,169);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1289,'De modificar','De modificar',5,1,169);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1290,'修改','修改',0,1,170);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1291,'Modify','Modify',1,1,170);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1292,'修改','修改',2,1,170);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1293,'変更','変更',3,1,170);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1294,'модифицировать','модифицировать',4,1,170);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1295,'modificar','modificar',5,1,170);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1296,'删除','删除',0,1,171);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1297,'Delete','Delete',1,1,171);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1298,'刪除','刪除',2,1,171);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1299,'削除','削除',3,1,171);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1300,'удалять','удалять',4,1,171);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1301,'borrar','borrar',5,1,171);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1302,'CMS类型列表','CMS类型列表',0,1,172);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1303,'CMS Type List','CMS Type List',1,1,172);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1304,'CMS類型列表','CMS類型列表',2,1,172);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1305,'CMSの種類の一覧','CMSの種類の一覧',3,1,172);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1306,'CMS Список типов','CMS Список типов',4,1,172);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1307,'CMS lista de tipos','CMS lista de tipos',5,1,172);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1308,'添加表单','添加表单',0,1,173);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1309,'Add Form','Add Form',1,1,173);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1310,'添加表單','添加表單',2,1,173);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1311,'フォームを追加します。','フォームを追加します。',3,1,173);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1312,'Добавить форму','Добавить форму',4,1,173);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1313,'Agregar formulario','Agregar formulario',5,1,173);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1314,'添加','添加',0,1,174);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1315,'Add','Add',1,1,174);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1316,'添加','添加',2,1,174);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1317,'追加','追加',3,1,174);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1318,'добавлять','добавлять',4,1,174);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1319,'a?adir','a?adir',5,1,174);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1320,'修改表单','修改表单',0,1,175);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1321,'Modified Form','Modified Form',1,1,175);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1322,'修改表單','修改表單',2,1,175);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1323,'変更フォーム','変更フォーム',3,1,175);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1324,'Изменить С','Изменить С',4,1,175);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1325,'De modificar','De modificar',5,1,175);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1326,'修改','修改',0,1,176);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1327,'Modify','Modify',1,1,176);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1328,'修改','修改',2,1,176);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1329,'変更','変更',3,1,176);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1330,'модифицировать','модифицировать',4,1,176);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1331,'modificar','modificar',5,1,176);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1332,'删除','删除',0,1,177);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1333,'Delete','Delete',1,1,177);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1334,'刪除','刪除',2,1,177);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1335,'削除','削除',3,1,177);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1336,'удалять','удалять',4,1,177);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1337,'borrar','borrar',5,1,177);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1338,'文章移动表单','文章移动表单',0,1,178);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1339,'article move form','article move form',1,1,178);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1340,'文章移動表單','文章移動表單',2,1,178);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1341,'記事の移動形態','記事の移動形態',3,1,178);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1342,'форма статье двигаться','форма статье двигаться',4,1,178);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1343,'artículo forma se mueven','artículo forma se mueven',5,1,178);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1344,'文章移动','文章移动',0,1,179);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1345,'article move','article move',1,1,179);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1346,'文章移動','文章移動',2,1,179);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1347,'記事の移動','記事の移動',3,1,179);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1348,'Статья двигаться','Статья двигаться',4,1,179);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1349,'artículo se mueven','artículo se mueven',5,1,179);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1350,'软件移动表单','软件移动表单',0,1,180);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1351,'software move form','software move form',1,1,180);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1352,'軟件移動表單','軟件移動表單',2,1,180);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1353,'ソフトウェアの移動形態','ソフトウェアの移動形態',3,1,180);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1354,'форме программного обеспечения перемещения','форме программного обеспечения перемещения',4,1,180);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1355,'software de forma avanzar','software de forma avanzar',5,1,180);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1356,'软件移动','软件移动',0,1,181);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1357,'software move','software move',1,1,181);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1358,'軟件移動','軟件移動',2,1,181);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1359,'ソフトウェアの動き','ソフトウェアの動き',3,1,181);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1360,'программное обеспечение двигаться','программное обеспечение двигаться',4,1,181);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1361,'software se mueven','software se mueven',5,1,181);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1362,'设置账号表单','设置账号表单',0,1,182);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1363,'set account form','set account form',1,1,182);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1364,'設置賬號表單','設置賬號表單',2,1,182);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1365,'アカウントフォームを設定する','アカウントフォームを設定する',3,1,182);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1366,'набор форма счета','набор форма счета',4,1,182);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1367,'conjunto de formularios en cuenta','conjunto de formularios en cuenta',5,1,182);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1368,'修改','修改',0,1,183);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1369,'Modify','Modify',1,1,183);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1370,'修改','修改',2,1,183);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1371,'変更','変更',3,1,183);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1372,'модифицировать','модифицировать',4,1,183);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1373,'modificar','modificar',5,1,183);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1374, '会员登录设置', '会员登录设置',0,1,184);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1375, '修改', '修改会员登录配置',0,1, 185);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1376, '会员登录设置', '会员登录设置',0,0,43);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1377, 'Member login settings', 'Member login settings',1,1,184);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1378, 'Modify', 'Login to modify the configuration',1,1,185);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1379, 'Member login settings', 'Member login settings',1,0,43);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1380, '會員登錄設置', '會員登錄設置',2,1,184);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1381, '修改', '修改會員登錄配置', 2,1,185);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1382, '會員登錄設置', '會員登錄設置',2,0,43);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1383, 'メンバーのログイン設定', 'メンバーのログイン設定',3,1,184);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1384, '変更', '設定を変更するには、ログイン',3,1,185);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1385, 'メンバーのログイン設定', 'メンバーのログイン設定',3,0,43);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1386, 'Настройки Вход для зарегистрированных пользователей', 'Настройки Вход для зарегистрированных пользователей',4,1,184);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1387, 'изменять', 'Войти, чтобы изменить конфигурацию',4,1,185);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1388, 'Настройки Вход для зарегистрированных пользователей', 'Настройки Вход для зарегистрированных пользователей',4,0,43);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1389, 'Configuración miembro de inicio de sesión', 'Configuración miembro de inicio de sesión',5,1,184);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1390, 'modificar', 'Inicie sesión para modificar la configuración',5,1,185);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1391, 'Configuración miembro de inicio de sesión', 'Configuración miembro de inicio de sesión',5,0,43);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1392, '生成静态文件', '生成静态文件', 0, 1, 186);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1393, '删除静态文件', '删除静态文件', 0, 1, 187);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1394, 'Generate static file', 'Generate static file', 1, 1, 186);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1395, 'Delete static file', 'Delete static file', 1, 1, 187);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1396, '生成靜態文件', '生成靜態文件', 2, 1, 186);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1397, '删除靜態文件', '删除靜態文件', 2, 1, 187);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1398, '静的ファイルを生成する', '静的ファイルを生成する', 3, 1, 186);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1399, '静的なファイルを削除します。', '静的なファイルを削除します。', 3, 1, 187);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1400, 'Создание статических файлов', 'Создание статических файлов', 4, 1, 186);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1401, 'Удаление статических файлов', 'Удаление статических файлов', 4, 1, 187);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1402, 'Generan archivos estáticos', 'Generan archivos estáticos', 5, 1, 186);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1403, 'Eliminar archivos estáticos', 'Eliminar archivos estáticos', 5, 1, 187);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1404, 'Oauth登录设置', 'Oauth登录设置', 0, 0, 44);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1405, '关键字历史列表', '关键字历史列表', 0, 0, 45);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1406, '支付订单列表', '支付订单列表', 0, 0, 46);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1407, 'Oauth login settings', 'Oauth login settings', 1, 0, 44);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1408, 'Keyword history list', 'Keyword history list', 1, 0, 45);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1409, 'The list of payment orders', 'The list of payment orders', 1, 0, 46);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1410, 'Oauth登錄設置', 'Oauth登錄設置', 2, 0, 44);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1411, '關鍵字歷史列表', '關鍵字歷史列表', 2, 0, 45);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1412, '支付訂單列表', '支付訂單列表', 2, 0, 46);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1413, 'OAuthのログイン設定', 'OAuthのログイン設定', 3, 0, 44);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1414, 'キーワードの履歴リスト', 'キーワードの履歴リスト', 3, 0, 45);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1415, '支払指図のリスト', '支払指図のリスト', 3, 0, 46);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1416, 'OAuth параметры входа', 'OAuth параметры входа', 4, 0, 44);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1417, 'Список ключевых слов история', 'Список ключевых слов история', 4, 0, 45);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1418, 'Список платежных поручений', 'Список платежных поручений', 4, 0, 46);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1419, 'OAuth configuración de inicio de sesión', 'OAuth configuración de inicio de sesión', 5, 0, 44);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1420, 'Palabra lista de la historia', 'Palabra lista de la historia', 5, 0, 45);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1421, 'La lista de órdenes de pago', 'La lista de órdenes de pago', 5, 0, 46);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1422, '上传图片表单', '上传图片表单', 0, 1, 188);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1423, '上传图片', '上传图片', 0, 1, 189);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1424, '上传附件表单', '上传附件表单', 0, 1, 190);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1425, '上传附件', '上传附件', 0, 1, 191);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1426, '评论审核', '评论审核', 0, 1, 192);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1427, '关键字历史列表', '关键字历史列表', 0, 1, 193);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1428, '删除', '删除', 0, 1, 194);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1429, 'Oauth登录设置', 'Oauth登录设置', 0, 1, 195);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1430, '添加表单', '添加表单', 0, 1, 196);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1431, '添加', '添加', 0, 1, 197);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1432, '修改表单', '修改表单', 0, 1, 198);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1433, '修改', '修改', 0, 1, 199);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1434, '删除', '删除', 0, 1, 200);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1435, '支付订单列表', '支付订单列表', 0, 1, 201);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1436, '已付款', '已付款', 0, 1, 202);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1437, '删除', '删除', 0, 1, 203);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1438, 'Upload pictures form', 'Upload pictures form', 1, 1, 188);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1439, 'Upload pictures', 'Upload pictures', 1, 1, 189);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1440, 'Upload attachment form', 'Upload attachment form', 1, 1, 190);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1441, 'Post attachments', 'Post attachments', 1, 1, 191);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1442, 'Comment Moderation', 'Comment Moderation', 1, 1, 192);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1443, 'Keyword history list', 'Keyword history list', 1, 1, 193);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1444, 'Delete', 'Delete', 1, 1, 194);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1445, 'Oauth login settings', 'Oauth login settings', 1, 1, 195);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1446, 'Add form', 'Add form', 1, 1, 196);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1447, 'Add', 'Add', 1, 1, 197);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1448, 'Modify the form', 'Modify the form', 1, 1, 198);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1449, 'Modify', 'Modify', 1, 1, 199);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1450, 'Delete', 'Delete', 1, 1, 200);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1451, 'The list of payment orders', 'The list of payment orders', 1, 1, 201);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1452, 'Paid', 'Paid', 1, 1, 202);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1453, 'Delete', 'Delete', 1, 1, 203);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1454, '上傳圖片表單', '上傳圖片表單', 2, 1, 188);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1455, '上傳圖片', '上傳圖片', 2, 1, 189);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1456, '上傳附件表單', '上傳附件表單', 2, 1, 190);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1457, '上傳附件', '上傳附件', 2, 1, 191);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1458, '評論審核', '評論審核', 2, 1, 192);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1459, '關鍵字歷史列表', '關鍵字歷史列表', 2, 1, 193);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1460, '刪除', '刪除', 2, 1, 194);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1461, 'Oauth登錄設置', 'Oauth登錄設置', 2, 1, 195);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1462, '添加表單', '添加表單', 2, 1, 196);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1463, '添加', '添加', 2, 1, 197);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1464, '修改表單', '修改表單', 2, 1, 198);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1465, '修改', '修改', 2, 1, 199);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1466, '刪除', '刪除', 2, 1, 200);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1467, '支付訂單列表', '支付訂單列表', 2, 1, 201);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1468, '已付款', '已付款', 2, 1, 202);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1469, '刪除', '刪除', 2, 1, 203);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1470, '写真のアップロードフォーム', '写真のアップロードフォーム', 3, 1, 188);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1471, '写真をアップロード', '写真をアップロード', 3, 1, 189);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1472, '添付ファイルのアップロードフォーム', '添付ファイルのアップロードフォーム', 3, 1, 190);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1473, '添付ファイルを投稿する', '添付ファイルを投稿する', 3, 1, 191);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1474, 'コメントモデレーション', 'コメントモデレーション', 3, 1, 192);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1475, 'キーワードの履歴リスト', 'キーワードの履歴リスト', 3, 1, 193);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1476, '削除する', '削除する', 3, 1, 194);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1477, 'OAuthのログイン設定', 'OAuthのログイン設定', 3, 1, 195);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1478, 'フォームを追加する', 'フォームを追加する', 3, 1, 196);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1479, '加える', '加える', 3, 1, 197);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1480, 'フォームを変更', 'フォームを変更', 3, 1, 198);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1481, '修正する', '修正する', 3, 1, 199);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1482, '削除する', '削除する', 3, 1, 200);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1483, '支払指図のリスト', '支払指図のリスト', 3, 1, 201);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1484, '有料', '有料', 3, 1, 202);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1485, '削除する', '削除する', 3, 1, 203);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1486, 'Загрузить фото форме', 'Загрузить фото форме', 4, 1, 188);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1487, 'Загрузить фото', 'Загрузить фото', 4, 1, 189);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1488, 'Загрузите приложение форме', 'Загрузите приложение форме', 4, 1, 190);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1489, 'Сообщение вложения', 'Сообщение вложения', 4, 1, 191);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1490, 'Комментарий умеренности', 'Комментарий умеренности', 4, 1, 192);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1491, 'Список ключевых слов история', 'Список ключевых слов история', 4, 1, 193);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1492, 'удалять', 'удалять', 4, 1, 194);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1493, 'OAuth параметры входа', 'OAuth параметры входа', 4, 1, 195);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1494, 'Добавить форме', 'Добавить форме', 4, 1, 196);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1495, 'добавлять', 'добавлять', 4, 1, 197);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1496, 'Измените форму', 'Измените форму', 4, 1, 198);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1497, 'изменять', 'изменять', 4, 1, 199);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1498, 'удалять', 'удалять', 4, 1, 200);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1499, 'Список платежных поручений', 'Список платежных поручений', 4, 1, 201);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1500, 'оплачиваемый', 'оплачиваемый', 4, 1, 202);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1501, 'удалять', 'удалять', 4, 1, 203);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1502, 'Subir imágenes de forma', 'Subir imágenes de forma', 5, 1, 188);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1503, 'Subir imágenes', 'Subir imágenes', 5, 1, 189);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1504, 'Transferir el formulario adjunto', 'Transferir el formulario adjunto', 5, 1, 190);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1505, 'Enviar archivos adjuntos', 'Enviar archivos adjuntos', 5, 1, 191);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1506, 'comentario moderación', 'comentario moderación', 5, 1, 192);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1507, 'Palabra lista de la historia', 'Palabra lista de la historia', 5, 1, 193);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1508, 'borrar', 'borrar', 5, 1, 194);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1509, 'OAuth configuración de inicio de sesión', 'OAuth configuración de inicio de sesión', 5, 1, 195);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1510, 'Agregar la forma', 'Agregar la forma', 5, 1, 196);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1511, 'añadir', 'añadir', 5, 1, 197);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1512, 'Modificar el formulario', 'Modificar el formulario', 5, 1, 198);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1513, 'modificar', 'modificar', 5, 1, 199);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1514, 'borrar', 'borrar', 5, 1, 200);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1515, 'La lista de órdenes de pago', 'La lista de órdenes de pago', 5, 1, 201);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1516, 'pagado', 'pagado', 5, 1, 202);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1517, 'borrar', 'borrar', 5, 1, 203);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1518, '专题搜索', '专题搜索', 0, 1, 204);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1519, 'Special Topic Search', 'Special Topic Search', 1, 1, 204);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1520, '專題搜索', '專題搜索', 2, 1, 204);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1521, '特別なトピックの検索', '特別なトピックの検索', 3, 1, 204);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1522, 'Специальный поиск темы', 'Специальный поиск темы', 4, 1, 204);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1523, 'Buscar Tema Especial', 'Buscar Tema Especial', 5 ,1, 204);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1524, '图片列表', '图片列表', 0, 0, 47);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1525, 'List Of Images', 'List Of Images', 1, 0, 47);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1526, '圖片列表', '圖片列表', 2, 0, 47);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1527, 'イメージのリスト', 'イメージのリスト', 3, 0, 47);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1528, 'Список изображений', 'Список изображений', 4, 0, 47);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1529, 'Lista de imágenes', 'Lista de imágenes', 5, 0, 47);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1530, '移动表单', '视频移动表单', 0, 1, 205);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1531, 'Move Form', 'Move Form', 1, 1, 205);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1532, '移動表單', '視頻移動表單', 2, 1, 205);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1533, 'フォームを移動', 'フォームを移動', 3, 1, 205);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1534, 'перемещать форму', 'перемещать форму', 4, 1, 205);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1535, 'mover la forma', 'mover la forma', 5, 1, 205);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1536, '移动提交', '移动提交', 0, 1, 206);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1537, 'Move Submit', 'Move Submit', 1, 1, 206);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1538, '移動提交', '移動提交', 2, 1, 206);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1539, '提出移動', '提出移動', 3, 1, 206);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1540, 'двигаться представить', 'двигаться представить', 4, 1, 206);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1541, 'se mueven presente', 'se mueven presente', 5, 1, 206);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1542, '图片列表', '图片列表', 0, 1, 207);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1543, 'List Of Images', 'List Of Images', 1, 1, 207);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1544, '圖片列表', '圖片列表', 2, 1, 207);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1545, 'イメージのリスト', 'イメージのリスト', 3, 1, 207);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1546, 'Список изображений', 'Список изображений', 4, 1, 207);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1547, 'Lista de imágenes', 'Lista de imágenes', 5, 1, 207);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1548, '添加表单', '添加表单', 0, 1, 208);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1549, 'Add Form', 'Add Form', 1, 1, 208);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1550, '添加表單', '添加表單', 2, 1, 208);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1551, 'フォームを追加します。', 'フォームを追加します。', 3, 1, 208);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1552, 'Добавить форму', 'Добавить форму', 4, 1, 208);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1553, 'Agregar formulario', 'Agregar formulario', 5, 1, 208);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1554, '添加', '添加', 0, 1, 209);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1555, 'Add', 'Add', 1, 1, 209);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1556, '添加', '添加', 2, 1, 209);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1557, '追加', '追加', 3, 1, 209);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1558, 'добавлять', 'добавлять', 4, 1, 209);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1559, 'a?adir', 'a?adir', 5, 1, 209);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1560, '修改表单', '修改表单', 0, 1, 210);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1561, 'Modified Form', 'Modified Form', 1, 1, 210);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1562, '修改表單', '修改表單', 2, 1, 210);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1563, '変更フォーム', '変更フォーム', 3, 1, 210);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1564, 'Изменить С', 'Изменить С', 4, 1, 210);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1565, 'De modificar', 'De modificar', 5, 1, 210);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1566, '修改', '修改', 0, 1, 211);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1567, 'Modify', 'Modify', 1, 1, 211);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1568, '修改', '修改', 2, 1, 211);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1569, '変更', '変更', 3, 1, 211);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1570, 'модифицировать', 'модифицировать', 4, 1, 211);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1571, 'modificar', 'modificar', 5, 1, 211);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1572, '删除', '删除', 0, 1, 212);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1573, 'Delete', 'Delete', 1, 1, 212);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1574, '刪除', '刪除', 2, 1, 212);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1575, '削除', '削除', 3, 1, 212);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1576, 'удалять', 'удалять', 4, 1, 212);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1577, 'borrar', 'borrar', 5, 1, 212);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1578, '移动表单', '图片移动表单', 0, 1, 213);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1579, 'Move Form', 'Move Form', 1, 1, 213);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1580, '移動表單', '圖片移動表單', 2, 1, 213);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1581, 'フォームを移動', 'フォームを移動', 3, 1, 213);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1582, 'перемещать форму', 'перемещать форму', 4, 1, 213);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1583, 'mover la forma', 'mover la forma', 5, 1, 213);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1584, '移动提交', '图片移动提交', 0, 1, 214);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1585, 'Move Submit', 'Move Submit', 1, 1, 214);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1586, '移動提交', '圖片移動提交', 2, 1, 214);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1587, '提出移動', '提出移動', 3, 1, 214);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1588, 'двигаться представить', 'двигаться представить', 4, 1, 214);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1589, 'se mueven presente', 'se mueven presente', 5, 1, 214);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1590, '上传表单', '上传表单', 0, 1, 215);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1591, 'Upload Form', 'Upload Form', 1, 1, 215);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1592, '上傳表單', '上傳表單', 2, 1, 215);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1593, 'フォームをアップロードする', 'フォームをアップロードする', 3, 1, 215);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1594, 'Загрузите форму', 'Загрузите форму', 4, 1, 215);
INSERT INTO vj_dictionary (id,name,description,language,modelId,contentId) VALUES ( 1595, 'formulario de carga', 'formulario de carga', 5, 1, 215);

INSERT INTO vj_email_config (configId,sender,email,smtpAddress,isHtml,isEsmtp,isAttachment,emailPort,retry,emailInterval,timeOut,userName,password) VALUES ( 1,'微骏邮件系统','system@java.sh','smtp.qq.com','T','T','F',25,10,3000,30000,'system@java.sh','4711433');


INSERT INTO vj_member_group (groupId,groupName,fileSize,fileSuffix,upgradeExp,language) VALUES ( 1,'初级会员',50,'zip,rar',1000,0);
INSERT INTO vj_member_group (groupId,groupName,fileSize,fileSuffix,upgradeExp,language) VALUES ( 2,'收费会员',50,'zip,rar',5000,0);

INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 1,'内容模型','#','1.gif',0,0,0,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 2,'内容管理','#','1.gif',1,1,1,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 3,'文章列表','listsFunctionArticle','1.gif',2,2,2,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 4,'软件列表','listsFunctionSoft','1.gif',2,2,3,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 5,'内容功能','#','1.gif',1,1,4,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 6,'标签管理','listsFunctionTagList','1.gif',5,2,5,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 7,'评论管理','listsFunctionComment','1.gif',5,2,6,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 8,'生成静态文件','listsFunctionStaticFile','1.gif',5,2,7,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 9,'索引管理','listsFunctionLuceneContent','1.gif',5,2,8,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 10,'用户模型','#','1.gif',0,0,9,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 11,'前台用户','#','1.gif',10,1,10,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 12,'会员列表','listsUserMember','1.gif',11,2,11,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 13,'会员组','listsUserMemberGroup','1.gif',11,2,12,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 14,'后台用户','#','1.gif',10,1,13,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 15,'管理员列表','listsUserAdmin','1.gif',14,2,14,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 16,'角色列表','listsPopedomRole','1.gif',14,2,15,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 17,'权限管理','listsPopedomResource','1.gif',14,2,16,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 18,'登录日志','listsUserAdminLog','1.gif',14,2,17,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 19,'在线管理员','listsOnlineUserAdmin','1.gif',14,2,18,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 20,'系统模型','#','1.gif',0,0,19,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 21,'系统设置','#','1.gif',20,1,20,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 22,'站点设置','listsFunctionWebSite','1.gif',21,2,21,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 23,'安全设置','listsPopedomSafeConfig','1.gif',21,2,22,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 24,'导航设置','listsPopedomNavigate','1.gif',21,2,23,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 25,'水印设置','listsFunctionWatermark','1.gif',21,2,24,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 26,'邮件设置','listsFunctionEmailConfig','1.gif',21,2,25,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 27,'系统功能','#','1.gif',20,1,26,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 28,'备份数据','listsFunctionDatabase','1.gif',27,2,27,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 29,'国际化管理','listsFunctionDictionary','1.gif',27,2,28,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 30,'文件管理','listsFunctionFileManage','1.gif',27,2,29,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 31,'发送邮件','listsSendSystemEmail','1.gif',27,2,30,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 32,'模板设置','listsFunctionTemplateConfig','1.gif',21,2,31,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 33,'模板标签设置','listsFunctionTemplateTag','1.gif',21,2,32,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 34,'友情链接','listsFunctionLink','1.gif',27,2,33,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 35,'下载网址过滤','listsPopedomFilterUrl','1.gif',27,2,34,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 36,'系统变量设置','listsFunctionSystemConfig','1.gif',21,2,35,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 37,'栏目管理','listsFunctionNode','1.gif',5,2,36,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 38,'频道模型管理','listsFunctionChannelModel','1.gif',27,2,37,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 39,'投票管理','listsFunctionVote','1.gif',27,2,38,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 40,'专题列表','listsFunctionSpecialTopic','1.gif',2,2,39,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 41,'视频列表','listsFunctionVideo','1.gif',2,2,40,0,'F');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 42,'CMS类型列表','listsFunctionCmsType','1.gif',2,2,41,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 43,'会员登录设置','listsMemberPopedomSafeConfig','1.gif',21,2,42,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 44, 'Oauth登录设置', 'listsFunctionOauthConfig', '1.gif',21,2,43,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 45, '关键字历史列表', 'listsFunctionKeywordHistory', '1.gif',5,2,44,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 46, '支付订单列表', 'listsFunctionPayOrder', '1.gif',11,2,45,0,'T');
INSERT INTO vj_navigate (navigateId,title,url,ico,parentId,nodeLevel,nodeSort,language,display) VALUES ( 47, '图片列表', 'listsFunctionPhoto', '1.gif',2,2,46,0, 'T');

INSERT INTO vj_nodes (nodeId,nodeName,modelId,nodeType,nodeSort,parentId,keyword,isShowMap,isSubDomain,isCreateList,isCreateContent,isContribute,listNameRule,contentNameRule,nodePopedom,nodeDir,parentDir,indexTemplate,listTemplate,contentTemplate,nodeLevel,staticCount,fileCount) VALUES ( 1,'默认栏目',1,1,0,0,'默认栏目','T','F','F','F','F','index',0,'0','/test','/test','article_index.html','article_list.html','article_page.html',0,8,0);

INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 1,'内容模型','#','内容模型','n',0,0,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 2,'内容管理','#','内容管理','n',1,1,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 3,'文章管理列表','/admin/listsFunctionArticle.**','文章列表','u',2,2,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 4,'访问添加文章表单内容','/admin/addFormFunctionArticle.**','添加表单','u',3,3,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 5,'添加文章内容','/admin/addFunctionArticle.**','添加','u',4,3,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 6,'删除文章内容','/admin/deleteFunctionArticle.**','删除','u',5,3,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 7,'修改文章表单','/admin/modifyFormFunctionArticle.**','修改表单','u',6,3,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 8,'修改文章内容','/admin/updateFunctionArticle.**','修改','u',7,3,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 9,'软件列表','/admin/listsFunctionSoft.**','软件列表','u',8,2,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 10,'添加软件表单','/admin/addFormFunctionSoft.**','添加表单','u',9,9,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 11,'添加软件内容','/admin/addFunctionSoft.**','添加','u',10,9,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 12,'删除软件内容','/admin/deleteFunctionSoft.**','删除','u',11,9,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 13,'修改软件表单','/admin/modifyFormFunctionSoft.**','修改表单','u',12,9,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 14,'修改软件内容','/admin/updateFunctionSoft.**','修改','u',13,9,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 15,'内容模块功能','#','内容功能','n',14,1,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 16,'删除内容列表的静态文件','/admin/deletePageFunctionStaticFile.**','删除静态文件','u',15,15,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 17,'生成内容列表的静态文件','/admin/genPageFunctionStaticFile.**','生成静态文件','u',16,15,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 18,'生成内容列表的索引文件','/admin/genpageFunctionLuceneContent.**','生成索引文件','u',17,15,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 19,'标签管理','/admin/listsFunctionTagList.**','标签管理','u',18,15,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 20,'删除内容标签','/admin/deleteFunctionTagList.**','删除','u',19,19,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 21,'评论管理','/admin/listsFunctionComment.**','评论管理','u',20,15,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 22,'删除评论','/admin/deleteFunctionComment.**','删除','u',21,21,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 23,'修改评论表单','/admin/modifyFormFunctionComment.**','修改表单','u',22,21,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 24,'修改评论','/admin/updateFunctionCommen.**','修改','u',23,21,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 25,'生成静态管理页面','/admin/listsFunctionStaticFile.**','管理静态文件','u',24,15,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 26,'添加静态文件','/admin/addFunctionStaticFile.**','添加','u',25,25,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 27,'索引管理','/admin/listsFunctionLuceneContent.**','索引管理','u',26,15,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 28,'添加索引','/admin/addFunctionLuceneContent.**','添加','u',27,27,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 29,'删除索引表单','/admin/deleteFormFunctionLuceneContent.**','删除表单','u',28,27,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 30,'删除索引','/admin/deleteFunctionLuceneContent.**','删除','u',29,27,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 31,'更新索引表单','/admin/modifyFormFunctionLuceneContent.**','更新表单','u',30,27,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 32,'更新索引','/admin/updateFunctionLuceneContent.**','更新','u',31,27,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 33,'栏目管理','/admin/listsFunctionNode.**','栏目管理','u',32,15,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 34,'添加栏目表单','/admin/addFormFunctionNode.**','添加表单','u',33,33,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 35,'添加栏目','/admin/addFunctionNode.**','添加','u',34,33,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 36,'删除栏目','/admin/deleteFunctionNode.**','删除','u',35,33,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 37,'修改栏目表单','/admin/modifyFormFunctionNode.**','修改表单','u',36,33,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 38,'修改栏目','/admin/updateFunctionNode.**','修改','u',37,33,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 39,'用户模型','#','用户模型','n',38,0,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 40,'前台用户','#','前台用户','n',39,39,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 41,'会员列表','/admin/listsUserMember.**','会员列表','u',40,40,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 42,'添加会员表单','/admin/addFormUserMember.**','添加表单','u',41,41,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 43,'添加会员','/admin/addUserMember.**','添加','u',42,41,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 44,'删除会员','/admin/deleteUserMember.**','删除','u',43,41,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 45,'修改会员表单','/admin/modifyFormUserMember.**','修改表单','u',44,41,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 46,'修改会员','/admin/updateUserMember.**','修改','u',45,41,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 47,'查看会员','/admin/findUserMember.**','查看','u',46,41,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 48,'会员组','/admin/listsUserMemberGroup.**','会员组','u',47,40,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 49,'添加会员组表单','/admin/addFormUserMemberGroup.**','添加表单','u',48,48,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 50,'添加会员组','/admin/addUserMemberGroup.**','添加','u',49,48,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 51,'删除会员组','/admin/deleteUserMemberGroup.**','删除','u',50,48,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 52,'修改会员组表单','/admin/modifyFormUserMemberGroup.**','修改表单','u',51,48,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 53,'修改会员组','/admin/updateUserMemberGroup.**','修改','u',52,48,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 54,'后台用户管理','#','后台用户','n',53,39,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 55,'管理员列表','/admin/listsUserAdmin.**','管理员列表','u',54,54,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 56,'添加管理员表单','/admin/addFormUserAdmin.**','添加管理员表单','u',55,55,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 57,'添加管理员','/admin/addUserAdmin.**','添加管理员','u',56,55,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 58,'删除管理员','/admin/deleteUserAdmin.**','删除管理员','u',57,55,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 59,'修改管理员表单','/admin/modifyFormUserAdmin.**','修改管理员表单','u',58,55,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 60,'修改管理员','/admin/updateUserAdmin.**','修改管理员','u',59,55,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 61,'修改管理员角色表单','/admin/modifyRoleFormUserAdmin.**','修改角色表单','u',60,55,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 62,'修改管理员角色','/admin/updateRoleUserAdmin.**','修改角色','u',61,55,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 63,'查看管理员','/admin/findUserAdmin.**','查看管理员','u',62,55,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 64,'角色列表','/admin/listsPopedomRole.**','角色列表','u',63,54,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 65,'添加角色表单','/admin/addFormPopedomRole.**','添加角色表单','u',64,64,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 66,'添加角色','/admin/addPopedomRole.**','添加角色','u',65,64,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 67,'删除角色','/admin/deletePopedomRole.**','删除角色','u',66,64,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 68,'修改角色表单','/admin/modifyFormPopedomRole.**','修改表单','u',67,64,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 69,'修改角色','/admin/updatePopedomRole.**','修改角色','u',68,64,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 70,'修改角色权限表单','/admin/findPopedomRole.**','修改角色权限表单','u',69,64,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 71,'修改角色权限','/admin/modifyResourcePopedomRole.**','修改角色权限','u',70,64,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 72,'修改角色菜单表单','/admin/findNavigatePopedomRole.**','修改角色导航表单','u',71,64,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 73,'修改角色菜单','/admin/modifyNavigatePopedomRole.**','修改角色导航','u',72,64,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 74,'权限管理','/admin/listsPopedomResource.**','权限管理','u',73,54,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 75,'添加权限表单','/admin/addFormPopedomResource.**','添加表单','u',74,74,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 76,'添加权限','/admin/addPopedomResource.**','添加','u',75,74,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 77,'删除权限','/admin/deletePopedomResource.**','删除','u',76,74,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 78,'修改权限表单','/admin/modifyFormPopedomResource.**','修改表单','u',77,74,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 79,'修改权限','/admin/updatePopedomResource.**','修改','u',78,74,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 80,'刷新权限','/admin/refreshPopedomResource.**','刷新','u',79,74,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 81,'登陆日志列表','/admin/listsUserAdminLog.**','登陆日志','u',80,54,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 82,'删除日志','/admin/deleteUserAdminLog.**','删除','u',81,81,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 83,'在线管理员','/admin/listsOnlineUserAdmin.**','在线管理员','u',82,54,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 84,'删除在线管理员','/admin/deleteOnlineUserAdmin.**','删除','u',83,83,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 85,'系统模型','#','系统模型','n',84,0,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 86,'系统设置','#','系统设置','n',85,85,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 87,'站点设置表单','/admin/listsFunctionWebSite.**','站点设置','u',86,86,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 88,'修改站点','/admin/updateFunctionWebSite.**','修改站点','u',87,87,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 89,'安全设置','/admin/listsPopedomSafeConfig.**','安全设置','u',88,86,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 90,'修改安全设置','/admin/updatePopedomSafeConfig.**','修改','u',89,89,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 91,'菜单设置列表','/admin/listsPopedomNavigate.**','导航设置','u',90,86,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 92,'添加导航表单','/admin/addFormPopedomNavigate.**','添加表单','u',91,91,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 93,'添加导航','/admin/addPopedomNavigate.**','添加','u',92,91,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 94,'删除导航','/admin/deletePopedomNavigate.**','删除','u',93,91,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 95,'修改导航表单','/admin/modifyFormPopedomNavigate.**','修改表单','u',94,91,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 96,'修改导航','/admin/updatePopedomNavigate.**','修改','u',95,91,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 97,'水印设置','/admin/listsFunctionWatermark.**','水印设置','u',96,86,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 98,'修改水印','/admin/updateFunctionWatermark.**','修改','u',97,97,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 99,'邮件设置','/admin/listsFunctionEmailConfig.**','邮件设置','u',98,86,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 100,'修改邮件','/admin/updateFunctionEmailConfig.**','修改','u',99,99,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 101,'模板设置','/admin/listsFunctionTemplateConfig.**','模板设置','u',100,86,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 102,'修改模板','/admin/updateFunctionTemplateConfig.**','修改','u',101,101,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 103,'模板标签设置列表','/admin/listsFunctionTemplateTag.**','模板标签设置','u',102,86,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 104,'添加模板标签表单','/admin/addFormFunctionTemplateTag.**','添加表单','u',103,103,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 105,'添加模板标签','/admin/addFunctionTemplateTag.**','添加','u',104,103,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 106,'删除模板标签','/admin/deleteFunctionTemplateTag.**','删除','u',105,103,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 107,'修改模板标签表单','/admin/modifyFormFunctionTemplateTag.**','修改表单','u',106,103,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 108,'修改模板标签','/admin/updateFunctionTemplateTag.**','修改','u',107,103,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 109,'系统变量设置','/admin/listsFunctionSystemConfig.**','系统变量设置','u',108,86,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 110,'添加系统变量表单','/admin/addFormFunctionSystemConfig.**','添加表单','u',109,109,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 111,'添加系统变量','/admin/addFunctionSystemConfig.**','添加','u',110,109,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 112,'删除系统变量','/admin/deleteFunctionSystemConfig.**','删除','u',111,109,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 113,'修改系统变量表单','/admin/modifyFormFunctionSystemConfig.**','修改表单','u',112,109,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 114,'修改系统变量','/admin/updateFunctionSystemConfig.**','修改','u',113,109,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 115,'系统功能','#','系统功能','n',114,85,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 116,'备份数据','/admin/listsFunctionDatabase.**','备份数据','u',115,115,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 117,'备份和还原','/admin/executeFunctionDatabase.**','备份和还原','u',116,116,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 118,'国际化管理','/admin/listsFunctionDictionary.**','国际化管理','u',117,115,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 119,'添加国际化表单','/admin/addFormFunctionDictionary.**','添加表单','u',118,118,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 120,'添加国际化','/admin/addFunctionDictionary.**','添加','u',119,118,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 121,'删除国际化','/admin/deleteFunctionDictionary.**','删除','u',120,118,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 122,'修改国际化表单','/admin/modifyFormFunctionDictionary.**','修改表单','u',121,118,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 123,'修改国际化','/admin/updateFunctionDictionary.**','修改','u',122,118,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 124,'文件管理','/admin/listsFunctionFileManage.**','文件管理','u',123,115,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 125,'上传文件表单','/admin/addFormFunctionFileManage.**','上传文件表单','u',124,124,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 126,'上传文件','/admin/uploadFunctionFileManage.**','上传文件','u',125,124,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 127,'重命文件名表单','/admin/renameFormFunctionFileManage.**','修改文件名表单','u',126,124,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 128,'修改文件名','/admin/updateRenameFunctionFileManage.**','修改文件名','u',127,124,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 129,'修改文件数据表单','/admin/modifyFormFunctionFileManage.**','修改文件数据表单','u',128,124,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 130,'修改文件数据','/admin/updateFunctionFileManage.**','修改文件数据','u',129,124,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 131,'删除文件','/admin/deleteFunctionFileManage.**','删除文件','u',130,124,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 132,'创建文件目录','/admin/createDirFunctionFileManage.**','创建文件目录','u',131,124,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 133,'发送邮件','/admin/listsSendSystemEmail.**','发送邮件','u',132,115,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 134,'发送邮件','/admin/sendSystemEmail.**','发送','u',133,133,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 135,'友情链接','/admin/listsFunctionLink.**','友情链接','u',134,115,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 136,'添加友情链接表单','/admin/addFormFunctionLink.**','添加表单','u',135,135,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 137,'添加友情链接','/admin/addFunctionLink.**','添加','u',136,135,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 138,'删除友情链接','/admin/deleteFunctionLink.**','删除','u',137,135,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 139,'修改友情链接表单','/admin/modifyFormFunctionLink.**','修改表单','u',138,135,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 140,'修改友情链接','/admin/updateFunctionLink.**','修改','u',139,135,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 141,'下载网址过滤','/admin/listsPopedomFilterUrl.**','下载网址过滤','u',140,115,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 142,'添加下载网址过滤表单','/admin/addFormPopedomFilterUrl.**','添加表单','u',141,141,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 143,'添加下载网址过滤','/admin/addPopedomFilterUrl.**','添加','u',142,141,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 144,'删除下载网址过滤','/admin/deletePopedomFilterUrl.**','删除','u',143,141,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 145,'下载网址过滤的修改表单','/admin/modifyFormPopedomFilterUrl.**','修改表单','u',144,141,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 146,'修改下载网址过滤','/admin/updatePopedomFilterUrl.**','修改','u',145,141,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 147,'频道模型管理','/admin/listsFunctionChannelModel.**','频道模型管理','u',146,115,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 148,'添加频道模型表单','/admin/addFormFunctionChannelModel.**','添加表单','u',147,147,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 149,'添加频道模型','/admin/addFunctionChannelModel.**','添加','u',148,147,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 150,'删除频道模型','/admin/deleteFunctionChannelModel.**','删除','u',149,147,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 151,'修改频道模型表单','/admin/modifyFormFunctionChannelModel.**','修改表单','u',150,147,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 152,'修改频道模型','/admin/updateFunctionChannelModel.**','修改','u',151,147,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 153,'投票管理','/admin/listsFunctionVote.**','投票管理','u',152,115,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 154,'添加投票表单','/admin/addFormFunctionVote.**','添加表单','u',153,153,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 155,'添加投票','/admin/addFunctionVote.**','添加','u',154,153,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 156,'删除投票','/admin/deleteFunctionVote.**','删除','u',155,153,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 157,'修改投票表单','/admin/modifyFormFunctionVote.**','修改表单','u',156,153,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 158,'修改投票','/admin/updateFunctionVote.**','修改','u',157,153,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 159,'后台首页','/admin/index.**','后台首页','u',158,115,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 160,'专题列表','/admin/listsFunctionSpecialTopic.**','视频栏目','u',159,2,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 161,'添加专题表单','/admin/addFormFunctionSpecialTopic.**','添加表单','u',160,160,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 162,'添加专题','/admin/addFunctionSpecialTopic.**','添加','u',161,160,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 163,'修改专题表单','/admin/modifyFormFunctionSpecialTopic.**','修改表单','u',162,160,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 164,'修改专题','/admin/updateFunctionSpecialTopic.**','修改','u',163,160,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 165,'删除专题','/admin/deleteFunctionSpecialTopic.**','删除','u',164,160,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 166,'视频列表','/admin/listsFunctionVideo.**','视频列表','u',165,2,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 167,'添加视频表单','/admin/addFormFunctionVideo.**','添加表单','u',166,166,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 168,'添加视频','/admin/addFunctionVideo.**','添加','u',167,166,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 169,'修改视频表单','/admin/modifyFormFunctionVideo.**','修改表单','u',168,166,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 170,'修改视频','/admin/updateFunctionVideo.**','修改','u',169,166,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 171,'删除视频','/admin/deleteFunctionVideo.**','删除','u',170,166,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 172,'CMS类型列表','/admin/listsFunctionCmsType.**','CMS类型列表','u',171,2,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 173,'添加CMS类型表单','/admin/addFormFunctionCmsType.**','添加表单','u',172,172,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 174,'添加CMS类型','/admin/addFunctionCmsType.**','添加','u',173,172,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 175,'修改CMS类型表单','/admin/modifyFormFunctionCmsType.**','修改表单','u',174,172,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 176,'修改CMS类型','/admin/updateFunctionCmsType.**','修改','u',175,172,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 177,'删除CMS类型','/admin/deleteFunctionCmsType.**','删除','u',176,172,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 178,'文章移动表单','/admin/moveFormFunctionArticle.**','移动表单','u',177,3,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 179,'文章移动','/admin/moveSubmitFunctionArticle.**','移动提交','u',178,3,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 180,'软件移动表单','/admin/moveFormFunctionSoft.**','移动表单','u',179,9,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 181,'软件移动','/admin/moveSubmitFunctionSoft.**','移动提交','u',180,9,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 182,'设置我的账号表单','/admin/myModifyFormUserAdmin.**','设置账号','u',181,54,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 183,'修改我的资料','/admin/myUpdateUserAdmin.**','修改','u',182,182,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 184,'会员登录设置','/admin/listsMemberPopedomSafeConfig.**','会员登录设置','u',183,86,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 185,'修改会员登录配置','/admin/updateMemberPopedomSafeConfig.**','修改','u',184,184,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 186,'生成静态文件','/admin/genNodeFunctionStaticFile.**','生成静态文件','u',185,33,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES ( 187,'删除静态文件','/admin/deleteNodeFunctionStaticFile.**','删除静态文件','u',186,33,0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (188, '上传图片表单', '/admin/uploadImageForm.**', '上传图片表单', 'u', 187, 15, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (189, '上传图片', '/admin/uploadImageFile.**', '上传图片', 'u', 188, 188, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (190, '上传附件表单', '/admin/uploadAttachmentForm.**', '上传附件表单', 'u', 189, 15, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (191, '上传附件', '/admin/uploadAttachmentFile.**', '上传附件', 'u', 190, 190, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (192, '评论审核', '/admin/auditFunctionComment.**', '评论审核', 'u', 191, 21, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (193, '关键字历史列表', '/admin/listsFunctionKeywordHistory.**', '关键字历史列表', 'u', 192, 15, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (194, '删除关键字', '/admin/deleteFunctionKeywordHistory.**', '删除', 'u', 193, 193, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (195, 'Oauth登录设置', '/admin/listsFunctionOauthConfig.**', 'Oauth登录设置', 'u', 194, 86, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (196, '添加表单', '/admin/addFormFunctionOauthConfig.**', '添加表单', 'u', 195, 195, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (197, '添加', '/admin/addFunctionOauthConfig.**', '添加', 'u', 196, 195, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (198, '修改表单', '/admin/modifyFormFunctionOauthConfig.**', '修改表单', 'u', 197, 195, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (199, '修改', '/admin/updateFunctionOauthConfig.**', '修改', 'u', 198, 195, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (200, '删除', '/admin/deleteFunctionOauthConfig.**', '删除', 'u', 199, 195, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (201, '支付订单列表', '/admin/listsFunctionPayOrder.**', '支付订单列表', 'u', 200, 40, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (202, '已付款', '/admin/confirmFunctionPayOrder.**', '已付款', 'u', 201, 201, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (203, '删除', '/admin/deleteFunctionPayOrder.**', '删除', 'u', 202, 201, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES  (204, '专题搜索', '/admin/selectFromScpecialTopicContent.**', '专题搜索', 'u', 203, 160, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES (205, '移动表单', '/admin/moveFormFunctionVideo.**', '移动表单', 'u', 204, 166, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES (206, '移动提交', '/admin/moveSubmitFunctionVideo.**', '移动提交', 'u', 205, 166, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES (207, '图片列表', '/admin/listsFunctionPhoto.**', '图片列表', 'u', 206, 2, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES (208, '添加表单', '/admin/addFormFunctionPhoto.**', '添加表单', 'u', 207, 207, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES (209, '添加', '/admin/addFunctionPhoto.**', '添加', 'u', 208, 207, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES (210, '修改表单', '/admin/modifyFormFunctionPhoto.**', '修改表单', 'u', 209, 207, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES (211, '修改图片', '/admin/updateFunctionPhoto.**', '修改', 'u', 210, 207, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES (212, '删除图片', '/admin/deleteFunctionPhoto.**', '删除', 'u', 211, 207, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES (213, '移动表单', '/admin/moveFormFunctionPhoto.**', '移动表单', 'u', 212, 207, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES (214, '移动提交', '/admin/moveSubmitFunctionPhoto.**', '移动提交', 'u', 213, 207, 0);
INSERT INTO vj_resources (resourceId,description,expressionDesc,resourceName,resourceType,nodeSort,parentId,language) VALUES (215, '上传表单', '/admin/uploadFormFunctionPhoto.**', '上传表单', 'u', 214, 207, 0);
INSERT INTO vj_roles (roleId,description,roleName,language) VALUES ( 0,'超级管理员','超级管理员',0);

INSERT INTO vj_safe_config (configId,isAccountExpire,isVerCode,isLockAccount,isPassExpire,isEnable,isAutoRelieve,accountLockTime,accountExpireTime,disableCount,passwordExpireTime,passwordErrorCount) VALUES ( '1','T','F','T','T','T','T',2,20,3,33,3);
INSERT INTO vj_safe_config (configId,isAccountExpire,isVerCode,isLockAccount,isPassExpire,isEnable,isAutoRelieve,accountLockTime,accountExpireTime,disableCount,passwordExpireTime,passwordErrorCount) VALUES ( '2','T','F','T','T','T','T',2,20,3,33,3);

INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 1,'core_isAdminLog','是否开启管理员日志',2,'T',0,'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 2,'cms_register_welcome','是否发送注册欢迎信',2,'F',0,'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 3, 'cms_memberUpgradeCosts', '升级会员费用', 4, '100', 0, 'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 4,'cms_installDirectory','CMS安装目录',0,'/',0,'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 5,'cms_imageUrl','图片域名地址',0,'http://localhost/cms',0,'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 6,'cms_imageUploadDirectory','图片上传目录',0,'/upload/image/',0,'F');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 7,'core_coding','系统编码',0,'utf-8',0,'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 8,'core_staticSuffix','静态后缀',0,'.html',0,'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 9,'core_dynamicSuffix','动态后缀',0,'.jhtml',0,'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 10,'core_folderStyle','1(年月日)2(年月)3(年)格式',1,'2',0,'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 11,'cms_softUploadDirectory','软件路径',0,'/upload/soft/',0,'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 12,'cms_softAddress','软件下载地址',0,'http://localhost/cms',0,'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 13,'cms_isSha1','T真,F假',2,'T',0,'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 14,'cms_isContentLucene','全文搜索',2,'T',0,'F');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 15,'cms_memberFaceUploadDirectory','会员头像上传路径',0,'/upload/face/',0,'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 16,'cms_alipayInfo','支付宝信息',0,'partner,prestrKey,sellerEmail',0,'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 17,'cms_memberSubmission', '会员登录投稿', 2, 'F', 0, 'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 18, 'cms_isAuditComment', '评论审核', 2, 'F', 0, 'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 19, 'cms_thumbnails_width', '略缩图宽度', 1, '120', 0, 'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 20, 'cms_thumbnails_height', '略缩图高度', 1, '120', 0, 'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 21, 'cms_aliyun_oss_config','阿里云OSS配置信息(ID,Secret,URL)',0,'ID,Secret,URL',0,'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 22, 'cms_aliyun_oss_bucketName','阿里云OSS的bucketName值',0,'vijun',0,'T');
INSERT INTO vj_system_config (id,varName,description,type,value,modelId,status) VALUES ( 23, 'cms_user_init_capacity', '用户初始网盘容量(MB/单位)', 1, '50', 0, 'T');

INSERT INTO vj_template_config (id,templateLocale,dateTimeFormat,dateFormat,timeFormat,numberFormat,tagSyntax) VALUES ( 1,0,'yyyy-MM-dd HH:mm:ss','yyyy-MM-dd','HH:mm:ss','0.######',2);

INSERT INTO vj_template_tag (tagId,tagName,tagClass,description,status) VALUES ( 1,'sys_list_c','com.vijun.cms.util.freemarker.directive.ContentListDirective','内容列表','1');
INSERT INTO vj_template_tag (tagId,tagName,tagClass,description,status) VALUES ( 2,'sys_cut','com.vijun.cms.util.freemarker.directive.CutDirective','文本剪切','1');
INSERT INTO vj_template_tag (tagId,tagName,tagClass,description,status) VALUES ( 3,'sys_list','com.vijun.cms.util.freemarker.directive.NodeListDirective','栏目列表','1');
INSERT INTO vj_template_tag (tagId,tagName,tagClass,description,status) VALUES ( 4,'sys_list_cp','com.vijun.cms.util.freemarker.directive.ContentListByCountDirective','内容列表带分页','1');
INSERT INTO vj_template_tag (tagId,tagName,tagClass,description,status) VALUES ( 5,'sys_pagination','com.vijun.cms.util.freemarker.directive.PaginationDirective','分页标签','1');
INSERT INTO vj_template_tag (tagId,tagName,tagClass,description,status) VALUES ( 6,'sys_member','com.vijun.cms.util.freemarker.directive.MemberDirective','会员内容','1');
INSERT INTO vj_template_tag (tagId,tagName,tagClass,description,status) VALUES ( 7,'sys_search','com.vijun.cms.util.freemarker.directive.SearchDirective','搜索内容','1');
INSERT INTO vj_template_tag (tagId,tagName,tagClass,description,status) VALUES ( 8,'sys_lucene','com.vijun.cms.util.freemarker.directive.LuceneSearchDirective','全文搜索','1');
INSERT INTO vj_template_tag (tagId,tagName,tagClass,description,status) VALUES ( 9,'sys_timeZone','com.vijun.cms.util.freemarker.directive.TimeZoneDirective','时区','1');
INSERT INTO vj_template_tag (tagId,tagName,tagClass,description,status) VALUES ( 10,'sys_sql','com.vijun.cms.util.freemarker.directive.SqlDirective','sql标签','1');
INSERT INTO vj_template_tag (tagId,tagName,tagClass,description,status) VALUES ( 11,'sys_format','com.vijun.cms.util.freemarker.directive.TextFormatDirective','内容格式','1');
INSERT INTO vj_template_tag (tagId,tagName,tagClass,description,status) VALUES ( 12,'sys_special','com.vijun.cms.util.freemarker.directive.SpecialTopicDirective','专题标签','1');

INSERT INTO vj_watermark (watermarkId,watermarkPath,alpha,watermarkPosition,spacingX,spacingY,watermarkText,fontPath,fontColor,fontSize,watermarkType,width,height) VALUES ( '1','/template/images/mark.png','0.5',9,-20,1,'技术网','/template/font/1.ttf','B22222',20,'1',300,200);

INSERT INTO vj_web_config (configId,websiteName,publicityTitle,url,templateDir,keyword,description,recordNumber,powerby,systemVersion) VALUES  ('1','微骏技术网','努力做好java技术平台','http://www.vijun.com','/WEB-INF/cms/template/default/zh_CN/','java','微骏技术网','沪ICP备12006519号-1','Copyright  2012 vijun.com All Rights Reserved.','1.0 Release');