DROP TABLE IF EXISTS `vj_consumption_record`;
CREATE TABLE `vj_consumption_record` (
  `id` char(32) NOT NULL DEFAULT '',
  `memberId` char(32) DEFAULT NULL,
  `contentId` char(32) DEFAULT NULL,
  `nodeId` int(11) DEFAULT NULL,
  `consumption` double DEFAULT NULL,
  `consumptionTime` int(11) DEFAULT NULL,
  `consumptionType` int(11) DEFAULT NULL,
  `state` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_consumption_record_cId_nId` (`contentId`,`nodeId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `vj_photos`;
CREATE TABLE `vj_photos` (
  `id` char(32) NOT NULL,
  `photoText` text,
  `style` char(1) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


DROP TABLE IF EXISTS `vj_special_topic`;
CREATE TABLE `vj_special_topic` (
  `id` int(11) NOT NULL DEFAULT '0',
  `nodeId` int(11) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `titleImg` varchar(255) DEFAULT NULL,
  `code` text,
  `createTime` int(10) DEFAULT NULL,
  `author` varchar(50) DEFAULT NULL,
  `templatePath` varchar(255) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `isStatic` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_vj_special_topic_createTime` (`createTime`),
  KEY `IX_vj_special_topic_title` (`title`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `vj_keyword_history`;
CREATE TABLE `vj_keyword_history` (
  `id` char(32) NOT NULL,
  `keyword` varchar(255) DEFAULT NULL,
  `searchCount` int(11) DEFAULT NULL,
  `isContent` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_vj_keyword_history_keyword` (`keyword`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `vj_member_consume_record`;
CREATE TABLE `vj_member_consume_record` (
  `id` char(32) NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `amountType` tinyint(4) DEFAULT NULL,
  `action` tinyint(4) DEFAULT NULL,
  `description` varchar(255) DEFAULT NULL,
  `memberId` char(32) DEFAULT NULL,
  `creationTime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_vj_member_consume_recore_creationTime` (`creationTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `vj_email_validation`;
CREATE TABLE `vj_email_validation` (
  `id` char(32) NOT NULL,
  `userId` char(32) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `keyValue` char(32) DEFAULT NULL,
  `recordTime` int(11) DEFAULT NULL,
  `inTime` int(11) DEFAULT NULL,
  `hit` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `vj_pay_order`;
CREATE TABLE `vj_pay_order` (
  `id` char(32) NOT NULL,
  `title` varchar(200) DEFAULT NULL,
  `orderNo` char(32) DEFAULT NULL,
  `payNo` varchar(150) DEFAULT NULL,
  `memberId` char(32) DEFAULT NULL,
  `payPrice` decimal(10,2) DEFAULT NULL,
  `quantity` int(11) DEFAULT NULL,
  `payType` tinyint(4) DEFAULT NULL,
  `remark` varchar(250) DEFAULT NULL,
  `status` tinyint(4) DEFAULT NULL,
  `creationTime` int(11) DEFAULT NULL,
  `payTime` int(11) DEFAULT NULL,
  `ConfirmTime` int(11) DEFAULT NULL,
  `ipAddress` varchar(40) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_vj_pay_order_creationTime` (`creationTime`),
  UNIQUE KEY `IX_vj_pay_order_orderNo` (`orderNo`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `vj_oauth_config`;
CREATE TABLE `vj_oauth_config` (
  `id` int(11) NOT NULL,
  `name` varchar(20) DEFAULT NULL,
  `clientId` varchar(150) DEFAULT NULL,
  `clientSecret` varchar(150) DEFAULT NULL,
  `redirectUri` varchar(150) DEFAULT NULL,
  `authorizeUrl` varchar(150) DEFAULT NULL,
  `tokenUrl` varchar(150) DEFAULT NULL,
  `meUrl` varchar(150) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IX_vj_oauth_config_name` (`name`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

INSERT INTO `vj_oauth_config` VALUES (1, 'qq', '', '', 'http://www.vijun.com/oauth/qq/authorizationCode.sh', 'https://graph.qq.com/oauth2.0/authorize', 'https://graph.qq.com/oauth2.0/token', 'https://graph.qq.com/oauth2.0/me');
INSERT INTO `vj_oauth_config` VALUES (2, 'msn', '', '', 'http://www.vijun.com/oauth/msn/authorizationCode.sh', 'https://oauth.live.com/authorize', 'https://oauth.live.com/token', 'https://apis.live.net/v5.0/me');
INSERT INTO `vj_oauth_config` VALUES (3, 'baidu', '', '', 'http://www.vijun.com/oauth/baidu/authorizationCode.sh', 'https://openapi.baidu.com/oauth/2.0/authorize', 'https://openapi.baidu.com/oauth/2.0/token', 'https://openapi.baidu.com/rest/2.0/passport/users/getInfo');

DROP TABLE IF EXISTS `vj_oauth`;
CREATE TABLE `vj_oauth` (
  `id` char(32) NOT NULL,
  `openId` varchar(100) DEFAULT NULL,
  `memberId` char(32) DEFAULT NULL,
  `loginType` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IX_vj_oauth_openId` (`openId`),
  KEY `IX_vj_oauth_memberId` (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

DROP TABLE IF EXISTS `vj_admin_log`;
CREATE TABLE `vj_admin_log` (
  `id` char(32) NOT NULL,
  `code` tinyint(4) DEFAULT NULL,
  `type` char(1) DEFAULT NULL,
  `userName` varchar(100) DEFAULT NULL,
  `ipAddress` varchar(40) DEFAULT NULL,
  `recordTime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_vj_admin_log_time` (`recordTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_admin_log` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_admin_role`;
CREATE TABLE `vj_admin_role` (
  `adminId` char(32) NOT NULL,
  `roleId` int(11) NOT NULL,
  PRIMARY KEY (`adminId`,`roleId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
LOCK TABLES `vj_admin_role` WRITE;
INSERT INTO `vj_admin_role` VALUES ('402881e52bc4aa42012bc4b22fdd0004',0);
UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_admins`;
CREATE TABLE `vj_admins` (
  `adminId` char(32) NOT NULL,
  `username` varchar(20) DEFAULT NULL,
  `password` char(56) DEFAULT NULL,
  `accountExpired` char(1) DEFAULT NULL,
  `accountLocked` char(1) DEFAULT NULL,
  `credentialsExpired` char(1) DEFAULT NULL,
  `enable` char(1) DEFAULT NULL,
  `lastLoginIp` varchar(40) DEFAULT NULL,
  `lastLoginTime` int(11) DEFAULT NULL,
  `lastUpdatePassWordTime` int(11) DEFAULT NULL,
  `loginCount` int(11) DEFAULT NULL,
  `loginErrorCount` int(11) DEFAULT NULL,
  `registerTime` int(11) DEFAULT NULL,
  `myTimeZone` char(6) DEFAULT NULL,
  `myLanguage` tinyint(4) DEFAULT NULL,
  `isPassExpire` char(1) DEFAULT NULL,
  `accountLockCount` int(11) DEFAULT NULL,
  `isAccountExpire` char(1) DEFAULT NULL,
  `superPassword` char(56) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `question` char(1) DEFAULT NULL,
  `answer` varchar(250) DEFAULT NULL,
  `isAnswerLogin` char(1) DEFAULT NULL,
  PRIMARY KEY (`adminId`),
  UNIQUE KEY `IX_vj_admins_username` (`username`),
  KEY `IX_vj_admins_register` (`registerTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `vj_admins` WRITE;
INSERT INTO `vj_admins` VALUES ('402881e52bc4aa42012bc4b22fdd0004','admin','4ABE1307ADEEF96E9FA296BA39250C6FF6D764462B83DE8475BA94D2','F','F','F','F','192.168.244.1',1315092024,1299882271,815,0,1296952652,'+08:00',0,'F',0,'F','5EF458ADD47610C4A4D0B0DEC1C608709AD303E771C45A594ABFDF14','458479@qq.com','0','d','F');
UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_channel_model`;
CREATE TABLE `vj_channel_model` (
  `modelId` int(11) NOT NULL,
  `modelName` varchar(50) DEFAULT NULL,
  `type` char(1) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `enable` char(1) DEFAULT NULL,
  `language` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`modelId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
LOCK TABLES `vj_channel_model` WRITE;
INSERT INTO `vj_channel_model` VALUES (1,'文章模型','0','文章模型','T',0),(2,'软件模型','0','软件模型','T',0),(3,'图片模型','0','图片模型','T',0),(4,'视频模型','0','视频模型','T',0);
UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_cms_type`;
CREATE TABLE `vj_cms_type` (
  `id` int(11) NOT NULL DEFAULT '0',
  `name` varchar(150) DEFAULT NULL,
  `typeId` int(11) DEFAULT NULL,
  `modelId` int(11) DEFAULT NULL,
  `keyId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
LOCK TABLES `vj_cms_type` WRITE;
INSERT INTO `vj_cms_type` VALUES (1,'简体中文',1,2,1),(2,'繁体中文',1,2,2),(3,'英语',1,2,3),(4,'多国语言',1,2,4),(5,'exe',2,2,1),(6,'rar',2,2,2),(7,'zip',2,2,3),(8,'7z',2,2,4),(9,'iso',2,2,5),(10,'win xp/7/2008/2003/2000',3,2,1);

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_comments`;
CREATE TABLE `vj_comments` (
  `commentsId` char(32) NOT NULL,
  `contentId` char(32) DEFAULT NULL,
  `commentsText` varchar(500) DEFAULT NULL,
  `support` int(11) DEFAULT NULL,
  `against` int(11) DEFAULT NULL,
  `commentsTime` int(11) DEFAULT NULL,
  `ipAddress` varchar(40) DEFAULT NULL,
  `memberId` char(32) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `nodeId` int(11) DEFAULT NULL,
  `modelId` int(11) DEFAULT NULL,
  PRIMARY KEY (`commentsId`),
  KEY `IX_vj_comments_contentId` (`contentId`),
  KEY `IX_vj_comments_commentTime` (`commentsTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
LOCK TABLES `vj_comments` WRITE;
UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_content_text`;
CREATE TABLE `vj_content_text` (
  `id` char(32) NOT NULL,
  `detail` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `vj_content_text` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_contents`;

CREATE TABLE `vj_contents` (
  `id` char(32) NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `subTitle` varchar(250) DEFAULT NULL,
  `copyFrom` varchar(50) DEFAULT NULL,
  `authorName` varchar(50) DEFAULT NULL,
  `authorId` char(32) DEFAULT NULL,
  `keyword` varchar(50) DEFAULT NULL,
  `intro` varchar(500) DEFAULT NULL,
  `publishTime` int(11) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `tags` varchar(100) DEFAULT NULL,
  `isTop` char(1) DEFAULT NULL,
  `isRecommend` char(1) DEFAULT NULL,
  `isPic` char(1) DEFAULT NULL,
  `isComment` char(1) DEFAULT NULL,
  `isFlash` char(1) DEFAULT NULL,
  `permissionLevel` char(1) DEFAULT NULL,
  `modelId` int(11) DEFAULT NULL,
  `nodeId` int(11) DEFAULT NULL,
  `urlRename` varchar(250) DEFAULT NULL,
  `titleImg` varchar(250) DEFAULT NULL,
  `costMoney` int(11) DEFAULT NULL,
  `staticDir` varchar(100) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_vj_contents_urlRename` (`urlRename`),
  KEY `IX_vj_contents_title` (`title`),
  KEY `IX_vj_contents_publishTime` (`publishTime`),
  KEY `IX_vj_contents_nodeId` (`nodeId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_contents` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_cost_point_history`;

CREATE TABLE `vj_cost_point_history` (
  `id` char(32) NOT NULL,
  `itemId` char(32) DEFAULT NULL,
  `costPoint` int(11) DEFAULT NULL,
  `memberId` char(32) DEFAULT NULL,
  `costTime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 ROW_FORMAT=DYNAMIC;


LOCK TABLES `vj_cost_point_history` WRITE;

UNLOCK TABLES;

DROP TABLE IF EXISTS `vj_dictionary`;

CREATE TABLE `vj_dictionary` (
  `id` int(11) NOT NULL,
  `name` varchar(250) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `language` tinyint(4) DEFAULT NULL,
  `modelId` int(11) DEFAULT NULL,
  `contentId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_dictionary` WRITE;

INSERT INTO `vj_dictionary` VALUES (35,'下载网址过滤','下载网址过滤',0,0,35),(34,'友情链接','友情链接',0,0,34),(33,'模板标签设置','模板标签设置',0,0,33),(32,'模板设置','模板设置',0,0,32),(31,'发送邮件','发送邮件',0,0,31),(30,'文件管理','文件管理',0,0,30),(29,'国际化管理','国际化管理',0,0,29),(28,'备份数据','备份数据',0,0,28),(27,'系统功能','系统功能',0,0,27),(26,'邮件设置','邮件设置',0,0,26),(25,'水印设置','水印设置',0,0,25),(24,'导航设置','导航设置',0,0,24),(23,'安全设置','安全设置',0,0,23),(22,'站点设置','站点设置',0,0,22),(21,'系统设置','系统设置',0,0,21),(20,'系统模型','系统模型',0,0,20),(19,'在线管理员','在线管理员',0,0,19),(18,'登陆日志','登陆日志',0,0,18),(17,'权限管理','权限管理',0,0,17),(16,'角色列表','角色列表',0,0,16),(15,'管理员列表','管理员列表',0,0,15),(14,'后台用户','后台用户',0,0,14),(13,'会员组','会员组',0,0,13),(12,'会员列表','会员列表',0,0,12),(11,'前台用户','前台用户',0,0,11),(10,'用户模型','用户模型',0,0,10),(9,'索引管理','索引管理',0,0,9),(8,'生成静态文件','生成静态文件',0,0,8),(7,'评论管理','评论管理',0,0,7),(6,'标签管理','标签管理',0,0,6),(5,'内容功能','内容功能',0,0,5),(4,'软件列表','软件列表',0,0,4),(3,'文章列表','文章列表',0,0,3),(2,'内容管理','内容管理',0,0,2),(1,'内容模型','内容模型',0,0,1),(36,'系统变量设置','系统变量设置',0,0,36),(37,'栏目管理','栏目管理',0,0,37),(38,'频道模型管理','频道模型管理',0,0,38),(39,'Content Model','Content Model',1,0,1),(40,'Content Management','Content Management',1,0,2),(41,'Article List','Article List',1,0,3),(42,'Software List','Software List',1,0,4),(43,'Content Function','Content Function',1,0,5),(44,'Tag Management','Tag Management',1,0,6),(45,'Comment Management','Comment Management',1,0,7),(46,'Generate Static File','Generate Static File',1,0,8),(47,'Index Management','Index Management',1,0,9),(48,'User Model','User Model',1,0,10),(49,'Front User','Front User',1,0,11),(50,'Member List','Member List',1,0,12),(51,'Member Group','Member Group',1,0,13),(52,'Background User','Background User',1,0,14),(53,'Manager List','Manager List',1,0,15),(54,'Roles List','Roles List',1,0,16),(55,'Permission Management','Permission Management',1,0,17),(56,'Login Log','Login Log',1,0,18),(57,'Online Manager','Online Manager',1,0,19),(58,'System Model','System Model',1,0,20),(59,'System Setting','System Setting',1,0,21),(60,'Site Setting','Site Setting',1,0,22),(61,'Security Setting','Security Setting',1,0,23),(62,'Navigation Setting','Navigation Setting',1,0,24),(63,'Watermark Setting','Watermark Setting',1,0,25),(64,'Mail Setting','Mail Setting',1,0,26),(65,'System Function','System Function',1,0,27),(66,'Backup Data','Backup Data',1,0,28),(67,'I18n management','International management',1,0,29),(68,'File Management','File Management',1,0,30),(69,'Send Email','Send Email',1,0,31),(70,'Template Setting','Template Setting',1,0,32),(71,'Template Tag Setting','Template Tag Setting',1,0,33),(72,'Link','Link',1,0,34),(73,'Download URL Filter','Download URL Filter',1,0,35),(74,'System Variable Setting','System Variable Setting',1,0,36),(75,'Node Management','Node Management',1,0,37),(76,'Channel Model Management','Channel Model Management',1,0,38),(77,'Vote Management','Vote Management',1,0,39),(78,'内容模型','内容模型',2,0,1),(79,'内容管理','内容管理',2,0,2),(80,'文章列表','文章列表',2,0,3),(81,'軟件列表','軟件列表',2,0,4),(82,'内容功能','内容功能',2,0,5),(83,'標籤管理','標籤管理',2,0,6),(84,'評論管理','評論管理',2,0,7),(85,'生成靜態文件','生成靜態文件',2,0,8),(86,'索引管理','索引管理',2,0,9),(87,'用户模型','用户模型',2,0,10),(88,'前台用户','前台用户',2,0,11),(89,'會員列表','會員列表',2,0,12),(90,'會員組','會員組',2,0,13),(91,'後台用戶','後台用戶',2,0,14),(92,'管理員列表','管理員列表',2,0,15),(93,'角色列表','角色列表',2,0,16),(94,'權限管理','權限管理',2,0,17),(95,'登錄日誌','登錄日誌',2,0,18),(96,'在線管理員','在線管理員',2,0,19),(97,'系統模型','系統模型',2,0,20),(98,'系統設置','系統設置',2,0,21),(99,'站點設置','站點設置',2,0,22),(100,'安全設置','安全設置',2,0,23),(101,'導航設置','導航設置',2,0,24),(102,'水印設置','水印設置',2,0,25),(103,'郵件設置','郵件設置',2,0,26),(104,'系統功能','系統功能',2,0,27),(105,'備份數據','備份數據',2,0,28),(106,'國際化管理','國際化管理',2,0,29),(107,'文件管理','文件管理',2,0,30),(108,'發送郵件','發送郵件',2,0,31),(109,'模板設置','模板設置',2,0,32),(110,'模板標籤設置','模板標籤設置',2,0,33),(111,'友情鏈接','友情鏈接',2,0,34),(112,'下載網址過濾','下載網址過濾',2,0,35),(113,'系統變量設置','系統變量設置',2,0,36),(114,'欄目管理','欄目管理',2,0,37),(115,'頻道模型管理','頻道模型管理',2,0,38),(116,'投票管理','投票管理',2,0,39),(117,'コンテンツモデル','コンテンツモデル',3,0,1),(118,'コンテンツ管理','コンテンツ管理',3,0,2),(119,'記事一覧','記事一覧',3,0,3),(120,'ソフトウェア一覧','ソフトウェア一覧',3,0,4),(121,'コンテンツ関数','コンテンツ関数',3,0,5),(122,'タグ管','タグ管',3,0,6),(123,'コメント管理','コメント管理',3,0,7),(124,'を生成する静的ファイル','を生成する静的ファイル',3,0,8),(125,'インデックス管理','インデックス管理',3,0,9),(126,'ユーザーモデル','ユーザーモデル',3,0,10),(127,'フロントユーザー','フロントユーザー',3,0,11),(128,'メンバーリスト','メンバーリスト',3,0,12),(129,'会員グループ','会員グループ',3,0,13),(130,'背景ユーザー','背景ユーザー',3,0,14),(131,'マネージャのリスト','マネージャのリスト',3,0,15),(132,'ロールのリスト','ロールのリスト',3,0,16),(133,'パーミッション管理','パーミッション管理',3,0,17),(134,'ログレコード','ログレコード',3,0,18),(135,'オンラインマネージャ','オンラインマネージャ',3,0,19),(136,'システムモデル','システムモデル',3,0,20),(137,'システム設定','システム設定',3,0,21),(138,'サイトの設定','サイトの設定',3,0,22),(139,'セキュリティの設定','セキュリティの設定',3,0,23),(140,'ナビゲーション設定','ナビゲーション設定',3,0,24),(141,'透かし設定','透かし設定',3,0,25),(142,'メール設定','メール設定',3,0,26),(143,'システム関数','システム関数',3,0,27),(144,'バックアップデータ','バックアップデータ',3,0,28),(145,'国際管理','国際管理',3,0,29),(146,'ファイル管理','ファイル管理',3,0,30),(147,'電子メールを送信する','電子メールを送信する',3,0,31),(148,'テンプレートの設定','テンプレートの設定',3,0,32),(149,'テンプレートタグ設定','テンプレートタグ設定',3,0,33),(150,'リンク','リンク',3,0,34),(151,'ダウンロードURLフィルタリング','ダウンロードURLフィルタリング',3,0,35),(152,'システム設定変数','システム設定変数',3,0,36),(153,'ノード管理','ノード管理',3,0,37),(154,'チャネルモデルの管理','チャネルモデルの管理',3,0,38),(155,'投票管理','投票管理',3,0,39),(156,'Модель содержимого','Модель содержимого',4,0,1),(157,'Управление контентом','Управление контентом',4,0,2),(158,'Список статей','Список статей',4,0,3),(159,'Список программного обеспечения','Список программного обеспечения',4,0,4),(160,'Содержание функции','Содержание функции',4,0,5),(161,'Управление метками','Управление метками',4,0,6),(162,'Комментарий управления','Комментарий управления',4,0,7),(163,'Создание статических файлов','Создание статических файлов',4,0,8),(164,'Индекс управления','Индекс управления',4,0,9),(165,'Пользователь модели','Пользователь модели',4,0,10),(166,'Отдел пользователя','Отдел пользователя',4,0,11),(167,'Пользователи','Пользователи',4,0,12),(168,'Группа','Группа',4,0,13),(169,'Справочная пользователя','Справочная пользователя',4,0,14),(170,'Менеджер Список','Менеджер Список',4,0,15),(171,'Роль Список','Роль Список',4,0,16),(172,'Разрешение управления','Разрешение управления',4,0,17),(173,'Войти Вход','Войти Вход',4,0,18),(174,'Интернет Manager','Интернет Manager',4,0,19),(175,'Модель системы','Модель системы',4,0,20),(176,'Настройки системы','Настройки системы',4,0,21),(177,'Параметры сайта','Параметры сайта',4,0,22),(178,'Настройки безопасности','Настройки безопасности',4,0,23),(179,'Навигация настройки','Навигация настройки',4,0,24),(180,'Водяной знак Настройка','Водяной знак Настройка',4,0,25),(181,'Настройки почты','Настройки почты',4,0,26),(182,'Система функции','Система функции',4,0,27),(183,'Резервное копирование данных','Резервное копирование данных',4,0,28),(184,'Международный менеджмент','Международный менеджмент',4,0,29),(185,'Управление файлами','Управление файлами',4,0,30),(186,'Отправить по электронной почте','Отправить по электронной почте',4,0,31),(187,'Параметры шаблона','Параметры шаблона',4,0,32),(188,'Теги набор шаблонов','Теги набор шаблонов',4,0,33),(189,'Ссылки','Ссылки',4,0,34),(190,'Скачать URL фильтра','Скачать URL фильтра',4,0,35),(191,'Системная переменная Настройка','Системная переменная Настройка',4,0,36),(192,'Узел управления','Узел управления',4,0,37),(193,'Источник Model Management','Источник Model Management',4,0,38),(194,'Проголосовать управления','Проголосовать управления',4,0,39),(195,'Contenido del modelo de','Contenido del modelo de',5,0,1),(196,'Gestión de Contenidos','Gestión de Contenidos',5,0,2),(197,'Lista de artículos','Lista de artículos',5,0,3),(198,'Lista de software','Lista de software',5,0,4),(199,'Contenido de la función','Contenido de la función',5,0,5),(200,'Tag Management','Tag Management',5,0,6),(201,'Comentario de gestión','Comentario de gestión',5,0,7),(202,'Generar archivos estáticos','Generar archivos estáticos',5,0,8),(203,'Índice de gestión','Índice de gestión',5,0,9),(204,'Usuario modelo','Usuario modelo',5,0,10),(205,'Frente usuario','Frente usuario',5,0,11),(206,'Miembros de la lista','Miembros de la lista',5,0,12),(207,'Miembro del Grupo','Miembro del Grupo',5,0,13),(208,'Antecedentes usuario','Antecedentes usuario',5,0,14),(209,'Administrador de listas','Administrador de listas',5,0,15),(210,'Lista de papel','Lista de papel',5,0,16),(211,'Permiso de gestión','Permiso de gestión',5,0,17),(212,'Ingresar Registrarse','Ingresar Registrarse',5,0,18),(213,'Online Manager','Online Manager',5,0,19),(214,'Modelo del sistema','Modelo del sistema',5,0,20),(215,'Configuración del sistema','Configuración del sistema',5,0,21),(216,'Configuración del sitio','Configuración del sitio',5,0,22),(217,'Configuración de seguridad','Configuración de seguridad',5,0,23),(218,'Ajustes de navegación','Ajustes de navegación',5,0,24),(219,'Marca de agua Marco','Marca de agua Marco',5,0,25),(220,'Configuración del correo','Configuración del correo',5,0,26),(221,'La función del sistema','La función del sistema',5,0,27),(222,'Copia de seguridad de datos','Copia de seguridad de datos',5,0,28),(223,'Gestión internacional','Gestión internacional',5,0,29),(224,'Administración de Archivo','Administración de Archivo',5,0,30),(225,'Enviar por e-mail','Enviar por e-mail',5,0,31),(226,'Configuración de plantilla','Configuración de plantilla',5,0,32),(227,'Juego Etiquetas de Plantilla','Juego Etiquetas de Plantilla',5,0,33),(228,'Enlaces','Enlaces',5,0,34),(229,'Descargar Filtro de URL','Descargar Filtro de URL',5,0,35),(230,'Variable del Sistema Marco','Variable del Sistema Marco',5,0,36),(231,'El nodo de administración','El nodo de administración',5,0,37),(232,'Canal Modelo de Gestión','Canal Modelo de Gestión',5,0,38),(233,'Votación de Gestión','Votación de Gestión',5,0,39),(234,'内容模型','内容模型',0,1,1),(235,'内容管理','内容管理',0,1,2),(236,'文章列表','文章列表',0,1,3),(237,'添加表单','添加表单',0,1,4),(238,'添加','添加',0,1,5),(239,'删除','删除',0,1,6),(240,'修改表单','修改表单',0,1,7),(241,'修改','修改',0,1,8),(242,'软件列表','软件列表',0,1,9),(243,'添加表单','添加表单',0,1,10),(244,'添加','添加',0,1,11),(245,'删除','删除',0,1,12),(246,'修改表单','修改表单',0,1,13),(247,'修改','修改',0,1,14),(248,'内容功能','内容功能',0,1,15),(249,'删除静态文件','删除静态文件',0,1,16),(250,'生成静态文件','生成静态文件',0,1,17),(251,'生成索引文件','生成索引文件',0,1,18),(252,'标签管理','标签管理',0,1,19),(253,'删除','删除',0,1,20),(254,'评论管理','评论管理',0,1,21),(255,'删除','删除',0,1,22),(256,'修改表单','修改表单',0,1,23),(257,'修改','修改',0,1,24),(258,'管理静态文件','管理静态文件',0,1,25),(259,'添加','添加',0,1,26),(260,'索引管理','索引管理',0,1,27),(261,'添加','添加',0,1,28),(262,'删除表单','删除表单',0,1,29),(263,'删除','删除',0,1,30),(264,'更新表单','更新表单',0,1,31),(265,'更新','更新',0,1,32),(266,'栏目管理','栏目管理',0,1,33),(267,'添加表单','添加表单',0,1,34),(268,'添加','添加',0,1,35),(269,'删除','删除',0,1,36),(270,'修改表单','修改表单',0,1,37),(271,'修改','修改',0,1,38),(272,'用户模型','用户模型',0,1,39),(273,'前台用户','前台用户',0,1,40),(274,'会员列表','会员列表',0,1,41),(275,'添加表单','添加表单',0,1,42),(276,'添加','添加',0,1,43),(277,'删除','删除',0,1,44),(278,'修改表单','修改表单',0,1,45),(279,'修改','修改',0,1,46),(280,'查看','查看',0,1,47),(281,'会员组','会员组',0,1,48),(282,'添加表单','添加表单',0,1,49),(283,'添加','添加',0,1,50),(284,'删除','删除',0,1,51),(285,'修改表单','修改表单',0,1,52),(286,'修改','修改',0,1,53),(287,'后台用户','后台用户',0,1,54),(288,'管理员列表','管理员列表',0,1,55),(289,'添加管理员表单','添加管理员表单',0,1,56),(290,'添加管理员','添加管理员',0,1,57),(291,'删除管理员','删除管理员',0,1,58),(292,'修改管理员表单','修改管理员表单',0,1,59),(293,'修改管理员','修改管理员',0,1,60),(294,'修改角色表单','修改角色表单',0,1,61),(295,'修改角色','修改角色',0,1,62),(296,'查看管理员','查看管理员',0,1,63),(297,'角色列表','角色列表',0,1,64),(298,'添加角色表单','添加角色表单',0,1,65),(299,'添加角色','添加角色',0,1,66),(300,'删除角色','删除角色',0,1,67),(301,'修改表单','修改表单',0,1,68),(302,'修改角色','修改角色',0,1,69),(303,'修改角色权限表单','修改角色权限表单',0,1,70),(304,'修改角色权限','修改角色权限',0,1,71),(305,'修改角色导航表单','修改角色导航表单',0,1,72),(306,'修改角色导航','修改角色导航',0,1,73),(307,'权限管理','权限管理',0,1,74),(308,'添加表单','添加表单',0,1,75),(309,'添加','添加',0,1,76),(310,'删除','删除',0,1,77),(311,'修改表单','修改表单',0,1,78),(312,'修改','修改',0,1,79),(313,'刷新','刷新',0,1,80),(314,'登陆日志','登陆日志',0,1,81),(315,'删除','删除',0,1,82),(316,'在线管理员','在线管理员',0,1,83),(317,'删除','删除',0,1,84),(318,'系统模型','系统模型',0,1,85),(319,'系统设置','系统设置',0,1,86),(320,'站点设置','站点设置',0,1,87),(321,'修改站点','修改站点',0,1,88),(322,'安全设置','安全设置',0,1,89),(323,'修改','修改',0,1,90),(324,'导航设置','导航设置',0,1,91),(325,'添加表单','添加表单',0,1,92),(326,'添加','添加',0,1,93),(327,'删除','删除',0,1,94),(328,'修改表单','修改表单',0,1,95),(329,'修改','修改',0,1,96),(330,'水印设置','水印设置',0,1,97),(331,'修改','修改',0,1,98),(332,'邮件设置','邮件设置',0,1,99),(333,'修改','修改',0,1,100),(334,'模板设置','模板设置',0,1,101),(335,'修改','修改',0,1,102),(336,'模板标签设置','模板标签设置',0,1,103),(337,'添加表单','添加表单',0,1,104),(338,'添加','添加',0,1,105),(339,'删除','删除',0,1,106),(340,'修改表单','修改表单',0,1,107),(341,'修改','修改',0,1,108),(342,'系统变量设置','系统变量设置',0,1,109),(343,'添加表单','添加表单',0,1,110),(344,'添加','添加',0,1,111),(345,'删除','删除',0,1,112),(346,'修改表单','修改表单',0,1,113),(347,'修改','修改',0,1,114),(348,'系统功能','系统功能',0,1,115),(349,'备份数据','备份数据',0,1,116),(350,'备份和还原','备份和还原',0,1,117),(351,'国际化管理','国际化管理',0,1,118),(352,'添加表单','添加表单',0,1,119),(353,'添加','添加',0,1,120),(354,'删除','删除',0,1,121),(355,'修改表单','修改表单',0,1,122),(356,'修改','修改',0,1,123),(357,'文件管理','文件管理',0,1,124),(358,'上传文件表单','上传文件表单',0,1,125),(359,'上传文件','上传文件',0,1,126),(360,'修改文件名表单','修改文件名表单',0,1,127),(361,'修改文件名','修改文件名',0,1,128),(362,'修改文件数据表单','修改文件数据表单',0,1,129),(363,'修改文件数据','修改文件数据',0,1,130),(364,'删除文件','删除文件',0,1,131),(365,'创建文件目录','创建文件目录',0,1,132),(366,'发送邮件','发送邮件',0,1,133),(367,'发送','发送',0,1,134),(368,'友情链接','友情链接',0,1,135),(369,'添加表单','添加表单',0,1,136),(370,'添加','添加',0,1,137),(371,'删除','删除',0,1,138),(372,'修改表单','修改表单',0,1,139),(373,'修改','修改',0,1,140),(374,'下载网址过滤','下载网址过滤',0,1,141),(375,'添加表单','添加表单',0,1,142),(376,'添加','添加',0,1,143),(377,'删除','删除',0,1,144),(378,'修改表单','修改表单',0,1,145),(379,'修改','修改',0,1,146),(380,'频道模型管理','频道模型管理',0,1,147),(381,'添加表单','添加表单',0,1,148),(382,'添加','添加',0,1,149),(383,'删除','删除',0,1,150),(384,'修改表单','修改表单',0,1,151),(385,'修改','修改',0,1,152),(386,'投票管理','投票管理',0,1,153),(387,'添加表单','添加表单',0,1,154),(388,'添加','添加',0,1,155),(389,'删除','删除',0,1,156),(390,'修改表单','修改表单',0,1,157),(391,'修改','修改',0,1,158),(392,'后台首页','后台首页',0,1,159),(393,'Content Model','Content Model',1,1,1),(394,'Content Management','Content Management',1,1,2),(395,'Article list','Article list',1,1,3),(396,'Add Form','Add Form',1,1,4),(397,'Add','Add',1,1,5),(398,'Delete','Delete',1,1,6),(399,'Modified Form','Modified Form',1,1,7),(400,'Modify','Modify',1,1,8),(401,'Software List','Software List',1,1,9),(402,'Add Form','Add Form',1,1,10),(403,'Add','Add',1,1,11),(404,'Delete','Delete',1,1,12),(405,'Modified Form','Modified Form',1,1,13),(406,'Modify','Modify',1,1,14),(407,'Content Function','Content Function',1,1,15),(408,'Delete Static File','Delete Static File',1,1,16),(409,'Generate Static File','Generate Static File',1,1,17),(410,'Generate Index File','Generate Index File',1,1,18),(411,'Tag Management','Tag Management',1,1,19),(412,'Delete','Delete',1,1,20),(413,'Comment Management','Comment Management',1,1,21),(414,'Delete','Delete',1,1,22),(415,'Modified Form','Modified Form',1,1,23),(416,'Modify','Modify',1,1,24),(417,'Management Static File','Management Static File',1,1,25),(418,'Add','Add',1,1,26),(419,'Index Management','Index Management',1,1,27),(420,'Add','Add',1,1,28),(421,'Delete Form','Delete Form',1,1,29),(422,'Delete','Delete',1,1,30),(423,'Update Form','Update Form',1,1,31),(424,'Update','Update',1,1,32),(425,'Node Management','Node Management',1,1,33),(426,'Add Form','Add Form',1,1,34),(427,'Add','Add',1,1,35),(428,'Delete','Delete',1,1,36),(429,'Modified Form','Modified Form',1,1,37),(430,'Modify','Modify',1,1,38),(431,'User Model','User Model',1,1,39),(432,'Front Users','Front Users',1,1,40),(433,'Members List','Members List',1,1,41),(434,'Add Form','Add Form',1,1,42),(435,'Add','Add',1,1,43),(436,'Delete','Delete',1,1,44),(437,'Modified Form','Modified Form',1,1,45),(438,'Modify','Modify',1,1,46),(439,'View','View',1,1,47),(440,'Member Group','Member Group',1,1,48),(441,'Add Form','Add Form',1,1,49),(442,'Add','Add',1,1,50),(443,'Delete','Delete',1,1,51),(444,'Modified Form','Modified Form',1,1,52),(445,'Modify','Modify',1,1,53),(446,'Background User','Background User',1,1,54),(447,'Manager List','Manager List',1,1,55),(448,'Add Administrator Form','Add Administrator Form',1,1,56),(449,'Add Administrator','Add Administrator',1,1,57),(450,'Remove administrator','Remove administrator',1,1,58),(451,'Change administrator Form','Change administrator Form',1,1,59),(452,'Change administrator','Change administrator',1,1,60),(453,'Modify Role Form','Modify Role Form',1,1,61),(454,'Modify Role','Modify Role',1,1,62),(455,'View Manager','View Manager',1,1,63),(456,'Role List','Role List',1,1,64),(457,'Add Role Form','Add Role Form',1,1,65),(458,'Add Role','Add Role',1,1,66),(459,'Delete Role','Delete Role',1,1,67),(460,'Modified Form','Modified Form',1,1,68),(461,'Modify the role','Modify the role',1,1,69),(462,'Modify Role Permission Form','Modify Role Permission Form',1,1,70),(463,'Modify Role Permission','Modify Role Permission',1,1,71),(464,'Modify Role Navigation Form','Modify Role Navigation Form',1,1,72),(465,'Modify Role Navigation','Modify Role Navigation',1,1,73),(466,'Permission Management','Permission Management',1,1,74),(467,'Add Form','Add Form',1,1,75),(468,'Add','Add',1,1,76),(469,'Delete','Delete',1,1,77),(470,'Modified Form','Modified Form',1,1,78),(471,'Modify','Modify',1,1,79),(472,'Refresh','Refresh',1,1,80),(473,'Login Log','Login Log',1,1,81),(474,'Delete','Delete',1,1,82),(475,'Online Manager','Online Manager',1,1,83),(476,'Delete','Delete',1,1,84),(477,'System Model','System Model',1,1,85),(478,'System Setting','System Setting',1,1,86),(479,'Site Setting','Site Setting',1,1,87),(480,'Modify Site','Modify Site',1,1,88),(481,'Security Setting','Security Setting',1,1,89),(482,'Modify','Modify',1,1,90),(483,'Navigation settings','Navigation settings',1,1,91),(484,'Add Form','Add Form',1,1,92),(485,'Add','Add',1,1,93),(486,'Delete','Delete',1,1,94),(487,'Modified Form','Modified Form',1,1,95),(488,'Modify','Modify',1,1,96),(489,'Watermark','Watermark',1,1,97),(490,'Modify','Modify',1,1,98),(491,'Mail Setting','Mail Setting',1,1,99),(492,'Modify','Modify',1,1,100),(493,'Template Setting','Template Setting',1,1,101),(494,'Modify','Modify',1,1,102),(495,'Template Tag Setting','Template Tag Setting',1,1,103),(496,'Add Form','Add Form',1,1,104),(497,'Add','Add',1,1,105),(498,'Delete','Delete',1,1,106),(499,'Modified Form','Modified Form',1,1,107),(500,'Modify','Modify',1,1,108),(501,'System Variable Setting','System Variable Setting',1,1,109),(502,'Add Form','Add Form',1,1,110),(503,'Add','Add',1,1,111),(504,'Delete','Delete',1,1,112),(505,'Modified Form','Modified Form',1,1,113),(506,'Modify','Modify',1,1,114),(507,'System function','System function',1,1,115),(508,'Backup Data','Backup Data',1,1,116),(509,'Backup And Restore','Backup And Restore',1,1,117),(510,'International management','International management',1,1,118),(511,'Add Form','Add Form',1,1,119),(512,'Add','Add',1,1,120),(513,'Delete','Delete',1,1,121),(514,'Modified Form','Modified Form',1,1,122),(515,'Modify','Modify',1,1,123),(516,'Document Management','Document Management',1,1,124),(517,'Upload Form','Upload Form',1,1,125),(518,'Upload File','Upload File',1,1,126),(519,'Modify File Name Form','Modify File Name Form',1,1,127),(520,'Modify File Name','Modify File Name',1,1,128),(521,'Modify File Data Form','Modify File Data Form',1,1,129),(522,'Modify File Data','Modify File Data',1,1,130),(523,'Delete File','Delete File',1,1,131),(524,'Create File Directory','Create File Directory',1,1,132),(525,'Send e-mail','Send e-mail',1,1,133),(526,'Send','Send',1,1,134),(527,'Link','Link',1,1,135),(528,'Add Form','Add Form',1,1,136),(529,'Add','Add',1,1,137),(530,'Delete','Delete',1,1,138),(531,'Modified Form','Modified Form',1,1,139),(532,'Modify','Modify',1,1,140),(533,'Download URL filter','Download URL filter',1,1,141),(534,'Add Form','Add Form',1,1,142),(535,'Add','Add',1,1,143),(536,'Delete','Delete',1,1,144),(537,'Modified Form','Modified Form',1,1,145),(538,'Modify','Modify',1,1,146),(539,'Channel Model Management','Channel Model Management',1,1,147),(540,'Add Form','Add Form',1,1,148),(541,'Add','Add',1,1,149),(542,'Delete','Delete',1,1,150),(543,'Modified Form','Modified Form',1,1,151),(544,'Modify','Modify',1,1,152),(545,'Vote Management','Vote Management',1,1,153),(546,'Add Form','Add Form',1,1,154),(547,'Add','Add',1,1,155),(548,'Delete','Delete',1,1,156),(549,'Modified Form','Modified Form',1,1,157),(550,'Modify','Modify',1,1,158),(551,'Background Home','Background Home',1,1,159),(552,'﻿內容模型','﻿內容模型',2,1,1),(553,'內容管理','內容管理',2,1,2),(554,'文章列表','文章列表',2,1,3),(555,'添加表單','添加表單',2,1,4),(556,'添加','添加',2,1,5),(557,'刪除','刪除',2,1,6),(558,'修改表單','修改表單',2,1,7),(559,'修改','修改',2,1,8),(560,'軟件列表','軟件列表',2,1,9),(561,'添加表單','添加表單',2,1,10),(562,'添加','添加',2,1,11),(563,'刪除','刪除',2,1,12),(564,'修改表單','修改表單',2,1,13),(565,'修改','修改',2,1,14),(566,'內容功能','內容功能',2,1,15),(567,'刪除靜態文件','刪除靜態文件',2,1,16),(568,'生成靜態文件','生成靜態文件',2,1,17),(569,'生成索引文件','生成索引文件',2,1,18),(570,'標籤管理','標籤管理',2,1,19),(571,'刪除','刪除',2,1,20),(572,'評論管理','評論管理',2,1,21),(573,'刪除','刪除',2,1,22),(574,'修改表單','修改表單',2,1,23),(575,'修改','修改',2,1,24),(576,'管理靜態文件','管理靜態文件',2,1,25),(577,'添加','添加',2,1,26),(578,'索引管理','索引管理',2,1,27),(579,'添加','添加',2,1,28),(580,'刪除表單','刪除表單',2,1,29),(581,'刪除','刪除',2,1,30),(582,'更新表單','更新表單',2,1,31),(583,'更新','更新',2,1,32),(584,'欄目管理','欄目管理',2,1,33),(585,'添加表單','添加表單',2,1,34),(586,'添加','添加',2,1,35),(587,'刪除','刪除',2,1,36),(588,'修改表單','修改表單',2,1,37),(589,'修改','修改',2,1,38),(590,'用戶模型','用戶模型',2,1,39),(591,'前台用戶','前台用戶',2,1,40),(592,'會員列表','會員列表',2,1,41),(593,'添加表單','添加表單',2,1,42),(594,'添加','添加',2,1,43),(595,'刪除','刪除',2,1,44),(596,'修改表單','修改表單',2,1,45),(597,'修改','修改',2,1,46),(598,'查看','查看',2,1,47),(599,'會員組','會員組',2,1,48),(600,'添加表單','添加表單',2,1,49),(601,'添加','添加',2,1,50),(602,'刪除','刪除',2,1,51),(603,'修改表單','修改表單',2,1,52),(604,'修改','修改',2,1,53),(605,'後台用戶','後台用戶',2,1,54),(606,'管理員列表','管理員列表',2,1,55),(607,'添加管理員表單','添加管理員表單',2,1,56),(608,'添加管理員','添加管理員',2,1,57),(609,'刪除管理員','刪除管理員',2,1,58),(610,'修改管理員表單','修改管理員表單',2,1,59),(611,'修改管理員','修改管理員',2,1,60),(612,'修改角色表單','修改角色表單',2,1,61),(613,'修改角色','修改角色',2,1,62),(614,'查看管理員','查看管理員',2,1,63),(615,'角色列表','角色列表',2,1,64),(616,'添加角色表單','添加角色表單',2,1,65),(617,'添加角色','添加角色',2,1,66),(618,'刪除角色','刪除角色',2,1,67),(619,'修改表單','修改表單',2,1,68),(620,'修改角色','修改角色',2,1,69),(621,'修改角色權限表單','修改角色權限表單',2,1,70),(622,'修改角色權限','修改角色權限',2,1,71),(623,'修改角色導航表單','修改角色導航表單',2,1,72),(624,'修改角色導航','修改角色導航',2,1,73),(625,'權限管理','權限管理',2,1,74),(626,'添加表單','添加表單',2,1,75),(627,'添加','添加',2,1,76),(628,'刪除','刪除',2,1,77),(629,'修改表單','修改表單',2,1,78),(630,'修改','修改',2,1,79),(631,'刷新','刷新',2,1,80),(632,'登陸日誌','登陸日誌',2,1,81),(633,'刪除','刪除',2,1,82),(634,'在線管理員','在線管理員',2,1,83),(635,'刪除','刪除',2,1,84),(636,'系統模型','系統模型',2,1,85),(637,'系統設置','系統設置',2,1,86),(638,'站點設置','站點設置',2,1,87),(639,'修改站點','修改站點',2,1,88),(640,'安全設置','安全設置',2,1,89),(641,'修改','修改',2,1,90),(642,'導航設置','導航設置',2,1,91),(643,'添加表單','添加表單',2,1,92),(644,'添加','添加',2,1,93),(645,'刪除','刪除',2,1,94),(646,'修改表單','修改表單',2,1,95),(647,'修改','修改',2,1,96),(648,'水印設置','水印設置',2,1,97),(649,'修改','修改',2,1,98),(650,'郵件設置','郵件設置',2,1,99),(651,'修改','修改',2,1,100),(652,'模板設置','模板設置',2,1,101),(653,'修改','修改',2,1,102),(654,'模板標籤設置','模板標籤設置',2,1,103),(655,'添加表單','添加表單',2,1,104),(656,'添加','添加',2,1,105),(657,'刪除','刪除',2,1,106),(658,'修改表單','修改表單',2,1,107),(659,'修改','修改',2,1,108),(660,'系統變量設置','系統變量設置',2,1,109),(661,'添加表單','添加表單',2,1,110),(662,'添加','添加',2,1,111),(663,'刪除','刪除',2,1,112),(664,'修改表單','修改表單',2,1,113),(665,'修改','修改',2,1,114),(666,'系統功能','系統功能',2,1,115),(667,'備份數據','備份數據',2,1,116),(668,'備份和還原','備份和還原',2,1,117),(669,'國際化管理','國際化管理',2,1,118),(670,'添加表單','添加表單',2,1,119),(671,'添加','添加',2,1,120),(672,'刪除','刪除',2,1,121),(673,'修改表單','修改表單',2,1,122),(674,'修改','修改',2,1,123),(675,'文件管理','文件管理',2,1,124),(676,'上傳文件表單','上傳文件表單',2,1,125),(677,'上傳文件','上傳文件',2,1,126),(678,'修改文件名表單','修改文件名表單',2,1,127),(679,'修改文件名','修改文件名',2,1,128),(680,'修改文件數據表單','修改文件數據表單',2,1,129),(681,'修改文件數據','修改文件數據',2,1,130),(682,'刪除文件','刪除文件',2,1,131),(683,'創建文件目錄','創建文件目錄',2,1,132),(684,'發送郵件','發送郵件',2,1,133),(685,'發送','發送',2,1,134),(686,'友情鏈接','友情鏈接',2,1,135),(687,'添加表單','添加表單',2,1,136),(688,'添加','添加',2,1,137),(689,'刪除','刪除',2,1,138),(690,'修改表單','修改表單',2,1,139),(691,'修改','修改',2,1,140),(692,'下載網址過濾','下載網址過濾',2,1,141),(693,'添加表單','添加表單',2,1,142),(694,'添加','添加',2,1,143),(695,'刪除','刪除',2,1,144),(696,'修改表單','修改表單',2,1,145),(697,'修改','修改',2,1,146),(698,'頻道模型管理','頻道模型管理',2,1,147),(699,'添加表單','添加表單',2,1,148),(700,'添加','添加',2,1,149),(701,'刪除','刪除',2,1,150),(702,'修改表單','修改表單',2,1,151),(703,'修改','修改',2,1,152),(704,'投票管理','投票管理',2,1,153),(705,'添加表單','添加表單',2,1,154),(706,'添加','添加',2,1,155),(707,'刪除','刪除',2,1,156),(708,'修改表單','修改表單',2,1,157),(709,'修改','修改',2,1,158),(710,'後台首頁','後台首頁',2,1,159),(711,'﻿コンテンツモデル','﻿コンテンツモデル',3,1,1),(712,'コンテンツ管理','コンテンツ管理',3,1,2),(713,'記事一覧','記事一覧',3,1,3),(714,'形成するに追加','形成するに追加',3,1,4),(715,'追加','追加',3,1,5),(716,'削除','削除',3,1,6),(717,'変更フォーム','変更フォーム',3,1,7),(718,'変更','変更',3,1,8),(719,'ソフトウェア一覧','ソフトウェア一覧',3,1,9),(720,'形成するに追加','形成するに追加',3,1,10),(721,'追加','追加',3,1,11),(722,'削除','削除',3,1,12),(723,'変更フォーム','変更フォーム',3,1,13),(724,'変更','変更',3,1,14),(725,'コンテンツ関数','コンテンツ関数',3,1,15),(726,'削除する静的ファイル','削除する静的ファイル',3,1,16),(727,'を生成する静的ファイル','を生成する静的ファイル',3,1,17),(728,'を生成するインデックスファイル','を生成するインデックスファイル',3,1,18),(729,'タグ管理','タグ管理',3,1,19),(730,'削除','削除',3,1,20),(731,'コメント管理','コメント管理',3,1,21),(732,'削除','削除',3,1,22),(733,'変更フォーム','変更フォーム',3,1,23),(734,'変更','変更',3,1,24),(735,'管理静的ファイル','管理静的ファイル',3,1,25),(736,'追加','追加',3,1,26),(737,'インデックス管理','インデックス管理',3,1,27),(738,'追加','追加',3,1,28),(739,'削除フォーム','削除フォーム',3,1,29),(740,'削除','削除',3,1,30),(741,'更新フォーム','更新フォーム',3,1,31),(742,'更新','更新',3,1,32),(743,'ローカル管理','ローカル管理',3,1,33),(744,'形成するに追加','形成するに追加',3,1,34),(745,'追加','追加',3,1,35),(746,'削除','削除',3,1,36),(747,'変更フォーム','変更フォーム',3,1,37),(748,'変更','変更',3,1,38),(749,'ユーザーモデル','ユーザーモデル',3,1,39),(750,'フロントユーザー','フロントユーザー',3,1,40),(751,'メンバーリスト','メンバーリスト',3,1,41),(752,'形成するに追加','形成するに追加',3,1,42),(753,'追加','追加',3,1,43),(754,'削除','削除',3,1,44),(755,'変更フォーム','変更フォーム',3,1,45),(756,'変更','変更',3,1,46),(757,'友達','友達',3,1,47),(758,'会員グループ','会員グループ',3,1,48),(759,'形成するに追加','形成するに追加',3,1,49),(760,'追加','追加',3,1,50),(761,'削除','削除',3,1,51),(762,'変更フォーム','変更フォーム',3,1,52),(763,'変更','変更',3,1,53),(764,'背景ユーザー','背景ユーザー',3,1,54),(765,'マネージャのリスト','マネージャのリスト',3,1,55),(766,'管理者の追加フォーム','管理者の追加フォーム',3,1,56),(767,'管理者の追加','管理者の追加',3,1,57),(768,'管理者を削除する','管理者を削除する',3,1,58),(769,'管理フォームを変更します。','管理フォームを変更します。',3,1,59),(770,'管理者を変更する','管理者を変更する',3,1,60),(771,'フォームの変更の役割','フォームの変更の役割',3,1,61),(772,'変更の役割','変更の役割',3,1,62),(773,'ビューマネージャ','ビューマネージャ',3,1,63),(774,'ロールのリスト','ロールのリスト',3,1,64),(775,'役割の追加フォーム','役割の追加フォーム',3,1,65),(776,'役割の追加','役割の追加',3,1,66),(777,'削除する役割','削除する役割',3,1,67),(778,'変更フォーム','変更フォーム',3,1,68),(779,'変更の役割','変更の役割',3,1,69),(780,'変更ロール権限が形成さ','変更ロール権限が形成さ',3,1,70),(781,'変更ロール権限','変更ロール権限',3,1,71),(782,'ナビゲーションフォームの変更の役割','ナビゲーションフォームの変更の役割',3,1,72),(783,'ナビゲーションの変更の役割','ナビゲーションの変更の役割',3,1,73),(784,'パーミッション管理','パーミッション管理',3,1,74),(785,'形成するに追加','形成するに追加',3,1,75),(786,'追加','追加',3,1,76),(787,'削除','削除',3,1,77),(788,'変更フォーム','変更フォーム',3,1,78),(789,'変更','変更',3,1,79),(790,'リフレッシュ','リフレッシュ',3,1,80),(791,'ログログ','ログログ',3,1,81),(792,'削除','削除',3,1,82),(793,'オンラインマネージャ','オンラインマネージャ',3,1,83),(794,'削除','削除',3,1,84),(795,'システムモデル','システムモデル',3,1,85),(796,'システム設定','システム設定',3,1,86),(797,'サイトの設定','サイトの設定',3,1,87),(798,'変更サイト','変更サイト',3,1,88),(799,'セキュリティの設定','セキュリティの設定',3,1,89),(800,'変更','変更',3,1,90),(801,'ナビゲーション設定','ナビゲーション設定',3,1,91),(802,'形成するに追加','形成するに追加',3,1,92),(803,'追加','追加',3,1,93),(804,'削除','削除',3,1,94),(805,'変更フォーム','変更フォーム',3,1,95),(806,'変更','変更',3,1,96),(807,'透かし','透かし',3,1,97),(808,'変更','変更',3,1,98),(809,'メール設定','メール設定',3,1,99),(810,'変更','変更',3,1,100),(811,'テンプレートの設定','テンプレートの設定',3,1,101),(812,'変更','変更',3,1,102),(813,'設定テンプレートタグ','設定テンプレートタグ',3,1,103),(814,'形成するに追加','形成するに追加',3,1,104),(815,'追加','追加',3,1,105),(816,'削除','削除',3,1,106),(817,'変更フォーム','変更フォーム',3,1,107),(818,'変更','変更',3,1,108),(819,'システム変数が設定されている','システム変数が設定されている',3,1,109),(820,'形成するに追加','形成するに追加',3,1,110),(821,'追加','追加',3,1,111),(822,'削除','削除',3,1,112),(823,'変更フォーム','変更フォーム',3,1,113),(824,'変更','変更',3,1,114),(825,'システム関数','システム関数',3,1,115),(826,'バックアップデータ','バックアップデータ',3,1,116),(827,'バックアップと復元','バックアップと復元',3,1,117),(828,'国際管理','国際管理',3,1,118),(829,'形成するに追加','形成するに追加',3,1,119),(830,'追加','追加',3,1,120),(831,'削除','削除',3,1,121),(832,'変更フォーム','変更フォーム',3,1,122),(833,'変更','変更',3,1,123),(834,'ドキュメント管理','ドキュメント管理',3,1,124),(835,'アップロードフォーム','アップロードフォーム',3,1,125),(836,'ファイルをアップロード','ファイルをアップロード',3,1,126),(837,'修正ファイル名の形式','修正ファイル名の形式',3,1,127),(838,'修正ファイル名','修正ファイル名',3,1,128),(839,'修正ファイルのデータが形成さ','修正ファイルのデータが形成さ',3,1,129),(840,'ファイルを変更しデータ','ファイルを変更しデータ',3,1,130),(841,'ファイルを削除する','ファイルを削除する',3,1,131),(842,'ファイルのディレクトリを作成します。','ファイルのディレクトリを作成します。',3,1,132),(843,'電子メールを送信する','電子メールを送信する',3,1,133),(844,'送信','送信',3,1,134),(845,'リンク','リンク',3,1,135),(846,'形成するに追加','形成するに追加',3,1,136),(847,'追加','追加',3,1,137),(848,'削除','削除',3,1,138),(849,'変更フォーム','変更フォーム',3,1,139),(850,'変更','変更',3,1,140),(851,'ダウンロードURLフィルタリング','ダウンロードURLフィルタリング',3,1,141),(852,'形成するに追加','形成するに追加',3,1,142),(853,'追加','追加',3,1,143),(854,'削除','削除',3,1,144),(855,'変更フォーム','変更フォーム',3,1,145),(856,'変更','変更',3,1,146),(857,'チャネルモデルの管理','チャネルモデルの管理',3,1,147),(858,'形成するに追加','形成するに追加',3,1,148),(859,'追加','追加',3,1,149),(860,'削除','削除',3,1,150),(861,'変更フォーム','変更フォーム',3,1,151),(862,'変更','変更',3,1,152),(863,'投票管理','投票管理',3,1,153),(864,'形成するに追加','形成するに追加',3,1,154),(865,'追加','追加',3,1,155),(866,'削除','削除',3,1,156),(867,'変更フォーム','変更フォーム',3,1,157),(868,'変更','変更',3,1,158),(869,'背景ホーム','背景ホーム',3,1,159),(870,'﻿Модель содержимого','﻿Модель содержимого',4,1,1),(871,'Управление контентом','Управление контентом',4,1,2),(872,'Список статей','Список статей',4,1,3),(873,'Добавить форме','Добавить форме',4,1,4),(874,'Добавить','Добавить',4,1,5),(875,'Удалить','Удалить',4,1,6),(876,'Измененном виде','Измененном виде',4,1,7),(877,'Изменить','Изменить',4,1,8),(878,'Список программного обеспечения','Список программного обеспечения',4,1,9),(879,'Добавить форме','Добавить форме',4,1,10),(880,'Добавить','Добавить',4,1,11),(881,'Удалить','Удалить',4,1,12),(882,'Измененном виде','Измененном виде',4,1,13),(883,'Изменить','Изменить',4,1,14),(884,'Содержание особенности','Содержание особенности',4,1,15),(885,'Удалить статических файлов','Удалить статических файлов',4,1,16),(886,'Создание статических файлов','Создание статических файлов',4,1,17),(887,'Создание индексных файлов','Создание индексных файлов',4,1,18),(888,'Управление метками','Управление метками',4,1,19),(889,'Удалить','Удалить',4,1,20),(890,'Комментарий управления','Комментарий управления',4,1,21),(891,'Удалить','Удалить',4,1,22),(892,'Измененном виде','Измененном виде',4,1,23),(893,'Изменить','Изменить',4,1,24),(894,'Управление статического файла','Управление статического файла',4,1,25),(895,'Добавить','Добавить',4,1,26),(896,'Индекс управления','Индекс управления',4,1,27),(897,'Добавить','Добавить',4,1,28),(898,'Удалить вид','Удалить вид',4,1,29),(899,'Удалить','Удалить',4,1,30),(900,'Обновление формы','Обновление формы',4,1,31),(901,'Обновление','Обновление',4,1,32),(902,'Местное управление','Местное управление',4,1,33),(903,'Добавить форме','Добавить форме',4,1,34),(904,'Добавить','Добавить',4,1,35),(905,'Удалить','Удалить',4,1,36),(906,'Измененном виде','Измененном виде',4,1,37),(907,'Изменить','Изменить',4,1,38),(908,'Пользователь модели','Пользователь модели',4,1,39),(909,'Отдел пользователя','Отдел пользователя',4,1,40),(910,'Пользователи','Пользователи',4,1,41),(911,'Добавить форме','Добавить форме',4,1,42),(912,'Добавить','Добавить',4,1,43),(913,'Удалить','Удалить',4,1,44),(914,'Измененном виде','Измененном виде',4,1,45),(915,'Изменить','Изменить',4,1,46),(916,'Открыть','Открыть',4,1,47),(917,'Группа','Группа',4,1,48),(918,'Добавить форме','Добавить форме',4,1,49),(919,'Добавить','Добавить',4,1,50),(920,'Удалить','Удалить',4,1,51),(921,'Измененном виде','Измененном виде',4,1,52),(922,'Изменить','Изменить',4,1,53),(923,'Справочная пользователя','Справочная пользователя',4,1,54),(924,'Менеджер Список','Менеджер Список',4,1,55),(925,'Добавить администратора форме','Добавить администратора форме',4,1,56),(926,'Добавить администратора','Добавить администратора',4,1,57),(927,'Удалить администратора','Удалить администратора',4,1,58),(928,'Изменение формы администратора','Изменение формы администратора',4,1,59),(929,'Изменение администратора','Изменение администратора',4,1,60),(930,'Изменить роль формы','Изменить роль формы',4,1,61),(931,'Изменить роль','Изменить роль',4,1,62),(932,'View Manager','View Manager',4,1,63),(933,'Список ролей','Список ролей',4,1,64),(934,'Добавить Роль формы','Добавить Роль формы',4,1,65),(935,'Добавить роль','Добавить роль',4,1,66),(936,'Удалить роль','Удалить роль',4,1,67),(937,'Измененном виде','Измененном виде',4,1,68),(938,'Изменить роль','Изменить роль',4,1,69),(939,'Изменить разрешения роль формы','Изменить разрешения роль формы',4,1,70),(940,'разрешения Изменить роль','разрешения Изменить роль',4,1,71),(941,'Изменить роль навигации форме','Изменить роль навигации форме',4,1,72),(942,'Изменить роль навигации','Изменить роль навигации',4,1,73),(943,'Управление правами','Управление правами',4,1,74),(944,'Добавить форме','Добавить форме',4,1,75),(945,'Добавить','Добавить',4,1,76),(946,'Удалить','Удалить',4,1,77),(947,'Измененном виде','Измененном виде',4,1,78),(948,'Изменить','Изменить',4,1,79),(949,'Обновить','Обновить',4,1,80),(950,'Вход Вход','Вход Вход',4,1,81),(951,'Удалить','Удалить',4,1,82),(952,'Интернет Manager','Интернет Manager',4,1,83),(953,'Удалить','Удалить',4,1,84),(954,'Модель системы','Модель системы',4,1,85),(955,'Настройки системы','Настройки системы',4,1,86),(956,'Параметры сайта','Параметры сайта',4,1,87),(957,'Изменить сайт','Изменить сайт',4,1,88),(958,'Настройки безопасности','Настройки безопасности',4,1,89),(959,'Изменить','Изменить',4,1,90),(960,'Навигация настройки','Навигация настройки',4,1,91),(961,'Добавить форме','Добавить форме',4,1,92),(962,'Добавить','Добавить',4,1,93),(963,'Удалить','Удалить',4,1,94),(964,'Измененном виде','Измененном виде',4,1,95),(965,'Изменить','Изменить',4,1,96),(966,'Водяной знак','Водяной знак',4,1,97),(967,'Изменить','Изменить',4,1,98),(968,'Настройки почты','Настройки почты',4,1,99),(969,'Изменить','Изменить',4,1,100),(970,'Параметры шаблона','Параметры шаблона',4,1,101),(971,'Изменить','Изменить',4,1,102),(972,'Теги набор шаблонов','Теги набор шаблонов',4,1,103),(973,'Добавить форме','Добавить форме',4,1,104),(974,'Добавить','Добавить',4,1,105),(975,'Удалить','Удалить',4,1,106),(976,'Измененном виде','Измененном виде',4,1,107),(977,'Изменить','Изменить',4,1,108),(978,'Система переменная установлена','Система переменная установлена',4,1,109),(979,'Добавить форме','Добавить форме',4,1,110),(980,'Добавить','Добавить',4,1,111),(981,'Удалить','Удалить',4,1,112),(982,'Измененном виде','Измененном виде',4,1,113),(983,'Изменить','Изменить',4,1,114),(984,'Система функции','Система функции',4,1,115),(985,'Резервное копирование данных','Резервное копирование данных',4,1,116),(986,'Резервное копирование и восстановление','Резервное копирование и восстановление',4,1,117),(987,'Международный менеджмент','Международный менеджмент',4,1,118),(988,'Добавить форме','Добавить форме',4,1,119),(989,'Добавить','Добавить',4,1,120),(990,'Удалить','Удалить',4,1,121),(991,'Измененном виде','Измененном виде',4,1,122),(992,'Изменить','Изменить',4,1,123),(993,'Управление документами','Управление документами',4,1,124),(994,'Форма для закачки','Форма для закачки',4,1,125),(995,'Загрузить файл','Загрузить файл',4,1,126),(996,'Изменить форму названия файла','Изменить форму названия файла',4,1,127),(997,'Изменить имя файла','Изменить имя файла',4,1,128),(998,'Внесите изменения в файл данных формы','Внесите изменения в файл данных формы',4,1,129),(999,'Изменить файл данных','Изменить файл данных',4,1,130),(1000,'Удаление файлов','Удаление файлов',4,1,131),(1001,'Создайте файл каталога','Создайте файл каталога',4,1,132),(1002,'Отправить по электронной почте','Отправить по электронной почте',4,1,133),(1003,'Отправить','Отправить',4,1,134),(1004,'Ссылки','Ссылки',4,1,135),(1005,'Добавить форме','Добавить форме',4,1,136),(1006,'Добавить','Добавить',4,1,137),(1007,'Удалить','Удалить',4,1,138),(1008,'Измененном виде','Измененном виде',4,1,139),(1009,'Изменить','Изменить',4,1,140),(1010,'Скачать URL фильтра','Скачать URL фильтра',4,1,141),(1011,'Добавить форме','Добавить форме',4,1,142),(1012,'Добавить','Добавить',4,1,143),(1013,'Удалить','Удалить',4,1,144),(1014,'Измененном виде','Измененном виде',4,1,145),(1015,'Изменить','Изменить',4,1,146),(1016,'Источник Model Management','Источник Model Management',4,1,147),(1017,'Добавить форме','Добавить форме',4,1,148),(1018,'Добавить','Добавить',4,1,149),(1019,'Удалить','Удалить',4,1,150),(1020,'Измененном виде','Измененном виде',4,1,151),(1021,'Изменить','Изменить',4,1,152),(1022,'Проголосовать управления','Проголосовать управления',4,1,153),(1023,'Добавить форме','Добавить форме',4,1,154),(1024,'Добавить','Добавить',4,1,155),(1025,'Удалить','Удалить',4,1,156),(1026,'Измененном виде','Измененном виде',4,1,157),(1027,'Изменить','Изменить',4,1,158),(1028,'Справочная Главная','Справочная Главная',4,1,159),(1029,'﻿Contenido del modelo de','﻿Contenido del modelo de',5,1,1),(1030,'Gestión de Contenidos','Gestión de Contenidos',5,1,2),(1031,'Lista de artículos','Lista de artículos',5,1,3),(1032,'Agregar formulario','Agregar formulario',5,1,4),(1033,'Agregar','Agregar',5,1,5),(1034,'Eliminar','Eliminar',5,1,6),(1035,'Formulario de actualización','Formulario de actualización',5,1,7),(1036,'Modificar','Modificar',5,1,8),(1037,'Lista de software','Lista de software',5,1,9),(1038,'Agregar formulario','Agregar formulario',5,1,10),(1039,'Agregar','Agregar',5,1,11),(1040,'Eliminar','Eliminar',5,1,12),(1041,'Formulario de actualización','Formulario de actualización',5,1,13),(1042,'Modificar','Modificar',5,1,14),(1043,'Contenido de la función','Contenido de la función',5,1,15),(1044,'Eliminar archivo estático','Eliminar archivo estático',5,1,16),(1045,'Generar archivo estático','Generar archivo estático',5,1,17),(1046,'Generar archivo de índice','Generar archivo de índice',5,1,18),(1047,'Tag Management','Tag Management',5,1,19),(1048,'Eliminar','Eliminar',5,1,20),(1049,'Comentario de gestión','Comentario de gestión',5,1,21),(1050,'Eliminar','Eliminar',5,1,22),(1051,'Formulario de actualización','Formulario de actualización',5,1,23),(1052,'Modificar','Modificar',5,1,24),(1053,'Gestión de archivos estáticos','Gestión de archivos estáticos',5,1,25),(1054,'Agregar','Agregar',5,1,26),(1055,'Índice de gestión','Índice de gestión',5,1,27),(1056,'Agregar','Agregar',5,1,28),(1057,'Forma Eliminar','Forma Eliminar',5,1,29),(1058,'Eliminar','Eliminar',5,1,30),(1059,'Formulario de actualización','Formulario de actualización',5,1,31),(1060,'Actualizar','Actualizar',5,1,32),(1061,'Gestión Local','Gestión Local',5,1,33),(1062,'Agregar formulario','Agregar formulario',5,1,34),(1063,'Agregar','Agregar',5,1,35),(1064,'Eliminar','Eliminar',5,1,36),(1065,'Formulario de actualización','Formulario de actualización',5,1,37),(1066,'Modificar','Modificar',5,1,38),(1067,'Modelo de Usuario','Modelo de Usuario',5,1,39),(1068,'Frente usuario','Frente usuario',5,1,40),(1069,'Miembros de la lista','Miembros de la lista',5,1,41),(1070,'Agregar formulario','Agregar formulario',5,1,42),(1071,'Agregar','Agregar',5,1,43),(1072,'Eliminar','Eliminar',5,1,44),(1073,'Formulario de actualización','Formulario de actualización',5,1,45),(1074,'Modificar','Modificar',5,1,46),(1075,'Ver','Ver',5,1,47),(1076,'Miembro del Grupo','Miembro del Grupo',5,1,48),(1077,'Agregar formulario','Agregar formulario',5,1,49),(1078,'Agregar','Agregar',5,1,50),(1079,'Eliminar','Eliminar',5,1,51),(1080,'Formulario de actualización','Formulario de actualización',5,1,52),(1081,'Modificar','Modificar',5,1,53),(1082,'Antecedentes del usuario','Antecedentes del usuario',5,1,54),(1083,'Administrador de listas','Administrador de listas',5,1,55),(1084,'Agregar formulario de administrador','Agregar formulario de administrador',5,1,56),(1085,'Agregar administrador','Agregar administrador',5,1,57),(1086,'Quitar administrador','Quitar administrador',5,1,58),(1087,'Formulario de cambio de administrador','Formulario de cambio de administrador',5,1,59),(1088,'Cambio de administrador','Cambio de administrador',5,1,60),(1089,'Modificar el formulario papel','Modificar el formulario papel',5,1,61),(1090,'Modificar papel','Modificar papel',5,1,62),(1091,'Administrador de vistas','Administrador de vistas',5,1,63),(1092,'Lista de papel','Lista de papel',5,1,64),(1093,'Agregar formulario papel','Agregar formulario papel',5,1,65),(1094,'Añadir Papel','Añadir Papel',5,1,66),(1095,'Eliminar papel','Eliminar papel',5,1,67),(1096,'Formulario de actualización','Formulario de actualización',5,1,68),(1097,'Modificar el papel','Modificar el papel',5,1,69),(1098,'Papel Modificar Formulario de Permiso','Papel Modificar Formulario de Permiso',5,1,70),(1099,'Modificar permisos papel','Modificar permisos papel',5,1,71),(1100,'Función de navegación Modificar Formulario','Función de navegación Modificar Formulario',5,1,72),(1101,'Modificar Navegación Papel','Modificar Navegación Papel',5,1,73),(1102,'Permiso de gestión','Permiso de gestión',5,1,74),(1103,'Agregar formulario','Agregar formulario',5,1,75),(1104,'Agregar','Agregar',5,1,76),(1105,'Eliminar','Eliminar',5,1,77),(1106,'Formulario de actualización','Formulario de actualización',5,1,78),(1107,'Modificar','Modificar',5,1,79),(1108,'Actualizar','Actualizar',5,1,80),(1109,'Ingresar Registrarse','Ingresar Registrarse',5,1,81),(1110,'Eliminar','Eliminar',5,1,82),(1111,'Online Manager','Online Manager',5,1,83),(1112,'Eliminar','Eliminar',5,1,84),(1113,'Modelo del sistema','Modelo del sistema',5,1,85),(1114,'Configuración del sistema','Configuración del sistema',5,1,86),(1115,'Sitio Marco','Sitio Marco',5,1,87),(1116,'Modificar sitio','Modificar sitio',5,1,88),(1117,'Configuración de seguridad','Configuración de seguridad',5,1,89),(1118,'Modificar','Modificar',5,1,90),(1119,'Ajustes de navegación','Ajustes de navegación',5,1,91),(1120,'Agregar formulario','Agregar formulario',5,1,92),(1121,'Agregar','Agregar',5,1,93),(1122,'Eliminar','Eliminar',5,1,94),(1123,'Formulario de actualización','Formulario de actualización',5,1,95),(1124,'Modificar','Modificar',5,1,96),(1125,'Filigrana','Filigrana',5,1,97),(1126,'Modificar','Modificar',5,1,98),(1127,'Correo Marco','Correo Marco',5,1,99),(1128,'Modificar','Modificar',5,1,100),(1129,'Plantilla Marco','Plantilla Marco',5,1,101),(1130,'Modificar','Modificar',5,1,102),(1131,'Marco de código de plantilla','Marco de código de plantilla',5,1,103),(1132,'Agregar formulario','Agregar formulario',5,1,104),(1133,'Agregar','Agregar',5,1,105),(1134,'Eliminar','Eliminar',5,1,106),(1135,'Formulario de actualización','Formulario de actualización',5,1,107),(1136,'Modificar','Modificar',5,1,108),(1137,'Variable del Sistema Marco','Variable del Sistema Marco',5,1,109),(1138,'Agregar formulario','Agregar formulario',5,1,110),(1139,'Agregar','Agregar',5,1,111),(1140,'Eliminar','Eliminar',5,1,112),(1141,'Formulario de actualización','Formulario de actualización',5,1,113),(1142,'Modificar','Modificar',5,1,114),(1143,'La función del sistema','La función del sistema',5,1,115),(1144,'Copia de seguridad de datos','Copia de seguridad de datos',5,1,116),(1145,'Copia de seguridad y restauración','Copia de seguridad y restauración',5,1,117),(1146,'Gestión internacional','Gestión internacional',5,1,118),(1147,'Agregar formulario','Agregar formulario',5,1,119),(1148,'Agregar','Agregar',5,1,120),(1149,'Eliminar','Eliminar',5,1,121),(1150,'Formulario de actualización','Formulario de actualización',5,1,122),(1151,'Modificar','Modificar',5,1,123),(1152,'Gestión Documental','Gestión Documental',5,1,124),(1153,'Cargar el formulario','Cargar el formulario',5,1,125),(1154,'Subir Archivo','Subir Archivo',5,1,126),(1155,'Modificar archivo Nombre del formulario','Modificar archivo Nombre del formulario',5,1,127),(1156,'Modificar nombre de archivo','Modificar nombre de archivo',5,1,128),(1157,'Modificar datos Presente el Formulario','Modificar datos Presente el Formulario',5,1,129),(1158,'Modificar archivo de datos','Modificar archivo de datos',5,1,130),(1159,'Eliminar archivos','Eliminar archivos',5,1,131),(1160,'Crear directorio de archivos','Crear directorio de archivos',5,1,132),(1161,'Enviar por e-mail','Enviar por e-mail',5,1,133),(1162,'Enviar','Enviar',5,1,134),(1163,'Enlace','Enlace',5,1,135),(1164,'Agregar formulario','Agregar formulario',5,1,136),(1165,'Agregar','Agregar',5,1,137),(1166,'Eliminar','Eliminar',5,1,138),(1167,'Formulario de actualización','Formulario de actualización',5,1,139),(1168,'Modificar','Modificar',5,1,140),(1169,'Descargar filtro de URL','Descargar filtro de URL',5,1,141),(1170,'Agregar formulario','Agregar formulario',5,1,142),(1171,'Agregar','Agregar',5,1,143),(1172,'Eliminar','Eliminar',5,1,144),(1173,'Formulario de actualización','Formulario de actualización',5,1,145),(1174,'Modificar','Modificar',5,1,146),(1175,'Canal Modelo de Gestión','Canal Modelo de Gestión',5,1,147),(1176,'Agregar formulario','Agregar formulario',5,1,148),(1177,'Agregar','Agregar',5,1,149),(1178,'Eliminar','Eliminar',5,1,150),(1179,'Formulario de actualización','Formulario de actualización',5,1,151),(1180,'Modificar','Modificar',5,1,152),(1181,'Votación de Gestión','Votación de Gestión',5,1,153),(1182,'Agregar formulario','Agregar formulario',5,1,154),(1183,'Agregar','Agregar',5,1,155),(1184,'Eliminar','Eliminar',5,1,156),(1185,'Formulario de actualización','Formulario de actualización',5,1,157),(1186,'Modificar','Modificar',5,1,158),(1187,'Antecedentes Inicio','Antecedentes Inicio',5,1,159),(1191,'スーパー管理者','スーパー管理者',3,2,0),(1188,'超级管理员','超级管理员',0,2,0),(1189,'Super Admin','Super Admin',1,2,0),(1190,'超級管理員','超級管理員',2,2,0),(1192,'Super Admin','Super Admin',4,2,0),(1193,'Super Admin','Super Admin',5,2,0),(1194,'文章模型','文章模型',0,3,1),(1195,'Article Model','Article Model',1,3,1),(1196,'文章模型','文章模型',2,3,1),(1197,'ペーパーモデル','ペーパーモデル',3,3,1),(1198,'Бумажная модель','Бумажная модель',4,3,1),(1199,'Modelo de Article','Modelo de Article',5,3,1),(1200,'软件模型','软件模型',0,3,2),(1201,'Software Model','Software Model',1,3,2),(1202,'軟件模型','軟件模型',2,3,2),(1203,'ソフトウェアモデル','ソフトウェアモデル',3,3,2),(1204,'программная модель','программная модель',4,3,2),(1205,'software de modelo','software de modelo',5,3,2),(1206,'图片模型','图片模型',0,3,3),(1207,'Image Model','Image Model',1,3,3),(1208,'圖片模型','圖片模型',2,3,3),(1209,'イメージモデル','イメージモデル',3,3,3),(1210,'Изображение модели','Изображение модели',4,3,3),(1211,'Imagen del modelo','Imagen del modelo',5,3,3),(1212,'专题列表','专题列表',0,0,40),(1213,'Special Topic List','Special Topic List',1,0,40),(1214,'專題列表','專題列表',2,0,40),(1215,'特別なトピックのリスト','特別なトピックのリスト',3,0,40),(1216,'Специальный список тему','Специальный список тему',4,0,40),(1217,'Lista de temas Especial','Lista de temas Especial',5,0,40),(1218,'视频列表','视频列表',0,0,41),(1219,'Video List','Video List',1,0,41),(1220,'視頻列表','視頻列表',2,0,41),(1221,'ビデオのリスト','ビデオのリスト',3,0,41),(1222,'Видео Список','Видео Список',4,0,41),(1223,'Lista de vídeo','Lista de vídeo',5,0,41),(1224,'CMS类型列表','CMS类型列表',0,0,42),(1225,'CMS Type List','CMS Type List',1,0,42),(1226,'CMS類型列表','CMS類型列表',2,0,42),(1227,'CMSの種類の一覧','CMSの種類の一覧',3,0,42),(1228,'CMS Список типов','CMS Список типов',4,0,42),(1229,'CMS lista de tipos','CMS lista de tipos',5,0,42),(1230,'专题列表','专题列表',0,1,160),(1231,'Special Topic List','Special Topic List',1,1,160),(1232,'專題列表','專題列表',2,1,160),(1233,'特別なトピックのリスト','特別なトピックのリスト',3,1,160),(1234,'Специальный список тему','Специальный список тему',4,1,160),(1235,'Lista de temas Especial','Lista de temas Especial',5,1,160),(1236,'添加表单','添加表单',0,1,161),(1237,'Add Form','Add Form',1,1,161),(1238,'添加表單','添加表單',2,1,161),(1239,'フォームを追加します。','フォームを追加します。',3,1,161),(1240,'Добавить форму','Добавить форму',4,1,161),(1241,'Agregar formulario','Agregar formulario',5,1,161),(1242,'添加','添加',0,1,162),(1243,'Add','Add',1,1,162),(1244,'添加','添加',2,1,162),(1245,'追加','追加',3,1,162),(1246,'добавлять','добавлять',4,1,162),(1247,'añadir','añadir',5,1,162),(1248,'修改表单','修改表单',0,1,163),(1249,'Modified Form','Modified Form',1,1,163),(1250,'修改表單','修改表單',2,1,163),(1251,'変更フォーム','変更フォーム',3,1,163),(1252,'Изменить С','Изменить С',4,1,163),(1253,'De modificar','De modificar',5,1,163),(1254,'修改','修改',0,1,164),(1255,'Modify','Modify',1,1,164),(1256,'修改','修改',2,1,164),(1257,'変更','変更',3,1,164),(1258,'модифицировать','модифицировать',4,1,164),(1259,'modificar','modificar',5,1,164),(1260,'删除','删除',0,1,165),(1261,'Delete','Delete',1,1,165),(1262,'刪除','刪除',2,1,165),(1266,'视频列表','视频列表',0,1,166),(1263,'削除','削除',3,1,165),(1264,'удалять','удалять',4,1,165),(1265,'borrar','borrar',5,1,165),(1267,'Video List','Video List',1,1,166),(1268,'視頻列表','視頻列表',2,1,166),(1269,'ビデオのリスト','ビデオのリスト',3,1,166),(1270,'Видео Список','Видео Список',4,1,166),(1271,'Lista de vídeo','Lista de vídeo',5,1,166),(1272,'添加表单','添加表单',0,1,167),(1273,'Add Form','Add Form',1,1,167),(1274,'添加表單','添加表單',2,1,167),(1275,'フォームを追加します。','フォームを追加します。',3,1,167),(1276,'Добавить форму','Добавить форму',4,1,167),(1277,'Agregar formulario','Agregar formulario',5,1,167),(1278,'添加','添加',0,1,168),(1279,'Add','Add',1,1,168),(1280,'添加','添加',2,1,168),(1281,'追加','追加',3,1,168),(1282,'добавлять','добавлять',4,1,168),(1283,'añadir','añadir',5,1,168),(1284,'修改表单','修改表单',0,1,169),(1285,'Modified Form','Modified Form',1,1,169),(1286,'修改表單','修改表單',2,1,169),(1287,'変更フォーム','変更フォーム',3,1,169),(1288,'Изменить С','Изменить С',4,1,169),(1289,'De modificar','De modificar',5,1,169),(1290,'修改','修改',0,1,170),(1291,'Modify','Modify',1,1,170),(1292,'修改','修改',2,1,170),(1293,'変更','変更',3,1,170),(1294,'модифицировать','модифицировать',4,1,170),(1295,'modificar','modificar',5,1,170),(1296,'删除','删除',0,1,171),(1297,'Delete','Delete',1,1,171),(1298,'刪除','刪除',2,1,171),(1299,'削除','削除',3,1,171),(1300,'удалять','удалять',4,1,171),(1301,'borrar','borrar',5,1,171),(1302,'CMS类型列表','CMS类型列表',0,1,172),(1303,'CMS Type List','CMS Type List',1,1,172),(1304,'CMS類型列表','CMS類型列表',2,1,172),(1305,'CMSの種類の一覧','CMSの種類の一覧',3,1,172),(1306,'CMS Список типов','CMS Список типов',4,1,172),(1307,'CMS lista de tipos','CMS lista de tipos',5,1,172),(1308,'添加表单','添加表单',0,1,173),(1309,'Add Form','Add Form',1,1,173),(1310,'添加表單','添加表單',2,1,173),(1311,'フォームを追加します。','フォームを追加します。',3,1,173),(1312,'Добавить форму','Добавить форму',4,1,173),(1313,'Agregar formulario','Agregar formulario',5,1,173),(1314,'添加','添加',0,1,174),(1315,'Add','Add',1,1,174),(1316,'添加','添加',2,1,174),(1317,'追加','追加',3,1,174),(1318,'добавлять','добавлять',4,1,174),(1319,'añadir','añadir',5,1,174),(1320,'修改表单','修改表单',0,1,175),(1321,'Modified Form','Modified Form',1,1,175),(1322,'修改表單','修改表單',2,1,175),(1323,'変更フォーム','変更フォーム',3,1,175),(1324,'Изменить С','Изменить С',4,1,175),(1325,'De modificar','De modificar',5,1,175),(1326,'修改','修改',0,1,176),(1327,'Modify','Modify',1,1,176),(1328,'修改','修改',2,1,176),(1329,'変更','変更',3,1,176),(1330,'модифицировать','модифицировать',4,1,176),(1331,'modificar','modificar',5,1,176),(1332,'删除','删除',0,1,177),(1333,'Delete','Delete',1,1,177),(1334,'刪除','刪除',2,1,177),(1335,'削除','削除',3,1,177),(1336,'удалять','удалять',4,1,177),(1337,'borrar','borrar',5,1,177),(1338,'文章移动表单','文章移动表单',0,1,178),(1339,'article move form','article move form',1,1,178),(1340,'文章移動表單','文章移動表單',2,1,178),(1341,'記事の移動形態','記事の移動形態',3,1,178),(1342,'форма статье двигаться','форма статье двигаться',4,1,178),(1343,'artículo forma se mueven','artículo forma se mueven',5,1,178),(1344,'文章移动','文章移动',0,1,179),(1345,'article move','article move',1,1,179),(1346,'文章移動','文章移動',2,1,179),(1347,'記事の移動','記事の移動',3,1,179),(1348,'Статья двигаться','Статья двигаться',4,1,179),(1349,'artículo se mueven','artículo se mueven',5,1,179),(1350,'软件移动表单','软件移动表单',0,1,180),(1351,'software move form','software move form',1,1,180),(1352,'軟件移動表單','軟件移動表單',2,1,180),(1353,'ソフトウェアの移動形態','ソフトウェアの移動形態',3,1,180),(1354,'форме программного обеспечения перемещения','форме программного обеспечения перемещения',4,1,180),(1355,'software de forma avanzar','software de forma avanzar',5,1,180),(1356,'软件移动','软件移动',0,1,181),(1357,'software move','software move',1,1,181),(1358,'軟件移動','軟件移動',2,1,181),(1359,'ソフトウェアの動き','ソフトウェアの動き',3,1,181),(1360,'программное обеспечение двигаться','программное обеспечение двигаться',4,1,181),(1361,'software se mueven','software se mueven',5,1,181),(1362,'设置账号表单','设置账号表单',0,1,182),(1363,'set account form','set account form',1,1,182),(1364,'設置賬號表單','設置賬號表單',2,1,182),(1365,'アカウントフォームを設定する','アカウントフォームを設定する',3,1,182),(1366,'набор форма счета','набор форма счета',4,1,182),(1367,'conjunto de formularios en cuenta','conjunto de formularios en cuenta',5,1,182),(1368,'修改','修改',0,1,183),(1369,'Modify','Modify',1,1,183),(1370,'修改','修改',2,1,183),(1371,'変更','変更',3,1,183),(1372,'модифицировать','модифицировать',4,1,183),(1373,'modificar','modificar',5,1,183),(1374,'会员登录设置','会员登录设置',0,1,184),(1375,'修改','修改会员登录配置',0,1,185),(1376,'会员登录设置','会员登录设置',0,0,43),(1377,'Member login settings','Member login settings',1,1,184),(1378,'Modify','Login to modify the configuration',1,1,185),(1379,'Member login settings','Member login settings',1,0,43),(1380,'會員登錄設置','會員登錄設置',2,1,184),(1381,'修改','修改會員登錄配置',2,1,185),(1382,'會員登錄設置','會員登錄設置',2,0,43),(1383,'メンバーのログイン設定','メンバーのログイン設定',3,1,184),(1384,'変更','設定を変更するには、ログイン',3,1,185),(1385,'メンバーのログイン設定','メンバーのログイン設定',3,0,43),(1386,'Настройки Вход для зарегистрированных пользователей','Настройки Вход для зарегистрированных пользователей',4,1,184),(1387,'изменять','Войти, чтобы изменить конфигурацию',4,1,185),(1388,'Настройки Вход для зарегистрированных пользователей','Настройки Вход для зарегистрированных пользователей',4,0,43),(1389,'Configuración miembro de inicio de sesión','Configuración miembro de inicio de sesión',5,1,184),(1390,'modificar','Inicie sesión para modificar la configuración',5,1,185),(1391,'Configuración miembro de inicio de sesión','Configuración miembro de inicio de sesión',5,0,43),(1392,'生成静态文件','生成静态文件',0,1,186),(1393,'删除静态文件','删除静态文件',0,1,187),(1394,'Generate static file','Generate static file',1,1,186),(1395,'Delete static file','Delete static file',1,1,187),(1396,'生成靜態文件','生成靜態文件',2,1,186),(1397,'删除靜態文件','删除靜態文件',2,1,187),(1398,'静的ファイルを生成する','静的ファイルを生成する',3,1,186),(1399,'静的なファイルを削除します。','静的なファイルを削除します。',3,1,187),(1400,'Создание статических файлов','Создание статических файлов',4,1,186),(1401,'Удаление статических файлов','Удаление статических файлов',4,1,187),(1402,'Generan archivos estáticos','Generan archivos estáticos',5,1,186),(1403,'Eliminar archivos estáticos','Eliminar archivos estáticos',5,1,187),(1404,'Oauth登录设置','Oauth登录设置',0,0,44),(1405,'关键字历史列表','关键字历史列表',0,0,45),(1406,'支付订单列表','支付订单列表',0,0,46),(1407,'Oauth login settings','Oauth login settings',1,0,44),(1408,'Keyword history list','Keyword history list',1,0,45),(1409,'The list of payment orders','The list of payment orders',1,0,46),(1410,'Oauth登錄設置','Oauth登錄設置',2,0,44),(1411,'關鍵字歷史列表','關鍵字歷史列表',2,0,45),(1412,'支付訂單列表','支付訂單列表',2,0,46),(1413,'OAuthのログイン設定','OAuthのログイン設定',3,0,44),(1414,'キーワードの履歴リスト','キーワードの履歴リスト',3,0,45),(1415,'支払指図のリスト','支払指図のリスト',3,0,46),(1416,'OAuth параметры входа','OAuth параметры входа',4,0,44),(1417,'Список ключевых слов история','Список ключевых слов история',4,0,45),(1418,'Список платежных поручений','Список платежных поручений',4,0,46),(1419,'OAuth configuración de inicio de sesión','OAuth configuración de inicio de sesión',5,0,44),(1420,'Palabra lista de la historia','Palabra lista de la historia',5,0,45),(1421,'La lista de órdenes de pago','La lista de órdenes de pago',5,0,46),(1422,'上传图片表单','上传图片表单',0,1,188),(1423,'上传图片','上传图片',0,1,189),(1424,'上传附件表单','上传附件表单',0,1,190),(1425,'上传附件','上传附件',0,1,191),(1426,'评论审核','评论审核',0,1,192),(1427,'关键字历史列表','关键字历史列表',0,1,193),(1428,'删除','删除',0,1,194),(1429,'Oauth登录设置','Oauth登录设置',0,1,195),(1430,'添加表单','添加表单',0,1,196),(1431,'添加','添加',0,1,197),(1432,'修改表单','修改表单',0,1,198),(1433,'修改','修改',0,1,199),(1434,'删除','删除',0,1,200),(1435,'支付订单列表','支付订单列表',0,1,201),(1436,'已付款','已付款',0,1,202),(1437,'删除','删除',0,1,203),(1438,'Upload pictures form','Upload pictures form',1,1,188),(1439,'Upload pictures','Upload pictures',1,1,189),(1440,'Upload attachment form','Upload attachment form',1,1,190),(1441,'Post attachments','Post attachments',1,1,191),(1442,'Comment Moderation','Comment Moderation',1,1,192),(1443,'Keyword history list','Keyword history list',1,1,193),(1444,'Delete','Delete',1,1,194),(1445,'Oauth login settings','Oauth login settings',1,1,195),(1446,'Add form','Add form',1,1,196),(1447,'Add','Add',1,1,197),(1448,'Modify the form','Modify the form',1,1,198),(1449,'Modify','Modify',1,1,199),(1450,'Delete','Delete',1,1,200),(1451,'The list of payment orders','The list of payment orders',1,1,201),(1452,'Paid','Paid',1,1,202),(1453,'Delete','Delete',1,1,203),(1454,'上傳圖片表單','上傳圖片表單',2,1,188),(1455,'上傳圖片','上傳圖片',2,1,189),(1456,'上傳附件表單','上傳附件表單',2,1,190),(1457,'上傳附件','上傳附件',2,1,191),(1458,'評論審核','評論審核',2,1,192),(1459,'關鍵字歷史列表','關鍵字歷史列表',2,1,193),(1460,'刪除','刪除',2,1,194),(1461,'Oauth登錄設置','Oauth登錄設置',2,1,195),(1462,'添加表單','添加表單',2,1,196),(1463,'添加','添加',2,1,197),(1464,'修改表單','修改表單',2,1,198),(1465,'修改','修改',2,1,199),(1466,'刪除','刪除',2,1,200),(1467,'支付訂單列表','支付訂單列表',2,1,201),(1468,'已付款','已付款',2,1,202),(1469,'刪除','刪除',2,1,203),(1470,'写真のアップロードフォーム','写真のアップロードフォーム',3,1,188),(1471,'写真をアップロード','写真をアップロード',3,1,189),(1472,'添付ファイルのアップロードフォーム','添付ファイルのアップロードフォーム',3,1,190),(1473,'添付ファイルを投稿する','添付ファイルを投稿する',3,1,191),(1474,'コメントモデレーション','コメントモデレーション',3,1,192),(1475,'キーワードの履歴リスト','キーワードの履歴リスト',3,1,193),(1476,'削除する','削除する',3,1,194),(1477,'OAuthのログイン設定','OAuthのログイン設定',3,1,195),(1478,'フォームを追加する','フォームを追加する',3,1,196),(1479,'加える','加える',3,1,197),(1480,'フォームを変更','フォームを変更',3,1,198),(1481,'修正する','修正する',3,1,199),(1482,'削除する','削除する',3,1,200),(1483,'支払指図のリスト','支払指図のリスト',3,1,201),(1484,'有料','有料',3,1,202),(1485,'削除する','削除する',3,1,203),(1486,'Загрузить фото форме','Загрузить фото форме',4,1,188),(1487,'Загрузить фото','Загрузить фото',4,1,189),(1488,'Загрузите приложение форме','Загрузите приложение форме',4,1,190),(1489,'Сообщение вложения','Сообщение вложения',4,1,191),(1490,'Комментарий умеренности','Комментарий умеренности',4,1,192),(1491,'Список ключевых слов история','Список ключевых слов история',4,1,193),(1492,'удалять','удалять',4,1,194),(1493,'OAuth параметры входа','OAuth параметры входа',4,1,195),(1494,'Добавить форме','Добавить форме',4,1,196),(1495,'добавлять','добавлять',4,1,197),(1496,'Измените форму','Измените форму',4,1,198),(1497,'изменять','изменять',4,1,199),(1498,'удалять','удалять',4,1,200),(1499,'Список платежных поручений','Список платежных поручений',4,1,201),(1500,'оплачиваемый','оплачиваемый',4,1,202),(1501,'удалять','удалять',4,1,203),(1502,'Subir imágenes de forma','Subir imágenes de forma',5,1,188),(1503,'Subir imágenes','Subir imágenes',5,1,189),(1504,'Transferir el formulario adjunto','Transferir el formulario adjunto',5,1,190),(1505,'Enviar archivos adjuntos','Enviar archivos adjuntos',5,1,191),(1506,'comentario moderación','comentario moderación',5,1,192),(1507,'Palabra lista de la historia','Palabra lista de la historia',5,1,193),(1508,'borrar','borrar',5,1,194),(1509,'OAuth configuración de inicio de sesión','OAuth configuración de inicio de sesión',5,1,195),(1510,'Agregar la forma','Agregar la forma',5,1,196),(1511,'añadir','añadir',5,1,197),(1512,'Modificar el formulario','Modificar el formulario',5,1,198),(1513,'modificar','modificar',5,1,199),(1514,'borrar','borrar',5,1,200),(1515,'La lista de órdenes de pago','La lista de órdenes de pago',5,1,201),(1516,'pagado','pagado',5,1,202),(1517,'borrar','borrar',5,1,203),(1518,'专题搜索','专题搜索',0,1,204),(1519,'Special Topic Search','Special Topic Search',1,1,204),(1520,'專題搜索','專題搜索',2,1,204),(1521,'特別なトピックの検索','特別なトピックの検索',3,1,204),(1522,'Специальный поиск темы','Специальный поиск темы',4,1,204),(1523,'Buscar Tema Especial','Buscar Tema Especial',5,1,204),(1524,'图片列表','图片列表',0,0,47),(1525,'List Of Images','List Of Images',1,0,47),(1526,'圖片列表','圖片列表',2,0,47),(1527,'イメージのリスト','イメージのリスト',3,0,47),(1528,'Список изображений','Список изображений',4,0,47),(1529,'Lista de imágenes','Lista de imágenes',5,0,47),(1530,'移动表单','视频移动表单',0,1,205),(1531,'Move Form','Move Form',1,1,205),(1532,'移動表單','視頻移動表單',2,1,205),(1533,'フォームを移動','フォームを移動',3,1,205),(1534,'перемещать форму','перемещать форму',4,1,205),(1535,'mover la forma','mover la forma',5,1,205),(1536,'移动提交','移动提交',0,1,206),(1537,'Move Submit','Move Submit',1,1,206),(1538,'移動提交','移動提交',2,1,206),(1539,'提出移動','提出移動',3,1,206),(1540,'двигаться представить','двигаться представить',4,1,206),(1541,'se mueven presente','se mueven presente',5,1,206),(1542,'图片列表','图片列表',0,1,207),(1543,'List Of Images','List Of Images',1,1,207),(1544,'圖片列表','圖片列表',2,1,207),(1545,'イメージのリスト','イメージのリスト',3,1,207),(1546,'Список изображений','Список изображений',4,1,207),(1547,'Lista de imágenes','Lista de imágenes',5,1,207),(1548,'添加表单','添加表单',0,1,208),(1549,'Add Form','Add Form',1,1,208),(1550,'添加表單','添加表單',2,1,208),(1551,'フォームを追加します。','フォームを追加します。',3,1,208),(1552,'Добавить форму','Добавить форму',4,1,208),(1553,'Agregar formulario','Agregar formulario',5,1,208),(1554,'添加','添加',0,1,209),(1555,'Add','Add',1,1,209),(1556,'添加','添加',2,1,209),(1557,'追加','追加',3,1,209),(1558,'добавлять','добавлять',4,1,209),(1559,'a?adir','a?adir',5,1,209),(1560,'修改表单','修改表单',0,1,210),(1561,'Modified Form','Modified Form',1,1,210),(1562,'修改表單','修改表單',2,1,210),(1563,'変更フォーム','変更フォーム',3,1,210),(1564,'Изменить С','Изменить С',4,1,210),(1565,'De modificar','De modificar',5,1,210),(1566,'修改','修改',0,1,211),(1567,'Modify','Modify',1,1,211),(1568,'修改','修改',2,1,211),(1569,'変更','変更',3,1,211),(1570,'модифицировать','модифицировать',4,1,211),(1571,'modificar','modificar',5,1,211),(1572,'删除','删除',0,1,212),(1573,'Delete','Delete',1,1,212),(1574,'刪除','刪除',2,1,212),(1575,'削除','削除',3,1,212),(1576,'удалять','удалять',4,1,212),(1577,'borrar','borrar',5,1,212),(1578,'移动表单','图片移动表单',0,1,213),(1579,'Move Form','Move Form',1,1,213),(1580,'移動表單','圖片移動表單',2,1,213),(1581,'フォームを移動','フォームを移動',3,1,213),(1582,'перемещать форму','перемещать форму',4,1,213),(1583,'mover la forma','mover la forma',5,1,213),(1584,'移动提交','图片移动提交',0,1,214),(1585,'Move Submit','Move Submit',1,1,214),(1586,'移動提交','圖片移動提交',2,1,214),(1587,'提出移動','提出移動',3,1,214),(1588,'двигаться представить','двигаться представить',4,1,214),(1589,'se mueven presente','se mueven presente',5,1,214),(1590,'上传表单','上传表单',0,1,215),(1591,'Upload Form','Upload Form',1,1,215),(1592,'上傳表單','上傳表單',2,1,215),(1593,'フォームをアップロードする','フォームをアップロードする',3,1,215),(1594,'Загрузите форму','Загрузите форму',4,1,215),(1595,'formulario de carga','formulario de carga',5,1,215);

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_email_config`;

CREATE TABLE `vj_email_config` (
  `configId` int(1) NOT NULL,
  `sender` varchar(50) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `smtpAddress` varchar(250) DEFAULT NULL,
  `isHtml` char(1) DEFAULT NULL,
  `isEsmtp` char(1) DEFAULT NULL,
  `isAttachment` char(1) DEFAULT NULL,
  `emailPort` int(11) DEFAULT NULL,
  `retry` int(11) DEFAULT NULL,
  `emailInterval` int(11) DEFAULT NULL,
  `timeOut` int(11) DEFAULT NULL,
  `userName` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`configId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_email_config` WRITE;

INSERT INTO `vj_email_config` VALUES (1,'微骏邮件系统','system@java.sh','smtp.qq.com','T','T','F',25,10,3000,30000,'system@java.sh','4711433');

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_filter_url`;

CREATE TABLE `vj_filter_url` (
  `urlId` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `url` varchar(250) DEFAULT NULL,
  `type` char(1) DEFAULT NULL,
  PRIMARY KEY (`urlId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_filter_url` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_hit`;

CREATE TABLE `vj_hit` (
  `id` char(32) NOT NULL,
  `modelId` int(11) DEFAULT NULL,
  `nodeId` int(11) DEFAULT NULL,
  `click` int(11) DEFAULT NULL,
  `clickDay` int(11) DEFAULT NULL,
  `clickWeek` int(11) DEFAULT NULL,
  `clickMonth` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_hit` WRITE;


UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_links`;

CREATE TABLE `vj_links` (
  `linkId` char(32) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `url` varchar(250) DEFAULT NULL,
  `type` char(1) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `logo` varchar(250) DEFAULT NULL,
  `display` char(1) DEFAULT NULL,
  PRIMARY KEY (`linkId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_links` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_member_favorite`;

CREATE TABLE `vj_member_favorite` (
  `favoriteId` char(32) NOT NULL,
  `title` varchar(255) DEFAULT NULL,
  `modelId` int(11) DEFAULT NULL,
  `nodeId` int(11) DEFAULT NULL,
  `contentId` char(32) DEFAULT NULL,
  `memberId` char(32) DEFAULT NULL,
  `favoriteTime` int(11) DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`favoriteId`),
  KEY `IX_vj_member_favorite_favoriteTime` (`favoriteTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_member_favorite` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_member_funds`;
CREATE TABLE `vj_member_funds` (
  `memberId` char(32) NOT NULL,
  `memberMoney` decimal(10,2) DEFAULT NULL,
  `payPassword` char(56) DEFAULT NULL,
  `memberPoint` int(11) DEFAULT NULL,
  `costMoney` decimal(10,2) DEFAULT NULL,
  `costPoint` int(11) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `vj_member_funds` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_member_group`;

CREATE TABLE `vj_member_group` (
  `groupId` int(11) NOT NULL,
  `groupName` varchar(50) DEFAULT NULL,
  `fileSize` int(11) DEFAULT NULL,
  `fileSuffix` varchar(50) DEFAULT NULL,
  `upgradeExp` int(11) DEFAULT NULL,
  `description` varchar(45) DEFAULT NULL,
  `language` int(11) DEFAULT NULL,
  PRIMARY KEY (`groupId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `vj_member_group` WRITE;

INSERT INTO `vj_member_group` VALUES (1,'初级会员',50,'zip,rar',1000,'',0),(2,'收费会员',50,'zip,rar',5000,NULL,0);

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_member_info`;

CREATE TABLE `vj_member_info` (
  `memberId` char(32) NOT NULL,
  `netName` varchar(50) DEFAULT NULL,
  `trueName` varchar(50) DEFAULT NULL,
  `sex` char(1) DEFAULT NULL,
  `country` varchar(50) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `address` varchar(250) DEFAULT NULL,
  `phone` int(11) DEFAULT NULL,
  `mobile` int(11) DEFAULT NULL,
  `postCount` int(11) DEFAULT NULL,
  `face` varchar(250) DEFAULT NULL,
  `sign` varchar(250) DEFAULT NULL,
  `privacySet` char(1) DEFAULT NULL,
  `integral` int(11) DEFAULT NULL,
  `diskCapacity` int(11) DEFAULT NULL,
  `useCapacity` int(11) DEFAULT NULL,
  PRIMARY KEY (`memberId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_member_info` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_members`;

CREATE TABLE `vj_members` (
  `memberId` char(32) NOT NULL,
  `groupId` tinyint(4) DEFAULT NULL,
  `memberType` char(1) DEFAULT NULL,
  `loginId` varchar(20) DEFAULT NULL,
  `password` char(56) DEFAULT NULL,
  `email` varchar(150) DEFAULT NULL,
  `registerTime` int(11) DEFAULT NULL,
  `myTimeZone` char(6) DEFAULT NULL,
  `myLanguage` tinyint(4) DEFAULT NULL,
  `lastLoginIp` varchar(40) DEFAULT NULL,
  `lastLoginTime` int(11) DEFAULT NULL,
  `loginCount` int(11) DEFAULT NULL,
  `loginErrorCount` int(11) DEFAULT NULL,
  `answerErrorCount` int(11) DEFAULT NULL,
  `accountExpired` char(1) DEFAULT NULL,
  `accountLocked` char(1) DEFAULT NULL,
  `credentialsExpired` char(1) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  `lastUpdatePassWordTime` int(11) DEFAULT NULL,
  `isPassExpire` char(1) DEFAULT NULL,
  `isAccountExpire` char(1) DEFAULT NULL,
  `isAnswerLogin` char(1) DEFAULT NULL,
  `question` char(1) DEFAULT NULL,
  `answer` varchar(250) DEFAULT NULL,
   `accountLockCount` int(11) DEFAULT NULL,
  `accountLockTime` int(11) DEFAULT NULL,
  PRIMARY KEY (`memberId`),
  UNIQUE KEY `IX_vj_members_loginId` (`loginId`),
  UNIQUE KEY `IX_vj_members_email` (`email`),
  KEY `IX_vj_members_registerTime` (`registerTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_members` WRITE;


UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_navigate`;

CREATE TABLE `vj_navigate` (
  `navigateId` int(11) NOT NULL,
  `title` varchar(100) DEFAULT NULL,
  `url` varchar(250) DEFAULT NULL,
  `ico` varchar(250) DEFAULT NULL,
  `parentId` int(11) DEFAULT NULL,
  `nodeLevel` tinyint(4) DEFAULT NULL,
  `nodeSort` int(11) DEFAULT NULL,
  `language` tinyint(4) DEFAULT NULL,
  `display` char(1) DEFAULT NULL,
  PRIMARY KEY (`navigateId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_navigate` WRITE;

INSERT INTO `vj_navigate` VALUES (1,'内容模型','#','1.gif',0,0,0,0,'T'),(2,'内容管理','#','1.gif',1,1,1,0,'T'),(3,'文章列表','listsFunctionArticle','1.gif',2,2,2,0,'T'),(4,'软件列表','listsFunctionSoft','1.gif',2,2,3,0,'T'),(5,'内容功能','#','1.gif',1,1,4,0,'T'),(6,'标签管理','listsFunctionTagList','1.gif',5,2,5,0,'T'),(7,'评论管理','listsFunctionComment','1.gif',5,2,6,0,'T'),(8,'生成静态文件','listsFunctionStaticFile','1.gif',5,2,7,0,'T'),(9,'索引管理','listsFunctionLuceneContent','1.gif',5,2,8,0,'T'),(10,'用户模型','#','1.gif',0,0,9,0,'T'),(11,'前台用户','#','1.gif',10,1,10,0,'T'),(12,'会员列表','listsUserMember','1.gif',11,2,11,0,'T'),(13,'会员组','listsUserMemberGroup','1.gif',11,2,12,0,'T'),(14,'后台用户','#','1.gif',10,1,13,0,'T'),(15,'管理员列表','listsUserAdmin','1.gif',14,2,14,0,'T'),(16,'角色列表','listsPopedomRole','1.gif',14,2,15,0,'T'),(17,'权限管理','listsPopedomResource','1.gif',14,2,16,0,'T'),(18,'登录日志','listsUserAdminLog','1.gif',14,2,17,0,'T'),(19,'在线管理员','listsOnlineUserAdmin','1.gif',14,2,18,0,'T'),(20,'系统模型','#','1.gif',0,0,19,0,'T'),(21,'系统设置','#','1.gif',20,1,20,0,'T'),(22,'站点设置','listsFunctionWebSite','1.gif',21,2,21,0,'T'),(23,'安全设置','listsPopedomSafeConfig','1.gif',21,2,22,0,'T'),(24,'导航设置','listsPopedomNavigate','1.gif',21,2,23,0,'T'),(25,'水印设置','listsFunctionWatermark','1.gif',21,2,24,0,'T'),(26,'邮件设置','listsFunctionEmailConfig','1.gif',21,2,25,0,'T'),(27,'系统功能','#','1.gif',20,1,26,0,'T'),(28,'备份数据','listsFunctionDatabase','1.gif',27,2,27,0,'T'),(29,'国际化管理','listsFunctionDictionary','1.gif',27,2,28,0,'T'),(30,'文件管理','listsFunctionFileManage','1.gif',27,2,29,0,'T'),(31,'发送邮件','listsSendSystemEmail','1.gif',27,2,30,0,'T'),(32,'模板设置','listsFunctionTemplateConfig','1.gif',21,2,31,0,'T'),(33,'模板标签设置','listsFunctionTemplateTag','1.gif',21,2,32,0,'T'),(34,'友情链接','listsFunctionLink','1.gif',27,2,33,0,'T'),(35,'下载网址过滤','listsPopedomFilterUrl','1.gif',27,2,34,0,'T'),(36,'系统变量设置','listsFunctionSystemConfig','1.gif',21,2,35,0,'T'),(37,'栏目管理','listsFunctionNode','1.gif',5,2,36,0,'T'),(38,'频道模型管理','listsFunctionChannelModel','1.gif',27,2,37,0,'T'),(39,'投票管理','listsFunctionVote','1.gif',27,2,38,0,'T'),(40,'专题列表','listsFunctionSpecialTopic','1.gif',2,2,39,0,'T'),(41,'视频列表','listsFunctionVideo','1.gif',2,2,40,0,'T'),(42,'CMS类型列表','listsFunctionCmsType','1.gif',2,2,41,0,'T'),(43,'会员登录设置','listsMemberPopedomSafeConfig','1.gif',21,2,42,0,'T'),(44,'Oauth登录设置','listsFunctionOauthConfig','1.gif',21,2,43,0,'T'),(45,'关键字历史列表','listsFunctionKeywordHistory','1.gif',5,2,44,0,'T'),(46,'支付订单列表','listsFunctionPayOrder','1.gif',11,2,45,0,'T'),(47,'图片列表','listsFunctionPhoto','1.gif',2,2,46,0,'T');

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_nodes`;

CREATE TABLE `vj_nodes` (
  `nodeId` int(11) NOT NULL,
  `nodeName` varchar(100) DEFAULT NULL,
  `modelId` int(11) DEFAULT NULL,
  `nodeType` int(11) DEFAULT NULL,
  `nodeSort` int(11) DEFAULT NULL,
  `parentId` int(11) DEFAULT NULL,
  `keyword` varchar(250) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `isShowMap` char(1) DEFAULT NULL,
  `isSubDomain` char(1) DEFAULT NULL,
  `isCreateList` char(1) DEFAULT NULL,
  `isCreateContent` char(1) DEFAULT NULL,
  `isContribute` char(1) DEFAULT NULL,
  `subDomain` varchar(250) DEFAULT NULL,
  `listNameRule` varchar(250) DEFAULT NULL,
  `contentNameRule` int(11) DEFAULT NULL,
  `nodePopedom` char(1) DEFAULT NULL,
  `nodeDir` varchar(250) DEFAULT NULL,
  `parentDir` varchar(250) DEFAULT NULL,
  `nodeUrl` varchar(250) DEFAULT NULL,
  `indexTemplate` varchar(250) DEFAULT NULL,
  `listTemplate` varchar(250) DEFAULT NULL,
  `contentTemplate` varchar(250) DEFAULT NULL,
  `nodeLevel` int(11) DEFAULT NULL,
  `staticCount` int(11) DEFAULT NULL,
  `fileCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`nodeId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_nodes` WRITE;

INSERT INTO `vj_nodes` VALUES (1,'默认栏目',1,1,0,0,'默认栏目','','T','F','F','F','F','','index',0,'0','/test','/test','','article_index.html','article_list.html','article_page.html',0,8,0);

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_online_admin`;

CREATE TABLE `vj_online_admin` (
  `id` char(32) NOT NULL,
  `userName` varchar(50) DEFAULT NULL,
  `address` varchar(40) DEFAULT NULL,
  `roleName` varchar(50) DEFAULT NULL,
  `loginTime` int(11) DEFAULT NULL,
  `sessionId` char(32) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_online_admin` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_password_recovery`;

CREATE TABLE `vj_password_recovery` (
  `id` char(32) NOT NULL,
  `userId` char(32) DEFAULT NULL,
  `recordTime` int(11) DEFAULT NULL,
  `keyValue` char(32) DEFAULT NULL,
  `hit` int(11) DEFAULT NULL,
  `inTime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_password_recovery` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_password_recovery_history`;

CREATE TABLE `vj_password_recovery_history` (
  `id` char(32) NOT NULL,
  `userId` char(32) DEFAULT NULL,
  `hit` int(11) DEFAULT NULL,
  `recordTime` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_password_recovery_history` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_resources`;

CREATE TABLE `vj_resources` (
  `resourceId` int(11) NOT NULL,
  `description` varchar(250) DEFAULT NULL,
  `expressionDesc` varchar(150) DEFAULT NULL,
  `resourceName` varchar(50) DEFAULT NULL,
  `resourceType` char(1) DEFAULT NULL,
  `nodeSort` int(11) DEFAULT NULL,
  `parentId` int(11) DEFAULT NULL,
  `language` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`resourceId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_resources` WRITE;

INSERT INTO `vj_resources` VALUES (1,'内容模型','#','内容模型','n',0,0,0),(2,'内容管理','#','内容管理','n',1,1,0),(3,'文章管理列表','/admin/listsFunctionArticle.**','文章列表','u',2,2,0),(4,'访问添加文章表单内容','/admin/addFormFunctionArticle.**','添加表单','u',3,3,0),(5,'添加文章内容','/admin/addFunctionArticle.**','添加','u',4,3,0),(6,'删除文章内容','/admin/deleteFunctionArticle.**','删除','u',5,3,0),(7,'修改文章表单','/admin/modifyFormFunctionArticle.**','修改表单','u',6,3,0),(8,'修改文章内容','/admin/updateFunctionArticle.**','修改','u',7,3,0),(9,'软件列表','/admin/listsFunctionSoft.**','软件列表','u',8,2,0),(10,'添加软件表单','/admin/addFormFunctionSoft.**','添加表单','u',9,9,0),(11,'添加软件内容','/admin/addFunctionSoft.**','添加','u',10,9,0),(12,'删除软件内容','/admin/deleteFunctionSoft.**','删除','u',11,9,0),(13,'修改软件表单','/admin/modifyFormFunctionSoft.**','修改表单','u',12,9,0),(14,'修改软件内容','/admin/updateFunctionSoft.**','修改','u',13,9,0),(15,'内容模块功能','#','内容功能','n',14,1,0),(16,'删除内容列表的静态文件','/admin/deletePageFunctionStaticFile.**','删除静态文件','u',15,15,0),(17,'生成内容列表的静态文件','/admin/genPageFunctionStaticFile.**','生成静态文件','u',16,15,0),(18,'生成内容列表的索引文件','/admin/genpageFunctionLuceneContent.**','生成索引文件','u',17,15,0),(19,'标签管理','/admin/listsFunctionTagList.**','标签管理','u',18,15,0),(20,'删除内容标签','/admin/deleteFunctionTagList.**','删除','u',19,19,0),(21,'评论管理','/admin/listsFunctionComment.**','评论管理','u',20,15,0),(22,'删除评论','/admin/deleteFunctionComment.**','删除','u',21,21,0),(23,'修改评论表单','/admin/modifyFormFunctionComment.**','修改表单','u',22,21,0),(24,'修改评论','/admin/updateFunctionCommen.**','修改','u',23,21,0),(25,'生成静态管理页面','/admin/listsFunctionStaticFile.**','管理静态文件','u',24,15,0),(26,'添加静态文件','/admin/addFunctionStaticFile.**','添加','u',25,25,0),(27,'索引管理','/admin/listsFunctionLuceneContent.**','索引管理','u',26,15,0),(28,'添加索引','/admin/addFunctionLuceneContent.**','添加','u',27,27,0),(29,'删除索引表单','/admin/deleteFormFunctionLuceneContent.**','删除表单','u',28,27,0),(30,'删除索引','/admin/deleteFunctionLuceneContent.**','删除','u',29,27,0),(31,'更新索引表单','/admin/modifyFormFunctionLuceneContent.**','更新表单','u',30,27,0),(32,'更新索引','/admin/updateFunctionLuceneContent.**','更新','u',31,27,0),(33,'栏目管理','/admin/listsFunctionNode.**','栏目管理','u',32,15,0),(34,'添加栏目表单','/admin/addFormFunctionNode.**','添加表单','u',33,33,0),(35,'添加栏目','/admin/addFunctionNode.**','添加','u',34,33,0),(36,'删除栏目','/admin/deleteFunctionNode.**','删除','u',35,33,0),(37,'修改栏目表单','/admin/modifyFormFunctionNode.**','修改表单','u',36,33,0),(38,'修改栏目','/admin/updateFunctionNode.**','修改','u',37,33,0),(39,'用户模型','#','用户模型','n',38,0,0),(40,'前台用户','#','前台用户','n',39,39,0),(41,'会员列表','/admin/listsUserMember.**','会员列表','u',40,40,0),(42,'添加会员表单','/admin/addFormUserMember.**','添加表单','u',41,41,0),(43,'添加会员','/admin/addUserMember.**','添加','u',42,41,0),(44,'删除会员','/admin/deleteUserMember.**','删除','u',43,41,0),(45,'修改会员表单','/admin/modifyFormUserMember.**','修改表单','u',44,41,0),(46,'修改会员','/admin/updateUserMember.**','修改','u',45,41,0),(47,'查看会员','/admin/findUserMember.**','查看','u',46,41,0),(48,'会员组','/admin/listsUserMemberGroup.**','会员组','u',47,40,0),(49,'添加会员组表单','/admin/addFormUserMemberGroup.**','添加表单','u',48,48,0),(50,'添加会员组','/admin/addUserMemberGroup.**','添加','u',49,48,0),(51,'删除会员组','/admin/deleteUserMemberGroup.**','删除','u',50,48,0),(52,'修改会员组表单','/admin/modifyFormUserMemberGroup.**','修改表单','u',51,48,0),(53,'修改会员组','/admin/updateUserMemberGroup.**','修改','u',52,48,0),(54,'后台用户管理','#','后台用户','n',53,39,0),(55,'管理员列表','/admin/listsUserAdmin.**','管理员列表','u',54,54,0),(56,'添加管理员表单','/admin/addFormUserAdmin.**','添加管理员表单','u',55,55,0),(57,'添加管理员','/admin/addUserAdmin.**','添加管理员','u',56,55,0),(58,'删除管理员','/admin/deleteUserAdmin.**','删除管理员','u',57,55,0),(59,'修改管理员表单','/admin/modifyFormUserAdmin.**','修改管理员表单','u',58,55,0),(60,'修改管理员','/admin/updateUserAdmin.**','修改管理员','u',59,55,0),(61,'修改管理员角色表单','/admin/modifyRoleFormUserAdmin.**','修改角色表单','u',60,55,0),(62,'修改管理员角色','/admin/updateRoleUserAdmin.**','修改角色','u',61,55,0),(63,'查看管理员','/admin/findUserAdmin.**','查看管理员','u',62,55,0),(64,'角色列表','/admin/listsPopedomRole.**','角色列表','u',63,54,0),(65,'添加角色表单','/admin/addFormPopedomRole.**','添加角色表单','u',64,64,0),(66,'添加角色','/admin/addPopedomRole.**','添加角色','u',65,64,0),(67,'删除角色','/admin/deletePopedomRole.**','删除角色','u',66,64,0),(68,'修改角色表单','/admin/modifyFormPopedomRole.**','修改表单','u',67,64,0),(69,'修改角色','/admin/updatePopedomRole.**','修改角色','u',68,64,0),(70,'修改角色权限表单','/admin/findPopedomRole.**','修改角色权限表单','u',69,64,0),(71,'修改角色权限','/admin/modifyResourcePopedomRole.**','修改角色权限','u',70,64,0),(72,'修改角色菜单表单','/admin/findNavigatePopedomRole.**','修改角色导航表单','u',71,64,0),(73,'修改角色菜单','/admin/modifyNavigatePopedomRole.**','修改角色导航','u',72,64,0),(74,'权限管理','/admin/listsPopedomResource.**','权限管理','u',73,54,0),(75,'添加权限表单','/admin/addFormPopedomResource.**','添加表单','u',74,74,0),(76,'添加权限','/admin/addPopedomResource.**','添加','u',75,74,0),(77,'删除权限','/admin/deletePopedomResource.**','删除','u',76,74,0),(78,'修改权限表单','/admin/modifyFormPopedomResource.**','修改表单','u',77,74,0),(79,'修改权限','/admin/updatePopedomResource.**','修改','u',78,74,0),(80,'刷新权限','/admin/refreshPopedomResource.**','刷新','u',79,74,0),(81,'登陆日志列表','/admin/listsUserAdminLog.**','登陆日志','u',80,54,0),(82,'删除日志','/admin/deleteUserAdminLog.**','删除','u',81,81,0),(83,'在线管理员','/admin/listsOnlineUserAdmin.**','在线管理员','u',82,54,0),(84,'删除在线管理员','/admin/deleteOnlineUserAdmin.**','删除','u',83,83,0),(85,'系统模型','#','系统模型','n',84,0,0),(86,'系统设置','#','系统设置','n',85,85,0),(87,'站点设置表单','/admin/listsFunctionWebSite.**','站点设置','u',86,86,0),(88,'修改站点','/admin/updateFunctionWebSite.**','修改站点','u',87,87,0),(89,'安全设置','/admin/listsPopedomSafeConfig.**','安全设置','u',88,86,0),(90,'修改安全设置','/admin/updatePopedomSafeConfig.**','修改','u',89,89,0),(91,'菜单设置列表','/admin/listsPopedomNavigate.**','导航设置','u',90,86,0),(92,'添加导航表单','/admin/addFormPopedomNavigate.**','添加表单','u',91,91,0),(93,'添加导航','/admin/addPopedomNavigate.**','添加','u',92,91,0),(94,'删除导航','/admin/deletePopedomNavigate.**','删除','u',93,91,0),(95,'修改导航表单','/admin/modifyFormPopedomNavigate.**','修改表单','u',94,91,0),(96,'修改导航','/admin/updatePopedomNavigate.**','修改','u',95,91,0),(97,'水印设置','/admin/listsFunctionWatermark.**','水印设置','u',96,86,0),(98,'修改水印','/admin/updateFunctionWatermark.**','修改','u',97,97,0),(99,'邮件设置','/admin/listsFunctionEmailConfig.**','邮件设置','u',98,86,0),(100,'修改邮件','/admin/updateFunctionEmailConfig.**','修改','u',99,99,0),(101,'模板设置','/admin/listsFunctionTemplateConfig.**','模板设置','u',100,86,0),(102,'修改模板','/admin/updateFunctionTemplateConfig.**','修改','u',101,101,0),(103,'模板标签设置列表','/admin/listsFunctionTemplateTag.**','模板标签设置','u',102,86,0),(104,'添加模板标签表单','/admin/addFormFunctionTemplateTag.**','添加表单','u',103,103,0),(105,'添加模板标签','/admin/addFunctionTemplateTag.**','添加','u',104,103,0),(106,'删除模板标签','/admin/deleteFunctionTemplateTag.**','删除','u',105,103,0),(107,'修改模板标签表单','/admin/modifyFormFunctionTemplateTag.**','修改表单','u',106,103,0),(108,'修改模板标签','/admin/updateFunctionTemplateTag.**','修改','u',107,103,0),(109,'系统变量设置','/admin/listsFunctionSystemConfig.**','系统变量设置','u',108,86,0),(110,'添加系统变量表单','/admin/addFormFunctionSystemConfig.**','添加表单','u',109,109,0),(111,'添加系统变量','/admin/addFunctionSystemConfig.**','添加','u',110,109,0),(112,'删除系统变量','/admin/deleteFunctionSystemConfig.**','删除','u',111,109,0),(113,'修改系统变量表单','/admin/modifyFormFunctionSystemConfig.**','修改表单','u',112,109,0),(114,'修改系统变量','	 /admin/updateFunctionSystemConfig.**','修改','u',113,109,0),(115,'系统功能','#','系统功能','n',114,85,0),(116,'备份数据','/admin/listsFunctionDatabase.**','备份数据','u',115,115,0),(117,'备份和还原','/admin/executeFunctionDatabase.**','备份和还原','u',116,116,0),(118,'国际化管理','/admin/listsFunctionDictionary.**','国际化管理','u',117,115,0),(119,'添加国际化表单','/admin/addFormFunctionDictionary.**','添加表单','u',118,118,0),(120,'添加国际化','/admin/addFunctionDictionary.**','添加','u',119,118,0),(121,'删除国际化','/admin/deleteFunctionDictionary.**','删除','u',120,118,0),(122,'修改国际化表单','/admin/modifyFormFunctionDictionary.**','修改表单','u',121,118,0),(123,'修改国际化','/admin/updateFunctionDictionary.**','修改','u',122,118,0),(124,'文件管理','/admin/listsFunctionFileManage.**','文件管理','u',123,115,0),(125,'上传文件表单','/admin/addFormFunctionFileManage.**','上传文件表单','u',124,124,0),(126,'上传文件','/admin/uploadFunctionFileManage.**','上传文件','u',125,124,0),(127,'重命文件名表单','/admin/renameFormFunctionFileManage.**','修改文件名表单','u',126,124,0),(128,'修改文件名','/admin/updateRenameFunctionFileManage.**','修改文件名','u',127,124,0),(129,'修改文件数据表单','/admin/modifyFormFunctionFileManage.**','修改文件数据表单','u',128,124,0),(130,'修改文件数据','/admin/updateFunctionFileManage.**','修改文件数据','u',129,124,0),(131,'删除文件','/admin/deleteFunctionFileManage.**','删除文件','u',130,124,0),(132,'创建文件目录','/admin/createDirFunctionFileManage.**','创建文件目录','u',131,124,0),(133,'发送邮件','/admin/listsSendSystemEmail.**','发送邮件','u',132,115,0),(134,'发送邮件','/admin/sendSystemEmail.**','发送','u',133,133,0),(135,'友情链接','/admin/listsFunctionLink.**','友情链接','u',134,115,0),(136,'添加友情链接表单','/admin/addFormFunctionLink.**','添加表单','u',135,135,0),(137,'添加友情链接','/admin/addFunctionLink.**','添加','u',136,135,0),(138,'删除友情链接','/admin/deleteFunctionLink.**','删除','u',137,135,0),(139,'修改友情链接表单','/admin/modifyFormFunctionLink.**','修改表单','u',138,135,0),(140,'修改友情链接','/admin/updateFunctionLink.**','修改','u',139,135,0),(141,'下载网址过滤','/admin/listsPopedomFilterUrl.**','下载网址过滤','u',140,115,0),(142,'添加下载网址过滤表单','/admin/addFormPopedomFilterUrl.**','添加表单','u',141,141,0),(143,'添加下载网址过滤','/admin/addPopedomFilterUrl.**','添加','u',142,141,0),(144,'删除下载网址过滤','/admin/deletePopedomFilterUrl.**','删除','u',143,141,0),(145,'下载网址过滤的修改表单','/admin/modifyFormPopedomFilterUrl.**','修改表单','u',144,141,0),(146,'修改下载网址过滤','/admin/updatePopedomFilterUrl.**','修改','u',145,141,0),(147,'频道模型管理','/admin/listsFunctionChannelModel.**','频道模型管理','u',146,115,0),(148,'添加频道模型表单','/admin/addFormFunctionChannelModel.**','添加表单','u',147,147,0),(149,'添加频道模型','/admin/addFunctionChannelModel.**','添加','u',148,147,0),(150,'删除频道模型','/admin/deleteFunctionChannelModel.**','删除','u',149,147,0),(151,'修改频道模型表单','/admin/modifyFormFunctionChannelModel.**','修改表单','u',150,147,0),(152,'修改频道模型','/admin/updateFunctionChannelModel.**','修改','u',151,147,0),(153,'投票管理','/admin/listsFunctionVote.**','投票管理','u',152,115,0),(154,'添加投票表单','/admin/addFormFunctionVote.**','添加表单','u',153,153,0),(155,'添加投票','/admin/addFunctionVote.**','添加','u',154,153,0),(156,'删除投票','/admin/deleteFunctionVote.**','删除','u',155,153,0),(157,'修改投票表单','/admin/modifyFormFunctionVote.**','修改表单','u',156,153,0),(158,'修改投票','/admin/updateFunctionVote.**','修改','u',157,153,0),(159,'后台首页','/admin/index.**','后台首页','u',158,115,0),(160,'专题列表','/admin/listsFunctionSpecialTopic.**','专题列表','u',159,2,0),(161,'添加表单','/admin/addFormFunctionSpecialTopic.**','添加表单','u',160,160,0),(162,'添加专题','/admin/addFunctionSpecialTopic.**','添加','u',161,160,0),(163,'修改专题表单','/admin/modifyFormFunctionSpecialTopic.**','修改专题表单','u',162,160,0),(164,'修改专题','/admin/updateFunctionSpecialTopic.**','修改','u',163,160,0),(165,'删除专题','/admin/deleteFunctionSpecialTopic.**','删除','u',164,160,0),(166,'视频列表','/admin/listsFunctionVideo.**','视频列表','u',165,2,0),(167,'添加表单','/admin/addFormFunctionVideo.**','添加表单','u',166,166,0),(168,'添加','/admin/addFunctionVideo.**','添加','u',167,166,0),(169,'修改表单','/admin/modifyFormFunctionVideo.**','修改表单','u',168,166,0),(170,'修改','/admin/updateFunctionVideo.**','修改','u',169,166,0),(171,'删除','/admin/deleteFunctionVideo.**','删除','u',170,166,0),(172,'CMS类型列表','/admin/listsFunctionCmsType.**','CMS类型列表','u',171,2,0),(173,'添加CMS类型表单','/admin/addFormFunctionCmsType.**','添加表单','u',172,172,0),(174,'添加CMS类型','/admin/addFunctionCmsType.**','添加','u',173,172,0),(175,'修改CMS类型表单','/admin/modifyFormFunctionCmsType.**','修改表单','u',174,172,0),(176,'修改CMS类型','/admin/updateFunctionCmsType.**','修改','u',175,172,0),(177,'删除CMS类型','/admin/deleteFunctionCmsType.**','删除','u',176,172,0),(178,'文章移动表单','/admin/moveFormFunctionArticle.**','移动表单','u',177,3,0),(179,'文章移动','/admin/moveSubmitFunctionArticle.**','移动提交','u',178,3,0),(180,'软件移动表单','/admin/moveFormFunctionSoft.**','软件移动表单','u',179,9,0),(181,'移动表单','/admin/moveSubmitFunctionSoft.**','移动提交','u',180,9,0),(182,'设置我的账号表单','/admin/myModifyFormUserAdmin.**','设置账号','u',181,54,0),(183,'修改我的资料','/admin/myUpdateUserAdmin.**','修改','u',182,182,0),(184,'会员登录设置','/admin/listsMemberPopedomSafeConfig.**','会员登录设置','u',183,86,0),(185,'修改会员登录配置','/admin/updateMemberPopedomSafeConfig.**','修改','u',184,184,0),(186,'生成静态文件','/admin/genNodeFunctionStaticFile.**','生成静态文件','u',185,33,0),(187,'删除静态文件','/admin/deleteNodeFunctionStaticFile.**','删除静态文件','u',186,33,0),(188,'上传图片表单','/admin/uploadImageForm.**','上传图片表单','u',187,15,0),(189,'上传图片','/admin/uploadImageFile.**','上传图片','u',188,188,0),(190,'上传附件表单','/admin/uploadAttachmentForm.**','上传附件表单','u',189,15,0),(191,'上传附件','/admin/uploadAttachmentFile.**','上传附件','u',190,190,0),(192,'评论审核','/admin/uploadAttachmentFile.**','评论审核','u',191,21,0),(193,'关键字历史列表','/admin/listsFunctionKeywordHistory.**','关键字历史列表','u',192,15,0),(194,'删除关键字','/admin/deleteFunctionKeywordHistory.**','删除','u',193,193,0),(195,'Oauth登录设置','/admin/listsFunctionOauthConfig.**','Oauth登录设置','u',194,86,0),(196,'添加表单','/admin/addFormFunctionOauthConfig.**','添加表单','u',195,195,0),(197,'添加','/admin/addFunctionOauthConfig.**','添加','u',196,195,0),(198,'修改表单','/admin/modifyFormFunctionOauthConfig.**','修改表单','u',197,195,0),(199,'修改','/admin/updateFunctionOauthConfig.**','修改','u',198,195,0),(200,'删除','/admin/deleteFunctionOauthConfig.**','删除','u',199,195,0),(201,'支付订单列表','/admin/listsFunctionPayOrder.**','支付订单列表','u',200,40,0),(202,'已付款','/admin/confirmFunctionPayOrder.**','已付款','u',201,201,0),(203,'删除','/admin/deleteFunctionPayOrder.**','删除','u',202,201,0),(204,'专题搜索','/admin/selectFromScpecialTopicContent.**','专题搜索','u',203,160,0),(205,'移动表单','/admin/moveFormFunctionVideo.**','移动表单','u',204,166,0),(206,'移动提交','/admin/moveSubmitFunctionVideo.**','移动提交','u',205,166,0),(207,'图片列表','/admin/listsFunctionPhoto.**','图片列表','u',206,2,0),(208,'添加表单','/admin/addFormFunctionPhoto.**','添加表单','u',207,207,0),(209,'添加','/admin/addFunctionPhoto.**','添加','u',208,207,0),(210,'修改表单','/admin/modifyFormFunctionPhoto.**','修改表单','u',209,207,0),(211,'修改图片','/admin/updateFunctionPhoto.**','修改','u',210,207,0),(212,'删除图片','/admin/deleteFunctionPhoto.**','删除','u',211,207,0),(213,'移动表单','/admin/moveFormFunctionPhoto.**','移动表单','u',212,207,0),(214,'移动提交','/admin/moveSubmitFunctionPhoto.**','移动提交','u',213,207,0),(215,'上传表单','/admin/uploadFormFunctionPhoto.**','上传表单','u',214,207,0);


UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_role_navigate`;

CREATE TABLE `vj_role_navigate` (
  `roleId` int(11) NOT NULL,
  `navigateId` int(11) NOT NULL,
  PRIMARY KEY (`roleId`,`navigateId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_role_navigate` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_role_resource`;

CREATE TABLE `vj_role_resource` (
  `roleId` int(11) NOT NULL,
  `resourceId` int(11) NOT NULL,
  PRIMARY KEY (`roleId`,`resourceId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_role_resource` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_roles`;

CREATE TABLE `vj_roles` (
  `roleId` int(11) NOT NULL,
  `description` varchar(250) DEFAULT NULL,
  `roleName` varchar(50) DEFAULT NULL,
  `language` tinyint(4) DEFAULT NULL,
  PRIMARY KEY (`roleId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_roles` WRITE;

INSERT INTO `vj_roles` VALUES (0,'超级管理员','超级管理员',0);

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_safe_config`;

CREATE TABLE `vj_safe_config` (
  `configId` char(1) NOT NULL,
  `isAccountExpire` char(1) DEFAULT NULL,
  `isVerCode` char(1) DEFAULT NULL,
  `isLockAccount` char(1) DEFAULT NULL,
  `isPassExpire` char(1) DEFAULT NULL,
  `isEnable` char(1) DEFAULT NULL,
  `isAutoRelieve` char(1) DEFAULT NULL,
  `accountLockTime` int(11) DEFAULT NULL,
  `accountExpireTime` int(11) DEFAULT NULL,
  `disableCount` int(11) DEFAULT NULL,
  `passwordExpireTime` int(11) DEFAULT NULL,
  `passwordErrorCount` int(11) DEFAULT NULL,
  PRIMARY KEY (`configId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_safe_config` WRITE;

INSERT INTO `vj_safe_config` VALUES ('1','T','F','T','T','T','T',2,20,3,33,3),('2','T','F','T','T','T','T',2,20,3,33,3);

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_softs`;

CREATE TABLE `vj_softs` (
  `id` char(32) NOT NULL,
  `fileType` int(11) DEFAULT NULL,
  `fileSize` varchar(50) DEFAULT NULL,
  `star` char(1) DEFAULT NULL,
  `runSystem` int(11) DEFAULT NULL,
  `website` varchar(250) DEFAULT NULL,
  `language` int(11) DEFAULT NULL,
  `authorize` varchar(50) DEFAULT NULL,
  `email` varchar(250) DEFAULT NULL,
  `downloadUrl` text,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_softs` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_system_config`;

CREATE TABLE `vj_system_config` (
  `id` int(11) NOT NULL,
  `varName` varchar(150) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `type` int(11) DEFAULT NULL,
  `value` varchar(250) DEFAULT NULL,
  `modelId` int(11) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `IX_vj_system_config_varName` (`varName`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_system_config` WRITE;

INSERT INTO `vj_system_config` VALUES (1,'core_isAdminLog','是否开启管理员日志',2,'T',0,'T'),(2,'cms_register_welcome','是否发送注册欢迎信',2,'F',0,'T'),( 3, 'cms_memberUpgradeCosts', '升级会员费用', 4, '100', 0, 'T'),(4,'cms_installDirectory','CMS安装目录',0,'/',0,'T'),(5,'cms_imageUrl','图片域名地址',0,'http://localhost/cms',0,'T'),(6,'cms_imageUploadDirectory','图片上传目录',0,'/upload/image/',0,'F'),(7,'core_coding','系统编码',0,'utf-8',0,'T'),(8,'core_staticSuffix','静态后缀',0,'.html',0,'T'),(9,'core_dynamicSuffix','动态后缀',0,'.jhtml',0,'T'),(10,'core_folderStyle','1(年月日)2(年月)3(年)格式',1,'2',0,'T'),(11,'cms_softUploadDirectory','软件路径',0,'/upload/soft/',0,'T'),(12,'cms_softAddress','软件下载地址',0,'http://localhost/cms',0,'T'),(13,'cms_isSha1','T真,F假',2,'T',0,'T'),(14,'cms_isContentLucene','全文搜索',2,'T',0,'F'),(15,'cms_memberFaceUploadDirectory','会员头像上传路径',0,'/upload/face/',0,'T'),(16,'cms_alipayInfo','支付宝信息',0,'partner,prestrKey,sellerEmail',0,'T'),(17, 'cms_memberSubmission', '会员登录投稿', 2, 'F', 0, 'T'),(18, 'cms_isAuditComment', '评论审核', 2, 'T', 0, 'T'),(19, 'cms_thumbnails_width', '略缩图宽度', 1, '120', 0, 'T'),(20, 'cms_thumbnails_height', '略缩图高度', 1, '120', 0, 'T'),(21,'cms_aliyun_oss_config','阿里云OSS配置信息(ID,Secret,URL)',0,'ID,Secret,URL',0,'T'),(22,'cms_aliyun_oss_bucketName','阿里云OSS的bucketName值',0,'vijun',0,'T'),(23, 'cms_user_init_capacity', '用户初始网盘容量(MB/单位)', 1, '50', 0, 'T');

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_tag_list`;

CREATE TABLE `vj_tag_list` (
  `tagId` char(32) NOT NULL,
  `contentId` char(32) DEFAULT NULL,
  `nodeId` int(11) DEFAULT NULL,
  `tagName` varchar(20) DEFAULT NULL,
  `tagTime` int(11) DEFAULT NULL,
  PRIMARY KEY (`tagId`),
  KEY `IX_vj_tag_list_tagName` (`tagName`),
  KEY `IX_vj_tag_list_contentId` (`contentId`),
  KEY `IX_vj_tag_list_tagTime` (`tagTime`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_tag_list` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_template_config`;

CREATE TABLE `vj_template_config` (
  `id` int(11) NOT NULL,
  `templateLocale` int(11) DEFAULT NULL,
  `dateTimeFormat` varchar(50) DEFAULT NULL,
  `dateFormat` varchar(50) DEFAULT NULL,
  `timeFormat` varchar(50) DEFAULT NULL,
  `numberFormat` varchar(50) DEFAULT NULL,
  `tagSyntax` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_template_config` WRITE;

INSERT INTO `vj_template_config` VALUES (1,0,'yyyy-MM-dd HH:mm:ss','yyyy-MM-dd','HH:mm:ss','0.######',2);
UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_template_tag`;

CREATE TABLE `vj_template_tag` (
  `tagId` int(11) NOT NULL,
  `tagName` varchar(50) DEFAULT NULL,
  `tagClass` varchar(250) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  PRIMARY KEY (`tagId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_template_tag` WRITE;

INSERT INTO `vj_template_tag` VALUES (1,'sys_list_c','com.vijun.cms.util.freemarker.directive.ContentListDirective','内容列表','1'),(2,'sys_cut','com.vijun.cms.util.freemarker.directive.CutDirective','文本剪切','1'),(3,'sys_list','com.vijun.cms.util.freemarker.directive.NodeListDirective','栏目列表','1'),(4,'sys_list_cp','com.vijun.cms.util.freemarker.directive.ContentListByCountDirective','内容列表带分页','1'),(5,'sys_pagination','com.vijun.cms.util.freemarker.directive.PaginationDirective','分页标签','1'),(6,'sys_member','com.vijun.cms.util.freemarker.directive.MemberDirective','会员内容','1'),(7,'sys_search','com.vijun.cms.util.freemarker.directive.SearchDirective','搜索内容','1'),(8,'sys_lucene','com.vijun.cms.util.freemarker.directive.LuceneSearchDirective','全文搜索','1'),(9,'sys_timeZone','com.vijun.cms.util.freemarker.directive.TimeZoneDirective','时区','1'),(10,'sys_sql','com.vijun.cms.util.freemarker.directive.SqlDirective','sql标签','1'),(11,'sys_format','com.vijun.cms.util.freemarker.directive.TextFormatDirective','内容格式化','1'),(12,'sys_special','com.vijun.cms.util.freemarker.directive.SpecialTopicDirective','专题','1');

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_video`;

CREATE TABLE `vj_video` (
  `id` char(32) NOT NULL,
  `playerUrl` varchar(255) DEFAULT NULL,
  `videoTime` varchar(50) DEFAULT NULL,
  `language` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_video` WRITE;



UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_vote`;

CREATE TABLE `vj_vote` (
  `id` int(11) NOT NULL,
  `subject` varchar(250) DEFAULT NULL,
  `startTime` int(11) DEFAULT NULL,
  `endTime` int(11) DEFAULT NULL,
  `hit` int(11) DEFAULT NULL,
  `status` char(1) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_vote` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_vote_topic`;

CREATE TABLE `vj_vote_topic` (
  `id` char(32) NOT NULL,
  `title` varchar(250) DEFAULT NULL,
  `voteCount` int(11) DEFAULT NULL,
  `voteId` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `IX_vj_vote_topic_voteId` (`voteId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

LOCK TABLES `vj_vote_topic` WRITE;

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_watermark`;

CREATE TABLE `vj_watermark` (
  `watermarkId` char(1) NOT NULL,
  `watermarkPath` varchar(250) DEFAULT NULL,
  `alpha` char(3) DEFAULT NULL,
  `watermarkPosition` int(11) DEFAULT NULL,
  `spacingX` int(11) DEFAULT NULL,
  `spacingY` int(11) DEFAULT NULL,
  `watermarkText` varchar(250) DEFAULT NULL,
  `fontPath` varchar(250) DEFAULT NULL,
  `fontColor` char(6) DEFAULT NULL,
  `fontSize` int(11) DEFAULT NULL,
  `watermarkType` char(1) DEFAULT NULL,
  `width` int(11) DEFAULT NULL,
  `height` int(11) DEFAULT NULL,
  PRIMARY KEY (`watermarkId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_watermark` WRITE;

INSERT INTO `vj_watermark` VALUES ('1','/template/images/mark.png','0.5',9,-20,1,'技术网','/template/font/1.ttf','B22222',20,'1',300,200);

UNLOCK TABLES;
DROP TABLE IF EXISTS `vj_web_config`;

CREATE TABLE `vj_web_config` (
  `configId` char(1) NOT NULL,
  `websiteName` varchar(250) DEFAULT NULL,
  `publicityTitle` varchar(250) DEFAULT NULL,
  `url` varchar(250) DEFAULT NULL,
  `templateDir` varchar(250) DEFAULT NULL,
  `keyword` varchar(250) DEFAULT NULL,
  `description` varchar(250) DEFAULT NULL,
  `recordNumber` varchar(50) DEFAULT NULL,
  `powerby` varchar(2000) DEFAULT NULL,
  `systemVersion` varchar(50) DEFAULT NULL,
  PRIMARY KEY (`configId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;


LOCK TABLES `vj_web_config` WRITE;

INSERT INTO `vj_web_config` VALUES ('1','微骏技术网','努力做好java技术平台','http://www.vijun.com','/WEB-INF/cms/template/default/zh_CN/','java','微骏技术网','沪ICP备12006519号-1','Copyright  2012 vijun.com All Rights Reserved.','1.0 Release');

UNLOCK TABLES;
