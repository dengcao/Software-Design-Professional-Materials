﻿
						微骏CMS系统产品使用说明 


一、平台需求
1.Windows和平台：
Apache+tomcat/Nginx + tomcat/jboss/ + (MSSQL 2005、mysql 5.x、Oracle、Sybase、DB2、PostgreSQL)

2.基本目录结构
/
/admin       系统后台管理文件目录
/member      会员后台文件目录
/install     系统安装目录（安装完毕后建议删除）
/META-INF    无
/template    模板文件目录（前台模板的文件统一放到这）
/WEB-INF     系统重要文件目录（请给予相关文件夹访问权限，防止被黑客利用）



二、程序安装使用
1.下载程序解压到本地目录;
2.上传程序到网站根目录
3.运行http://www.yourname.com/install/(yourname表示你的域名),按照安装提速说明进行程序安装
 
三、相关资源
微骏CMS官方主站       www.vijun.com
论坛                  bbs.vijun.com