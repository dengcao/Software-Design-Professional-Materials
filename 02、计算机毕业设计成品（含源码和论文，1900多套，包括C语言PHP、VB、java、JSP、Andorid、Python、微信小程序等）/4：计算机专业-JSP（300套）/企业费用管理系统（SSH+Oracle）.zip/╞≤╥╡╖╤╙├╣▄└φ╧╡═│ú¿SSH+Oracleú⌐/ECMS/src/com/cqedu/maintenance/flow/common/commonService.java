package com.cqedu.maintenance.flow.common;

public interface commonService {
  
}
