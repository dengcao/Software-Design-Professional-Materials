package com.cqedu.finance.common.service;

public interface CommonService {

}
