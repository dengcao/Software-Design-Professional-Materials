package com.cqedu.reim.common.service;

public interface CommonService {

}
