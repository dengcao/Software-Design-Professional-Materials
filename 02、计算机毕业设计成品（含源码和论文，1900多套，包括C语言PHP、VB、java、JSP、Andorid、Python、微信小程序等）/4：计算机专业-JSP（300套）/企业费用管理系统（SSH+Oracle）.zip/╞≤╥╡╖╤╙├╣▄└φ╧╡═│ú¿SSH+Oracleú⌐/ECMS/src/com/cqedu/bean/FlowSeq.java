package com.cqedu.bean;

public class FlowSeq extends AbstractFlowSeq {

	/**
	 * 
	 */
	private static final long serialVersionUID = -931829145821723316L;

	public FlowSeq() {
		super();
		// TODO Auto-generated constructor stub
	}

	public FlowSeq(Integer flowsid, Flow flow, Seq seq, Integer flowsequence,
			Integer isdelete) {
		super(flowsid, flow, seq, flowsequence, isdelete);
		// TODO Auto-generated constructor stub
	}

    

    
	
	

}
