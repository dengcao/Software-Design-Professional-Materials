package com.cqedu.budget.applist.common.service;

public interface CommonService {

}
