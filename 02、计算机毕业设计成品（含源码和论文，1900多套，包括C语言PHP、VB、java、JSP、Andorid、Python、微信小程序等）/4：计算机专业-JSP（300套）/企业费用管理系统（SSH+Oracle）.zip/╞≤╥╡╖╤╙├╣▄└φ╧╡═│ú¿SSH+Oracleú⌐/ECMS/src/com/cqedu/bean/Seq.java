package com.cqedu.bean;

public class Seq extends AbstractSeq {

	/**
	 * 
	 */
	private static final long serialVersionUID = -2726103784592783920L;

	public Seq() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Seq(Integer sid, Integer id, String name, Integer isdelete) {
		super(sid, id, name, isdelete);
		// TODO Auto-generated constructor stub
	}

	
	
    

	

	
	

}
