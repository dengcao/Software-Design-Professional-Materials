package com.cqedu.maintenance.user.common;

public interface commonService {

}
