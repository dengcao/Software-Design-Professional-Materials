package com.cqedu.bean;

public class Department extends AbstractDepartment {
	

}
