package com.cqedu.bean;

public class Role extends AbstractRole {

	public Role() {
		super();
	}

}
