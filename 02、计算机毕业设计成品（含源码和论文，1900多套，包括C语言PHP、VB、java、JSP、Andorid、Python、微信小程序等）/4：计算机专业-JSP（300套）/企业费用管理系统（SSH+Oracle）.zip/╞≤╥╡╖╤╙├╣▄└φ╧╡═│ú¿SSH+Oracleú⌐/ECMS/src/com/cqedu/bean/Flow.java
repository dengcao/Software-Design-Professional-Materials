package com.cqedu.bean;

import java.math.BigDecimal;




public class Flow extends AbstractFlow {

	/**
	 * 
	 */
	private static final long serialVersionUID = -389265408924819403L;

	public Flow() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Flow(Integer fid, String fname, String ftype, User user,
			Integer maxseqno, BigDecimal isdelete) {
		super(fid, fname, ftype, user, maxseqno, isdelete);
		// TODO Auto-generated constructor stub
	}
    
   

	
    
	
	
	
}


