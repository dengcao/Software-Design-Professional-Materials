package com.fhway.spring.aop;

public interface Hello {
	public void sayHello(String name);
}
