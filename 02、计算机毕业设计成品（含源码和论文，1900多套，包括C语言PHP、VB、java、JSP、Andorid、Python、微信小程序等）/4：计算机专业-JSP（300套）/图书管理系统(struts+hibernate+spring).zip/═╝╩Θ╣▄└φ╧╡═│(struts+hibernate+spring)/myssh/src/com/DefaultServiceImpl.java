package com;

public class DefaultServiceImpl {

	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
	public void gg(){
    	System.out.println("gggg");
    }
}
