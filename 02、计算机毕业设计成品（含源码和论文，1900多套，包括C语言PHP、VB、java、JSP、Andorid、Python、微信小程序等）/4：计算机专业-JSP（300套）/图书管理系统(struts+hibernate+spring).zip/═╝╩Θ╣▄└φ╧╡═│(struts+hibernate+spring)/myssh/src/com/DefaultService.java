package com;

public class DefaultService {
	private DefaultServiceImpl DService;
	public DefaultServiceImpl getDService() {
		return DService;
	}
	public void setDService(DefaultServiceImpl service) {
		DService = service;
	}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}
    public void gg(){
    	System.out.println("gggg");
    }
}
