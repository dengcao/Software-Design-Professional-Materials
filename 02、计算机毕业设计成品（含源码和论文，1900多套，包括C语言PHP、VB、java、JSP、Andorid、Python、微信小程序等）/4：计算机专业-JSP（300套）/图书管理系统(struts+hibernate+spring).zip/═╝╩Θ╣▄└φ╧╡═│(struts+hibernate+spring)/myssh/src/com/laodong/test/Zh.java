package com.laodong.test;

public class Zh {
   public String re(){
	   ThreadLocal l;
	   return "ok";
   }
}
