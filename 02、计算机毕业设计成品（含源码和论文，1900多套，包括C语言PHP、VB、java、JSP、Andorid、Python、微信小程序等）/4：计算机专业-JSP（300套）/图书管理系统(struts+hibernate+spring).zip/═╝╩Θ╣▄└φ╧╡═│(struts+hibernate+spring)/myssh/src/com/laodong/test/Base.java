package com.laodong.test;

public class Base {
	 static  int i;
	 {
		i=0;
	}
  static public void aa(int i){
	  
  }
  public int hashCode(){
	  return 0;
  }
}

