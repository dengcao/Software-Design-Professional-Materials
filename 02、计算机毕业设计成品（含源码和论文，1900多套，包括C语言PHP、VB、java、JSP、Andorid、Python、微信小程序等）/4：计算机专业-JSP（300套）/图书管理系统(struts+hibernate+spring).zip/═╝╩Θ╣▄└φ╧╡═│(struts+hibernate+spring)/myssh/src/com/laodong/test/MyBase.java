package com.laodong.test;

public class MyBase extends Base{
	static public void aa(int i){

	}

}

