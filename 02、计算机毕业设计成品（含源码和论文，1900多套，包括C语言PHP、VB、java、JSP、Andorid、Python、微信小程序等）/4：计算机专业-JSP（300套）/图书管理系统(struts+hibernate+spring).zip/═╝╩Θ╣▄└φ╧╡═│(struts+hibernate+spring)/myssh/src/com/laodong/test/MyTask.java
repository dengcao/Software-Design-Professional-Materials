package com.laodong.test;

import java.util.TimerTask;

public class MyTask extends TimerTask{
	public void run()
    {
       System.out.println( "Hi" );
    }

}
