package com.laodong.test;

public interface MyInterface {
 static int a=0;
}

