package com.laodong.test;

public class TwoSubClass extends SubClass{
	void aa(){}
}

