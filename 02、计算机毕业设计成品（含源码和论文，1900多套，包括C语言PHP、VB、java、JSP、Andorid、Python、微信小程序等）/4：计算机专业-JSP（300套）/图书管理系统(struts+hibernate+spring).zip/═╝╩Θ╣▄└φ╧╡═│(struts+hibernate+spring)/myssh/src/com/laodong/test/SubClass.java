package com.laodong.test;

public abstract class SubClass extends Base{
    abstract  void aa();
}

