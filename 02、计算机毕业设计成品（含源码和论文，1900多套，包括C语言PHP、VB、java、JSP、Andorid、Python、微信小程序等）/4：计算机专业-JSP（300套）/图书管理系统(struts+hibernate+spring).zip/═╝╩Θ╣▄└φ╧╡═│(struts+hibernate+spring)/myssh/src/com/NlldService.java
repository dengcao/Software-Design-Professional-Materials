package com;

public class NlldService {
	public void taxInsBookinfoObj(Bookinfo obj)throws Exception{
		
	}
}
