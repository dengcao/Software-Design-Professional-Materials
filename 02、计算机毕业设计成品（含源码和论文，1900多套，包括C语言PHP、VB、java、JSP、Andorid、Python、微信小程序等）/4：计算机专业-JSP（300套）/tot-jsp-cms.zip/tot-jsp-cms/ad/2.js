document.write('<a href="http://www.sohu.com" target="_blank"><img src="/upload/2008-08-11/1459662688.jpg" border="0" width="200" height="80"></a>');
