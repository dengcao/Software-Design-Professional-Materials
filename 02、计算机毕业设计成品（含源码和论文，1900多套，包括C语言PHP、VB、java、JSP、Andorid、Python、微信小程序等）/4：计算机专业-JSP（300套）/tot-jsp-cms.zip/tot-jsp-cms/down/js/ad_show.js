// JavaScript Document
document.write('<img src="" width="250" height="200" />');