-- ----------------------------
-- Table structure for ad
-- ----------------------------
CREATE TABLE `ad` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(255) default '',
  `url` varchar(255) default '',
  `stime` datetime default '2009-06-01 12:41:33',
  `etime` datetime default '2009-06-01 12:41:33',
  `addid` int(11) default '0',
  `time` datetime default '2009-06-01 12:41:33',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for admin
-- ----------------------------
CREATE TABLE `admin` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(255) default '',
  `user` varchar(50) default '',
  `passw` varchar(255) default '',
  `roleid` int(11) default '1',
  `lasttime` datetime default '2009-06-01 12:41:33',
  `lastip` varchar(20) default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for flv
-- ----------------------------
CREATE TABLE `flv` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(255) default '',
  `homeid` int(11) default '0',
  `typeid` int(11) default '0',
  `serid` int(11) default '0',
  `adid` int(11) default '0',
  `file` varchar(150) default '',
  `body` mediumtext,
  `flvpic` varchar(255) default '',
  `isbest` int(2) default '0',
  `hot` int(11) default '0',
  `addid` int(11) default '0',
  `time` datetime default '2009-06-01 12:41:33',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for home
-- ----------------------------
CREATE TABLE `home` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `title` varchar(255) default '',
  `body` text,
  `homepic` varchar(100) default '',
  `isbest` int(2) default '0',
  `addid` int(11) default '0',
  `time` datetime default '2009-06-01 12:41:33',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for role
-- ----------------------------
CREATE TABLE `role` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(255) default '',
  `scopeid` varchar(255) default '0',
  `time` datetime default '2009-06-01 12:41:33',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for scope
-- ----------------------------
CREATE TABLE `scope` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(255) default '',
  `note` varchar(255) default '',
  `time` datetime default '2009-06-01 12:41:33',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for ser
-- ----------------------------
CREATE TABLE `ser` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(255) default '',
  `dir` varchar(150) default '',
  `addid` int(11) default '0',
  `time` datetime default '2009-06-01 12:41:33',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Table structure for type
-- ----------------------------
CREATE TABLE `type` (
  `id` int(11) unsigned NOT NULL auto_increment,
  `name` varchar(255) default '',
  `parent` int(11) default '0',
  `addid` int(11) default '0',
  `time` datetime default '2009-06-01 12:41:33',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=gbk;

-- ----------------------------
-- Records 
-- ----------------------------
INSERT INTO `admin` VALUES ('1', 'jspgen', 'JSPGen', 'A7B64CAC904F6F1A1912C6F1C3396A14', '1', '2009-06-01 12:41:33', '');
INSERT INTO `flv` VALUES ('1', '�Ϸ���Ȼ����', '0', '2', '1', '0', '1250684690421.flv', '', '1250684690421.jpg', '1', '1452', '1', '2007-07-17 11:09:02');
INSERT INTO `role` VALUES ('1', 'ϵͳ����', '1,2,3,4,5,6,7,8,9', '2009-06-01 12:41:33');
INSERT INTO `scope` VALUES ('1', 'Ȩ�޹���', '', '2009-06-01 12:41:33');
INSERT INTO `scope` VALUES ('2', '��ɫ����', '', '2009-06-01 12:41:33');
INSERT INTO `scope` VALUES ('3', '����Ա����', '', '2009-06-01 12:41:33');
INSERT INTO `scope` VALUES ('4', '�������', '', '2009-06-01 12:41:33');
INSERT INTO `scope` VALUES ('5', 'ר������', '', '2009-06-01 12:41:33');
INSERT INTO `scope` VALUES ('6', '��Ƶ����', '', '2009-06-01 12:41:33');
INSERT INTO `scope` VALUES ('7', '������', '', '2009-06-01 12:41:33');
INSERT INTO `scope` VALUES ('8', '����������', '', '2009-06-01 12:41:33');
INSERT INTO `scope` VALUES ('9', '������Ϣ', '', '2009-06-01 12:41:33');
INSERT INTO `ser` VALUES ('1', '����', 'swf', '1', '2009-06-01 12:41:33');
INSERT INTO `type` VALUES ('1', '����MTV', '0', '1', '2009-06-01 12:41:33');
INSERT INTO `type` VALUES ('2', '��������', '0', '1', '2009-06-01 12:41:33');
INSERT INTO `type` VALUES ('3', '���µ�Ӱ', '0', '1', '2009-06-01 12:41:33');
INSERT INTO `type` VALUES ('4', '�����', '0', '1', '2009-06-01 12:41:33');
INSERT INTO `type` VALUES ('5', '���ű���', '0', '1', '2009-06-01 12:41:33');
