function InFlvUrl(){
	document.all.flvurl.value = document.all.flv.value;
}
function InPicUrl(){
	document.all.picurl.value = document.all.pic.value;
}
function OpenUrl(url,i){
	if(i==0){width = 370;height = 150;}else{width = 370;height = 200;}
	x = (screen.width-width)/2;y = (screen.height-height)/2;
	window.open(url,"�ϴ��ļ�","height="+height+",width="+width+",top="+y+",left="+x+",toolbar=no,menubar=no,scrollbars=no, resizable=no,location=no,status=no");
}
function doSearch(){
	if(isNull($GenID('key').value)){
		alert('�ؼ��ֲ���Ϊ�գ�');
		$GenID('key').focus();
		return false;
	}
	return true;
}