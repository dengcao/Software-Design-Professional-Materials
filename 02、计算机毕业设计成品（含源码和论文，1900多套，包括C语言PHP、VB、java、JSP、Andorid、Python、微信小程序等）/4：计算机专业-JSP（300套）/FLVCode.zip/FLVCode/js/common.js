function killerrors(){return true;}window.onerror=killerrors;
//״̬����ʾ����
window.defaultStatus="��ѧ��Ƶ ������ѧ����ĵ��ε�... ������Ƶ����ϵQQ:190582560"; 

function AddFav(url,title){
     if(document.all){
	 window.external.AddFavorite(url,title);
     }else if(window.sidebar){
	 window.sidebar.addPanel(title,url,'');
     }
}
function ToCopy(txt){
	window.clipboardData.setData("Text",txt);
	alert("�����Ѿ����Ƶ���������! �밴 Ctrl+V ճ��...");
}
function BackURL(url,target){
	 var urlStr='about:blank';	var targetStr='index';
     if(!isNull(url)){urlStr = url;}
	 if(!isNull(target)){targetStr = target;}
	 window.open(urlStr,targetStr);
}
function OpenURL(url, width, height){
	var x=(screen.width-width)/2; var y=(screen.height-height)/2;
	window.open(url,'��������','height='+height+',width='+width+',top='+y+',left='+x+',toolbar=no,menubar=no,scrollbars=no, resizable=no,location=no,status=no');
}
function InUrl(name,url){
	$GenID(name).value = $GenID(url).value;
}
function redirect(url){
	BackURL(url,'');
}
function confirmurl(url,message){
	if(confirm(message)) redirect(url);
}
function confirmform(form,message){
	if(confirm(message)) form.submit();
}
//Cookie����
function setCookie(name,value,expire){ 
	var cookieString=name+'='+encodeURI(value); 
	if(expire>0){
		var date=new Date();
		date.setTime(date.getTime+expire); 
		cookieString=cookieString+';expire='+date.toGMTString(); 
	}
	document.cookie=cookieString; 
}
function getCookie(name){ 
	var strCookie=document.cookie; 
	var arrCookie=strCookie.split('; '); 
	for(var i=0;i<arrCookie.length;i++){ 
		var arr=arrCookie[i].split('='); 
		if(arr[0]==name)return decodeURI(arr[1]); 
	} 
	return '';
} 
function delCookie(name){ 
	var date=new Date(); 
	date.setTime(date.getTime()-10000); 
	document.cookie=name+'=v;expire='+date.toGMTString(); 
}
function $GenID(id) {
	return document.getElementById(id);
}
function $GenName(name) {
	return document.getElementsByName(name);
}
function isNull(str){//��ֵ���
	if(str == '') return true; 
	var regu = '^[ ]+$'; 
	var re = new RegExp(regu); 
	return re.test(str); 
}
function isEnglish(str){//Ӣ��ֵ���
	if(str.length == 0)	return false;
	for(i=0; i<str.length; i++){
		if(str.charCodeAt(i)>128)	return false;
	}
	return true;
}
function isChinese(str){//����ֵ���
	if(str.length == 0)	return false;
	for(i=0; i<str.length; i++) {
		if(str.charCodeAt(i)>128)	return true;
	}
	return false;
}
function isEmail(str){//E-mailֵ���
	var myReg = /^[-_A-Za-z0-9]+@([_A-Za-z0-9]+\.)+[A-Za-z0-9]{2,3}$/; 
	if(myReg.test(str)) return true; 
	return false; 
}
function isNumber(str){//��ֵ���
	if(str.length == 0)	return false;
	for(i=0; i<str.length; i++){
		if(str.charAt(i)<'0' || str.charAt(i)>'9')	return false;
	}
	return true;
}
function isNum(str){
	var Letters = '1234567890';//�����Լ����ӿ�����ֵ
	var i;	var c;
	for(i=0; i<str.length; i++){
		c = Str.charAt(i);
		if(Letters.indexOf(c)<0)	return  false;
		return  true;
	}
}
function isIP(str){//IP���
	if(isNull(str)) return false; 
	var re=/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/g
	//ƥ��IP��ַ���������ʽ 
	if(re.test(str)){ 
		if( RegExp.$1<256 && RegExp.$2<256 && RegExp.$3<256 && RegExp.$4<256) return true; 
	} 
	return false; 
}
function isMobile(str){//�ֻ����
	var regu = /^(13[0-9]|15[0|3|6|7|8|9]|18[8|9])\d{8}$/g
	//130 131 132 133 134 135 136 137 138 139 150 158 159
	var re = new RegExp(regu); 
	if(re.test(str)){ 
		return true; 
	}else{ 
		return false; 
	} 
}
//ȡֵ
function CheckValue(name,gap){
	var value='';
	var checkes = $GenName(name);
	for(i=0;i<checkes.length;i++){
		if(checkes[i].checked){			
			value += (value == '' ? checkes[i].value : gap+checkes[i].value);
		}
	}
	return value;	/*alert(value);*/
}
//ȫѡ ��ѡ
function CheckAllNot(id,name){
	var checkes = $GenName(name);
	if($GenID(id).checked==true){
		for(i=0;i<checkes.length;i++){
			checkes[i].checked=true;
		}
	}else{
		for(i=0;i<checkes.length;i++){
			checkes[i].checked=false;
		}
	}
}
//ȫѡ
function CheckAll(name){
	var checkes = $GenName(name);
	for(i=0;i<checkes.length;i++){
		checkes[i].checked=true;
	}
}
//ȫ��ѡ
function CheckNot(name){
	var checkes = $GenName(name);
	for(i=0;i<checkes.length;i++){
		checkes[i].checked=false;
	}
}
//��ѡ
function CheckRever(name){
	var checkes = $GenName(name);
	for(i=0;i<checkes.length;i++){
		if(checkes[i].checked){
			checkes[i].checked=false;
		}else{
			checkes[i].checked=true;
		}
	}
}
