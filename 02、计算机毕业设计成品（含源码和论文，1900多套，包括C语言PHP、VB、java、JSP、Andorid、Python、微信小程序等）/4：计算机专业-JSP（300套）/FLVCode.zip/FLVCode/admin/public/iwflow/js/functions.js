var IE = (document.all) ? 1 : 0;
var NS = (document.layers) ? 1 : 0;

//window status functions
window.defaultStatus = "";
function winStatus( msg )
{
	window.status = msg;
}

function goThere( node,loc ) {
	//Only perform folder opening, don't close anything
	if( parent.nav.indexOfEntries[node].isOpen == false )
		parent.nav.clickOnNode(node);
	window.location = loc;
}

function closeMe() {
	//self.close();
	parent.close();
}

function formSubmit() {
	parent.frames[0].document.forms[0].submit();
}

function openerReload() {
	if( parent.opener.name != null )
		parent.opener.location.reload();
}

function r() {
	self.setTimeout("rl()", 2000);
}
function rl(){
	self.location.reload();
}


// nav tree functions
function navRefresh() {
	top.nav.location.reload();
}

// string functions
function trim( str ) {
	// Immediately return if no trimming is needed
	if( (str.charAt(0) != ' ') && (str.charAt(str.length-1) != ' ') ) { return str; }
	// Trim leading spaces
	while( str.charAt(0)  == ' ' ) {
		str = '' + str.substring(1,str.length);
	}
	// Trim trailing spaces
	while( str.charAt(str.length-1)  == ' ' ) {
		str = '' + str.substring(0,str.length-1);
	}

	return str;
}

function strReplace( entry, bad, good ) {
	temp = "" + entry; // temporary holder
	while( temp.indexOf(bad) > -1 ) {
		pos= temp.indexOf( bad );
		temp = "" + ( temp.substring(0, pos) + good + 
			temp.substring( (pos + bad.length), temp.length) );
	}
	return temp;
}

//Remove html Language mark such as "<" and ">"
function strRemoveHtml(strIn){
	if (strIn == null ) return "";
	temp = strIn ;
	find1 = temp.indexOf("<") ;
	while(find1 > -1){
		find2 = temp.indexOf(">",find1 + 1);
		if (find2 == -1)  find2 = find1 ;
		find2 = find2 + 1 ;
		temp = temp.substring(0, find1)  + temp.substring(find2,temp.length);
		find1 = temp.indexOf("<") ;
	}
	return temp;
}
		
		
	
	

	