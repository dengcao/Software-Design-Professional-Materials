
function Constant()
{
	this.URL = "http://192.168.20.195";
}