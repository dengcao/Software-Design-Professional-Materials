package com.user;

public class UserData {
	private int id;
	public void setId(int id){
		this.id = id;
	}
	public int getId(){
		return this.id;
	}
	
	private String name;
	public void setName(String name){
		this.name = name;
	}
	public String getName(){
		return this.name;
	}
	
	private String password;
	public void setPassword(String password){
		this.password = password;
	}
	public String getPassword(){
		return this.password;
	}
	
	private String qq;
	public void setQq(String qq){
		this.qq = qq;
	}
	public String getQq(){
		return this.qq;
	}
	
	private String email;
	public void setEmail(String email){
		this.email = email;
	}
	public String getEmail(){
		return this.email;
	}
	
	private String www;
	public void setWww(String www){
		this.www = www;
	}
	public String getWww(){
		return this.www;
	}
	
	private String power;
	public void setPower(String power){
		this.power = power;
	}
	public String getPower(){
		return this.power;
	}
	
	private String regeditTime;
	public void setRegeditTime(String regeditTime){
		this.regeditTime = regeditTime;
	}
	public String getRegeditTime(){
		return this.regeditTime;
	}
	
	private int sendArticle;
	public void setSendArticle(int sendArticle){
		this.sendArticle = sendArticle;
	}
	public int getSendArticle(){
		return this.sendArticle;
	}
	
	private int replyNum;
	public void setReplyNum(int replyNum){
		this.replyNum = replyNum;
	}
	public int getReplyNum(){
		return this.replyNum;
	}
	
	private String sex;
	public void setSex(String sex){
		this.sex = sex;
	}
	public String getSex(){
		return this.sex;
	}
	
	private String face;
	public void setFace(String face){
		this.face = face;
	}
	public String getFace(){
		return this.face;
	}
	
	public String signname;
	public void setSignname(String signname){
		this.signname = signname;
	}
	public String getSignname(){
		return this.signname;
	}
	
	private int click_num;
	public void setClick_num(int click_num){
		this.click_num = click_num;
	}
	public int getClick_num(){
		return this.click_num;
	}
}
