 function my_kwicks(){
    $('.kwicks').kwicks({
		duration: 300,   
        max: 200,  
        spacing:  0  
    });
}  

 $(document).ready(function(){					
	my_kwicks();
});
