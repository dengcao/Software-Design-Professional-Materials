package com.dao;

import java.util.Date;
import java.util.List;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.hibernate.LockMode;
import org.springframework.context.ApplicationContext;
import org.springframework.orm.hibernate3.support.HibernateDaoSupport;

import com.java.Insrm;

/**
 * A data access object (DAO) providing persistence and search support for Insrm
 * entities. Transaction control of the save(), update() and delete() operations
 * can directly support Spring container-managed transactions or they can be
 * augmented to handle user-managed Spring transactions. Each of these methods
 * provides additional information for how to configure it for the desired type
 * of transaction control.
 * 
 * @see com.java.Insrm
 * @author MyEclipse Persistence Tools
 */

public class InsrmDAO extends HibernateDaoSupport {
	private static final Log log = LogFactory.getLog(InsrmDAO.class);
	// property constants
	public static final String INSKIND = "inskind";
	public static final String INSNUM = "insnum";
	public static final String INSFY = "insfy";
	public static final String INSEMP = "insemp";
	public static final String INSCOMPY = "inscompy";
	public static final String INSXM = "insxm";
	public static final String DES = "des";

	protected void initDao() {
		// do nothing
	}

	public void save(Insrm transientInstance) {
		log.debug("saving Insrm instance");
		try {
			getHibernateTemplate().save(transientInstance);
			log.debug("save successful");
		} catch (RuntimeException re) {
			log.error("save failed", re);
			throw re;
		}
	}

	public void delete(Insrm persistentInstance) {
		log.debug("deleting Insrm instance");
		try {
			getHibernateTemplate().delete(persistentInstance);
			log.debug("delete successful");
		} catch (RuntimeException re) {
			log.error("delete failed", re);
			throw re;
		}
	}

	public Insrm findById(java.lang.Long id) {
		log.debug("getting Insrm instance with id: " + id);
		try {
			Insrm instance = (Insrm) getHibernateTemplate().get(
					"com.java.Insrm", id);
			return instance;
		} catch (RuntimeException re) {
			log.error("get failed", re);
			throw re;
		}
	}

	public List findByExample(Insrm instance) {
		log.debug("finding Insrm instance by example");
		try {
			List results = getHibernateTemplate().findByExample(instance);
			log.debug("find by example successful, result size: "
					+ results.size());
			return results;
		} catch (RuntimeException re) {
			log.error("find by example failed", re);
			throw re;
		}
	}

	public List findByProperty(String propertyName, Object value) {
		log.debug("finding Insrm instance with property: " + propertyName
				+ ", value: " + value);
		try {
			String queryString = "from Insrm as model where model."
					+ propertyName + "= ?";
			return getHibernateTemplate().find(queryString, value);
		} catch (RuntimeException re) {
			log.error("find by property name failed", re);
			throw re;
		}
	}

	public List findByInskind(Object inskind) {
		return findByProperty(INSKIND, inskind);
	}

	public List findByInsnum(Object insnum) {
		return findByProperty(INSNUM, insnum);
	}

	public List findByInsfy(Object insfy) {
		return findByProperty(INSFY, insfy);
	}

	public List findByInsemp(Object insemp) {
		return findByProperty(INSEMP, insemp);
	}

	public List findByInscompy(Object inscompy) {
		return findByProperty(INSCOMPY, inscompy);
	}

	public List findByInsxm(Object insxm) {
		return findByProperty(INSXM, insxm);
	}

	public List findByDes(Object des) {
		return findByProperty(DES, des);
	}

	public List findAll() {
		log.debug("finding all Insrm instances");
		try {
			String queryString = "from Insrm";
			return getHibernateTemplate().find(queryString);
		} catch (RuntimeException re) {
			log.error("find all failed", re);
			throw re;
		}
	}

	public Insrm merge(Insrm detachedInstance) {
		log.debug("merging Insrm instance");
		try {
			Insrm result = (Insrm) getHibernateTemplate().merge(
					detachedInstance);
			log.debug("merge successful");
			return result;
		} catch (RuntimeException re) {
			log.error("merge failed", re);
			throw re;
		}
	}

	public void attachDirty(Insrm instance) {
		log.debug("attaching dirty Insrm instance");
		try {
			getHibernateTemplate().saveOrUpdate(instance);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public void attachClean(Insrm instance) {
		log.debug("attaching clean Insrm instance");
		try {
			getHibernateTemplate().lock(instance, LockMode.NONE);
			log.debug("attach successful");
		} catch (RuntimeException re) {
			log.error("attach failed", re);
			throw re;
		}
	}

	public static InsrmDAO getFromApplicationContext(ApplicationContext ctx) {
		return (InsrmDAO) ctx.getBean("InsrmDAO");
	}
}