package com.service.intface.print;

import java.util.List;

public interface PrintServices {

	public List seCarnmAll();
	
	public List PrintCarnum(Long id,String tab);
	
}
