package com.action.print;

import java.util.Date;


public class AnnumBean {

	private String carnum;
	private Date annumdate;//�������
	private String anum;//����º�
	private Long anfy;//������
	private String anemp;///������
	private String andep;//��쵥λ
	private Date anenda;//��Ч����
	private String andes;//��ע
	public String getCarnum() {
		return carnum;
	}
	public void setCarnum(String carnum) {
		this.carnum = carnum;
	}
	public Date getAnnumdate() {
		return annumdate;
	}
	public void setAnnumdate(Date annumdate) {
		this.annumdate = annumdate;
	}
	public String getAnum() {
		return anum;
	}
	public void setAnum(String anum) {
		this.anum = anum;
	}
	public Long getAnfy() {
		return anfy;
	}
	public void setAnfy(Long anfy) {
		this.anfy = anfy;
	}
	public String getAnemp() {
		return anemp;
	}
	public void setAnemp(String anemp) {
		this.anemp = anemp;
	}
	public String getAndep() {
		return andep;
	}
	public void setAndep(String andep) {
		this.andep = andep;
	}
	public Date getAnenda() {
		return anenda;
	}
	public void setAnenda(Date anenda) {
		this.anenda = anenda;
	}
	public String getAndes() {
		return andes;
	}
	public void setAndes(String andes) {
		this.andes = andes;
	}
	
}
