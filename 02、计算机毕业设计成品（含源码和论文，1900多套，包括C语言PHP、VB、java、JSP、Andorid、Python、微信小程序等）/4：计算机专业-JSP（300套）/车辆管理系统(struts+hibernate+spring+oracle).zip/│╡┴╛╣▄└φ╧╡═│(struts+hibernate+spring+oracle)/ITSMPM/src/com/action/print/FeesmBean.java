package com.action.print;

import java.util.Date;


public class FeesmBean {

	private String carnum;//
	private Date feesdate;//�ɷ�����
	private String feeskid;//�ɷ����
	private Long feesje;//�ɷѽ��
	private String feesemp;//������
	private String feesdep;//�շѵ�λ
	private Long feeszq;//�ɷ�����
	private String des;//����
	public String getCarnum() {
		return carnum;
	}
	public void setCarnum(String carnum) {
		this.carnum = carnum;
	}
	public Date getFeesdate() {
		return feesdate;
	}
	public void setFeesdate(Date feesdate) {
		this.feesdate = feesdate;
	}
	public String getFeeskid() {
		return feeskid;
	}
	public void setFeeskid(String feeskid) {
		this.feeskid = feeskid;
	}
	public Long getFeesje() {
		return feesje;
	}
	public void setFeesje(Long feesje) {
		this.feesje = feesje;
	}
	public String getFeesemp() {
		return feesemp;
	}
	public void setFeesemp(String feesemp) {
		this.feesemp = feesemp;
	}
	public String getFeesdep() {
		return feesdep;
	}
	public void setFeesdep(String feesdep) {
		this.feesdep = feesdep;
	}
	public Long getFeeszq() {
		return feeszq;
	}
	public void setFeeszq(Long feeszq) {
		this.feeszq = feeszq;
	}
	public String getDes() {
		return des;
	}
	public void setDes(String des) {
		this.des = des;
	}
	
	
}
