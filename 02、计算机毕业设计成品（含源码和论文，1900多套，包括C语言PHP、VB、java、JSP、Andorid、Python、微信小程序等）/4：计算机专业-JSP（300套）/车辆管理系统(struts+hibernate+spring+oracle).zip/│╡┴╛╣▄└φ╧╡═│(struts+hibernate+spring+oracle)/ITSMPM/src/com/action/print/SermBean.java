package com.action.print;

import java.util.Date;

public class SermBean {

	private String carnum;//���ƺ�
	private Date serdate;//��������
	private String seremp;//������
	private String sershop;//������
	private Date ytake;//Ԥ��ȡ��ʱ��
	private String serron;//����ԭ��
	private Long serje;//���
	private Date sjtake;//ʵ��ȡ��ʱ��
	public String getCarnum() {
		return carnum;
	}
	public void setCarnum(String carnum) {
		this.carnum = carnum;
	}
	public Date getSerdate() {
		return serdate;
	}
	public void setSerdate(Date serdate) {
		this.serdate = serdate;
	}
	public String getSeremp() {
		return seremp;
	}
	public void setSeremp(String seremp) {
		this.seremp = seremp;
	}
	public String getSershop() {
		return sershop;
	}
	public void setSershop(String sershop) {
		this.sershop = sershop;
	}
	public Date getYtake() {
		return ytake;
	}
	public void setYtake(Date ytake) {
		this.ytake = ytake;
	}
	public String getSerron() {
		return serron;
	}
	public void setSerron(String serron) {
		this.serron = serron;
	}
	public Long getSerje() {
		return serje;
	}
	public void setSerje(Long serje) {
		this.serje = serje;
	}
	public Date getSjtake() {
		return sjtake;
	}
	public void setSjtake(Date sjtake) {
		this.sjtake = sjtake;
	}
	
}
