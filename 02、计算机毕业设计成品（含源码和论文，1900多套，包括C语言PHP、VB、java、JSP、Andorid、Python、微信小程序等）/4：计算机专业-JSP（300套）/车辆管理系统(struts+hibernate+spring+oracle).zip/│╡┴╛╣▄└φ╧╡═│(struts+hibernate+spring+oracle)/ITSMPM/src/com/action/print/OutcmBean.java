package com.action.print;

import java.util.Date;

public class OutcmBean {

	private String carnum;//���ƺ�
	private String drivnm;//��ʻԱ
	private Date ucdate;//����ʱ��
	private Date indate;//Ԥ�ƻ�ʱ��
	private String ucempnm;//�ó���
	private String dtation;//Ŀ�ص�
	private String ucloca;//�����ص�
	private String phonum;//�ó��˺���
	private String thing;//����
	public String getCarnum() {
		return carnum;
	}
	public void setCarnum(String carnum) {
		this.carnum = carnum;
	}
	public String getDrivnm() {
		return drivnm;
	}
	public void setDrivnm(String drivnm) {
		this.drivnm = drivnm;
	}
	public Date getUcdate() {
		return ucdate;
	}
	public void setUcdate(Date ucdate) {
		this.ucdate = ucdate;
	}
	public Date getIndate() {
		return indate;
	}
	public void setIndate(Date indate) {
		this.indate = indate;
	}
	public String getUcempnm() {
		return ucempnm;
	}
	public void setUcempnm(String ucempnm) {
		this.ucempnm = ucempnm;
	}
	public String getDtation() {
		return dtation;
	}
	public void setDtation(String dtation) {
		this.dtation = dtation;
	}
	public String getUcloca() {
		return ucloca;
	}
	public void setUcloca(String ucloca) {
		this.ucloca = ucloca;
	}
	public String getPhonum() {
		return phonum;
	}
	public void setPhonum(String phonum) {
		this.phonum = phonum;
	}
	public String getThing() {
		return thing;
	}
	public void setThing(String thing) {
		this.thing = thing;
	}
	
	
	
}
