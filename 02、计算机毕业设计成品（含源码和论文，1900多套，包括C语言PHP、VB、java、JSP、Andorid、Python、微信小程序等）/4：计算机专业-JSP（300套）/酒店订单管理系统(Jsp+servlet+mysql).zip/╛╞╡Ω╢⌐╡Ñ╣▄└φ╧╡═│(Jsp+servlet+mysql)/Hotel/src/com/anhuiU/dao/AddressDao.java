package com.anhuiU.dao;

import java.util.List;

import com.anhuiU.model.BaseModel;

public class AddressDao extends BaseDao {


	public void add(BaseModel bm) {
		// TODO Auto-generated method stub
		
	}


	public void delete(int id) {
		// TODO Auto-generated method stub
		
	}


	public List select() {
		// TODO Auto-generated method stub
		return null;
	}


	public void update(BaseModel bm) {
		// TODO Auto-generated method stub
		
	}

	

}
