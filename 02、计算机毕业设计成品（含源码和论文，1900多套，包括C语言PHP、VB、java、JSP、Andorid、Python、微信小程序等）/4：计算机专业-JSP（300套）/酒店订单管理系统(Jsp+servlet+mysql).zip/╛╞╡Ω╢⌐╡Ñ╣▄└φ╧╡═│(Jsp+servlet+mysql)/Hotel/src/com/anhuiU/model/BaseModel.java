package com.anhuiU.model;

public abstract class BaseModel {

}
