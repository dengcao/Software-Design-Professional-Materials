package com.service;
import com.bu.mars.*;
public class MarsBusinessservice {
private BillInfoBusiness billinfobusiness;
private BranchBusiness branchbusiness;
private CargoInfoBusiness cargoinfobusiness;
private Customerbusiness customerbusiness;
private TrafficLogBusiness trafficlogbusiness;
private TruckInfoBusiness truckinfobusiness;
private UserInfoBusiness userinfobusiness;
private DriverInfoBusiness driverinfobusiness;
private AfficheInfoBusiness afficheinfobusiness;
public BillInfoBusiness getBillinfobusiness() {
	return billinfobusiness;
}
public void setBillinfobusiness(BillInfoBusiness billinfobusiness) {
	this.billinfobusiness = billinfobusiness;
}
public BranchBusiness getBranchbusiness() {
	return branchbusiness;
}
public void setBranchbusiness(BranchBusiness branchbusiness) {
	this.branchbusiness = branchbusiness;
}
public CargoInfoBusiness getCargoinfobusiness() {
	return cargoinfobusiness;
}
public void setCargoinfobusiness(CargoInfoBusiness cargoinfobusiness) {
	this.cargoinfobusiness = cargoinfobusiness;
}
public Customerbusiness getCustomerbusiness() {
	return customerbusiness;
}
public void setCustomerbusiness(Customerbusiness customerbusiness) {
	this.customerbusiness = customerbusiness;
}
public TrafficLogBusiness getTrafficlogbusiness() {
	return trafficlogbusiness;
}
public void setTrafficlogbusiness(TrafficLogBusiness trafficlogbusiness) {
	this.trafficlogbusiness = trafficlogbusiness;
}
public TruckInfoBusiness getTruckinfobusiness() {
	return truckinfobusiness;
}
public void setTruckinfobusiness(TruckInfoBusiness truckinfobusiness) {
	this.truckinfobusiness = truckinfobusiness;
}
public UserInfoBusiness getUserinfobusiness() {
	return userinfobusiness;
}
public void setUserinfobusiness(UserInfoBusiness userinfobusiness) {
	this.userinfobusiness = userinfobusiness;
}
public DriverInfoBusiness getDriverinfobusiness() {
	return driverinfobusiness;
}
public void setDriverinfobusiness(DriverInfoBusiness driverinfobusiness) {
	this.driverinfobusiness = driverinfobusiness;
}
public AfficheInfoBusiness getAfficheinfobusiness() {
	return afficheinfobusiness;
}
public void setAfficheinfobusiness(AfficheInfoBusiness afficheinfobusiness) {
	this.afficheinfobusiness = afficheinfobusiness;
}
}
