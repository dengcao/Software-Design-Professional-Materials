package com.accp.myoa.common;

public class OnLineCount {
	private static int count=0;

	public static int getCount() {
		return count;
	}

	public static void setCount(int count) {
		OnLineCount.count = count;
	}
	
}
