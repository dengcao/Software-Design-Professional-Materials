package com.xh369.dto;

public class Productsviews implements java.io.Serializable{

    private ProductsviewsId id;

    public Productsviews(){
    }

    public ProductsviewsId getId() {
        return id;
    }

    public void setId(ProductsviewsId id) {
        this.id = id;
    }
}
