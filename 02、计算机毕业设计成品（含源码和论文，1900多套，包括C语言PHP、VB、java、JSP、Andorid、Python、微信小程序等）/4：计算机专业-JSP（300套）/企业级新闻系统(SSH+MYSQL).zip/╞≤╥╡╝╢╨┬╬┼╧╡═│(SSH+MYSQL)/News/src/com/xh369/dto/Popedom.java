package com.xh369.dto;

import java.io.Serializable;

public class Popedom implements Serializable{
	
	private Integer id;
	private String popedom;
	
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getPopedom() {
		return popedom;
	}
	public void setPopedom(String popedom) {
		this.popedom = popedom;
	}	
}
