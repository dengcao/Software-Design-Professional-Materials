package com.xh369.dto;

public class Articlesviews implements java.io.Serializable{

    private ArticlesviewsId id;

    public Articlesviews() {
    }

    public ArticlesviewsId getId() {
        return this.id;
    }

    public void setId(ArticlesviewsId id) {
        this.id = id;
    }
}
