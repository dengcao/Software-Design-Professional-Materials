package org.bit.demo;

public class Configuration {
	public static final String INDEX_STORE_PATH = "c:/denyqiu/lucene/index";
}