package net.acai.filter;


/**
 * Title:        ��������
 * Description:
 * Copyright:    Copyright (c) 2002
 * Company:      www.SuperSpace.com
 * @author:       SuperSpace
 * @version 1.0
 */
public interface UBB 
{
	public String convertString();
	public void setString(String input);
	public String getInputString();
	public String getFilterString();
}