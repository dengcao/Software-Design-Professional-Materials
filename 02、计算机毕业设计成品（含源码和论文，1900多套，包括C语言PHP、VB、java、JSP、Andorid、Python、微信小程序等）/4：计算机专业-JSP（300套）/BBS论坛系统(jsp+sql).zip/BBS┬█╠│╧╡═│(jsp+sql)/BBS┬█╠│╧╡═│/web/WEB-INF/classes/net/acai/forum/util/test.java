package net.acai.forum.util;

import java.util.*;
import java.text.*;
public class test{

	public static void main(String args[]){
		try{
			DateFormat df = DateFormat.getDateInstance();

			Date date=df.parse("2002-04-02");
			Date NDate=new Date();
			
		}
		catch(Exception e){
			e.printStackTrace();
		}
	}
}
