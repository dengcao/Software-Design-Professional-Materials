var MaxAppend=-1,MinAppend=2;
function AddAppend(Id){
	var Row = $("tr","#"+Id).length;
	if(MaxAppend > 0){
		if(Row >= MaxAppend){alert("���ܳ��� "+MaxAppend+" ��...");return;}
	}
	
	var html = "<tr>";
	html += "<td><input type=\"text\" name=\"DIYVar_Desc\" size=\"15\" /></td>";
	html += "<td><input type=\"text\" name=\"DIYVar_Name\" size=\"15\" /> =&gt;</td>";
	html += "<td><input type=\"text\" name=\"DIYVar_Value\" size=\"15\" /></td>";
	html += "</tr>";
	
	$("#"+Id).append(html);
}
function DelAppend(Id){
	var Row = $("tr","#"+Id).length;
	if(Row > MinAppend){
		var LastTr = $("#"+Id+" tr:last");
			LastTr.remove();
		return;
	}
	
}