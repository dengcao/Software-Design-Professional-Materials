var MaxAppend=-1,MinAppend=2;
function AddAppend(Id){
	var Row = $("tr","#"+Id).length;
	if(MaxAppend > 0){
		if(Row >= MaxAppend){alert("���ܳ��� "+MaxAppend+" ��...");return;}
	}
	
	var html = "<tr>";
	html += "<td align=\"left\" valign=\"top\">����<input name=\"OptionSort\" type=\"text\" id=\"OptionSort"+(Row+1)+"\"  value=\"0\" size=\"5\">&nbsp;���ƣ�<input name=\"OptionTitle\" type=\"text\" id=\"OptionTitle"+(Row+1)+"\" size=\"30\">&nbsp;ͼƬ��<input type=\"text\" name=\"OptionImage\" id=\"OptionImage"+(Row+1)+"\" size=\"15\" />&nbsp;<input name=\"ViewImage\" type=\"button\" class=\"button_style\" id=\"ViewImage"+(Row+1)+"\" value=\"���...\" onClick=\"Gen.OpenWin('../ListFiles.jsp?InId=OptionImage"+(Row+1)+"&Type=gov.file','','600','350');\">&nbsp;<input name=\"UpImage\" type=\"button\" class=\"button_style\" id=\"UpImage"+(Row+1)+"\" value=\"�ϴ�ͼƬ\" onClick=\"Gen.OpenWin('../Upload.jsp?InId=OptionImage"+(Row+1)+"&Type=gov.file','','500','300');\"></td>";
	html += "</tr>";
	
	$("#"+Id).append(html);
}
function DelAppend(Id){
	var Row = $("tr","#"+Id).length;
	if(Row > MinAppend){
		var LastTr = $("#"+Id+" tr:last");
			LastTr.remove();
		return;
	}
	
}