var urlhttp= JSPGen.ContextURL+'include/Ajax.jsp';
$.ajaxSetup({cache:false});/*�ر�Ajax����*/

/*�����б�*/
/*��ȡʡ���б�*/
function LoadProvince(){
    var pars = 'act=Province';
	$.ajax({url:urlhttp,async:false,type:'get',dataType:'text',data:pars,success:setProvince});
}
function setProvince(text){
    var provinces = text.split('|');
	var currmodule = enterValue(provinces, 'Province');
	LoadCity(currmodule);
}
/*��ȡ�����б�*/
function LoadCity(Province){
    var pars = 'act=City&Province='+Province;
	$.ajax({url:urlhttp,async:false,type:'get',dataType:'text',data:pars,success:setCity});
}
function setCity(text){/*alert(text);*/
    var citys = text.split('|');
	var currplan = enterValue(citys, 'City');
	LoadArea(currplan);
}
/*��ȡ�����б�*/
function LoadArea(City){
    var pars = 'act=Area&City='+City;
	$.ajax({url:urlhttp,async:false,type:'get',dataType:'text',data:pars,success:setArea});
}

/*******************
 *��������
 *******************/
function LoadBirthProvince(){
    var pars = 'act=Province';
	$.ajax({url:urlhttp,async:false,type:'get',dataType:'text',data:pars,success:setBirthProvince});
}
function setBirthProvince(text){
    var provinces = text.split('|');
	var currmodule = enterBirthValue(provinces, 'BirthProvince');
	LoadBirthCity(currmodule);
}
/*��ȡ�����б�*/
function LoadBirthCity(Province){
    var pars = 'act=City&Province='+Province;
	$.ajax({url:urlhttp,async:false,type:'get',dataType:'text',data:pars,success:setBirthCity});
}
function setBirthCity(text){
    var citys = text.split('|');
	var currplan = enterBirthValue(citys, 'BirthCity');
	LoadBirthArea(currplan);
}
/*��ȡ�����б�*/
function LoadBirthArea(City){
    var pars = 'act=Area&City='+City;
	$.ajax({url:urlhttp,async:false,type:'get',dataType:'text',data:pars,success:setBirthArea});
}
/*******************
 *��ס����
 *******************/
function LoadResideProvince(){
    var pars = 'act=Province';
	$.ajax({url:urlhttp,async:false,type:'get',dataType:'text',data:pars,success:setResideProvince});
}
function setResideProvince(text){
    var provinces = text.split('|');
	var currmodule = enterResideValue(provinces, 'ResideProvince');
	LoadResideCity(currmodule);
}
/*��ȡ�����б�*/
function LoadResideCity(Province){
    var pars = 'act=City&Province='+Province;
	$.ajax({url:urlhttp,async:false,type:'get',dataType:'text',data:pars,success:setResideCity});
}
function setResideCity(text){
    var citys = text.split('|');
	var currplan = enterResideValue(citys, 'ResideCity');
	LoadResideArea(currplan);
}
/*��ȡ�����б�*/
function LoadResideArea(City){
    var pars = 'act=Area&City='+City;
	$.ajax({url:urlhttp,async:false,type:'get',dataType:'text',data:pars,success:setResideArea});
}
/*******************/


/*��������*/
function setArea(text){
    var areas = text.split('|');
	enterValue(areas, 'Area');
}
function setBirthArea(text){
    var areas = text.split('|');
	enterBirthValue(areas, 'BirthArea');
}
function setResideArea(text){
    var areas = text.split('|');
	/*if(areas.length > 0){
		$('#ResideArea').style.visibility = 'visible';*/
		enterResideValue(areas, 'ResideArea');
	/*}else $('#ResideArea').style.visibility = 'hidden'; //����*/
}

function enterValue(cell,objSelect){
	clearPreValue(objSelect);
	var selectedval = ''; /*cell[0];*/
	for(i=0; i<cell.length; i++){
		var ves = cell[i].split(':');
		if(i==0) selectedval = ves[0];
	    isselected = addOption(objSelect, ves[0], ves[1]);
	    if(isselected){
			selectedval = ves[0];
	    }
		
	}
	return selectedval;
}
function enterBirthValue(cell,objSelect){
	clearPreValue(objSelect);
	var selectedval = ''; /*cell[0];*/
	for(i=0; i<cell.length; i++){
		var ves = cell[i].split(':');
		if(i==0) selectedval = ves[0];
	    isselected = addBirthOption(objSelect, ves[0], ves[1]);
	    if(isselected){
			selectedval = ves[0];
	    }
	}
	return selectedval;
}
function enterResideValue(cell,objSelect){
	clearPreValue(objSelect);
	var selectedval = ''; /*cell[0];*/
	for(i=0; i<cell.length; i++){
		var ves = cell[i].split(':');
		if(i==0) selectedval = ves[0];
	    isselected = addResideOption(objSelect, ves[0], ves[1]);
	    if(isselected){
			selectedval = ves[0];
	    }
	}
	return selectedval;
}

function addOption(objSelect,value,text){
	$('<option value=\''+value+'\'>'+text+'</option>').appendTo('#'+objSelect);/*�����������option*/
	if((value == SelProvince) || (value == SelCity) || (value == SelArea)){
		$('#'+objSelect).attr('value',value);/*����value='value'Ϊ��ǰѡ����*/
		return true;
	}else{
		return false;
	}
}
function addBirthOption(objSelect,value,text){
	$('<option value=\''+value+'\'>'+text+'</option>').appendTo('#'+objSelect);
	if((value == SelBirthProvince) || (value == SelBirthCity) || (value == SelBirthArea)){
		$('#'+objSelect).attr('value',value);
		return true;
	}else{
		return false;
	}
}
function addResideOption(objSelect,value,text){
	$('<option value=\''+value+'\'>'+text+'</option>').appendTo('#'+objSelect);
	if((value == SelResideProvince) || (value == SelResideCity) || (value == SelResideArea)){
		$('#'+objSelect).attr('value',value);
		return true;
	}else{
		return false;
	}
}

function clearPreValue(objSelect){
	$('#'+objSelect).empty(); /*���������*/
}