/*
 * ��ҳ����ͼ�л�
 */
(function($){
	$.fn.extend({
		imgSlide: function(options) {
		
			if(options.auto  == undefined)  	options.auto  = true;			//Ĭ��Ϊ�Զ�����
			if(options.type  == undefined)  	options.type  = 'click';		//Ĭ��Ϊ����л�
			if(options.speed == undefined)  	options.speed = 3000;			//Ĭ��Ϊ3000����
			var div = this;
			var imgDiv = this.children('.image');
			var navDiv = this.children('.number');
			var titDiv = this.children('.title');
			
			var items = $('#'+options.data+' > li > a');
			var itemsLength = items.length;
			if(itemsLength == 0) return this;
			
			var length = itemsLength / 2;
			var timeoutReturn;
			var curItemIndex = 0; //��ǰ������
			var navDivHtml = '';
			
			//var turn = false;
			for(var i =1;i<length+1;i++) {
				navDivHtml +='<span class="">'+i+'</span>';
			}
			navDiv.html(navDivHtml);
			
			var process = function(turn) {
				imgDiv.html(items.eq(curItemIndex*2));
				titDiv.html(items.eq(curItemIndex*2+1));
				navDiv.children('span.this').removeClass('this');
				navDiv.children('span').eq(curItemIndex).addClass('this');
				if(options.auto != false) {
					curItemIndex++;
				}
				if(curItemIndex == length) curItemIndex = 0;
				if(turn != true) {
					timeoutReturn = setTimeout(process,options.speed);
				}
			}
			
			navDiv.children('span').each(function(i) {
				$(this).bind(options.type,function() {
					clearTimeout(timeoutReturn);
					curItemIndex = i;
					process(true);
					return false;
				});
			});
			
			this.mouseover(function(e){
				clearTimeout(timeoutReturn);
				div.mouseout(function(evt){
					div.unbind('mouseout');
					var all = div.find('*');
					var t = evt.relatedTarget;
					if(all.index(t) != -1 && t != div[0]) return ;
					timeoutReturn = setTimeout(process,options.speed);
				});
			});
			process();
			return this;
		}
	});
})(jQuery);

/* 
 * ���ͼƬ�л�
 * titContainer	- ��������ѡ���(class, id, tag)
 * mainContainer - ��������ѡ���(class, id, tag)
 * titCell		- ��ѡ���������ⵥԪ������Ĭ��Ϊli
 * mainCell		- ��ѡ���������ݵ�Ԫ������Ĭ��Ϊli
 * titOnClassName -��ѡ��������ǩѡ��ʱ����ʽ, Ĭ��Ϊon
 * defaultIndex 	- ��ѡ������Ĭ��ѡ�еı�ǩ��������0��ʼ
 * interTime		- ��ѡ������������0�����ǩ���Զ��л�����interTimeΪ���ʱ�䣬��λ����
 */
function PicSwitch(titContainer, mainContainer, titCell, mainCell, titOnClassName, defaultIndex, interTime){
	var titCell = (titCell==null || titCell==undefined) ? 'li' : titCell;
	var mainCell = (mainCell==null || mainCell==undefined) ? 'li' : mainCell;
	var titOnClassName = (titOnClassName==null || titOnClassName==undefined) ? 'on' : titOnClassName;
	var defaultIndex = (defaultIndex==null || defaultIndex==undefined) ? 0 : defaultIndex;

	var onTag = defaultIndex;
	var oTitle = jQuery(titContainer);
	var oMain = jQuery(mainContainer);
	var PicsCount = oTitle.find(titCell).length;
	var sInterval = null;
	
	/* ����defaultIndex��ʼ�� */
	oTitle.find(titCell + ":eq(" + defaultIndex + ")").addClass(titOnClassName);
	oMain.find(mainCell + ":eq(" + defaultIndex + ")").fadeIn({queue: false, duration: 500});
	
	/* ���������¼� */
	oTitle.find(titCell).each(function(i, ele){
		jQuery(ele).hover(function(){
			/* if(sInterval != null)clearInterval(sInterval); */
			if(i != onTag){
				oTitle.find(titCell + ":eq(" + onTag + ")").removeClass(titOnClassName);
				oMain.find(mainCell).hide();
				
				oTitle.find(titCell + ":eq(" + i + ")").addClass(titOnClassName);
				onTag = i;
				oMain.find(mainCell + ":eq(" + i + ")").fadeIn({queue: false, duration: 600});
			}
		});
	});
	
	if(interTime >= 0){/* 'interTime' enables auto-switch function. */
		sInterval = setInterval(function next(){
			oTitle.find(titCell + ":eq(" + onTag + ")").removeClass(titOnClassName);
			oMain.find(mainCell).hide();
			
			if(++onTag >= PicsCount)onTag = 0;
			oTitle.find(titCell + ":eq(" + onTag + ")").addClass(titOnClassName);
			oMain.find(mainCell + ":eq(" + onTag + ")").fadeIn({queue: false, duration: 600});
		}, interTime);
	}
}