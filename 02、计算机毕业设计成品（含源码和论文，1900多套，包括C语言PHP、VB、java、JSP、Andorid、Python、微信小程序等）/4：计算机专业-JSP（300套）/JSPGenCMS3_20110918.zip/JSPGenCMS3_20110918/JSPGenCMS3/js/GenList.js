/*<script type="text/javascript" src="GenList.js">< /script>*/
/*GenList.ShowPop(null,"list","GoTo",50,100,null);*/

/***************
 * @ Name Div�б�
 * @ Version 2.0
 * @ Writer JSPGen
 * @ Time 2008��8��
 * @ Address www.jspgen.com
 * @ E-mail:jspgen@163.com  QQ 190582560
 ***************/
 
/************
 * ���ݳ�ʼ��
 ************/
/*ȥ��˵�*/
var GoTo = Array(
				 Array("blog.jspgen.com","����"),
				 Array("bbs.jspgen.com","����"),
				 Array("zone.jspgen.com","�ռ�")
);

/************
 * ��ز�������
 ************/
var GenListFun = {
	"init":null
	/*��ֵ����*/
	,"setValue":function(id,PareID,value){
		if($GenId(PareID)){ $GenId(PareID).innerHTML = value; }else{ PareID.innerHTML = value; }
		if(id != null || id != "")GenList.HidePop(id);//�ر��б�
	}
	/*��������*/
	/*,"Fun...":function( ... ){ ... }*/
};

/************
 * ����Div�б����� �� ��ʾЧ������
 ************/
var GenList = {
	/*��ʼ��*/
	"init":function(id,PareID,popw,poph,style,evt){
		var Mxy; var Nwh;
		if($GenId(id))GenList.HidePop(id);
		if($GenId(PareID)){
			Mxy = Gen.getObjectXY(PareID); Nwh = Gen.getObjectWHN(PareID);
		}else{ Mxy = Gen.getMouseXY(evt); Nwh = [0, 0, null]; }
		var DivStr = document.createElement("div"); DivStr.id = id;	 DivStr.className = style;
		DivStr.style.width = parseInt(popw)+"px";	DivStr.style.height = parseInt(poph)+"px";
		DivStr.style.left = parseInt(Mxy[0])+"px";	DivStr.style.top = (parseInt(Mxy[1]) + parseInt(Nwh[1]))+"px";
		DivStr.onmouseover = function(){ Gen.HideShowDiv(id,1); };
		DivStr.onmouseout = function(){ Gen.HideShowDiv(id,0);};
		DivStr.innerHTML = "<span>���Ժ�...</span>";
		document.body.appendChild(DivStr);
	}
	/*��ʾ�б� ��������ID ����ID ���� ���� �߶� ��ʽ*/
	,"ShowPop":function(id,PareID,para,popw,poph,style,evt){
		if(!id)id = "ListPop";
		if(!style)style = "ListPop";
		GenList.init(id,PareID,popw,poph,style,evt);
		var InnerStr = "";
		switch(para){
			case "GoTo":
				for(var i = 0; i<GoTo.length; i++){
					InnerStr += "<li class=\"MouseOut\" "
						+ "onmouseover=\"Gen.setCss(this,'MouseOver')\" onmouseout=\"Gen.setCss(this,'MouseOut')\" "
						+ "onClick=\"return GenListFun.setValue('"+ id +"','"+ PareID +"','"+ GoTo[i][0] +"')\">"
						+ GoTo[i][1]+"</li>";
				}	
				InnerStr = "<ul>" + InnerStr + "</ul>";					break;
			/*��������*/
			/*case "GoTo": 												break;*/
			
			default:alert(ParamErrText);								break;
		}
		$GenId(id).innerHTML = InnerStr;
		
	}
	/*�رղ���*/
	,"HidePop":function(id){
		document.body.removeChild($GenId(id));
	}
};