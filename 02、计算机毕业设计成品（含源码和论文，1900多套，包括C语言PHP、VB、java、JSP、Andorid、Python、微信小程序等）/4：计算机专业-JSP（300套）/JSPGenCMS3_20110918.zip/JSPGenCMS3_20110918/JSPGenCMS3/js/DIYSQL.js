/*JSON��ַ*/
var httpurl=JSPGen.ContextURL+'include/JSON.jsp';

/*���SQL���*/
var DBSourceID,DBTable;
var select_type = ['IS NULL','IS NOT NULL'];
function DIYSQL(){
	var sql = '',a ='*',where = '',order = '';
	$("input:checked").each(function(){
		if(isNaN($(this).val())){
			if(a!='*'){
				a += ',`'+$(this).val()+'`';
			}else{
				a = '`'+$(this).val()+'`';
			}
		}
	});
	sql += 'SELECT '+a+' FROM `'+DBTable+'`';
	$("select[name='func']").each(function(){
		var val = $(this).val();
		var id = $(this).attr('d');
		if($.inArray(val,select_type)<0){
			var field_val = $("#fields_"+id).val();
			if(field_val!=''){
				if(val != 'LIKE %*%' && val != 'LIKE *%' && val != 'LIKE %*'){
					if(where!=''){
						where += ' AND `'+id+'` '+val+' \''+field_val+'\'';
					}else{
						where += '`'+id+'` '+val+' \''+field_val+'\'';
					}
				}else{
					if(where!=''){
						if(val == 'LIKE %*%'){
							where += " AND `"+id+"` "+val.replace('%*%',"'%"+field_val+"%'");
						}
						if(val == 'LIKE *%'){
							where += " AND `"+id+"` "+val.replace('*%',"'"+field_val+"%'");
						}
						if(val == 'LIKE %*'){
							where += " AND `"+id+"` "+val.replace('%*',"'%"+field_val+"'");
						}
					}else{
						if(val == 'LIKE %*%'){
							where += "`"+id+"` "+val.replace('%*%',"'%"+field_val+"%'");
						}
						if(val == 'LIKE *%'){
							where += "`"+id+"` "+val.replace('*%',"'"+field_val+"%'");
						}
						if(val == 'LIKE %*'){
							where += "`"+id+"` "+val.replace('%*',"'%"+field_val+"'");
						}
					}
				}
			}
		}else{
			if(where!=''){
				where += ' AND `'+id+'` '+val;
			}else{
				where += '`'+id+'` '+val;
			}
		}
	});
	if(where!='')sql += ' WHERE '+where;
	$("select[name='order']").each(function(){
		var selected = $(this).val();
		var d = $(this).attr('d');
		if(selected!=''){
			if(order!=''){
				order += ", `"+d+"` "+selected;
			}else{
				order += " `"+d+"` "+selected;
			}
		}
	});
	if(order!=''){
		sql += ' ORDER BY '+order;
	}else{
		sql += '';
	}
	Submit(sql,DBSourceID);
}
/*��ȡ����Դ*/
function getDBSource(){
	$("#dbsource").html('<option>��ѡ��</option><option value="0">��ϵͳ</option>');
	$.getJSON(httpurl+'?act=DBSource&time='+new Date(),function(data){
		if(data){
			$.each(data,function(i,n){
				if(n.name){
					$("#dbsource").append('<option value="'+n.name+'">'+n.name+'</option>');
				}
			});

		}
		document.getElementById('dbsource').selectedIndex=1;
		getDBTable('0');
	});
}
/*��ȡ���ݱ�*/
function getDBTable(val){
	DBSourceID = val;
	$("#dbtable").html('<option>��ѡ��</option>');
	if(val!=''){
		$.getJSON(httpurl+'?act=DBTable&Id='+val+'&time='+new Date(),function(data){
			if(data){
				$.each(data,function(i,n){
                    var selected = '';
					/*
					if(n.tablename=='content'){selected = 'selected';	getDBField(n.tablename);}
					*/
					$("#dbtable").append('<option value="'+n.tablename+'" '+selected+'>'+(n.nickname ? n.nickname : n.tablename)+'</option>');
				});
				$("#db_table").show();
			}else{
				alert('û���ҵ����ݱ�');
			}
		})
	}
}
/*��ȡ���ݱ��ֶ�*/
var types = ['int','tinyint','smallint','mediumint','bigint'];
function getDBField(val){
	DBTable = val;
	$("#where_sql").html('<tr></tr>');
	if(val!=''){
		$.getJSON(httpurl+'?act=DBField&Id='+DBSourceID+'&DBTable='+val+'&time='+new Date(),function(data){
			if(data){
				$.each(data,function(i,n){
					var str = '<tr><td>'+(n.nickname ? n.nickname+' ('+n.field+')' : n.field)+'</td><td>'+n.type+(n.num ? '('+n.num+')' : '')+'</td><td class="align_c"><input type="checkbox" value="'+n.field+'" id="checkbox_'+n.field+'" style="border:0px"></td><td class="align_c"><select name="func" d="'+n.field+'"><option value="="';
					if($.inArray(n.type,types)>=0){str += ' selected';}
					str += '>=</option><option value=">">></option><option value=">=">>=</option> <option value="<"><</option><option value="<="><=</option><option value="!=">!=</option><option value="LIKE"';
					if($.inArray(n.type,types)<0){str += ' selected';}
					str += '>LIKE</option><option value="LIKE %*%">LIKE % * %</option><option value="LIKE *%">LIKE * %</option><option value="LIKE %*">LIKE % *</option><option value="NOT LIKE">NOT LIKE</option><option value="IS NULL">IS NULL</option><option value="IS NOT NULL">IS NOT NULL</option> </select></td><td class="align_c"><input type="text" id="fields_'+n.field+'" size="15"></td><td class="align_c"><select name="order" d="'+n.field+'" id="order_'+n.field+'"><option value=""></option><option value="ASC">����</option><option value="DESC">����</option></select></td></tr>';
					$("#where_sql").append(str);
				});
				$('#where').show();
			}else{
				alert('û���ҵ��ֶ�');
			}
		});
	}
}