$(document).ready(function(){
����$("input[type='text']").addClass('input_blur');
����$("input[type='password']").addClass('input_blur');
    $("input[type='submit']").addClass('button_style');
    $("input[type='reset']").addClass('button_style');
    $("input[type='button']").addClass('button_style');
    $("input[type='radio']").addClass('radio_style');
    $("input[type='checkbox']").addClass('checkbox_style');
    $("input[type='textarea']").addClass('textarea_style');
    $("input[type='file']").addClass('file_style');
����$("input[type='file']").blur(function () { this.className='input_blur'; } );
����$("input[type='file']").focus(function () { this.className='input_focus'; } );
����$("input[type='password']").blur(function () { this.className='input_blur'; } );
����$("input[type='password']").focus(function () { this.className='input_focus'; } );
����$("input[type='text']").blur(function () { this.className='input_blur'; } );
����$("input[type='text']").focus(function () { this.className='input_focus'; } );
	$("#Title").focus(function () { this.className='inputTitle'; } );
����$("#Title").blur(function () { this.className='inputTitle'; } );
    $("textarea").blur(function () { this.className='textarea_style'; } );
����$("textarea").focus(function () { this.className='textarea_focus'; } )
����$(".table_list tr").mouseover(function () { this.className='mouseover'; } );
����$(".table_list tr").mouseout(function () { this.className=''; } );

	$("img[tag]").css({cursor:"pointer"}).click(function(){
       var flag=$(this).attr('tag');
       var fck=$("#"+$(this).attr('fck')+'___Frame');
       var fckh=fck.height();
	   (flag==0) ? fck.height(fckh-120):fck.height(fckh+120);
    });
});

/* ��ȡ�༭��ͼƬ��ַ */
function getEditorImages(Id,Editor){
	var Text = "";	var Value = "";
	var Imgs = window.frames[Editor+"___Frame"].window.frames[0].document.getElementsByTagName("IMG");	
	/* ��["Content___Frame"]��"Content"�����Լ�������Id */
	/* $("#"+Id).empty(); */
	for(var i=0; i<Imgs.length; i++){
		Text = Imgs[i].src;	Value = Imgs[i].src;
		Text = Text.substring(Text.lastIndexOf("/")+1);
		if(!isExitItem(Id,Value)){
			$("<option value='"+Value+"'>"+Text+"</option>").appendTo($("#"+Id));
		}
	}
}

/* �ж��Ƿ����ѡ�� */
function isExitItem(Id,Value){
	var isExit = false;
	$("#"+Id+" option").each(function(){
		if($(this).val() == Value){
			return true;
		}
	});
	return isExit;
}