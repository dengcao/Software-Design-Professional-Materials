var MaxAppend=6,MinAppend=2;
function AddAppend(Id){
	var Row = $("tr","#"+Id).length;
	if(MaxAppend > 0){
		if(Row >= MaxAppend){alert("���ܳ��� "+MaxAppend+" ��...");return;}
	}
	
	var html = "<tr>";
	html += "<td>�ļ����ƣ�<input name=\"text"+(Row+1)+"\" type=\"text\" id=\"text"+(Row+1)+"\" size=\"30\">&nbsp;<input name=\"file"+(Row+1)+"\" type=\"file\" id=\"file"+(Row+1)+"\" size=\"25\" ></td>";
	html += "</tr>";
	
	$("#"+Id).append(html);
}
function DelAppend(Id){
	var Row = $("tr","#"+Id).length;
	if(Row > MinAppend){
		var LastTr = $("#"+Id+" tr:last");
			LastTr.remove();
		return;
	}
	
}