/*<script type="text/javascript" src="GenJq.js">< /script>*/

/*���jQuery1.3min.js һ��ʹ��*/

/***************
 * @ Name GenJq��
 * @ Version 1.0
 * @ Writer JSPGen
 * @ Time 2009��3��
 * @ Address www.jspgen.com
 * @ E-mail:jspgen@163.com  QQ 190582560
 ***************/
var CheckFlag = false;
var GenJq = {
   "init": null
	/*��ѡ�� ȫѡ*/
    ,"CheckAll":function(name){
		$("input:checkbox[name='"+name+"']").attr("checked",'true');
    }
	/*��ѡ�� ȡ��ȫѡ*/
	,"UnCheckAll":function(name){
		$("input:checkbox[name='"+name+"']").removeAttr("checked");
    }
	/*��ѡ�� ��ѡ*/
    ,"ReCheckAll":function(name){
		$("input:checkbox[name='"+name+"']").each(function(){
			if($(this).attr("checked")){
				$(this).removeAttr("checked");
			}else{
				$(this).attr("checked",'true');
			}
		});
	}
	/*��ѡ�� ȫѡ ��ѡ �л�ʽ*/
    ,"ReUnCheckAll":function(name){
		if(CheckFlag){
			this.UnCheckAll(name);
			CheckFlag = false;
			return true;
		}else{
			this.CheckAll(name);
			CheckFlag = true;
			return false;
		}
	}
	/*��ȡ ��ѡ��ֵ*/
    ,"CheckValue":function(name,gap){
		var ides = "";
		$("input:checkbox[name='"+name+"'][checked]").each(function(){
			ides  += $(this).val()+gap;
		});
		return ides;
	}
	/*��ȡ ��ѡ��ֵ*/
    ,"RadioValue":function(name){
		var ides = "";
		/*ides = $("input:radio[name='"+name+"'][checked]").val();*/
		$("input:radio[name='"+name+"'][checked]").each(function(){
			ides = $(this).val();
		});
		return ides;
	}
	/*�ж� ��չ���Ƿ����*/
    ,"isExt":function(ext,arr){
    	if($.inArray(ext,arr) == -1){
			return false;
    	}else{
			return true;
		}
	}
};