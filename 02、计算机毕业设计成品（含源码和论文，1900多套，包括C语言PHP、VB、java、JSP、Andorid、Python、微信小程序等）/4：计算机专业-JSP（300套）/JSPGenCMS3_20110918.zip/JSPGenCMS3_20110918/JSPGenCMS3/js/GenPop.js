/*<script type="text/javascript" src="GenPop.js">< /script>*/
/*GenPop.OpenPop("��������",null,"300","85");*/

/***************
 * @ Name Div����
 * @ Version 2.0
 * @ Writer JSPGen
 * @ Time 2008��8��
 * @ Address www.jspgen.com
 * @ E-mail:jspgen@163.com  QQ 190582560
 ***************/
JSPGen.LoadCSS(JSPGen.ContextURL+'images/Pop/PopStyle.css');

/************
 * ����Div����
 ************/
var GenPop = {
	"init": null
	/*���ֲ�*/
	,"Mask":function(){
		var DivStr = document.createElement("div"); DivStr.id = "Mask";
		if(window.XMLHttpRequest){
			DivStr.style.width = "100%"; DivStr.style.height = "100%";
		}else{
			var innerwh = Gen.getInnerWH(); var offxy = Gen.getScrollXY();
			DivStr.style.width = (innerwh[0] + offxy[0])+"px";
			DivStr.style.height = (innerwh[1] + offxy[1])+"px";
		}
		document.body.appendChild(DivStr);	Gen.setAlpha("Mask",30);
		Gen.HideShowSelect(0);
	}
	/*�򿪴���*/
	,"OpenPop":function(title,url,popw,poph,scrolle){
		if(!url)url = "about:blank";	if(scrolle!=true){scrolle="no";}else{scrolle="yes";}
		var DivStr = document.createElement("div"); DivStr.id = "PopBorder";
		DivStr.style.width = (parseInt(popw)+20)+"px";	 DivStr.style.height = (parseInt(poph)+50)+"px"; 
		DivStr.innerHTML = "<div id=\"Pop\" style=\"width:"+ parseInt(popw)+"px; height:"+(parseInt(poph)+32)+"px;\"><div class=\"Header\" onMouseDown=\"Gen.StartMove('PopBorder',event);\" onMouseUp=\"Gen.StopMove();\">"
				+ "	<div class=\"Title\">"+ title +"</div>"
				+ "	<div class=\"Close\" onClick=\"GenPop.ClosePop();\" title=\"�ر�\"></div>"
				+ "</div>"
				+ "<div class=\"Content\">"
				+"	<iframe id=\"Pop_iframe\" name=\"Pop_iframe\" allowTransparency=\"true\" src=\""+url+"\" frameborder=0 height="+poph+"px marginwidth=0 marginheight=0 scrolling=\""+scrolle+"\">�Բ��� �����������֧��IFrame ��ʹ��IE��FF��������°汾����</iframe>"
				+" </div></div>";
		document.body.appendChild(DivStr);	Gen.setCenter("PopBorder");
		GenPop.Mask();
	}
	/*�رղ���*/
	,"ClosePop":function(){
		document.body.removeChild($GenId("PopBorder")); 
		document.body.removeChild($GenId("Mask"));
		Gen.HideShowSelect(1);
	}
};