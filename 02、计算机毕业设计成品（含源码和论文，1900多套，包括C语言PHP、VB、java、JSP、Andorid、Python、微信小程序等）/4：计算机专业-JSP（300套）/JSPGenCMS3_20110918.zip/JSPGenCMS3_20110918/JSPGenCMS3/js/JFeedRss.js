function JFeedRss(RssURL,Id,Num,Prefix,Postfix,CSS){
	Num = Num ? Num : 10;
	Prefix = Prefix ? Prefix : '';
	Postfix = Postfix ? Postfix : '';
	
	jQuery.getFeed({
		url: RssURL,
		success: function (feed){
			var Html='';
            for(var i=0; i<feed.items.length && i<Num; i++){
                var jitem = feed.items[i];
                Html += Prefix + '<a href="' + jitem.link + '" target="_blank">' + jitem.title + '</a>' + Postfix;
            }
			$('#'+Id).addClass(CSS);
			$('#'+Id).append(Html);
		}
	});
}