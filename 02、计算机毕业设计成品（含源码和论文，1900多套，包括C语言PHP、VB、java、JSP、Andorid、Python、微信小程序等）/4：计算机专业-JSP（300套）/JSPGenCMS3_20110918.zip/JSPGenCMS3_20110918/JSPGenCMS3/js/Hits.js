function getHits(ContextURL,Id,Type){
	var httpurl=ContextURL+'include/Ajax.jsp';
    var pars = 'act='+Type+'Hits&Id='+Id+'&time='+new Date();
	$.ajax({url:httpurl,async:false,type:'get',dataType:'text',data:pars,success:setHits});
}
function setHits(text){
	$('#Hits').html(text);
}