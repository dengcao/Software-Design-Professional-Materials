/*<script type="text/javascript" src="Gen.js">< /script>*/
/*
var FileName = ["GenJs��","Gen.js"];
var Version = "2.0";
*/
/***************
 * @ Name Gen���
 * @ Version 2.0
 * @ Writer JSPGen
 * @ Time 2008��8��
 * @ Address www.jspgen.com
 * @ E-mail:jspgen@163.com  QQ 190582560
 ***************/
/*��ʾ���*/
var NoAgreeText = "�˲�����������ܾ��������������ַ������ about:config ���س�\nȻ�� [signed.applets.codebase_principal_support] ����Ϊ true";
var ParamErrText = "��������";

/*�ж������*/
var Browser = new Object();
Browser.isMozilla = (typeof document.implementation != "undefined") && (typeof document.implementation.createDocument != "undefined") && (typeof HTMLDocument!="undefined");
Browser.isIE = window.ActiveXObject ? true : false;
Browser.isFirefox = (navigator.userAgent.toLowerCase().indexOf("firefox")!=-1);
Browser.isNetscape = (navigator.appName == "Netscape") ? true:false;
Browser.isSafari = (navigator.userAgent.toLowerCase().indexOf("safari")!=-1);
Browser.isOpera = (navigator.userAgent.toLowerCase().indexOf("opera")!=-1);

/*��ȡ����ID ���� ����*/
function $GenId(id){return document.getElementById ? document.getElementById(id):null;}
function $GenName(id){return document.getElementsByName ? document.getElementsByName(id):null;}
function $GenTagName(id){return document.getElementsByTagName ? document.getElementsByTagName(id):null;}

/************
 * ���ò���
 ************/
var MaskArr=["hidden","visible"];
var Gen = {
   "init": null
   	/************
	 * վ�ڲ���
	 ************/
	/*������֤��*/
    ,"LoadCode":function(id,url){
		if($GenId(id)){
       		$GenId(id).src = url+"?"+(new Date().getTime()); 
		}else{
			return "";
		}
    }
	/*վ������*/
    ,"Search":function(url,key,target){
		var param = "&"+key+"=";
		if(url.indexOf("?") == -1)param = "?"+key+"=";
		if(ComUtil.isNull(target))target = "_blank";
        if(window.encodeURIComponent){
            url += param+encodeURIComponent($GenId(key).value);
        }else{
            url += param+($GenId(key).value);
        }
		this.Redirect(url,target);
	}
   	/************
	 * ��������
	 ************/
    /*��ȡ��ѡ�� ��ѡ���ֵ*/
	,"getValues":function(name,gap){
		var value="";
		var checkes = $GenName(name);
		for(i=0;i<checkes.length;i++){
			if(checkes[i].checked){			
				value += (value == "" ? checkes[i].value : gap+checkes[i].value);
			}
		}
		return value;	/*alert(value);*/
    }
	/*ȫѡ*/
	,"CheckAll":function(name){
		var checkes = $GenName(name);
		for(i=0;i<checkes.length;i++){
			checkes[i].checked=true;
		}
	}
	/*��ѡ*/
	,"ReCheckAll":function(name){
		var checkes = $GenName(name);
		for(i=0;i<checkes.length;i++){
			checkes[i].checked = !checkes[i].checked
		}
	}
	/*ȫ��ѡ*/
	,"UnCheckAll":function(name){
		var checkes = $GenName(name);
		for(i=0;i<checkes.length;i++){
			checkes[i].checked=false;
		}
	}
	/*ȫѡ ��ѡ �л�ʽ*/
	,"ReUnCheckAll":function(id,name){
		var checkes = $GenName(name);
		if($GenId(id).checked==true){
			for(i=0;i<checkes.length;i++){
				checkes[i].checked=true;
			}
		}else{
			for(i=0;i<checkes.length;i++){
				checkes[i].checked=false;
			}
		}
	}
	/*��ȡ�ļ���չ��*/
	,"getFileExt":function(fileName){
		var temp = fileName.split(".");
		var fileExt = temp[temp.length-1].toLowerCase();
		return fileExt;
	}
	/*��ȡ�ļ�����ͼƬ*/
	,"getFilePic":function (fileExt){
		var ExtPic;
		switch(fileExt.toLowerCase()){
			case "txt":
				ExtPic = "txt.gif";	break;
			case "chm":
			case "hlp":
				ExtPic = "hlp.gif";	break;
			case "doc":
				ExtPic = "doc.gif";	break;
			case "pdf":
				ExtPic = "pdf.gif";	break;
			case "mdb":
				ExtPic = "mdb.gif";	break;
			case "gif":
				ExtPic = "gif.gif";	break;
			case "jpg":
				ExtPic = "jpg.gif";	break;
			case "bmp":
				ExtPic = "bmp.gif";	break;
			case "png":
				ExtPic = "pic.gif";	break;
			case "asp":
			case "jsp":
			case "js":
			case "php":
			case "php3":
			case "aspx":
				ExtPic = "code.gif";break;
			case "htm":
			case "html":
			case "shtml":
				ExtPic = "htm.gif";	break;
			case "zip":
				ExtPic = "zip.gif";	break;
			case "rar":
				ExtPic = "rar.gif";	break;
			case "exe":
				ExtPic = "exe.gif";	break;
			case "avi":
				ExtPic = "avi.gif";	break;
			case "mpg":
			case "mpeg":
			case "asf":
				ExtPic = "mp.gif";	break;
			case "ra":
			case "rm":
				ExtPic = "rm.gif";	break;
			case "mp3":
				ExtPic = "mp3.gif";	break;
			case "mid":
			case "midi":
				ExtPic = "mid.gif";	break;
			case "wav":
				ExtPic = "audio.gif";break;
			case "xls":
				ExtPic = "xls.gif";	break;
			case "ppt":
			case "pps":
				ExtPic = "ppt.gif";	break;
			case "swf":
				ExtPic = "swf.gif";	break;
			default:
				ExtPic = "unknow.gif";break;
		}
		return ExtPic;
	}
	/************
	 * �������
	 ************/
	/*��ʾ����ĳ����(��) 0���� 1��ʾ*/
	,"HideShowDiv":function (id,num){	
		if($GenId(id)){
			$GenId(id).style.visibility = MaskArr[num];
		}else{
			id.style.visibility = MaskArr[num];
		}
	}
	,"HideShowSelect":function(num){ 
		var Select = $GenTagName("select");
		for(i=0; i<Select.length; i++){
			Select[i].style.visibility = MaskArr[num];
		}
	}
	/*��ȡ���ڵĳ���*/
	,"getInnerWH":function(){
		var myW = 0, myH = 0;
		if(typeof window.innerHeight != "undefined"){ 
			/*Non-IE*/
			myW = window.innerWidth;
			myH = window.innerHeight;
		}else if(document.documentElement && (document.documentElement.clientWidth || document.documentElement.clientHeight)){
			/*IE 6+*/
			myW = document.documentElement.clientWidth;
			myH = document.documentElement.clientHeight;
		}else if(document.body && (document.body.clientWidth || document.body.clientHeight)){
			/*IE 4*/
			myW = document.body.clientWidth;
			myH = document.body.clientHeight;
		}
		return [myW, myH];
	}
	/*��ȡscrollerƫ����*/
	,"getScrollXY":function(){
		var myX = 0, myY = 0;
		if(typeof window.pageYOffset != "undefined"){ 
			/*Netscape compliant*/
			myX = window.pageXOffset;
			myY = window.pageYOffset;
		}else if( document.body && (document.body.scrollLeft || document.body.scrollTop)){
			/*DOM compliant*/
			myX = document.body.scrollLeft;
			myY = document.body.scrollTop;
		}else if(document.documentElement && (document.documentElement.scrollLeft || document.documentElement.scrollTop)){
			/*IE6 standards compliant mode*/
			myX = document.documentElement.scrollLeft;
			myY = document.documentElement.scrollTop;
		}
		return [myX, myY];
	}
	/*��ȡ�������*/
	,"getMouseXY":function(Event){
		var ScrollXY,MouseX,MouseY;
		ScrollXY = Gen.getScrollXY();
		if(document.all){
			MouseX = parseInt(ScrollXY[0]) + event.clientX;	MouseY = parseInt(ScrollXY[1]) + event.clientY;
		}else{ 
			MouseX = Event.pageX; MouseY = Event.pageY;
		}
        return [MouseX,MouseY];
	}
	/*��ȡ��������*/
	,"getObjectXY":function(id){
		var ScrollXY,ObjX,ObjY;
		if($GenId(id))id = $GenId(id);
		ScrollXY = Gen.getScrollXY();
		if(document.all){
			ObjX = parseInt(ScrollXY[0]) + id.offsetLeft;	ObjY = parseInt(ScrollXY[1]) + id.offsetTop;
		}else{ 
			ObjX = id.offsetLeft; ObjY = id.offsetTop;
		}
		return [ObjX, ObjY];

	}
	/*��ȡ������� �� ��������*/
	,"getObjectWHN":function(id){
		if($GenId(id))id = $GenId(id);
		return [id.offsetWidth, id.offsetHeight, id.offsetParent.nodeName];
	}
	/*�϶���ʼ*/
	,"StartMove":function(id,SEvent){
		var whichButton;
		if(document.all && SEvent.button==1) whichButton=true; else if(SEvent.button==0) whichButton=true;
    	if(whichButton){ 
			var DivID = $GenId(id);	/*document.getElementById(id);*/
			var offset_x = parseInt(SEvent.clientX - DivID.offsetLeft);
			var offset_y = parseInt(SEvent.clientY - DivID.offsetTop);
			document.documentElement.onmousemove = function(MEvent){
				var EEvent;
				if(document.all) EEvent = event; else EEvent = MEvent;
				var x = EEvent.clientX - offset_x;
				var y = EEvent.clientY - offset_y;
				DivID.style.left = parseInt(x)+"px";	DivID.style.top = parseInt(y)+"px";
			}
		}
	}
	/*�϶�����*/
	,"StopMove":function(){
		document.documentElement.onmousemove = null;
	}
	/*����ĳ������*/
	,"setCenter":function(id){
		var innerwh = Gen.getInnerWH();
		var offxy = Gen.getScrollXY();
		if(Browser.isIE){ /*IE*/
			if($GenId(id)){
				$GenId(id).style.top = ((innerwh[1]-$GenId(id).clientHeight)/2 + offxy[1])+"px";
				$GenId(id).style.left = ((innerwh[0]-$GenId(id).clientWidth)/2 + offxy[0])+"px";
			}else{
				id.style.top = ((innerwh[1]-obj.clientHeight)/2 + offxy[1])+"px";
				id.style.left = ((innerwh[0]-obj.clientWidth)/2 + offxy[0])+"px";
			}
		}else{
			if($GenId(id)){
				$GenId(id).style.top = ((innerwh[1]-$GenId(id).clientHeight)/2)+"px";
				$GenId(id).style.left = ((innerwh[0]-$GenId(id).clientWidth)/2)+"px";
			}else{
				id.style.top = ((innerwh[1]-obj.clientHeight)/2)+"px";
				id.style.left = ((innerwh[0]-obj.clientWidth)/2)+"px";
			}
		}
	}
	/*͸��ĳ������*/
	,"setAlpha":function(id,num){
		if(Browser.isIE){ /*IE*/
			if($GenId(id)){
				$GenId(id).style.filter = "alpha(opacity="+num+")";
			}else{
				id.style.filter = "alpha(opacity="+num+")";
			}
		}else{
			if($GenId(id)){
				$GenId(id).style.opacity = parseInt(num)/100;
			}else{
				id.style.opacity = parseInt(num)/100;
			}
		}
	}
	/*���´���*/
    ,"Dialog":function(url,title,width,height){
		if(Browser.isIE){ /*IE*/
			return showModalDialog(url, title, "dialogWidth:"+width+"px; dialogHeight:"+height+"px; help: no; scroll: yes; status: no");
		}else{
			return this.OpenWin(url,title,width,height); 
		}
	}
	/*���´���*/
    ,"OpenWin":function(url,title,width,height){ 
		var top="",left="";
		var innerwh = Gen.getInnerWH();		var offxy = Gen.getScrollXY();
		if(Browser.isIE){ /*IE*/
			top = ((innerwh[1]-height)/2 + offxy[1]);
			left = ((innerwh[0]-width)/2 + offxy[0]);
		}else{
			top = ((innerwh[1]-height)/2);
			left = ((innerwh[0]-width)/2);
		}
		return window.open(url,title,"top="+top+",left="+left+",width="+width+",height="+height+",toolbar=no,menubar=no,scrollbars=yes,resizable=no,location=no,status=no");
	}
	,"Redirect":function(url){
		/*if(url.indexOf("://") == -1 && url.substr(0, 1) != "/" && url.substr(0, 1) != "?") url = $GenName("base").href+url;
		location.href = url;*/
		this.Redirect(url,"");
	}
	,"Redirect":function(url,target){
	 	var urlStr="about:blank";	var targetStr="index";
     	if(!ComUtil.isNull(url)){urlStr = url;}
	 	if(!ComUtil.isNull(target)){targetStr = target;}
	 	return window.open(urlStr,targetStr);
	}
	,"ConfirmURL":function(url,message){
		if(confirm(message)) this.Redirect(url);
	}
	,"ConfirmForm":function(form,message){
		if(confirm(message)) form.submit();
	}
	/*��ȡ��ַ������*/
	,"getURLParam":function(name){
		var value = "";
		var params = document.location.search.match(new RegExp("[\?\&]" + name + "=([^\&]*)(\&?)","i"));
		value = params ? params[1] : params;
		return value;
	}
	/*��ȡ��ַ�����в�������(����)*/
	,"getURLPares":function(){
		var Pares = new Object();
		var Query = location.search.substring(1);
		var Pare = Query.split("&");
		for(var i=0; i<Pare.length; i++) {   
			var Pos = Pare[i].indexOf("=");
			if(Pos == -1) continue;
			var ArgName = Pare[i].substring(0,Pos);
			var value = Pare[i].substring(Pos+1);
			Pares[ArgName] = unescape(value);
		}
		return Pares;
	}
	/*����CSS*/
	,"setCss":function(id,name){
		if($GenId(id)){ $GenId(id).className = name; }else{ id.className = name; }
	}
	/*��ֵ����*/
	,"setValue":function(id,value){
		if($GenId(id)){ $GenId(id).innerHTML = value; }else{ id.innerHTML = value; }
	}
	/*ˢ��ҳ��*/
	,"Reload":function(){
		window.location.reload();
	}
	/*��ȡ��ǰҳ��ַ����ַ*/
	,"Location":function(){
		return window.location;
	}
	/*�����ղؼ�*/
	,"addFavorite":function(title,url){
		if(!url)url = Gen.Location();
		if(Browser.isIE){
			window.external.addFavorite(url,title);
		}else if(Browser.isFirefox){
			window.sidebar.addPanel(title,url,""); 
		}else if(Browser.isNetscape){
			alert("�˲�����������ܾ������ڼ��� Ctrl+D ������...");
		}else return true;
	}
	/*��Ϊ��ҳ*/
	,"setHomepage":function(url){
		if(!url)url = Gen.Location();
		if(Browser.isIE){
			document.body.style.behavior="url(#default#homepage)";
			document.body.setHomePage(url);
		}else if(Browser.isFirefox){
			if(window.netscape){
				try{
					netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect"); /*���ִ�����������*/
					alert("���óɹ�");
				}catch(e){
					alert(NoAgreeText);
					return false;
				}
			}
			var Prefs = Components.classes["@mozilla.org/preferences-service;1"].getService(Components. interfaces.nsIPrefBranch); 
			Prefs.setCharPref("browser.startup.homepage",url);
		}
		return true;
	}
	/*��������*/
	,"CopyText":function(text){
		if(Browser.isIE){
		/*if(window.clipboardData){*/
			window.clipboardData.clearData();   
        	window.clipboardData.setData("Text", text); alert("���Ƴɹ�");
		}else if(Browser.isFirefox){
			if(window.netscape){
				try{
					netscape.security.PrivilegeManager.enablePrivilege("UniversalXPConnect"); /*���ִ�����������*/
					alert("���Ƴɹ�");
				}catch(e){
					alert(NoAgreeText);
					return false;
				}
			}
			var Clip = Components.classes["@mozilla.org/widget/clipboard;1"].createInstance(Components.interfaces.nsIClipboard);   
        	if(!Clip) return;   
        	var Trans = Components.classes["@mozilla.org/widget/transferable;1"].createInstance(Components.interfaces.nsITransferable);   
        	if(!Trans) return;   
        	Trans.addDataFlavor("text/unicode");
			var TextStr = Components.classes["@mozilla.org/supports-string;1"].createInstance(Components.interfaces.nsISupportsString);    
        	TextStr.data = text;
        	Trans.setTransferData("text/unicode",TextStr,text.length*2);
        	var ClipID = Components.interfaces.nsIClipboard;
        	Clip.setData(Trans,null,ClipID.kGlobalClipboard);
		}
		return true;
	}
	/*���д���*/
    ,"RunCode":function(id){
		var value = "";
		if($GenId(id)){
			value = $GenId(id).value; 
		}else{
			value = id.value; 
		}
        var newWin = window.open("", "_blank", "");
        newWin.document.open("text/html", "replace");
		newWin.opener = null;
        newWin.document.write(value);
        newWin.document.close();
	}
	/*�������*/
    ,"SaveCode":function(id){
		var value = "";
		if($GenId(id)){
			value = $GenId(id).value; 
		}else{
			value = id.value; 
		}
        var newWin = window.open("", "_blank", "top=10000");
        newWin.document.open("text/html", "replace");
        newWin.document.write(value);
        newWin.document.execCommand("Saveas",false,"code.htm");
        newWin.close();
	}
};

/************
 * Cookie����
 ************/
var CookieUtil = {
	"init": null
	/*����Cookies*/
    ,"setCookie":function(name,value,expire){
		var cookieString=name+"="+encodeURI(value); 
		if(expire>0){
			var date=new Date();
			date.setTime(date.getTime+expire);
			cookieString=cookieString+";expire="+date.toGMTString(); 
		}
		document.cookie=cookieString; 
	}
	/*��ȡCookieֵ*/
    ,"getCookie":function(name){
		var strCookie=document.cookie; 
		var arrCookie=strCookie.split("; "); 
		for(var i=0;i<arrCookie.length;i++){ 
			var arr=arrCookie[i].split("="); 
			if(arr[0]==name)return decodeURI(arr[1]); 
		} 
		return "";
	}
	/*ɾ��Cookie*/
    ,"delCookie":function(name){
        var expires = new Date(); 
		expires.setTime(expires.getTime()-10000);
		document.cookie = name+"=null;expires="+expires.toGMTString();
	}
};

/************
 * �����ж�
 ************/
var ComUtil = {
	"init": null
	,"htmlEncode":function(str){
		return str.replace(/&/g, "&amp;").replace(/"/g, "&quot;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
	}
	,"strTrim":function(str){
		str = str.replace(/(^\s*)|(\s*$)/g, "");    
    	return str;
	}
	,"strLen":function(str){
		return str.replace(/[^\x00-\xff]/g, "**").length;
	}
	,"isNull":function(val){
		if(val == null) return true;
		if(val == "null") return true;
		if(val == "") return true; 
		var reg = "^[ ]+$"; 
		var re = new RegExp(reg); 
		return re.test(val);
	}
	,"isNum":function(val){
    	var reg = /[\d|\.|,]+/;
    	return reg.test(val);
	}
	,"isAlphaNum":function (str){
		var result=str.match(/^[a-zA-Z0-9]+$/);
		if(result==null) return false;
		return true;
	}
	,"isInt":function(val){
    	var reg = /\d+/;
    	return reg.test(val);
	}
	,"isEnglish":function(val){
		if(val.length == 0)	return false;
		for(i=0; i<val.length; i++){
			if(val.charCodeAt(i)>128)	return false;
		}
		return true;
	}
	,"isChinese":function(val){
		if(val.length == 0)	return false;
		for(i=0; i<val.length; i++) {
			if(val.charCodeAt(i)>128)	return true;
		}
		return false;
	}
	,"isEmail":function(email){
    	var reg = /([\w|_|\.|\+]+)@([-|\w]+)\.([A-Za-z]{2,4})/;
    	return reg.test(email);
	}
	,"isDate":function (str){
   		var result=str.match(/^(\d{4})(-|\/)(\d{1,2})\2(\d{1,2})$/);
   		if(result==null) return false;
   		var d=new Date(result[1], result[3]-1, result[4]);
   		return (d.getFullYear()==result[1] && d.getMonth()+1==result[3] && d.getDate()==result[4]);
	}
	,"isDateTime":function(val){
		var result=str.match(/^(\d{4})(-|\/)(\d{1,2})\2(\d{1,2}) (\d{1,2}):(\d{1,2}):(\d{1,2})$/);
		if(result==null) return false;
		var d = new Date(result[1], result[3]-1, result[4], result[5], result[6], result[7]);
		return (d.getFullYear()==result[1]&&(d.getMonth()+1)==result[3]&&d.getDate()==result[4]&&d.getHours()==result[5]&&d.getMinutes()==result[6]&&d.getSeconds()==result[7]);
	}
	,"isIP":function(val){
		if(this.isNull(val)) return false; 
		var reg=/^(\d+)\.(\d+)\.(\d+)\.(\d+)$/g;/*ƥ��IP��ַ���������ʽ*/
		if(reg.test(val)){ 
			if( RegExp.$1<256 && RegExp.$2<256 && RegExp.$3<256 && RegExp.$4<256) return true; 
		} 
		return false; 
	}
	,"isMobile":function(val){
		var reg = /^(13[0-9]|15[0|3|6|7|8|9]|18[8|9])\d{8}$/g;
		/*130 131 132 133 134 135 136 137 138 139 150 158 159*/
		var re = new RegExp(reg); 
		if(re.test(val)){ 
			return true; 
		}else{ 
			return false; 
		} 
	}
	/*��������һ��ѡ���Ƿ��Ѿ���һ����ѡ�� nameѡ�����*/
    ,"isChecked":function(name){
		var checkes = $GenName(name);
		for(i=0;i<checkes.length;i++){
			if(checkes[i].checked) return true;
		}
        return false;
    }
	/*����֤�͵����Ա�Ĺ�ϵ*/
	,"IdCardInfo":function (id){
		var sum=0; var info="";
		var city={11:"����",12:"���",13:"�ӱ�",14:"ɽ��",15:"���ɹ�",21:"����",22:"����",23:"������",31:"�Ϻ�",32:"����",33:"�㽭",34:" ����",35:"����",36:"����",37:"ɽ��",41:"����",42:"����",43:"����",44:"�㶫",45:"����",46:"����",50:"����",51:"�Ĵ�",52:"����",53:"����",54:"����",61:"����",62:"����",63:"�ຣ",64:"����",65:"�½�",71:"̨��",81:"���",82:"����",91:"����"};
		
		if(!Regexs.idcard.test(id))return false; /*�Ƿ�֤��*/
	
		id=id.replace(/x$/i,"a");
		if(city[parseInt(id.substr(0,2))]==null) return false; /*�Ƿ�����*/
	
		var birthday=id.substr(6,4)+"-"+Number(id.substr(10,2))+"-"+Number(id.substr(12,2));
		var d=new Date(birthday.replace(/-/g,"/"));
		if(birthday!=(d.getFullYear()+"-"+ (d.getMonth()+1) + "-" + d.getDate())) return false; /*�Ƿ�����*/ 
	
		for(var i = 17;i>=0;i --) sum += (Math.pow(2,i) % 11) * parseInt(id.charAt(17 - i),11) 
		if(sum%11!=1) return false; /*�Ƿ�֤��*/ 
	
		return [city[parseInt(id.substr(0,2))]+","+birthday+","+(id.substr(16,1)%2?"��":"Ů")];
	} 
	/*�ж��Ƿ��¼*/
	,"isLogin":function(name){
		var flag=false;
		if(getCookie(name) != null) flag=true;
		return flag;
	}
};

/************
 * onload�� ͬʱִ�ж������ 
 * Ĭ��ֻ��ִ��һ��
 ************/
function AddonloadEvent(fnct){
	if(typeof window.addEventListener != "undefined" ){
		window.addEventListener("load",fnct,false);
	}else{
		if(typeof window.attachEvent != "undefined"){
			window.attachEvent("onload", fnct);
		}else{
			if(window.onload != null){
				var oldOnload = window.onload;
				window.onload = function (e){
					oldOnload(e); window[fnct]();
				};
			}else{
				window.onload = fnc;
			}
		}
	}
}

/************
 * ͸����ʾIE��PNGͼƬ
 ************/
function CorrectPNG(){
	if(Browser.isIE){
		for(var i=0; i<document.images.length; i++){
			var img = document.images[i];
			var imgName = img.src.toUpperCase();
			if(imgName.substring(imgName.length-3, imgName.length) == "PNG"){
				var imgID = (img.id) ? "id=\"" + img.id + "\" " : "";
				var imgClass = (img.className) ? "class=\"" + img.className + "\" " : "";
				var imgTitle = (img.title) ? "title=\"" + img.title + "\" " : "title=\"" + img.alt + "\" ";
				var imgStyle = "display:inline-block;" + img.style.cssText;
				if(img.align == "left") imgStyle = "float:left;" + imgStyle;
				if(img.align == "right") imgStyle = "float:right;" + imgStyle;
				if(img.parentElement.href) imgStyle = "cursor:hand;" + imgStyle;
				var strNewHTML = "<span " + imgID + imgClass + imgTitle
						+ " style=\"width:" + img.width + "px; margin:6px; height:" + img.height + "px;" + imgStyle + ";"
						+ "filter:progid:DXImageTransform.Microsoft.AlphaImageLoader"
						+ "(src=\"" + img.src + "\", sizingMethod=\"scale\");\"></span>";
				img.outerHTML = strNewHTML;
				i = i-1;
			}
		}
	}
}
AddonloadEvent(CorrectPNG);

/************
 * ͼƬ��ʾЧ��
 ************/
var flag=false; 
function setPicWH(ImgD,w,h){ 
	var image=new Image();
	image.src=ImgD.src; 
	if(image.width>0 && image.height>0){ 
		flag=true; 
		if(image.width/image.height>= w/h){ 
			if(image.width>w){  
				ImgD.width=w; 
				ImgD.height=(image.height*w)/image.width; 
				ImgD.style.display="block";
			}else{ 
				ImgD.width=image.width;  
				ImgD.height=image.height; 
				ImgD.style.display="block";
			} 
		}else{
			if(image.height>h){  
				ImgD.height=h; 
				ImgD.width=(image.width*h)/image.height; 
				ImgD.style.display="block"; 
			}else{ 
				ImgD.width=image.width;  
				ImgD.height=image.height; 
				ImgD.style.display="block";
			} 
		} 
	} 
}