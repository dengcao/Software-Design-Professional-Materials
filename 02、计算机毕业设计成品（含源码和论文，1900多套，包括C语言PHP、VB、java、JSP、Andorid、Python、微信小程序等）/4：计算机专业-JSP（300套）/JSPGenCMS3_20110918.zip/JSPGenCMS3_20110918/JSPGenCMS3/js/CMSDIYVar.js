var MaxAppend=-1,MinAppend=1;
function AddAppend(Id){
	var Row = $("tr","#"+Id).length;
	if(MaxAppend > 0){
		if(Row >= MaxAppend){alert("���ܳ��� "+MaxAppend+" ��...");return;}
	}
	
	var html = "<tr>";
	html += "<td width=\"29%\">����&nbsp;<input type=\"text\" name=\"DIYVar_Desc\" size=\"20\" /></td>";
	html += "<td width=\"32%\">����&nbsp;<input type=\"text\" name=\"DIYVar_Name\" size=\"20\" />&nbsp;=&gt;</td>";
	html += "<td width=\"39%\">ֵ&nbsp;<input type=\"text\" name=\"DIYVar_Value\" size=\"30\" /></td>";
	html += "</tr>";

	$("#"+Id).append(html);
}
function DelAppend(Id){
	var Row = $("tr","#"+Id).length;
	if(Row > MinAppend){
		var LastTr = $("#"+Id+" tr:last");
			LastTr.remove();
		return;
	}
	
}