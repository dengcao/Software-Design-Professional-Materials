﻿/*
 * FCKeditor - The text editor for Internet - http://www.fckeditor.net
 * Copyright (C) 2003-2008 Frederico Caldeira Knabben
 *
 * == BEGIN LICENSE ==
 *
 * Licensed under the terms of any of the following licenses at your
 * choice:
 *
 *  - GNU General Public License Version 2 or later (the "GPL")
 *    http://www.gnu.org/licenses/gpl.html
 *
 *  - GNU Lesser General Public License Version 2.1 or later (the "LGPL")
 *    http://www.gnu.org/licenses/lgpl.html
 *
 *  - Mozilla Public License Version 1.1 or later (the "MPL")
 *    http://www.mozilla.org/MPL/MPL-1.1.html
 *
 * == END LICENSE ==
 *
 * Scripts related to the Media dialog window (see fck_Media.html).
 */

var dialog		= window.parent ;
var oEditor		= dialog.InnerDialogLoaded() ;
var FCK			= oEditor.FCK ;
var FCKLang		= oEditor.FCKLang ;
var FCKConfig	= oEditor.FCKConfig ;
var FCKTools	= oEditor.FCKTools ;

//#### Dialog Tabs

// Set the dialog tabs.
dialog.AddTab( 'Info', oEditor.FCKLang.DlgInfoTab ) ;

if ( FCKConfig.AttachUpload )
	dialog.AddTab( 'Upload', FCKLang.DlgLnkUpload ) ;

// Function called when a dialog tag is selected.
function OnDialogTabChange( tabCode ){
	ShowE('divInfo'		, ( tabCode == 'Info' ) ) ;
	ShowE('divUpload'	, ( tabCode == 'Upload' ) ) ;
}

// Get the selected Attach embed (if available).
var oFakeImage = dialog.Selection.GetSelectedElement() ;
var oEmbed ;

if ( oFakeImage ){
	if ( oFakeImage.tagName == 'IMG' && oFakeImage.getAttribute('_fckattach') )
		oEmbed = FCK.GetRealElement( oFakeImage ) ;
	else
		oFakeImage = null ;
}

window.onload = function(){
	// Translate the dialog box texts.
	oEditor.FCKLanguageManager.TranslatePage(document) ;

	// Load the selected element information (if any).
	LoadSelection() ;

	// Show/Hide the "Browse Server" button.
	GetE('tdBrowse').style.display = FCKConfig.AttachBrowser	? '' : 'none' ;

	// Set the actual uploader URL.
	if(FCKConfig.AttachUpload )
		GetE('frmUpload').action = FCKConfig.AttachUploadURL ;

	dialog.SetAutoSize( true ) ;

	// Activate the "OK" button.
	dialog.SetOkButton( true ) ;

	SelectField( 'txtUrl' ) ;
}

function LoadSelection(){
	if ( ! oEmbed ) return ;

	GetE('txtUrl').value    = GetAttribute( oEmbed, 'href', '' ) ;
	GetE('txtName').value    = oEmbed.innerHTML ;
	UpdatePreview() ;
}

//#### The OK button was hit.
function Ok(){
	if ( GetE('txtUrl').value.length == 0 ){
		dialog.SetSelectedTab( 'Info' ) ;
		GetE('txtUrl').focus() ;
		alert( oEditor.FCKLang.DlgAlertUrl ) ;
		return false ;
	}

	oEditor.FCKUndo.SaveUndoStep() ;
	if ( !oEmbed ){
		oEmbed		= FCK.EditorDocument.createElement( 'a' ) ;
	}
	UpdateEmbed( oEmbed ) ;

	FCK.InsertElement(oEmbed);
	return true ;
}

function UpdateEmbed( e ){
	var txtName = "";
	if(GetE('txtName').value.length == 0 ){
		txtName = GetE('txtUrl').value;
	}else{
		txtName = GetE('txtName').value;
	}
	SetAttribute( e, 'href', GetE('txtUrl').value ) ;
	e.innerHTML = txtName ;
}

var ePreview ;
function SetPreviewElement( previewEl ){
	ePreview = previewEl ;

	if ( GetE('txtUrl').value.length > 0 )
		UpdatePreview() ;
}

function UpdatePreview(){
	if ( !ePreview )
		return ;

	while ( ePreview.firstChild )
		ePreview.removeChild( ePreview.firstChild ) ;

	if ( GetE('txtUrl').value.length == 0 )
		ePreview.innerHTML = '&nbsp;' ;
	else{
		var oDoc	= ePreview.ownerDocument || ePreview.document ;
		var e		= oDoc.createElement( 'a' ) ;

		SetAttribute( e, 'href', GetE('txtUrl').value ) ;
		e.innerHTML = GetE('txtName').value ;
		ePreview.appendChild( e ) ;
	}
}

//<embed id="ePreview" src="fck_flash/claims.swf" width="100%" height="100%" style="visibility:hidden" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer">

function BrowseServer(){
	var BrowserURL = FCKConfig.AttachBrowserURL;
	if(BrowserURL.indexOf("?") == -1){
		BrowserURL += '?ProjectId='+FCKConfig.ProjectId ;
	}else{
		BrowserURL += '&ProjectId='+FCKConfig.ProjectId ;
	}
	OpenFileBrowser( BrowserURL, FCKConfig.AttachBrowserWindowWidth, FCKConfig.AttachBrowserWindowHeight ) ;
}

function SetUrl( url, width, height, filename){
	GetE('txtUrl').value = url ;
    if(filename) try {GetE('txtName').value = filename;}catch(e){}
	UpdatePreview() ;
	dialog.$( 'throbberBlock' ).style.visibility = 'hidden' ;
	dialog.SetSelectedTab( 'Info' ) ;
}

function OnUploadCompleted( errorNumber, fileUrl, fileName, customMsg ){
	// Remove animation
	window.parent.Throbber.Hide() ;
	GetE( 'divUpload' ).style.display  = '' ;

	switch ( errorNumber ){
		case 0 :	/* 成功 */
			alert( customMsg ) ;	/* 您已上传成功 */
			break ;
		case 1 :	/* 错误 */
			alert( customMsg ) ;
			return ;
		case 101 :	// 警告
			alert( customMsg ) ;
			break ;
		case 201 :
			alert( '文件名重复，该文件已更名为"' + fileName + '"' ) ;
			break ;
		case 202 :
			alert( '文件类型无效' ) ;
			return ;
		case 203 :
			alert( "安全错误，服务器不允许上传！" ) ;
			return ;
		case 500 :
			alert( '链接不上' ) ;
			break ;
		default :
			alert( '文件上传出错，错误代码: ' + errorNumber ) ;
			return ;
	}
	SetUrl( fileUrl ) ;
	GetE('frmUpload').reset() ;
}

function CheckUpload(){
	var sFile = GetE('txtUploadFile').value ;
	if ( sFile.length == 0 ){
		alert( '请选择一个上传对象' ) ;
		return false ;
	}
	
	if((GetE('frmUpload').action).indexOf("?") == -1){
		GetE('frmUpload').action += '?ProjectId='+FCKConfig.ProjectId ;
	}else{
		GetE('frmUpload').action += '&ProjectId='+FCKConfig.ProjectId ;
	}
	
	//alert(GetE('frmUpload').action);
	
	// Show animation
	window.parent.Throbber.Show( 100 ) ;
	GetE( 'divUpload' ).style.display  = 'none' ;

	return true ;
}
