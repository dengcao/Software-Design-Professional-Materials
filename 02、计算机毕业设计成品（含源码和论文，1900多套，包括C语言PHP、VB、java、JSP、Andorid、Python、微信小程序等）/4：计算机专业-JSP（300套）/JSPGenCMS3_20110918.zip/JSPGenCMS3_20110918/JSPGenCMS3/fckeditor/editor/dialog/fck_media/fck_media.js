﻿/*
 * FCKeditor - The text editor for Internet - http://www.fckeditor.net
 * Copyright (C) 2003-2008 Frederico Caldeira Knabben
 *
 * == BEGIN LICENSE ==
 *
 * Licensed under the terms of any of the following licenses at your
 * choice:
 *
 *  - GNU General Public License Version 2 or later (the "GPL")
 *    http://www.gnu.org/licenses/gpl.html
 *
 *  - GNU Lesser General Public License Version 2.1 or later (the "LGPL")
 *    http://www.gnu.org/licenses/lgpl.html
 *
 *  - Mozilla Public License Version 1.1 or later (the "MPL")
 *    http://www.mozilla.org/MPL/MPL-1.1.html
 *
 * == END LICENSE ==
 *
 * Scripts related to the Media dialog window (see fck_Media.html).
 */

var dialog		= window.parent ;
var oEditor		= dialog.InnerDialogLoaded() ;
var FCK			= oEditor.FCK ;
var FCKLang		= oEditor.FCKLang ;
var FCKConfig	= oEditor.FCKConfig ;
var FCKTools	= oEditor.FCKTools ;

//#### Dialog Tabs

// Set the dialog tabs.
dialog.AddTab( 'Info', oEditor.FCKLang.DlgInfoTab ) ;

if ( FCKConfig.MediaUpload )
	dialog.AddTab( 'Upload', FCKLang.DlgLnkUpload ) ;

// Function called when a dialog tag is selected.
function OnDialogTabChange( tabCode ){
	ShowE('divInfo'		, ( tabCode == 'Info' ) ) ;
	ShowE('divUpload'	, ( tabCode == 'Upload' ) ) ;
}

// Get the selected Media embed (if available).
var oFakeImage = dialog.Selection.GetSelectedElement() ;
var oEmbed ;

if ( oFakeImage ){
	if ( oFakeImage.tagName == 'IMG' && oFakeImage.getAttribute('_fckmedia') )
		oEmbed = FCK.GetRealElement( oFakeImage ) ;
	else
		oFakeImage = null ;
}

window.onload = function(){
	// Translate the dialog box texts.
	oEditor.FCKLanguageManager.TranslatePage(document) ;

	// Load the selected element information (if any).
	LoadSelection() ;

	// Show/Hide the "Browse Server" button.
	GetE('tdBrowse').style.display = FCKConfig.MediaBrowser	? '' : 'none' ;

	// Set the actual uploader URL.
	if ( FCKConfig.MediaUpload )
		GetE('frmUpload').action = FCKConfig.MediaUploadURL ;

	dialog.SetAutoSize( true ) ;

	// Activate the "OK" button.
	dialog.SetOkButton( true ) ;

	SelectField( 'txtUrl' ) ;
}

function LoadSelection(){
	if ( ! oEmbed ) return ;

	GetE('txtUrl').value    = GetAttribute( oEmbed, 'src', '' ) ;
	GetE('txtWidth').value  = GetAttribute( oEmbed, 'width', '' ) ;
	GetE('txtHeight').value = GetAttribute( oEmbed, 'height', '' ) ;
	GetE('chkAutoPlay').checked	= GetAttribute( oEmbed, 'play', 'true' ) == 'true' ;

	UpdatePreview() ;
}

//#### The OK button was hit.
function Ok()
{
	if ( GetE('txtUrl').value.length == 0 )
	{
		dialog.SetSelectedTab( 'Info' ) ;
		GetE('txtUrl').focus() ;

		alert( oEditor.FCKLang.DlgAlertUrl ) ;

		return false ;
	}

	oEditor.FCKUndo.SaveUndoStep() ;
	if ( !oEmbed )
	{
		oEmbed		= FCK.EditorDocument.createElement( 'EMBED' ) ;
		oFakeImage  = null ;
	}
	UpdateEmbed( oEmbed ) ;

	if ( !oFakeImage ){
		oFakeImage	= oEditor.FCKDocumentProcessor_CreateFakeImage( 'FCK__Media', oEmbed ) ;
		oFakeImage.setAttribute( '_fckmedia', 'true', 0 ) ;
		oFakeImage	= FCK.InsertElement( oFakeImage ) ;
	}

	oEditor.FCKEmbedAndObjectProcessor.RefreshView( oFakeImage, oEmbed ) ;

	return true ;
}

function UpdateEmbed( e ){
	SetAttribute( e, 'type'			, 'audio/x-pn-realaudio-plugin' ) ;
	SetAttribute( e, 'console'	, 'Clip1' ) ;
	SetAttribute( e, 'controls'	, 'IMAGEWINDOW,ControlPanel,StatusBar' ) ;
	SetAttribute( e, 'autostart'	, GetE('chkAutoPlay').checked ? 'true' : 'false' ) ;

	SetAttribute( e, 'src', GetE('txtUrl').value ) ;
	SetAttribute( e, "width" , GetE('txtWidth').value ) ;
	SetAttribute( e, "height", GetE('txtHeight').value ) ;
}

var ePreview ;

function SetPreviewElement( previewEl ){
	ePreview = previewEl ;

	if ( GetE('txtUrl').value.length > 0 )
		UpdatePreview() ;
}

function UpdatePreview(){
	if ( !ePreview )
		return ;

	while ( ePreview.firstChild )
		ePreview.removeChild( ePreview.firstChild ) ;

	if ( GetE('txtUrl').value.length == 0 )
		ePreview.innerHTML = '&nbsp;' ;
	else{
		/*
		if(url.indexOf('.rm')>0 || url.indexOf('.rmvb')>0 || url.indexOf('.ram')>0 ){
			ePreview.innerHTML = "<embed src='"+ url +"' quality='hight' wmode='transparent' type='audio/x-pn-realaudio-plugin' autostart='0' controls='IMAGEWINDOW,ControlPanel,StatusBar' console='Clip1' width='"+width+"' height='"+height+"'></embed>";
		}else{
			ePreview.innerHTML = "<embed src='"+ url +"' align='baseline' border='0' width='"+width+"' height='"+height+"' type='application/x-mplayer2' pluginspage='http://www.microsoft.com/isapi/redir.dll?prd=windows&amp;sbp=mediaplayer&amp;ar=media&amp;sba=plugin&amp;'   name='MediaPlayer' showcontrols='1' showpositioncontrols='0' showaudiocontrols='1' showtracker='1' showdisplay='0' showstatusbar='1' autosize='0' showgotobar='0' showcaptioning='0' autostart='0' autorewind='0' animationatstart='0' transparentatstart='0' allowscan='1' enablecontextmenu='1' clicktoplay='0' invokeurls='1' defaultframe='datawindow'></embed>";
		}
		*/
		var oDoc	= ePreview.ownerDocument || ePreview.document ;
		var e		= oDoc.createElement( 'EMBED' ) ;

		SetAttribute( e, 'src', GetE('txtUrl').value ) ;
		SetAttribute( e, 'width', '100%' ) ;
		SetAttribute( e, 'height', '100%' ) ;

		SetAttribute( e, 'type', 'audio/x-pn-realaudio-plugin' ) ;
		SetAttribute( e, 'console', 'Clip1' ) ;
		SetAttribute( e, 'controls', 'IMAGEWINDOW,ControlPanel,StatusBar' ) ;
		SetAttribute( e, 'autostart', 'true') ;

		ePreview.appendChild( e ) ;
	}
}

// <embed id="ePreview" src="fck_flash/claims.swf" width="100%" height="100%" style="visibility:hidden" type="application/x-shockwave-flash" pluginspage="http://www.macromedia.com/go/getflashplayer">

function BrowseServer(){
	var BrowserURL = FCKConfig.MediaBrowserURL;
	if(BrowserURL.indexOf("?") == -1){
		BrowserURL += '?ProjectId='+FCKConfig.ProjectId ;
	}else{
		BrowserURL += '&ProjectId='+FCKConfig.ProjectId ;
	}
	OpenFileBrowser( BrowserURL, FCKConfig.MediaBrowserWindowWidth, FCKConfig.MediaBrowserWindowHeight ) ;
}

function SetUrl( url, width, height ){
	GetE('txtUrl').value = url ;

	if ( width )
		GetE('txtWidth').value = width ;

	if ( height )
		GetE('txtHeight').value = height ;

	UpdatePreview() ;

	dialog.SetSelectedTab( 'Info' ) ;
}

function OnUploadCompleted( errorNumber, fileUrl, fileName, customMsg ){
	// Remove animation
	window.parent.Throbber.Hide() ;
	GetE( 'divUpload' ).style.display  = '' ;

	switch ( errorNumber ){
		case 0 :	/* 成功 */
			alert( customMsg ) ;	/* 您已上传成功 */
			break ;
		case 1 :	/* 错误 */
			alert( customMsg ) ;
			return ;
		case 101 :	// 警告
			alert( customMsg ) ;
			break ;
		case 201 :
			alert( '文件名重复，该文件已更名为"' + fileName + '"' ) ;
			break ;
		case 202 :
			alert( '文件类型无效' ) ;
			return ;
		case 203 :
			alert( "安全错误，服务器不允许上传！" ) ;
			return ;
		case 500 :
			alert( '链接不上' ) ;
			break ;
		default :
			alert( '文件上传出错，错误代码: ' + errorNumber ) ;
			return ;
	}

	SetUrl( fileUrl ) ;
	GetE('frmUpload').reset() ;
}


function CheckUpload(){
	var sFile = GetE('txtUploadFile').value ;
	
	if ( sFile.length == 0 ){
		alert( '请选择一个上传对象' ) ;
		return false ;
	}
	if((GetE('frmUpload').action).indexOf("?") == -1){
		GetE('frmUpload').action += '?ProjectId='+FCKConfig.ProjectId ;
	}else{
		GetE('frmUpload').action += '&ProjectId='+FCKConfig.ProjectId ;
	}
	
	//alert(GetE('frmUpload').action);
	// Show animation
	window.parent.Throbber.Show( 100 ) ;
	GetE( 'divUpload' ).style.display  = 'none' ;

	return true ;
}
function show_ok(id,val){
	alert(val);
	dialog.Cancel();
}