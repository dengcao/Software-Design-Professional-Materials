window.onload = function () {
	dp.SyntaxHighlighter.ClipboardSwf = 'Scripts/clipboard.swf';
	dp.SyntaxHighlighter.HighlightAll('code');
}
