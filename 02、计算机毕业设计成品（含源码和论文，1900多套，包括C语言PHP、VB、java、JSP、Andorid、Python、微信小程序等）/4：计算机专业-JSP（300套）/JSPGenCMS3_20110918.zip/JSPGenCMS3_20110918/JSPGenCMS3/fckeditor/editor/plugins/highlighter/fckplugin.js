﻿/*
 * 为FCKeditor增加 语法显示(HighLighter) 插件
 * Author	: JSPGen <JSPGen@163.com>
 * Http		: www.JSPGen.com
 * Date		: 2008-08-08
 */
FCKCommands.RegisterCommand( 'HighLighter', new FCKDialogCommand("HighLighter",FCKLang['CodeDlgTitle'],FCKConfig.PluginsPath + 'highlighter/highlighter.html', 520, 400));
var oHighLighterItem		= new FCKToolbarButton( 'HighLighter', FCKLang['CodeBtn'] ) ;
oHighLighterItem.IconPath	= FCKConfig.PluginsPath + 'highlighter/highlighter.gif' ;
FCKToolbarItems.RegisterItem( 'HighLighter', oHighLighterItem );
var FCKHighLighter = new Object();
var CSS_PATH 	  = FCKConfig.PluginsPath + "highlighter/dp.SyntaxHighlighter/Styles/";
var pool = {"firstCss" : true };
FCKHighLighter.Add = function( value ){
	var oDiv  = FCK.CreateElement("div");
 	oDiv._FCKhighLighter = "hlDiv" + Math.random()  ; 
	oDiv.className="dp-highlighter";
	oDiv.innerHTML = value;
	if(pool.firstCss) {
		pool.firstCss = false;
	}
}
FCKHighLighter.OnDoubleClick = function( div ){
	if(div.className == "dp-highlighter" && div.tagName=="DIV") FCKCommands.GetCommand( 'HighLighter' ).Execute() ;
}
FCK.RegisterDoubleClickHandler( FCKHighLighter.OnDoubleClick, 'DIV' ) ;
