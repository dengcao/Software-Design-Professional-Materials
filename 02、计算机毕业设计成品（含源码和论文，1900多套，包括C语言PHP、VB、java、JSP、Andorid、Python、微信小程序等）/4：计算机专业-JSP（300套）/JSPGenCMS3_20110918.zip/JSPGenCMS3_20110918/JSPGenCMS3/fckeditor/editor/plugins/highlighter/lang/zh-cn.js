﻿FCKLang.CodeBtn                     = '插入高亮代码' ;
FCKLang.CodeArea                    = '代码';
FCKLang.CodeDlgTitle                = '插入高亮代码' ;
FCKLang.CodeDlgName                 = '语言' ;
FCKLang.CodeErrNoName               = '请输入代码' ;
