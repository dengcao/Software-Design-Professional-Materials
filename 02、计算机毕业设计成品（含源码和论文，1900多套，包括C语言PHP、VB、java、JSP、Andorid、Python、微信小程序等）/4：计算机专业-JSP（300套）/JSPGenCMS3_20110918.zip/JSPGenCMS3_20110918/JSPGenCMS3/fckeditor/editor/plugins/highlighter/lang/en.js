﻿FCKLang.CodeBtn                     = 'Insert Code Highlighter' ;
FCKLang.CodeArea                    = 'Code';
FCKLang.CodeDlgTitle                = 'Insert Code Highlighter' ;
FCKLang.CodeDlgName                 = 'Language' ;
FCKLang.CodeErrNoName               = 'Please Insert Code' ;