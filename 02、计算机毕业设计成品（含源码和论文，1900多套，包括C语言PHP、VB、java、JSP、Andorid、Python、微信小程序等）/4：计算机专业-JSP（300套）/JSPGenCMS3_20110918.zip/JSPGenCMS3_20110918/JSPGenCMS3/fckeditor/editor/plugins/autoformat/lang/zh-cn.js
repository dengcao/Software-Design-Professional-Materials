﻿FCKLang.FormatBtn                   = '自动排版' ;
