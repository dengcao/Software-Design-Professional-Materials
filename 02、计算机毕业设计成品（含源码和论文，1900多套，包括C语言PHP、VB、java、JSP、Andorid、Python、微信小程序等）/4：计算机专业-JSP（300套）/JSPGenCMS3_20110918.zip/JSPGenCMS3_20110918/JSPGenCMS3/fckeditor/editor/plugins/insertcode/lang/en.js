﻿FCKLang.CodeBtn                     = 'Insert Code' ;
FCKLang.CodeArea                    = 'Code';
FCKLang.CodeDlgTitle                = 'Insert Code' ;
FCKLang.CodeDlgName                 = 'Language' ;
FCKLang.CodeErrNoName               = 'Please Insert Code' ;