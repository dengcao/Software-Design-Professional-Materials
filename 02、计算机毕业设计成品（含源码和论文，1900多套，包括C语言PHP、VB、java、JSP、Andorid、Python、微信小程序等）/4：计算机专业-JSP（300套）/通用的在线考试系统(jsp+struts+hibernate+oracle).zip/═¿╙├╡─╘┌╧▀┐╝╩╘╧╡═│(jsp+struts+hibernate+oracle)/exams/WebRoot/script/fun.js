

function chknumber(temp){
	return temp.match(/\D/)==null;
}