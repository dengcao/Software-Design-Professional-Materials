package com.xdf.exams.dao;

public interface IOptionsDAO extends IDAO{
	public void deletebyquestion(Long qid);
}
