package com.xdf.exams.util;


public class Constant {
	public static int PAGESIZE = 10;
}
