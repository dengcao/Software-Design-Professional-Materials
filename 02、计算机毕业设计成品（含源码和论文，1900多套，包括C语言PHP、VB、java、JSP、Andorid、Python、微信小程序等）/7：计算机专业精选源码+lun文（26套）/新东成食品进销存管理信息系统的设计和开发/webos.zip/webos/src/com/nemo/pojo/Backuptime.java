package com.nemo.pojo;

/**
 * @Author 刘宇飞
 * @Date 2016/05/04 18:11
 */
public class Backuptime {
    private int id;
    private String time;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }


    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }
}
