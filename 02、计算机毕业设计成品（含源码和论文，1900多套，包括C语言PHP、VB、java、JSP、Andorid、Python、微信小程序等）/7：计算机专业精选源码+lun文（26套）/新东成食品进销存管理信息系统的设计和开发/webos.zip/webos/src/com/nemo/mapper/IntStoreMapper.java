package com.nemo.mapper;

import com.nemo.pojo.IntStore;

import java.util.List;
import java.util.Map;

/**
 * @Author 刘宇飞
 * @Date 2016/04/08 22:23
 * 入库mapper
 */
public interface IntStoreMapper {

    public List<IntStore> findIntStoreList();

    public List<IntStore> findLimitList(Map<String, String> map);

    public List<IntStore> findAllLimitList(Map<String,String> map);

    public List<IntStore> count(Map<String, String> map);

    public boolean deleteIntStoreById(Map<String, String> map);

    public boolean updateIntStore(IntStore intStore);

    public boolean addIntStore(IntStore intStore);

    public IntStore findIntStoreById(Map<String, String> map);

    public boolean updateStatus(Map<String,String> map);

    public List<IntStore> findFuzzyList(Map<String,String> map);





}
