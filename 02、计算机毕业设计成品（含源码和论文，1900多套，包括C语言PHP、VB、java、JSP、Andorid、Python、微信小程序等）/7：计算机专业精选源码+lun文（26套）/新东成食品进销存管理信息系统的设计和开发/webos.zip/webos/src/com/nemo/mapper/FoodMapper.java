package com.nemo.mapper;

import com.nemo.pojo.Food;

import java.util.List;
import java.util.Map;

/**
 * @Author 刘宇飞
 * @Date 2016/04/08 22:23
 * 食品分类mapper
 */
public interface FoodMapper {

    public List<Food> findFoodList();

    public List<Food> findFoodList2(Map<String, String> map);

    public List<Food> findLimitList(Map<String, String> map);

    public int count();

    public boolean deleteFoodById(Map<String, String> map);

    public boolean updateFood(Food food);

    public boolean addFood(Food food);

    public Food findFoodById(Map<String, String> map);

    public List<Food> findFuzzyList(Map<String,String> map);

}
