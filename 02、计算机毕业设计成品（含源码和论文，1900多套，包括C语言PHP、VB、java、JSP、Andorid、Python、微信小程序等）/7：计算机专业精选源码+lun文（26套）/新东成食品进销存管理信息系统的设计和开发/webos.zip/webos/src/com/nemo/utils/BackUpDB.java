package com.nemo.utils;

import java.io.*;

/**
 * @Author 刘宇飞
 * @Date 2016/05/04 17:20
 */
public class BackUpDB {
    public static void main(String[] args) throws IOException {
     /*   backup("c:\\\\d.sql");
        recover("c:\\\\d.sql");*/
    }

    public static boolean backup() {
        try {
            Runtime rt = Runtime.getRuntime();
            // 调用 调用mysql的安装目录的命令
            Process child = rt
                    .exec("C://Program Files (x86)//MySQL//MySQL Server 5.0//bin//mysqldump -h localhost -uroot -p1  sms");
            // 设置导出编码为utf-8。这里必须是utf-8
            // 把进程执行中的控制台输出信息写入.sql文件，即生成了备份文件。注：如果不对控制台信息进行读出，则会导致进程堵塞无法运行
            InputStream in = child.getInputStream();// 控制台的输出信息作为输入流
            InputStreamReader xx = new InputStreamReader(in, "utf-8");
            // 设置输出流编码为utf-8。这里必须是utf-8，否则从流中读入的是乱码
            String inStr;
            StringBuffer sb = new StringBuffer("");
            String outStr;
            // 组合控制台输出信息字符串
            BufferedReader br = new BufferedReader(xx);
            while ((inStr = br.readLine()) != null) {
                sb.append(inStr + "\r\n");
            }
            outStr = sb.toString();
            // 要用来做导入用的sql目标文件：
            FileOutputStream fout = new FileOutputStream(
                    "d:/test.sql");
            OutputStreamWriter writer = new OutputStreamWriter(fout, "utf-8");
            writer.write(outStr);
            writer.flush();
            in.close();
            xx.close();
            br.close();
            writer.close();
            fout.close();
            System.out.println("");
            if(outStr.length()>0){
                return true;
            }else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    public static boolean recover() throws IOException {
        try {
            String fPath = "d:/test.sql";
            Runtime rt = Runtime.getRuntime();
            // 调用 mysql 安装目录的命令
            Process child = rt.exec("C://Program Files (x86)//MySQL//MySQL Server 5.0//bin//mysql -h localhost -uroot -p1  sms");

            OutputStream out = child.getOutputStream();// 控制台的输入信息作为输出流
            String inStr;
            StringBuffer sb = new StringBuffer("");
            String outStr;
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    new FileInputStream(fPath), "utf-8"));
            while ((inStr = br.readLine()) != null) {
                sb.append(inStr + "\r\n");
            }
            outStr = sb.toString();
            System.out.println(outStr);
            OutputStreamWriter writer = new OutputStreamWriter(out, "utf-8");
            writer.write(outStr);
            writer.flush();
            out.close();
            br.close();
            writer.close();
            System.out.println("");

            if(outStr.length()>0){
                return true;
            }else {
                return false;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

}
