package com.nemo.mapper;


import com.nemo.pojo.ProvideFood;

import java.util.List;
import java.util.Map;

/**
 *@Author 刘宇飞
 *@Date 2016/04/15 09:11
 *供应商供应食品mapper
 */
public interface ProvideFoodMapper {
    public boolean deleteProvideFoodById(Map<String, String> map);

    public boolean updateProvideFood(ProvideFood provideFood);

    public boolean addProvideFood(ProvideFood provideFood);

    public List<ProvideFood> findProvideFoodListByProviderId(Map<String, String> map);

    public List<ProvideFood> findProvideFoodListByFoodName(Map<String, String> map);

    public ProvideFood findProvideFoodById(Map<String, String> map);

    public List<ProvideFood> findLimitList(Map<String, String> map);

    public int count();

    public List<ProvideFood> findFuzzyList(Map<String,String> map);





}
