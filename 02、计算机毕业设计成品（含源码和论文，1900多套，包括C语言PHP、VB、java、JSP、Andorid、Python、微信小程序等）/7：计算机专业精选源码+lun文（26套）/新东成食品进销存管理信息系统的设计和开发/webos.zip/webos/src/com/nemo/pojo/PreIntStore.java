package com.nemo.pojo;

/**
 * Created by FWMS on 2016-05-11.
 * 进货单
 */
public class PreIntStore {
    private String preIntId;
    private int userId;
    private  String userName;
    private int intType;
    private String createTime;
    private String intDate;
    private int status;
    private String reason;
    private String remarks;

    public String getPreIntId() {
        return preIntId;
    }

    public void setPreIntId(String preIntId) {
        this.preIntId = preIntId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public int getIntType() {
        return intType;
    }

    public void setIntType(int intType) {
        this.intType = intType;
    }

    public String getCreateTime() {
        return createTime;
    }

    public void setCreateTime(String createTime) {
        this.createTime = createTime;
    }

    public String getIntDate() {
        return intDate;
    }

    public void setIntDate(String intDate) {
        this.intDate = intDate;
    }

    public int getStatus() {
        return status;
    }

    public void setStatus(int status) {
        this.status = status;
    }

    public String getReason() {
        return reason;
    }

    public void setReason(String reason) {
        this.reason = reason;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }
}
