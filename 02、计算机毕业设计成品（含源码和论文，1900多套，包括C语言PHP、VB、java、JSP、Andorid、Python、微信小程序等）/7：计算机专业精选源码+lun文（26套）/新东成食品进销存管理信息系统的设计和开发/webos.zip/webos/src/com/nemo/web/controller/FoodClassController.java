package com.nemo.web.controller;

import com.nemo.pojo.FoodClass;
import com.nemo.service.FoodClassService;
import com.nemo.utils.CustomUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * @Author 刘宇飞
 * @Date 2016/04/09 07:34
 * 食品分类操作类
 */
@Controller
@RequestMapping("/class")
public class FoodClassController {
    @Autowired
    FoodClassService foodClassService;
    private List<FoodClass> list;

    @RequestMapping("/list")
    public String allList(Model model) throws Exception{
       /* List<FoodClass> list = foodClassService.queryClassList();
        model.addAttribute("classlist",list);*/

        int count = foodClassService.count();
        model.addAttribute("count",count);
        return "foodclass/classList";
    }


    @RequestMapping(value={"/getList",""},produces = "plain/text;charset=UTF-8")
    @ResponseBody
    public String list(@RequestParam int index) throws Exception{
        List<FoodClass> list = foodClassService.findClassLimitListBy(index * 5,5);
        return CustomUtils.toJson(list);
    }

    @RequestMapping(value={"/getFList",""},produces = "plain/text;charset=UTF-8")
    @ResponseBody
    public String getFList(@RequestParam String condition) throws Exception{
        List<FoodClass> list = foodClassService.findFuzzyList(CustomUtils.transcoding(condition));
        return CustomUtils.toJson(list);
    }


    @RequestMapping("/add")
    public String addClass()throws Exception{
        list = foodClassService.queryClassList();
        return "foodclass/addclass";
    }

    @RequestMapping("save")
    public String saveClass(@ModelAttribute FoodClass foodClass,Model model){
        boolean has=false;
        for(int i=0;i<list.size();i++){
            if(foodClass.getClassName().equals(list.get(i).getClassName())){
                has=true;
            }
        }
      if(has){
          model.addAttribute("mess","已经存在，不能重复添加");
      }else {
         boolean res=foodClassService.addClass(foodClass);
          if(res){
              model.addAttribute("mess","添加分类成功");
          }else {
              model.addAttribute("mess","添加分类失败");
          }
      }


        return "foodclass/result";
    }

    @RequestMapping(value="/delete")
    public String delete(@RequestParam int id,Model model){
        boolean res = foodClassService.deleteClassById(id);
        if(res){
            model.addAttribute("mess", "删除分类成功");
        }else{
            model.addAttribute("mess", "删除分类失败");
        }
        return "foodclass/result";
    }

    @RequestMapping(value = "editClass")
    public String editClass(@RequestParam int id,Model model)throws Exception{
        FoodClass foodClass = foodClassService.findClassById(id);
        model.addAttribute("foodClass",foodClass);
        list = foodClassService.queryClassList();
        return "foodclass/editFoodClass";
    }

    @RequestMapping("update")
    public String updateClass(@ModelAttribute FoodClass foodClass,Model model){
        boolean has=false;
        for(int i=0;i<list.size();i++){
            if(foodClass.getClassName().equals(list.get(i).getClassName())){
                has=true;
            }
        }
        if(has) {
            model.addAttribute("mess", "不能修改为已经存在的分类");
        }else {
            boolean res = foodClassService.updateClass(foodClass);
            if(res){
                model.addAttribute("mess","修改分类成功");
            }else {
                model.addAttribute("mess","修改分类失败");
            }
        }

        return "foodclass/result";
    }
}
