package com.nemo.web.controller;

import com.nemo.pojo.IntStore;
import com.nemo.pojo.Store;
import com.nemo.service.IntStoreService;
import com.nemo.service.PreIntStoreService;
import com.nemo.service.StoreService;
import com.nemo.utils.CustomUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.List;

/**
 * @Author 刘宇飞
 * @Date 2016/04/09 07:34
 * 库存操作类
 */
@Controller
@RequestMapping("/intStore")
public class IntStoreController {
    @Autowired
    IntStoreService intStoreService;

    @Autowired
    StoreService storeService;

    @Autowired
    PreIntStoreService preIntStoreService;

    private int type=0;
    private String preIntId="";

    @RequestMapping("/list")
    public String list(@RequestParam int type,String preIntId,int status,Model model) throws Exception{
        this.type=type;
        this.preIntId=preIntId;
        model.addAttribute("type",type);
        model.addAttribute("preIntId",preIntId);
        model.addAttribute("status",status);
        List<IntStore> count = intStoreService.count(type, preIntId);

        model.addAttribute("count",count.size());
        if(type==3){
            return "store/preStoreList";
        }else {
            return "intStore/intStoreList";
        }

    }


    @RequestMapping(value={"/finish",""},produces = "plain/text;charset=UTF-8")
    @ResponseBody
    public String finish() throws Exception{
      boolean res=  preIntStoreService.finish(preIntId);
        if(res){
            return "操作成功";
        }else {
            return "操作失败";
        }

    }

    @RequestMapping(value={"/getLimitList",""},produces = "plain/text;charset=UTF-8")
    @ResponseBody
    public String list(@RequestParam int index) throws Exception{
        List<IntStore> list = intStoreService.findLimitList(index * 5,5,type,preIntId);
        return CustomUtils.toJson(list);
    }
    @RequestMapping(value={"/getFList",""},produces = "plain/text;charset=UTF-8")
    @ResponseBody
    public String getFList(@RequestParam String condition) throws Exception{
        List<IntStore> list = intStoreService.findFuzzyList(CustomUtils.transcoding(condition),type);
        return CustomUtils.toJson(list);
    }

    @RequestMapping("add")
    public String add(@RequestParam int type,Model model){
        this.type=type;
        model.addAttribute("type",type);
        model.addAttribute("preIntId",preIntId);

        return "intStore/addIntStore";
    }
    @RequestMapping("save")
    public String save(@ModelAttribute IntStore intStore,Model model){
        model.addAttribute("type",type);
        model.addAttribute("preIntId",preIntId);
        boolean res = intStoreService.addIntStore(intStore);
        if(res){
            model.addAttribute("mess","添加成功");
        }else {
            model.addAttribute("mess","添加失败");
        }
        return "intStore/result";
    }

    @RequestMapping("delete")
    public String delete(@RequestParam String id,Model model){
        model.addAttribute("type",type);
        model.addAttribute("preIntId",preIntId);
        boolean res=intStoreService.deleteIntStoreById(id);
        if(res){
            model.addAttribute("mess","删除成功");
        }else {
            model.addAttribute("mess","删除失败");
        }
        return "intStore/result";
    }

    @RequestMapping("putIntoStore")
    public String putIntoStore(@RequestParam String id,Model model){
        model.addAttribute("type",type);
        model.addAttribute("preIntId",preIntId);
        IntStore intStore = intStoreService.findIntStoreById(id);
        model.addAttribute("intStore",intStore);
        List<Store> slist = storeService.findId();
        if(slist.size()>0){
            model.addAttribute("id","00"+(slist.get(0).getStoreId()+1)+"");
        }else {
            model.addAttribute("id","001");
        }
        return "store/addStore";
    }



}
