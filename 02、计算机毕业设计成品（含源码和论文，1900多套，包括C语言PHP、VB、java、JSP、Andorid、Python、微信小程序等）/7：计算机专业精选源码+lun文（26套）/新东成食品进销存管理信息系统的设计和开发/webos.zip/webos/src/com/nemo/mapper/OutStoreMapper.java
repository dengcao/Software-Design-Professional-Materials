package com.nemo.mapper;

import com.nemo.pojo.OutStore;

import java.util.List;
import java.util.Map;

/**
 * @Author 刘宇飞
 * @Date 2016/04/08 22:23
 * 出库mapper
 */
public interface OutStoreMapper {

    public List<OutStore> findOutStoreList();

    public List<OutStore> findLimitList(Map<String, String> map);

    public int count();

    public boolean deleteOutStoreById(Map<String, String> map);

    public boolean addOutStore(OutStore outStore);

    public OutStore findOutStoreById(Map<String, String> map);

    int outTypeCount(Map<String, String> map);

    List<OutStore> findLimitTypeList(Map<String, String> map);

    public List<OutStore> findFuzzyList(Map<String,String> map);

    public List<OutStore> analyzeSele(Map<String,String> map);
}
