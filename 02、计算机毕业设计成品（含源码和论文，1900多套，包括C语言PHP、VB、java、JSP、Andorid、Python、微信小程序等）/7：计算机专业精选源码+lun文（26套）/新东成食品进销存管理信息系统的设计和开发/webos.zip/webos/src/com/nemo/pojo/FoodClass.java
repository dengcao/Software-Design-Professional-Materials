package com.nemo.pojo;

/**
 * @Author 刘宇飞
 * @Date 2016/04/08 22:21
 * 食品分类实体
 */
public class FoodClass {
    private int classId;
    private String className;

    public int getClassId() {
        return classId;
    }

    public void setClassId(int classId) {
        this.classId = classId;
    }

    public String getClassName() {
        return className;
    }

    public void setClassName(String className) {
        this.className = className;
    }
}
