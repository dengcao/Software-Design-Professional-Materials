package com.nemo.web.controller;

import com.nemo.pojo.PreIntStore;
import com.nemo.service.PreIntStoreService;
import com.nemo.utils.CustomUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * @Author 刘宇飞
 * @Date 2016/04/09 07:34
 * 食品分类操作类
 */
@Controller
@RequestMapping("/preIntStore")
public class PreIntStoreController {
    @Autowired
    PreIntStoreService preIntStoreService;

    private int type=0;

    @RequestMapping("/list")
    public String allList(@RequestParam int type,Model model) throws Exception{
        this.type=type;
        model.addAttribute("type",type);
        Map<String,String> map=new HashMap<>();
        map.put("intType",type+"");
        List<PreIntStore> list = preIntStoreService.findFuzzyList(map, 2);
        model.addAttribute("count",list.size());
        return "preIntStore/preIntStoreList";
    }
    @RequestMapping(value={"/getLimitList",""},produces = "plain/text;charset=UTF-8")
    @ResponseBody
    public String list(@RequestParam int index) throws Exception{
        Map<String,String> map=new HashMap<>();
        map.put("start",index*5+"");
        map.put("end",5+"");
        map.put("intType",type+"");
        List<PreIntStore> list = preIntStoreService.findFuzzyList(map, 3);
        return CustomUtils.toJson(list);
    }



    @RequestMapping("add")
    public String add(@RequestParam int type,Model model){
        this.type=type;
        model.addAttribute("type",type);


        Map<String,String> map=new HashMap<>();
        map.put("intType",type+"");
        List<PreIntStore> list = preIntStoreService.findFuzzyList(map, 1);
        model.addAttribute("size","00"+(list.size()+1)+"");
        return "preIntStore/addPreIntStore";
    }
    @RequestMapping("save")
    public String saveClass(@ModelAttribute PreIntStore preIntStore,Model model){
        model.addAttribute("type",type);
        boolean res = preIntStoreService.addPreIntStore(preIntStore);
        if(res){
            model.addAttribute("mess","添加成功");
        }else {
            model.addAttribute("mess","添加失败");
        }
        return "preIntStore/result";
    }
    @RequestMapping(value="/delete")
    public String delete(@RequestParam int id,Model model){
      return null;
    }

}
