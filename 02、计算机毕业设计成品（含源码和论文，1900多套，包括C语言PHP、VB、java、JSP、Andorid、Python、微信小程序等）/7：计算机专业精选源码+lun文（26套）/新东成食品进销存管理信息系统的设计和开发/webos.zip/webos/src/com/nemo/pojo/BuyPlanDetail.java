package com.nemo.pojo;

/**
 * @Author 刘宇飞
 * @Date 2016/04/14 16:07
 * 采购计划详情实体
 */
public class BuyPlanDetail {
    private int detailId;
    private String buyPlanId;
    private int foodId;
    private String foodName;
    private Double foodPrice;
    private int buyNum;
    private Double buyTotalMoney;
    private String remarks;



    public int getFoodId() {
        return foodId;
    }

    public void setFoodId(int foodId) {
        this.foodId = foodId;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public Double getFoodPrice() {
        return foodPrice;
    }

    public void setFoodPrice(Double foodPrice) {
        this.foodPrice = foodPrice;
    }


    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public int getDetailId() {
        return detailId;
    }

    public void setDetailId(int detailId) {
        this.detailId = detailId;
    }

    public String getBuyPlanId() {
        return buyPlanId;
    }

    public void setBuyPlanId(String buyPlanId) {
        this.buyPlanId = buyPlanId;
    }

    public int getBuyNum() {
        return buyNum;
    }

    public void setBuyNum(int buyNum) {
        this.buyNum = buyNum;
    }

    public Double getBuyTotalMoney() {
        return buyTotalMoney;
    }

    public void setBuyTotalMoney(Double buyTotalMoney) {
        this.buyTotalMoney = buyTotalMoney;
    }
}
