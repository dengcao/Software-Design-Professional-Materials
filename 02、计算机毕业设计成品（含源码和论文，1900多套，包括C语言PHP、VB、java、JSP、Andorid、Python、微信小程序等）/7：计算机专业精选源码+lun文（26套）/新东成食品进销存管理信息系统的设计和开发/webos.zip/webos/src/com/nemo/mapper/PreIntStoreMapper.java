package com.nemo.mapper;

import com.nemo.pojo.PreIntStore;

import java.util.List;
import java.util.Map;

/**
 * @Author 刘宇飞
 * @Date 2016/04/08 22:23
 * 进货单mapper
 */
public interface PreIntStoreMapper {
    List<PreIntStore> findFuzzyList(Map<String,String> map);
    boolean deletePreIntStore(Map<String,String> map);
    boolean addPreIntStore(PreIntStore preIntStore);

    boolean finish(Map<String, String> map);
}
