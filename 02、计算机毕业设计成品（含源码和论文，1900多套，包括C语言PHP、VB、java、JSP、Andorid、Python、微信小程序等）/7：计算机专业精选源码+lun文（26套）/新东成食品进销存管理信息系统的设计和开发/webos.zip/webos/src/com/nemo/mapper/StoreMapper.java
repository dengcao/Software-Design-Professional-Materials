package com.nemo.mapper;

import com.nemo.pojo.Store;

import java.util.List;
import java.util.Map;

/**
 * @Author 刘宇飞
 * @Date 2016/04/08 22:23
 * 库存mapper
 */
public interface StoreMapper {

    public List<Store> findStoreList();

    public List<Store> findLimitList(Map<String, String> map);

    public List<Store> findPoliceLimitList(Map<String, String> map);

    public int count();

    public boolean deleteStoreById(Map<String, String> map);

    public boolean updateStore(Store store);

    public boolean addStore(Store store);

    public Store findStoreById(Map<String, String> map);

    public List<Store> findStoreByFoodName(Map<String, String> map);

    public boolean setTotalZero(Map<String, String> map);

    public boolean setFoodNum(Store store);

    public boolean setStoreTotal(Store store);

    public List<Store> findFuzzyList(Map<String,String> map);

}
