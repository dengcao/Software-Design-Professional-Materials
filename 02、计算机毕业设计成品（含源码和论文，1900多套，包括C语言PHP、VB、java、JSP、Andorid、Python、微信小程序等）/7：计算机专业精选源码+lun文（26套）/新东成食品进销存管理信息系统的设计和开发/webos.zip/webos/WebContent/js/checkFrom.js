$(document).ready(function(){
    $("#jsFrom").validate({
        submitHandler:function(form){
            form.submit();
        }
    });

});