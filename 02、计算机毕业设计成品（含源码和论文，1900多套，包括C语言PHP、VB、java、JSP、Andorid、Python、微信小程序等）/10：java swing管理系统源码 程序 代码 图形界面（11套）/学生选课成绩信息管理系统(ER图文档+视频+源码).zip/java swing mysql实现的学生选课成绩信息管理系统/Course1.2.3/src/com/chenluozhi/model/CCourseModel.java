package com.chenluozhi.model;

public class CCourseModel {
	private Integer stu_id;
	private Integer course_id;
	private Integer ccourse_mark;
	private String ccourse_time;
	
	
	private String stu_name;
	private String course_name;
	private Integer teach_id;
	private String teach_name;
	
	
	
	
	
	public Integer getStu_id() {
		return stu_id;
	}
	public void setStu_id(Integer stu_id) {
		this.stu_id = stu_id;
	}
	public Integer getCourse_id() {
		return course_id;
	}
	public void setCourse_id(Integer course_id) {
		this.course_id = course_id;
	}
	public Integer getCcourse_mark() {
		return ccourse_mark;
	}
	public void setCcourse_mark(Integer ccourse_mark) {
		this.ccourse_mark = ccourse_mark;
	}
	public String getCcourse_time() {
		return ccourse_time;
	}
	public void setCcourse_time(String ccourse_time) {
		this.ccourse_time = ccourse_time;
	}
	public String getStu_name() {
		return stu_name;
	}
	public void setStu_name(String stu_name) {
		this.stu_name = stu_name;
	}
	public String getCourse_name() {
		return course_name;
	}
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}
	public Integer getTeach_id() {
		return teach_id;
	}
	public void setTeach_id(Integer teach_id) {
		this.teach_id = teach_id;
	}
	public String getTeach_name() {
		return teach_name;
	}
	public void setTeach_name(String teach_name) {
		this.teach_name = teach_name;
	}
	
	
	
}
