package com.chenluozhi.model;

public class ClassModel {
	
	private Integer class_id;
	private String class_name;
	private Integer class_maxnum;
	private Integer grade_id;
	public Integer getClass_id() {
		return class_id;
	}
	public void setClass_id(Integer class_id) {
		this.class_id = class_id;
	}
	public String getClass_name() {
		return class_name;
	}
	public void setClass_name(String class_name) {
		this.class_name = class_name;
	}
	public Integer getClass_maxnum() {
		return class_maxnum;
	}
	public void setClass_maxnum(Integer class_maxnum) {
		this.class_maxnum = class_maxnum;
	}
	public Integer getGrade_id() {
		return grade_id;
	}
	public void setGrade_id(Integer grade_id) {
		this.grade_id = grade_id;
	}
	

}
