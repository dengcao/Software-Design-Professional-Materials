package com.chenluozhi.model;

public class CourseModel {
	private Integer course_id;
	private String course_name;
	private Integer course_credit;
	private String course_info;
	private String course_begin_time;
	private Integer teach_id;
	
	private String teach_name;
	
	
	public Integer getCourse_id() {
		return course_id;
	}
	public void setCourse_id(Integer course_id) {
		this.course_id = course_id;
	}
	public String getCourse_name() {
		return course_name;
	}
	public void setCourse_name(String course_name) {
		this.course_name = course_name;
	}
	public Integer getCourse_credit() {
		return course_credit;
	}
	public void setCourse_credit(Integer course_credit) {
		this.course_credit = course_credit;
	}
	public String getCourse_info() {
		return course_info;
	}
	public void setCourse_info(String course_info) {
		this.course_info = course_info;
	}
	public String getCourse_begin_time() {
		return course_begin_time;
	}
	public void setCourse_begin_time(String course_begin_time) {
		this.course_begin_time = course_begin_time;
	}
	public Integer getTeach_id() {
		return teach_id;
	}
	public void setTeach_id(Integer teach_id) {
		this.teach_id = teach_id;
	}
	public String getTeach_name() {
		return teach_name;
	}
	public void setTeach_name(String teach_name) {
		this.teach_name = teach_name;
	}
	
	
	

}
