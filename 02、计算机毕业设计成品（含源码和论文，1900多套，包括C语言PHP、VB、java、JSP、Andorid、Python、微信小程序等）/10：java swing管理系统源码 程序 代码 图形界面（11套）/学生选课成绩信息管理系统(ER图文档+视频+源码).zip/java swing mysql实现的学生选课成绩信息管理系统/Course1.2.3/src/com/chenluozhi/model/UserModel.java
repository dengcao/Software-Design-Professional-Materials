package com.chenluozhi.model;

public class UserModel {
	
	private Integer user_id;
	private String user_name;
	private String user_password;
	private String user_login_ip;
	private String user_login_time;
	private String user_privilege;
	public Integer getUser_id() {
		return user_id;
	}
	public void setUser_id(Integer user_id) {
		this.user_id = user_id;
	}
	public String getUser_name() {
		return user_name;
	}
	public void setUser_name(String user_name) {
		this.user_name = user_name;
	}
	public String getUser_password() {
		return user_password;
	}
	public void setUser_password(String user_password) {
		this.user_password = user_password;
	}
	public String getUser_login_ip() {
		return user_login_ip;
	}
	public void setUser_login_ip(String user_login_ip) {
		this.user_login_ip = user_login_ip;
	}
	public String getUser_login_time() {
		return user_login_time;
	}
	public void setUser_login_time(String user_login_time) {
		this.user_login_time = user_login_time;
	}
	public String getUser_privilege() {
		return user_privilege;
	}
	public void setUser_privilege(String user_privilege) {
		this.user_privilege = user_privilege;
	}
	
	
	

}
