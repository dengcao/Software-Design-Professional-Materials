package com.chenluozhi.model;

public class TeacherModel {

	private Integer teach_id;
	private String teach_name;
	private String teach_sex;
	private String education;
	
	
	
	public Integer getTeach_id() {
		return teach_id;
	}
	public void setTeach_id(Integer teach_id) {
		this.teach_id = teach_id;
	}
	public String getTeach_name() {
		return teach_name;
	}
	public void setTeach_name(String teach_name) {
		this.teach_name = teach_name;
	}
	public String getTeach_sex() {
		return teach_sex;
	}
	public void setTeach_sex(String teach_sex) {
		this.teach_sex = teach_sex;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
}
