package otcyan.java.model;

import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.Vector;

import javax.swing.table.AbstractTableModel;

import otcyan.java.bean.User;
import otcyan.java.tools.DBHelp;

public class ReturnTicketModel extends AbstractTableModel{

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	//�е���
	private Vector<String> col  ;
	//�е���
	private Vector<Vector> rows ; 
	private DBHelp dbHelp = null ;
	
	ResultSetMetaData rsmd;
	
	public void initCol(){
		col=new Vector<String>();
		col.add("Ʊ��") ;
		col.add("�����") ;
		col.add("����") ;
		col.add("��λ��") ;
		col.add("��λ") ;
		col.add("��������") ;
		col.add("����ʱ��") ;
	}
	
	public ReturnTicketModel(String sql , String paras[] , User user , Vector<String> startTimes){
	
		int count = 0 ;
		//��ʼ����
		this.initCol() ;
		rows = new Vector<Vector>() ;
		dbHelp =new DBHelp();
		ResultSet rs=dbHelp.query(sql, paras);
		//�Ѳ�ѯ������뵽�б���
	
		try {
			 rsmd=rs.getMetaData();
//			for (int i = 0; i < rsmd.getColumnCount(); i++) {
//				this.col.add(rsmd.getColumnName(i+1));
//			}
				while(rs.next())
				{
					Vector<String> temp=new Vector<String>();
					for (int i = 0; i < rsmd.getColumnCount(); i++)
					{
						if(i==2){
							temp.add(user.getU_name()) ;
							continue ;
						}
						temp.add(rs.getString(i+1));
					}	
					temp.add(startTimes.get(count++)) ;
					rows.add(temp);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
			finally
			{
				if(rs!=null){
					try {
						rs.close() ;
					} catch (SQLException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				}
				dbHelp.close() ;
			}			
	
	}

//	//������ɾ��
//	public boolean upd(String sql,String paras[])
//	{
//
//		return db.updExcute(sql, paras);
//		
//	}
	
	public int getColumnCount() {
		// TODO Auto-generated method stub
	//	System.out.println(this.col.size());
		return this.col.size();
	}

	public int getRowCount() {
		// TODO Auto-generated method stub
		//System.out.println(this.rows.size());
		return this.rows.size();
		
	}

	public Object getValueAt(int raw, int col) {
		// TODO Auto-generated method stub
		return ((Vector)this.rows.get(raw)).get(col);
	}

	@Override
	public String getColumnName(int arg0) {
		// TODO Auto-generated method stub
		return (String)this.col.get(arg0);
	}


}
