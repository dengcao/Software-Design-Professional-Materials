/*
Navicat MySQL Data Transfer

Source Server         : 本地连接
Source Server Version : 50505
Source Host           : localhost:3306
Source Database       : car_rental

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2018-06-22 16:04:51
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `admin`
-- ----------------------------
DROP TABLE IF EXISTS `admin`;
CREATE TABLE `admin` (
  `adminname` varchar(20) CHARACTER SET utf8 NOT NULL,
  `admin_password` varchar(20) CHARACTER SET utf8 NOT NULL,
  PRIMARY KEY (`adminname`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of admin
-- ----------------------------
INSERT INTO `admin` VALUES ('admin', 'admin');

-- ----------------------------
-- Table structure for `car_information`
-- ----------------------------
DROP TABLE IF EXISTS `car_information`;
CREATE TABLE `car_information` (
  `number` int(11) NOT NULL,
  `cartype` varchar(25) CHARACTER SET utf8 DEFAULT NULL,
  `carower` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `price` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  `color` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `hire` varchar(10) CHARACTER SET utf8 DEFAULT NULL,
  `information` text CHARACTER SET utf8,
  `username` varchar(20) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`number`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of car_information
-- ----------------------------
INSERT INTO `car_information` VALUES ('1', '荣威550', '张三', '100', '白色', '是', '编号：1\n类型：小轿车\n车主：张三\n价格：300\n是否出租：是\n出租用户：llq', 'llq');
INSERT INTO `car_information` VALUES ('2', '现代朗动', '李四', '150', '白色', '否', 'SUV汽车，车况很好，每天只要500；', null);
INSERT INTO `car_information` VALUES ('3', '大众朗逸', '张三', '168', '红色', '是', null, '马云');
INSERT INTO `car_information` VALUES ('4', '日产轩逸', '李四', '189', '白色', '否', null, null);
INSERT INTO `car_information` VALUES ('5', '日产天籁', '张三', '200', '灰色', '否', null, null);
INSERT INTO `car_information` VALUES ('6', '日产奇骏', '李四', '368', '白色', '否', 'cvt2.5四驱豪华版', null);
INSERT INTO `car_information` VALUES ('7', '大众途观', '未知', '666', '白色', '是', null, 'llq');

-- ----------------------------
-- Table structure for `user`
-- ----------------------------
DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `username` varchar(20) CHARACTER SET utf8 NOT NULL,
  `user_password` varchar(20) NOT NULL,
  PRIMARY KEY (`username`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- ----------------------------
-- Records of user
-- ----------------------------
INSERT INTO `user` VALUES ('123', '123');
INSERT INTO `user` VALUES ('llq', '1');
INSERT INTO `user` VALUES ('马云', '1');
