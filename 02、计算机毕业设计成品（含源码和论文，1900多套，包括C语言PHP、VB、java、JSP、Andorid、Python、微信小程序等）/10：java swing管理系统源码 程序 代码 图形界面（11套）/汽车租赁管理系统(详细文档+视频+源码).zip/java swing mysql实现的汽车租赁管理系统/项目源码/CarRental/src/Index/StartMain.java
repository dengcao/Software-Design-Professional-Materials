package Index;

public class StartMain {

	/**
	 * @param args
	 */
	public static void main(String[] args) {

		Login login = new Login();
		
//		Zhuce zhuce = new Zhuce();
//		
	//	Guanliyuan guanliyuan = new Guanliyuan();
//		
//		Luru luru = new Luru();
//		
//		Xiangxi xiangxi = new Xiangxi();
//		
//		Xiangxi_yonghu xiangxi_yonghu = new Xiangxi_yonghu();
//		
//		Xinxitijiao xinxitijiao = new Xinxitijiao();
//		
//		Yonghuduan yonghuduan = new Yonghuduan();

	}

}
