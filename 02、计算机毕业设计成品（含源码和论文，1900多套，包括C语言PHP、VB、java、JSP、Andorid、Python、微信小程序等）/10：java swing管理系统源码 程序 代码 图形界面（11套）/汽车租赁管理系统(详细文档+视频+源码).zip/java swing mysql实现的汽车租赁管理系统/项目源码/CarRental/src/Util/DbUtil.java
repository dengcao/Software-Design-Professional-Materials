package Util;

public class DbUtil {
	public static String dbUrlString = "jdbc:mysql://localhost:3306/car_rental?useUnicode=true&characterEncoding=UTF-8";
	public static String dbUser = "root";
	public static String dbpassword = "";
}
