package net.wms.bean;

public class Storage {
	private int id;
	private String storagename;
	private String storagestyle;
	private int storageID;
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getStoragename() {
		return storagename;
	}
	public void setStoragename(String storagename) {
		this.storagename = storagename;
	}
	public String getStoragestyle() {
		return storagestyle;
	}
	public void setStoragestyle(String storagestyle) {
		this.storagestyle = storagestyle;
	}
	public int getStorageID() {
		return storageID;
	}
	public void setStorageID(int storageID) {
		this.storageID = storageID;
	}
	
}
