/*
Navicat MySQL Data Transfer

Source Server         : 本地数据库
Source Server Version : 50611
Source Host           : localhost:3306
Source Database       : db_library_swing

Target Server Type    : MYSQL
Target Server Version : 50611
File Encoding         : 65001

Date: 2018-12-26 21:26:54
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `tb_bookinfo`
-- ----------------------------
DROP TABLE IF EXISTS `tb_bookinfo`;
CREATE TABLE `tb_bookinfo` (
  `ISBN` varchar(20) DEFAULT NULL,
  `typeid` varchar(20) DEFAULT NULL,
  `writer` varchar(20) DEFAULT NULL,
  `translator` varchar(20) DEFAULT NULL,
  `publisher` varchar(20) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `price` double DEFAULT NULL,
  `bookname` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_bookinfo
-- ----------------------------
INSERT INTO `tb_bookinfo` VALUES ('1111111111111', '2', '毛以锋', '哈哈', '***出版社', '2013-04-24 00:00:00', '20', 'java开发');
INSERT INTO `tb_bookinfo` VALUES ('0000000000001', '1', '猿来入此', '猿来入此', '**大型出版社', '2018-01-26 00:00:00', '128', '猿来入此');

-- ----------------------------
-- Table structure for `tb_booktype`
-- ----------------------------
DROP TABLE IF EXISTS `tb_booktype`;
CREATE TABLE `tb_booktype` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `typeName` varchar(20) DEFAULT NULL,
  `days` varchar(20) DEFAULT NULL,
  `fk` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_booktype
-- ----------------------------
INSERT INTO `tb_booktype` VALUES ('1', '计算机类', '30', '0.1');
INSERT INTO `tb_booktype` VALUES ('2', '新闻类', '3', '0.1');
INSERT INTO `tb_booktype` VALUES ('4', '文学类', '3', '0.2');

-- ----------------------------
-- Table structure for `tb_borrow`
-- ----------------------------
DROP TABLE IF EXISTS `tb_borrow`;
CREATE TABLE `tb_borrow` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `bookISBN` varchar(20) DEFAULT NULL,
  `readerISBN` varchar(20) DEFAULT NULL,
  `num` varchar(20) DEFAULT NULL,
  `borrowDate` varchar(40) DEFAULT NULL,
  `backDate` varchar(40) DEFAULT NULL,
  `bookName` varchar(20) DEFAULT NULL,
  `operatorId` varchar(20) DEFAULT NULL,
  `isback` varchar(1) DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_borrow
-- ----------------------------
INSERT INTO `tb_borrow` VALUES ('1', '1111111111111', '1111111111111', null, '2013-04-25 02:53:34.0', '2013-04-25 02:53:34.0', null, '1', '0');
INSERT INTO `tb_borrow` VALUES ('2', '1111111111111', '1111111111111', null, '2013-04-25 02:59:10.0', '2013-04-28 02:59:10.0', null, '1', null);
INSERT INTO `tb_borrow` VALUES ('3', '1111111111111', '1111111111111', null, '2013-04-25 03:00:52.0', '2013-04-28 03:00:52.0', null, '1', '0');
INSERT INTO `tb_borrow` VALUES ('4', '1111111111111', '1111111111111', null, '2018-12-26 09:17:46.0', '2018-12-29 09:17:46.0', null, '1', '0');

-- ----------------------------
-- Table structure for `tb_operator`
-- ----------------------------
DROP TABLE IF EXISTS `tb_operator`;
CREATE TABLE `tb_operator` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(20) DEFAULT NULL,
  `sex` varchar(20) DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `identityCard` varchar(50) DEFAULT NULL,
  `workdate` datetime DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `admin` int(11) DEFAULT '0',
  `password` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_operator
-- ----------------------------
INSERT INTO `tb_operator` VALUES ('1', 'admin', null, null, null, null, null, '1', 'admin');
INSERT INTO `tb_operator` VALUES ('4', '猿来入此', '1', '25', '1223222335525', '2018-12-26 00:00:00', '13656565656', '0', '123456');

-- ----------------------------
-- Table structure for `tb_order`
-- ----------------------------
DROP TABLE IF EXISTS `tb_order`;
CREATE TABLE `tb_order` (
  `ISBN` varchar(20) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `number` varchar(20) DEFAULT NULL,
  `operator` varchar(20) DEFAULT NULL,
  `checkAndAccept` varchar(20) DEFAULT NULL,
  `zk` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_order
-- ----------------------------
INSERT INTO `tb_order` VALUES ('1111111111111', '2013-04-25 00:00:00', '11', 'java1234', '0', '0.1');
INSERT INTO `tb_order` VALUES ('0000000000001', '2018-12-26 00:00:00', '5', 'admin', '0', '0.9');

-- ----------------------------
-- Table structure for `tb_reader`
-- ----------------------------
DROP TABLE IF EXISTS `tb_reader`;
CREATE TABLE `tb_reader` (
  `name` varchar(20) DEFAULT NULL,
  `sex` varchar(20) DEFAULT NULL,
  `age` varchar(10) DEFAULT NULL,
  `identityCard` varchar(40) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `maxNum` varchar(10) DEFAULT NULL,
  `tel` varchar(20) DEFAULT NULL,
  `keepMoney` double DEFAULT NULL,
  `zj` int(11) DEFAULT NULL,
  `zy` varchar(20) DEFAULT NULL,
  `ISBN` varchar(20) DEFAULT NULL,
  `bztime` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of tb_reader
-- ----------------------------
INSERT INTO `tb_reader` VALUES ('张三', '1', '11', '1111111111111', '2014-04-24 00:00:00', '11', '11', '10', '3', '学生', '1111111111111', '2013-04-24 00:00:00');
INSERT INTO `tb_reader` VALUES ('陈小春', '1', '48', '1231231231231', '2019-12-26 00:00:00', '3', '13565656565', '323', '0', '演员', '1213212121321', '2018-12-26 00:00:00');
