# wechatapp-swiper-tab
![image](https://github.com/rongj/wechatapp-swiper-tab/blob/master/swipertab.GIF)
