# wechat-app-xiaoyima
微信小程序，小姨妈。代码很乱，练手为主

![image](https://raw.githubusercontent.com/iamjs1/wechat-app-xiaoyima/master/images/%E6%88%AA%E5%9B%BE.png)
