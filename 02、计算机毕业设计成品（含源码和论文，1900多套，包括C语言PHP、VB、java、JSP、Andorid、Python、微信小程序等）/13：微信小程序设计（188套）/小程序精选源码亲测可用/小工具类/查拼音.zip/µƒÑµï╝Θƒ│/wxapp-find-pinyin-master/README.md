微信小程序：查拼音
------


![](./art/demo.gif)


## License
MIT