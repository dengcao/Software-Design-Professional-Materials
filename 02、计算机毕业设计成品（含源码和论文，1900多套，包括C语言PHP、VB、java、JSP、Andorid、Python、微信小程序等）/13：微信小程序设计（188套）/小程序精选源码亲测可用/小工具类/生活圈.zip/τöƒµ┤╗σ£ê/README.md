# wechat-weapp-lifeTools
微信小程序生活工具集合

目前只加了一个空气质量查询的功能,后面还会再加其它的

![预览图片](https://github.com/yll2wcf/wechat-weapp-lifeTools/blob/master/1.gif?raw=true)

详细的描述稍后补充上来。


##你可能学到的知识:

1. css的优先级     详细见 /pages/air_quality/result.wxss
2. 页面跳转,数据的传递     /pages/air_quality/air_quality.js  ../result.js  common/utils.js
3. 网络请求              /pages/air_quality/air_quality.js
5. 样式统一  程序的配置  参考 app.wxss  app.json
6. modal显示和隐藏       /pages/air_quality/air_quality.wxml ../air_quality.js
7. 状态机 事件绑定等等
