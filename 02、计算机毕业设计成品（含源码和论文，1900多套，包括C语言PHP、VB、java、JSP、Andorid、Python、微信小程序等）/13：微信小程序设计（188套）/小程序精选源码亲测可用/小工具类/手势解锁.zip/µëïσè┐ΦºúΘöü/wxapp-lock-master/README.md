# wxapp-lock
# 微信小程序--手势解锁

![mahua](http://jsh5css.cn/blog/wp-content/uploads/2016/12/20161226174438_30942.gif)
* Ps：微信开发者工具和ios系统均测试正常，android系统暂时还有问题，有不足之处，请大家多多指点，谢谢~~
