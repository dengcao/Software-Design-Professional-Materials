# 微信小程序－画布时钟

### 说明：

利用canvas实现了模拟时钟功能。

### 数据接口:

使用本地数据接

### 目录结构：

- pages — 存放项目页面渲染相关文件

### 开发环境：

微信web开发者工具 v0.11.122100

### 感谢：

本项目原始版本由getweapp提供：https://github.com/getweapp/weapp-canvas-clock
