# 微信小程序实现IOS计算器
在[React Rock](https://react.rocks/)看到了用React实现的类IOS计算器，一时兴起，用小程序实现了一遍。虽然仍有一些体验问题，欢迎一起优化。
