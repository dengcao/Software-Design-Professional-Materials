# wechatapp-news-reader
微信小程序 —— 新闻阅读器

## 说明

1.数据部分API来源于[《中安新闻客户端》](http://www.anhuinews.com/)
2.富文本解析[wxParse](https://github.com/icindy/wxParse)




## 界面截图

<img style="margin:10px" width="320" src="screenshots/demo1.png" alt="主页页面">
<img style="margin:10px" width="320" src="screenshots/demo2.png" alt="设置页面">
<img style="margin:10px" width="320" src="screenshots/demo3.png" alt="专题页面">
<img style="margin:10px" width="320" src="screenshots/demo4.png" alt="专题列表页面">
<img style="margin:10px" width="320" src="screenshots/demo5.png" alt="详情页面">
<img style="margin:10px" width="320" src="screenshots/demo6.png" alt="发现">
