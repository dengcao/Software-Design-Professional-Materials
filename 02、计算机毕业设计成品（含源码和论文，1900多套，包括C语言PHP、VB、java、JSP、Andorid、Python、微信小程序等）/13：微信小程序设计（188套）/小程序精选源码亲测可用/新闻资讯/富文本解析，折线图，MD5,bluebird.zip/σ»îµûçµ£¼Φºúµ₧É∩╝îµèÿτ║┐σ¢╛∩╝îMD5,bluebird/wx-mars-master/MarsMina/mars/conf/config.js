
const conf = {
    //域名信息
    "domain": "http://www.hiwaycrowd.com/",
    //应用基础信息
    "app_info": {
        "app_name": "海汇随手记",  //应用名称
        "app_version": "v0.1.12121047", //版本号
    },
}

export default conf