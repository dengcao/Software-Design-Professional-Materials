
import config from 'mars/conf/config'

App({
  onLaunch: function () {
    //设置导航标题
    /*wx.setNavigationBarTitle({
      title: config.app_info.app_name
    })*/
  },
  onShow: function () {

  },
  onHide: function () {

  },
  onError: function (msg) {

  }
})