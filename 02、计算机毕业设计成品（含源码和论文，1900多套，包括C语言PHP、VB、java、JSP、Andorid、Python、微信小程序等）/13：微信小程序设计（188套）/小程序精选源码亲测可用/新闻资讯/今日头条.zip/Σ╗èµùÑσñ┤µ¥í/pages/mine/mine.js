Page({
  data:{
    item:{
        imagesrc:"../../imges/mine/arrow_right_setup_12x16_@2x.png",
        imagename:"好友动态"
    },
    celldata:[{
        imagesrc:"../../imges/mine/arrow_right_setup_12x16_@2x.png",
        imagename:"消息通知"
    },{
        imagesrc:"../../imges/mine/arrow_right_setup_12x16_@2x.png",
        imagename:"离线"
    },{
        imagesrc:"../../imges/mine/arrow_right_setup_12x16_@2x.png",
        imagename:"活动"
    },{
        imagesrc:"../../imges/mine/arrow_right_setup_12x16_@2x.png",
        imagename:"商城"
    },{
        imagesrc:"../../imges/mine/arrow_right_setup_12x16_@2x.png",
        imagename:"我要爆料"
    },{
        imagesrc:"../../imges/mine/arrow_right_setup_12x16_@2x.png",
        imagename:"反馈"
    }]
  },
  onLoad:function(options){
    // 页面初始化 options为页面跳转所带来的参数
    
  },
  onReady:function(){
    // 页面渲染完成
    
  },
  onShow:function(){
    // 页面显示
    
  },
  onHide:function(){
    // 页面隐藏
    
  },
  onUnload:function(){
    // 页面关闭
    
  }
})