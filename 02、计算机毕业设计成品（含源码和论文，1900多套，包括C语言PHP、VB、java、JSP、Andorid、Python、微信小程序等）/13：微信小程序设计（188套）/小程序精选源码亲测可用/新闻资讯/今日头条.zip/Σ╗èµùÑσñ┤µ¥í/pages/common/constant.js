let device_id = 6096495334;
let iid = 5034850950;
let params = {"device_id":6096495334,"aid":13,iid:5034850950};
let BASE_URL = "http://lf.snssdk.com/";

export {
    device_id,
    iid,
    params,
    BASE_URL,
}