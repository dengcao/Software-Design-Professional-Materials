# 微信小程序－会议精灵

### 说明：

虽然只实现了会议精灵首页，但设计较为美观，值得借鉴。

### 数据接口:

使用本地数据

### 目录结构：

- img — 存放项目图片
- pages — 存放项目页面相关文件，包括index,layout等页面
- utils — 存放日期处理文件，可require引入

### 开发环境：

微信web开发者工具 v0.10.102800

### 项目截图：

https://www.getweapp.com/project?projectId=5832c0dcbb2538f8186c7077
