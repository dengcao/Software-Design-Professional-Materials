// pages/mine/mine.js

var app = getApp()

Page({
  data:{
    text: 'init data data'
  },

  onLoad: function() {
    wx.setNavigationBarTitle({
      title: '我的'
    })
  }
  


})