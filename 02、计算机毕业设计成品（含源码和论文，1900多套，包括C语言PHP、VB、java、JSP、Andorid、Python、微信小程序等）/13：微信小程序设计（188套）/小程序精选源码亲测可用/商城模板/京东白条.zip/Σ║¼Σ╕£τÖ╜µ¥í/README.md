# 微信小程序－京东白条

### 说明：

实现了首页和白条页，以及微信小程序开放API接口功能和模块展示。

### 数据接口:

使用本地数据

### 目录结构：

- image — 存放项目图片
- images — 存放项目图片
- page — 微信小程序开放API和组件页面相关文件，包括API和component等
- pages — 存放项目页面相关文件，包括- baitiao,index,licai,logs,touzi,zhongchou等页面
- util,utils — 存放日期处理文件，可require引入

### 开发环境：

微信web开发者工具 v0.10.102800

### 项目截图：

https://www.getweapp.com/project?projectId=5832c56cbb2538f8186c7079