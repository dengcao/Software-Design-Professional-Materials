//licai.js
//获取应用实例

Page({
  data: {      
  },
  onLoad: function () {
    console.log('理财');  
  },
  onReady: function () {
   console.log('理财');  
  }
})
