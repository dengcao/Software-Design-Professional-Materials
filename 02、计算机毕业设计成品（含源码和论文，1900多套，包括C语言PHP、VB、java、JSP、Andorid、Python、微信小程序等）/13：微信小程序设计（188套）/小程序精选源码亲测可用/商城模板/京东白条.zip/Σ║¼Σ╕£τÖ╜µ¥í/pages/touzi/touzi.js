//touzi.js
//获取应用实例

Page({
  data: {      
  },
  onLoad: function () {
    console.log('touzi');  
  },
  onReady: function () {
   console.log('touzi');  
  }
})
