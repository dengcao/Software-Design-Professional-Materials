Page({
  data: {
    imageBox:[
      {
        "sortId":1,
        "src":"/images/sortMenuImages/sortMenu2.jpg"
      },
      {
        "sortId":2,
        "src":"/images/sortMenuImages/sortMenu3.jpg"
      },
      {
        "sortId":3,
        "src":"/images/sortMenuImages/sortMenu4.jpg"
      },
      {
        "sortId":4,
        "src":"/images/sortMenuImages/sortMenu5.jpg"
      },
      {
        "sortId":5,
        "src":"/images/sortMenuImages/sortMenu6.jpg"
      },
      {
        "sortId":6,
        "src":"/images/sortMenuImages/sortMenu7.jpg"
      },
      {
        "sortId":7,
        "src":"/images/sortMenuImages/sortMenu8.jpg"
      },
      {
        "sortId":8,
        "src":"/images/sortMenuImages/sortMenu9.jpg"
      },
    ]
  },
  // bindToSort: function() {
  //   wx.navigateTo({
  //     url: '/pages/sort/sort'
  //   })
  // },
  onLoad: function () {
    console.log('loaded.');
  }
});
