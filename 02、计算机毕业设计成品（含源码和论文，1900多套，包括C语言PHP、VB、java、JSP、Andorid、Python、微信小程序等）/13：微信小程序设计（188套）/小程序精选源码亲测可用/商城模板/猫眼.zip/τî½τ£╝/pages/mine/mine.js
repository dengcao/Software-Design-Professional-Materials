// mine.js

Page({
	data: {

	}
})
