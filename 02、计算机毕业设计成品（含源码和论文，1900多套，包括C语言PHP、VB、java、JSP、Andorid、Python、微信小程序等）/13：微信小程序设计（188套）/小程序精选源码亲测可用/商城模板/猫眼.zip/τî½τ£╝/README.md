# wx-maoyan(微信小程序)

# 介绍

学习下微信小程序，一个练手项目。

api是使用的http://www.jianshu.com/p/9855610eb1d4

应该不是官方的，很多api都没有，将就着用

侵权请联系我删除，QQ: 825618507

# 展示

![img_1](https://raw.githubusercontent.com/825618507/wx-maoyan/master/img_1.png)

![img_2](https://raw.githubusercontent.com/825618507/wx-maoyan/master/img_2.png)

## 使用

首先需要注册个微信小程序的账号啦，这个就不说了。

进入微信小程序，在设置 =》 开发设置 =》 服务器域名 =》 request合法域名中 添加 https://m.maoyan.com 这个地址，保存。

下载个微信web开发者工具，https://mp.weixin.qq.com/debug/wxadoc/dev/devtools/devtools.html?t=201715

剩下的也不说了，大家都会，不会的Google。创个新项目，把这个项目放进去就好啦。

由于api 的局限，很多需要资料都没有，目前只做了个首页的最近电影和电影详情。

有兴趣的同学可以往下做下去。

就酱~

