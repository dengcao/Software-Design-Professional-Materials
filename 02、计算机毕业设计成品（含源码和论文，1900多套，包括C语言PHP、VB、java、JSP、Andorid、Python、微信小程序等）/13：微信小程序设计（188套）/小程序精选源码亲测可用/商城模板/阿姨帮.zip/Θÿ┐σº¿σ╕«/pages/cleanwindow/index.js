var app=getApp();
Page({
  choose:function(e){
    wx.navigateTo({
      url:'../setting/index'
    })
  }
})
