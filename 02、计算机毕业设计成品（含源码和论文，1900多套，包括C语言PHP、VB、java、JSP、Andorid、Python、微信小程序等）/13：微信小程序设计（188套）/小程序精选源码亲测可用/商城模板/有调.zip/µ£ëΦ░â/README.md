# 微信小程序－有调

### 说明：

实现商品列表，详情展示等功能。

### 数据接口:

使用本地数据

### 目录结构：

- pages — 存放项目页面文件
- icon — 存放项目图标文件
- utils — 存放公共函数库文件

### 开发环境：

微信web开发者工具 v0.11.112301

### 项目截图：

https://www.getweapp.com/project?projectId=583a8ed3e8ff074c22472f31