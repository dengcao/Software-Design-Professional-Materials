var gotogos = [
  {
    cid:"21",
    url:"http://a.diaox2.com/cms/sites/default/files/20161107/zk/c1.jpg",
    title:"红色小恶魔游戏竞技鼠标",
    price:"￥348"
  },{
    cid:"22",
    url:"http://a.diaox2.com/cms/sites/default/files/20161104/goodthing/640.jpg",
    title:"让我将你的秀发挽起让我将你的秀发挽起让我将你的秀发挽起让我将你的秀发挽起让我将你的秀发挽起",
    price:"￥220"
  },{
    cid:"23",
    url:"http://a.diaox2.com/cms/sites/default/files/20161103/goodthing/fengmiantu.jpg",
    title:"是爷们的，这不来一发？！",
    price:"￥1200"
  }
]

export default gotogos
