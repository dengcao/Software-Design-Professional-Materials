 const articles = [
  {
    cid:1121,
    picUrl: '//a.diaox2.com/cms/sites/default/files/20161015/zk/SAOCOVER.jpg',
    title: '史上最全的分包装，最全最全史上最全的分包装史上最全的分包装，最全最全史上最全的分包装史上最全的分包装，最全最全史上最全的分包装史上最全的分包装，最全最全史上最全的分包装史上最全的分包装，最全最全史上最全的分包装',
    keyword:'胡子',
    price:12,
    count:1222
  }
  ,{
    cid:1122,
    picUrl: '//a.diaox2.com/cms/sites/default/files/20161017/extgt/wai640.jpg',
    title: '死了都要玩的极限旅游体验死了都要玩的极限旅游体验死了都要玩的极限旅游体验',
    keyword:'胡子',
    price:23.4,
    count:1222
  }
  ,{
    cid:1123,
    picUrl: '//a.diaox2.com/cms/sites/default/files/20161018/goodthing/hatIMGsss1.jpeg',
    title: '穿上它，就要露出来给你看',
    keyword:'哈哈',
    price:123,
    count:1222
  }
  ,{
    cid:1124,
    picUrl: '//a.diaox2.com/cms/sites/default/files/20160919/goodthing/640416eggcup.jpg',
    title: '你瞅啥，给你一锤子',
    keyword:'锤子',
    price:'1231',
    count:1222
  }
  ,{
    cid:1125,
    picUrl: 'http://a.diaox2.com/cms/sites/default/files/20161013/goodthing/c1.jpg',
    title: '给你的每支笔都开一个单人间',
    keyword:'笔',
    price:'32',
    count:12222
  }
  ,{
    cid:1126,
    picUrl: 'http://a.diaox2.com/cms/sites/default/files/20160902/goodthing/416.JPG',
    title: '这是一个好看，能装，还不贵的邮差包！',
    keyword:'锤子',
    price:'1231',
    count:12222
  }
  ,{
    cid:1127,
    picUrl: 'http://a.diaox2.com/cms/sites/default/files/20161018/extgt/c1.jpg',
    title: '这是一个好看，能装，还不贵的邮差包！',
    keyword:'锤子',
    price:'1231',
    count:12222
  }
  ,{
    cid:1128,
    picUrl: 'http://a.diaox2.com/cms/sites/default/files/20161013/goodthing/TTCOVER.jpg',
    title: '看脸，卖萌，蹭热度，这一定是套路最深的糖',
    keyword:'锤子',
    price:'1231',
    count:12222
  }
  ,{
    cid:1129,
    picUrl: 'http://a.diaox2.com/cms/sites/default/files/20161017/goodthing/JINNNNCOVER_0.jpg',
    title: '井柏然，你眼镜是不是戴反了？',
    keyword:'锤子',
    price:'1231',
    count:12222
  }
  ,{
    cid:1130,
    picUrl: 'http://a.diaox2.com/cms/sites/default/files/20161018/extgt/c1.jpg',
    title: '这些包你有钱也买不到，因为全世界只有一个',
    keyword:'锤子',
    price:'1231',
    count:12222
  }
  ,{
    cid:1131,
    picUrl: 'http://a.diaox2.com/cms/sites/default/files/20160929/goodthing/1_0.jpg',
    title: '和黑头say goodbye',
    keyword:'锤子',
    price:'1231',
    count:12222
  }
  ,{
    cid:1132,
    picUrl: 'http://a.diaox2.com/cms/sites/default/files/20161017/goodthing/640jiu.jpg',
    title: '这款瑜伽垫，凭什么比普通的贵20倍？',
    keyword:'锤子',
    price:'1231',
    count:12222
  }
]

const specials = [
 {
   cid:121312,
   picUrl: 'http://a.diaox2.com/cms/sites/default/files/20161015/zk/SAOCOVER.jpg',
   title: '这些骚货，让你成为一个合格的骚年',
   keyword:'胡子',
   price:12,
   count:1222
 }
 ,{
   cid:1232132,
   picUrl: 'http://a.diaox2.com/cms/sites/default/files/20161016/goodthing/640416cover.jpg',
   title: '￥9.9？就算你不爱cafe也该感受一下它所掀起的这场革命',
   keyword:'胡子',
   price:23.4,
   count:1222
 }
]

export default articles
export {specials}
