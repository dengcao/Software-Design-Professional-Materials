var res = {
  state: "SUCCESS",
  timestamp: 1478087388,
  message: "",
  data: [
    {
      sid: 1087,
      status: 1,
      type: 0,
      title: "BROOKS PICKWICK SMALL BACKPACK 小号双肩包",
      price: 1240,
      price_str: "￥1240起",
      brand: "BROOKS",
      brandori: "",
      images: [
        {
          url: "http://content.image.alimmdn.com/sku/1464110624069424_jpg.jpeg"
        }
      ],
      intro: "",
      specs: "品牌: BROOKS 型号: PICKWICK SMALL BACKPACK 颜色分类: Asphalt【需预定】,Saffron【需预定】,Octane【需预定】 自行车包种类: 骑行包(背包)",
      tags: [],
      sales: [
        {
          mart: "Brooks官网",
          intro: "可以直邮；国外网站打开较慢，请耐心等待~",
          price: "约￥1934",
          link_m_cps: "http://www.brooksengland.com/catalogue-and-shop/bags/cycle+bags+&+accoutrements/PICKWICK+Small+Backpack/",
          link_pc_cps: null,
          link_m_raw: null,
          link_pc_raw: null
        }, {
          link_pc_cps: null,
          link_m_cps: null,
          // link_m_cps: "http://item.taobao.com/item.htm?id=522219996410",
          link_pc_raw: null,
          link_m_raw: "http://item.taobao.com/item.htm?id=522219996410",
          mart: "淘宝",
          price: "￥1240",
          intro: "代购有风险，购买需谨慎"
        }, {
          link_pc_cps: null,
          link_m_cps: null,
          // link_m_cps: "http://item.taobao.com/item.htm?id=522219996410",
          link_pc_raw: null,
          link_m_raw: "http://tmail.com",
          mart: "tmall",
          price: "￥1240",
          intro: "代购有风险，购买需谨慎"
        }, {
          link_pc_cps: null,
          link_m_raw: "http://jd.com",
          mart: "京东",
          price: "￥1240",
          intro: "代购有风险，购买需谨慎"
        }, {
          link_pc_cps: null,
          link_m_raw: "http://shopbop.com",
          mart: "shopbop",
          price: "￥1240",
          intro: "代购有风险，购买需谨慎"
        }, {
          link_pc_cps: null,
          link_m_raw: "http://rakuten.com",
          mart: "rakuten",
          price: "￥1240",
          intro: "代购有风险，购买需谨慎"
        }, {
          link_pc_cps: null,
          link_m_raw: "http://amazon.cn",
          mart: "amazon中国",
          price: "￥1240",
          intro: "代购有风险，购买需谨慎"
        }, {
          link_pc_cps: null,
          link_m_raw: "http://amazon.jp",
          mart: "amazon日本",
          price: "￥1240",
          intro: "代购有风险，购买需谨慎"
        }, {
          link_pc_cps: null,
          link_m_raw: "http://amazon.de",
          mart: "amazon德国",
          price: "￥1240",
          intro: "代购有风险，购买需谨慎"
        }, {
          link_pc_cps: null,
          link_m_raw: "http://amazon.com",
          mart: "amazon",
          price: "￥1240",
          intro: "代购有风险，购买需谨慎"
        }
      ],
      revarticles: [
        18266495914141, 27208617826495, 28290949585339
      ],
      lastmod: "2016-07-18T05:41:39.000Z",
      extra: "",
      person: "dujuan"
    }
  ]
}

export default res
