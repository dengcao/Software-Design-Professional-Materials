//部署地址,开发工具调试时返回空字符串即可
//return "https://scholes.gzriver.com"
return "";