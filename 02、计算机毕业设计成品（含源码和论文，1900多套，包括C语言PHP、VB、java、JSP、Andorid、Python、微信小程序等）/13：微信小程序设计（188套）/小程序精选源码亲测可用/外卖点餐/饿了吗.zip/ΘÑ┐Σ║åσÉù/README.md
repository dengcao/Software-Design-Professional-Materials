# eleme
微信小程序-仿饿了么

引言：

参考vue的思想，对微信小程序进行一番研究，顺便写个小demo。结论是微信小程序和vue采用的都是mvvm的思路来开展，想深入了解小程序的机制可以参考vue，两者有许多相似之处。

目录结构：

googs — 存放商品信息页面 

image — 存放项目图片 

pages — 存放项目页面相关文件 

pay — 支付成功页面 

项目截图：

![image]( https://github.com/ayjacket/eleme/raw/master/pages/image/show.png)

欢迎学习交流
