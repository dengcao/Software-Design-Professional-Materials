Page({
    data: {
        hotMasters: [{
            name: "陈章鱼",
            avater: "czy.png",
            intro: "知乎50万关注答主，人丑就该多读书",
            fans: 2821
        }, {
            name: "马东",
            avater: "md.png",
            intro: "米未传媒CEO",
            fans: 18967
        }, {
            name: "张翼",
            avater: "lcx.png",
            intro: "猫奴+转业军官+电影/电视剧 演员",
            fans: 3646
        }],
        newMasters: [{
            name: "张男双",
            avater: "gzy.png",
            intro: "天文学家",
            fans: 4726
        }, {
            name: "龚琳娜",
            avater: "df.png",
            intro: "知乎50万关注答主，人丑就该多读书",
            fans: 2821
        }, {
            name: "古典",
            avater: "md.png",
            intro: "《拆掉思维里的墙》作者",
            fans: 3286
        }]
    },
    onLoad: function() {

    },
    toPerson: function() {

    }
})
