# weapp-hiapp
[HiApp](https://github.com/BelinChung/HiApp) 微信小程序版

## Previews
  ![Preview](https://github.com/BelinChung/weapp-hiapp/blob/master/demo/demo_v0.2.gif)

## Setup

1. **Clone the repo**

  ```
  $ git clone https://github.com/BelinChung/weapp-hiapp.git
  ```

2. **Import to Wechat DEV Tools**

    把项目导入到微信开发者工具中即可

## License

Copyright (c) 2016 Belin Chung. MIT Licensed, see [LICENSE](https://github.com/BelinChung/weapp-hiapp/blob/master/LICENSE) for details.
