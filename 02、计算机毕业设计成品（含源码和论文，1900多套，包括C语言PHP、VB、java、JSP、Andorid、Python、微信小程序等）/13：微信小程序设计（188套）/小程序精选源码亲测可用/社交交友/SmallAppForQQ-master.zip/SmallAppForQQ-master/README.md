# SmallAppForQQ

   作者：Code4Android
   
   新浪微博：http://weibo.com/745687294
   
   CSDN  :    http://blog.csdn.net/xiehuimx?viewmode=contents
   
   简书   :   http://www.jianshu.com/users/d5b531888b2b/latest_articles


##再次提醒，直接装官方软件,链接在下面。有什么问题可在博客留言.或者微博私信
##音乐信息使用的第三方接口，由于是免费的，限制每秒请求2次，所以可能会出现音乐加载失败问题。

创建微信小程序(微信应用号)，后续开发仿QQ应用程序

实现微信小程序（微信应用号）QQ 

进度更新：

![](https://github.com/xiehui999/SmallAppForQQ/blob/master/images/demo/qq.png)

![](https://github.com/xiehui999/SmallAppForQQ/blob/master/images/demo/contact.png)

![](https://github.com/xiehui999/SmallAppForQQ/blob/master/images/demo/dynamic.png)

![](https://github.com/xiehui999/SmallAppForQQ/blob/master/images/demo/music.png)

2016/09/25 00:37  Add images,Realization funnction QQ tab.

2016/09/25 12:28  Create pages of message,contact,dynamic and  create dynamic title bar.

2016/09/25 18:05  Solve the "Page注册错误"error.

2016/09/26 09:54  Add data in message.js file.

2016/09/26 13:09  Realization funnction of message pagepage.

2016/09/26 15:52  Perfect message page layout,add time,count field.

2016/09/26 16:08  Add App picture and adjust the picture to center display for message .

2016/09/26 22:46  Adjust layout

2016/09/27 12:09  Add a search box for a message page .

2016/09/27 18:33  Add part of the function of the contact page.

2016/09/28 20:22 Add group function of the contact page.

2016/09/28 13:34 Realization funnction of dynamic page.

2016/09/28 16:37 Adjust layout.

2016/09/28 20:30 添加微信官方demo（weixinapp-demo.zip） ，小程序的所有组件接口都在demo中有体现，是一个初入学习最好的材料。
                 注意下载文件后解压文件到其它目录，不要解压到SmallmallAppForQQ目录下，不然运行可能会出现问题。

2016/09/10/01  Add  bindtap for dynamic and create music page

2016/09/10/08  Achieve part of funnction of music page.

2016/09/10/10  Add random play music function.

目前正在紧张的开发中...请稍后，持续更新



微信小程序资料推荐：

##[ 微信小程序开发常见问题分析](http://blog.csdn.net/xiehuimx/article/details/52005355)

##[小程序开发文档](https://mp.weixin.qq.com/debug/wxadoc/dev/index.html)

##[小程序设计指南](https://mp.weixin.qq.com/debug/wxadoc/design/index.html)

##[小程序开发者工具](https://mp.weixin.qq.com/debug/wxadoc/dev/index.html)
##[Windows 64](https://servicewechat.com/wxa-dev-logic/download_redirect?type=x64&amp;from=mpwiki&amp;t=1474887501301),[Windows 32](https://servicewechat.com/wxa-dev-logic/download_redirect?type=ia32&amp;from=mpwiki&amp;t=1474887501301),[MAC](https://servicewechat.com/wxa-dev-logic/download_redirect?type=darwin&amp;from=mpwiki&amp;t=1474887501301)

##[4. 小程序官方demo](https://github.com/xiehui999/SmallAppForQQ/blob/master/weixinapp-demo.zip)
