//app.js
App({
    onLaunch: function () {
        console.log('App Launch')
    }
});

