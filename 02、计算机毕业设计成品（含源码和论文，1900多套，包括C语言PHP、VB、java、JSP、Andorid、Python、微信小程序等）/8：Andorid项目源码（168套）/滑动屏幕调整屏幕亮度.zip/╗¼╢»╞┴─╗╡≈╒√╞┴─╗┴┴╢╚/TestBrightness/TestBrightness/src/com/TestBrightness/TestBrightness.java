package com.TestBrightness;

import android.app.Activity;
import android.app.AlertDialog;
import android.app.AlertDialog.Builder;
import android.content.DialogInterface;
import android.os.Bundle;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.SeekBar;
import android.widget.SeekBar.OnSeekBarChangeListener;

import com.TestBrightness.manager.SystemManager;

public class TestBrightness extends Activity implements OnClickListener{
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        SystemManager.init(this);
        
        showBrightnessSettingDialog();
    }
    
	@Override
	public void onClick(View v) {
		showBrightnessSettingDialog();
	}
    
    private int mOldBrightness;
    private int mCurrentBrightness = 0;
    
    private int mOldAutomatic;

    private boolean mAutomaticAvailable;
    
    /**
     * Brightness value for dim backlight
     */
    private static final int BRIGHTNESS_DIM = 20;
    
    /**
     * Brightness value for fully on
     */
    private static final int BRIGHTNESS_ON = 255;
    
    // Backlight range is from 0 - 255. Need to make sure that user
    // doesn't set the backlight to 0 and get stuck
    private static final int MINIMUM_BACKLIGHT = BRIGHTNESS_DIM + 10;
    private static final int MAXIMUM_BACKLIGHT = BRIGHTNESS_ON;
    
    private void showBrightnessSettingDialog(){  
        final SystemManager systemManager = SystemManager.getInstance();  
        final Builder builder = new AlertDialog.Builder(this);  
        final View view = getLayoutInflater().inflate(R.layout.brightness_view, null);  
    
        // set brightness seekbar  
        final SeekBar brightnessBar = (SeekBar) view.findViewById(R.id.brightness_bar);  
        brightnessBar.setMax(MAXIMUM_BACKLIGHT - MINIMUM_BACKLIGHT);  
        int brightness = systemManager.getScreenBrightness();  
        int process = brightness - MINIMUM_BACKLIGHT;  
        if (process<0) {  
        	process = 0;  
        	mOldBrightness = MINIMUM_BACKLIGHT;  
        	mCurrentBrightness = MINIMUM_BACKLIGHT;  
        }else{  
        	mOldBrightness = brightness;  
        	mCurrentBrightness = brightness;  
        }  
        brightnessBar.setProgress(process);  
    
        // set automatic available checkbox  
        final CheckBox autoBrightness = (CheckBox)view.findViewById(R.id.auto_brightness);  
        mOldAutomatic = systemManager.getBrightnessMode();  
        mAutomaticAvailable = systemManager.isAutoBrightness();  
        autoBrightness.setChecked(mAutomaticAvailable);  
        if(mAutomaticAvailable){  
            brightnessBar.setVisibility(View.GONE);  
        }else{  
            brightnessBar.setVisibility(View.VISIBLE);  
        } 
        autoBrightness.setOnCheckedChangeListener(new OnCheckedChangeListener() {  
        	  
            @Override  
            public void onCheckedChanged(final CompoundButton buttonView, final boolean isChecked) {  
             mAutomaticAvailable = isChecked;  
             if(isChecked){  
                    brightnessBar.setVisibility(View.GONE);  
                    systemManager.startAutoBrightness();  
                    //systemManager.setBrightness(MainActivity.this, systemManager.getScreenBrightness());  
                    int process = systemManager.getScreenBrightness() - MINIMUM_BACKLIGHT;  
                    if (process<0) {  
                    	process = 0;  
                    }// end if  
                    brightnessBar.setProgress(process);  
                }else{  
                    brightnessBar.setVisibility(View.VISIBLE);  
                    systemManager.stopAutoBrightness();  
                    //systemManager.setBrightness(MainActivity.this, systemManager.getScreenBrightness());  
                    int process = systemManager.getScreenBrightness() - MINIMUM_BACKLIGHT;  
                    if (process<0) {
                    	process = 0;  
                    }// end if  
                    brightnessBar.setProgress(process);  
                }  
            }  
       
        });  
       
        brightnessBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {  
       
            @Override  
            public void onStopTrackingTouch(final SeekBar seekBar) {  
       
            }  
       
            @Override  
            public void onStartTrackingTouch(final SeekBar seekBar) {  
       
            }  
       
            @Override  
            public void onProgressChanged(final SeekBar seekBar, final int progress,  
                    final boolean fromUser) {  
            	mCurrentBrightness = progress + MINIMUM_BACKLIGHT;  
                systemManager.setBrightness(TestBrightness.this, mCurrentBrightness);  
            }  
        });  
       
        builder.setTitle(R.string.brightness);  
        builder.setView(view);  
        builder.setPositiveButton(android.R.string.ok, new DialogInterface.OnClickListener(){  
       
            @Override  
            public void onClick(final DialogInterface dialog, final int which) {  
             // set brightness  
                if(mAutomaticAvailable){  
                    systemManager.saveBrightness(systemManager.getScreenBrightness());  
                }else{  
                    systemManager.saveBrightness(mCurrentBrightness);  
                }  
            }  
       
        });  
        builder.setNegativeButton(android.R.string.cancel, new DialogInterface.OnClickListener() {  
       
            @Override  
            public void onClick(final DialogInterface dialog, final int which) {  
                // recover brightness  
             systemManager.setBrightness(TestBrightness.this, mOldBrightness);  
                systemManager.saveBrightness(mOldBrightness);  
                // recover automatic brightness mode  
                systemManager.setBrightnessMode(mOldAutomatic);  
            }  
        });  
       
        builder.show();  
    }

	
}