package cn.lkp;

import android.app.Activity;  
import android.os.Bundle;  
import android.os.Vibrator;  
import android.util.Log;  
import android.view.GestureDetector;  
import android.view.MotionEvent;  
import android.view.WindowManager;  
import android.widget.MediaController;  
import android.widget.VideoView;  
public class MainActivity extends Activity {  
    private VideoView myVideoView;  
    private String path = "/mnt/sdcard/video/1_baofeng.3gp";  
    private String TAG = "MainActivity";  
    private GestureDetector mGestureDetector;  
    private Vibrator vibrator;  
    /** Called when the activity is first created. */  
    @Override  
    public void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState);  
        setContentView(R.layout.main);  
        myVideoView = (VideoView) findViewById(R.id.myvideoview);  
        myVideoView.setVideoPath(path);  
        myVideoView.setMediaController(new MediaController(this));  
        myVideoView.requestFocus();  
        myVideoView.start();  
    }  
    /* 
     *  
     * ������Ļ���� lp = 0 ȫ�� ��lp= -1,����ϵͳ���ã� lp = 1; ���� 
     */  
    public void setBrightness(float brightness) {  
        WindowManager.LayoutParams lp = getWindow().getAttributes();  
        // if (lp.screenBrightness <= 0.1) {  
        // return;  
        // }  
        lp.screenBrightness = lp.screenBrightness + brightness / 255.0f;  
        if (lp.screenBrightness > 1) {  
            lp.screenBrightness = 1;  
            vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);  
            long[] pattern = { 10, 200 }; // OFF/ON/OFF/ON...  
            vibrator.vibrate(pattern, -1);  
        } else if (lp.screenBrightness < 0.2) {  
            lp.screenBrightness = (float) 0.2;  
            vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);  
            long[] pattern = { 10, 200 }; // OFF/ON/OFF/ON...  
            vibrator.vibrate(pattern, -1);  
        }  
        Log.e(TAG, "lp.screenBrightness= " + lp.screenBrightness);  
        getWindow().setAttributes(lp);  
    }  
    @Override  
    protected void onResume() {  
        mGestureDetector = new GestureDetector(  
                new GestureDetector.OnGestureListener() {  
                    public boolean onSingleTapUp(MotionEvent e) {  
                        return false;  
                    }  
                    public boolean onDown(MotionEvent e) {  
                        return false;  
                    }  
                    public void onLongPress(MotionEvent e) {  
                    }  
                    public boolean onFling(MotionEvent e1, MotionEvent e2,  
                            float velocityX, float velocityY) {  
                        return true;  
                    }  
                    public boolean onScroll(MotionEvent e1, MotionEvent e2,  
                            float distanceX, float distanceY) {  
                        final double FLING_MIN_DISTANCE = 0.5;  
                        final double FLING_MIN_VELOCITY = 0.5;  
                        if (e1.getY() - e2.getY() > FLING_MIN_DISTANCE  
                                && Math.abs(distanceY) > FLING_MIN_VELOCITY) {  
                            Log.e(TAG, "up");  
                            setBrightness(20);  
                        }  
                        if (e1.getY() - e2.getY() < FLING_MIN_DISTANCE  
                                && Math.abs(distanceY) > FLING_MIN_VELOCITY) {  
                            Log.e(TAG, "down");  
                            setBrightness(-20);  
                        }  
                        return true;  
                    }  
                    public void onShowPress(MotionEvent e) {  
                        // TODO Auto-generated method stub  
                    }  
                });  
        super.onResume();  
    }  
    public boolean onTouchEvent(MotionEvent event) {  
        boolean result = mGestureDetector.onTouchEvent(event);  
        if (!result) {  
            if (event.getAction() == MotionEvent.ACTION_UP) {  
                // getVideoInfosfromPath(filePath);  
            }  
            result = super.onTouchEvent(event);  
        }  
        return result;  
    }  
    @Override  
    protected void onStop() {  
        if (null != vibrator) {  
            vibrator.cancel();  
        }  
        super.onStop();  
    }  
}  