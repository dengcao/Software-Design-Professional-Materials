package com.test;

public class Personnel {
	
	private String id;
	private String username;
	private String name;
	private String telphone;
	private String email;
	private String userPhoto;
	private String deptName;
	private String depID;
	
	private int isRead;
	
	
	
	public Personnel(String name){
		
		this.name = name;
	}
	
	
	public Personnel(String id,String name,String userPhoto,String telphone,String depID,int isRead){
		
		this.id = id;
		this.name = name;
		this.userPhoto = userPhoto;
		this.telphone = telphone;
		this.depID = depID;
		this.isRead = isRead;
	}
	

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTelphone() {
		return telphone;
	}
	public void setTelphone(String telphone) {
		this.telphone = telphone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getUserPhoto() {
		return userPhoto;
	}
	public void setUserPhoto(String userPhoto) {
		this.userPhoto = userPhoto;
	}
	public String getDeptName() {
		return deptName;
	}
	public void setDeptName(String deptName) {
		this.deptName = deptName;
	}
	public String getDepID() {
		return depID;
	}
	public void setDepID(String depID) {
		this.depID = depID;
	}
	
	public int getIsRead() {
		return isRead;
	}

	public void setIsRead(int isRead) {
		this.isRead = isRead;
	}
}
