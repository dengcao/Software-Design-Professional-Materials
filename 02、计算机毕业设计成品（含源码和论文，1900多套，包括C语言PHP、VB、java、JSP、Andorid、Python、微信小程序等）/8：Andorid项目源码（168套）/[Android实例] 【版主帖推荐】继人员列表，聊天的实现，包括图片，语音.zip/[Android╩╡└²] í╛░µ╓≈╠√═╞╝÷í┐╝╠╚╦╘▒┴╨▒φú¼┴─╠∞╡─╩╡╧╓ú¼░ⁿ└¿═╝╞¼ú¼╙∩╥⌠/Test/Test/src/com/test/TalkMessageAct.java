package com.test;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Bitmap;
import android.graphics.drawable.Drawable;
import android.location.Location;
import android.media.MediaRecorder;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.provider.MediaStore;
import android.text.Spannable;
import android.text.TextUtils;
import android.text.style.ImageSpan;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnTouchListener;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import com.baidu.mapapi.BMapManager;
import com.baidu.mapapi.LocationListener;
import com.baidu.mapapi.MapActivity;

public class TalkMessageAct extends MapActivity implements OnClickListener{

	private ListView talkList;

	private static List<DetailEntity> list = null;

	private TextView titleText;
	private Button backButton;

	private View mediaView;

	private Button showMediaButton;
	private Button cancelMediaButton;

	private Button talkMessage_record;
	private Button talkMessage_voice;
	private boolean Voice_Sel = false;
	
	private AlertDialog voiceDialog;
	private MediaRecorder mediaRecorder;
	
	private Button expressionButton;

	private Button cameraButton;
	private Button photoButotn;
	private Button locationButton;
	private Button requestLocationButton;
	
	private ProgressBar progressBarBtn;
	private TextView progressBarText;

	private Button sendButton;
	private EditText edit;

	private AlertDialog expressionDialog;

	public static Integer[] mImageIds = { R.drawable.f000, R.drawable.f001,
			R.drawable.f002, R.drawable.f003, R.drawable.f004, R.drawable.f005,
			R.drawable.f006, R.drawable.f007, R.drawable.f008, R.drawable.f009,
			R.drawable.f010, R.drawable.f011, R.drawable.f012, R.drawable.f013,
			R.drawable.f014, R.drawable.f015, R.drawable.f016, R.drawable.f017,
			R.drawable.f018, R.drawable.f019, R.drawable.f020, R.drawable.f021,
			R.drawable.f022, R.drawable.f023, R.drawable.f024, R.drawable.f025,
			R.drawable.f026, R.drawable.f027, R.drawable.f028, R.drawable.f029,
			R.drawable.f030, R.drawable.f031, R.drawable.f032, R.drawable.f033,
			R.drawable.f034, R.drawable.f035, R.drawable.f036, R.drawable.f037,
			R.drawable.f038, R.drawable.f039, R.drawable.f040, R.drawable.f041,
			R.drawable.f042, R.drawable.f043, R.drawable.f044, R.drawable.f045,
			R.drawable.f046, R.drawable.f047, R.drawable.f048, R.drawable.f049,
			R.drawable.f050, R.drawable.f051, R.drawable.f052, R.drawable.f053,
			R.drawable.f054, R.drawable.f044, R.drawable.f056, R.drawable.f057,
			R.drawable.f058, R.drawable.f059, R.drawable.f060, R.drawable.f061,
			R.drawable.f062, R.drawable.f063, R.drawable.f064, R.drawable.f065,
			R.drawable.f066, R.drawable.f067, R.drawable.f068, R.drawable.f069,
			R.drawable.f070, R.drawable.f071, R.drawable.f072, R.drawable.f073 };

	private GridView expressionView;

	private List<Map<String, Object>> content = new ArrayList<Map<String, Object>>();

	private String TFuid;
	
	private String json;

	private List<DetailEntity> messageList;
	
	private double baiDu_Lon;
	private double baiDu_Lat;

	private BMapApiDemoApp app;

	private String friendName;
	
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.talkmessage);
		
//		IntentFilter mFilter = new IntentFilter();
//		mFilter.addAction("com.management_talkmessage.recevie");
//		registerReceiver(mBroadcastReceiver, mFilter);
		
		View view = LayoutInflater.from(this).inflate(
				R.layout.expressiondialog, null);
		expressionView = (GridView) view.findViewById(R.id.expression_gridview);
		for (int i = 0; i < mImageIds.length; i++) {
			Map<String, Object> map = new HashMap<String, Object>();
			map.put("IMAGE", mImageIds[i]);
			content.add(map);
		}
		

		SimpleAdapter adapter = new SimpleAdapter(this, content,
				R.layout.expressiondialog_context, new String[] { "IMAGE" },
				new int[] { R.id.expressiondialog_image });
		expressionView.setAdapter(adapter);
		expressionView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1,
					final int positon, long arg3) {

				setFace(positon + 1, mImageIds[positon]);
				expressionDialog.cancel();
			}

		});
		expressionDialog = new AlertDialog.Builder(this).create();
		expressionDialog.setView(view, 0, 0, 0, 0);
		
		talkList = (ListView) findViewById(R.id.talkmessage);

		mediaView = findViewById(R.id.talkmessage_media);
		
		progressBarBtn = (ProgressBar)findViewById(R.id.talkmessage_pro);
		progressBarText = (TextView)findViewById(R.id.talkmessage_protext);
		
//		friendName = this.getIntent().getStringExtra("name");

		titleText = (TextView) findViewById(R.id.talkmessage_title);
		titleText.setText("����");

		talkList = (ListView) findViewById(R.id.talkmessage);

		backButton = (Button) findViewById(R.id.talkmessage_backbtn);
		backButton.setOnClickListener(this);

		talkMessage_voice = (Button) findViewById(R.id.talkmessage_voice);
		talkMessage_voice.setOnClickListener(this);
		talkMessage_record = (Button) findViewById(R.id.talk_message_record);
		ButtonListener b = new ButtonListener();
		talkMessage_record.setOnTouchListener(b);

		showMediaButton = (Button) findViewById(R.id.talkmessage_showmedia);
		cancelMediaButton = (Button) findViewById(R.id.talkmessage_cancelmedia);
		showMediaButton.setOnClickListener(this);
		cancelMediaButton.setOnClickListener(this);

		expressionButton = (Button) findViewById(R.id.talkmessage_expression);
		expressionButton.setOnClickListener(this);

		cameraButton = (Button) findViewById(R.id.talkmessage_camera);
		photoButotn = (Button) findViewById(R.id.talkmessage_pic);
		locationButton = (Button)findViewById(R.id.talkmessage_location);
		requestLocationButton = (Button)findViewById(R.id.talkmessage_requestlocation);
		cameraButton.setOnClickListener(this);
		photoButotn.setOnClickListener(this);
		locationButton.setOnClickListener(this);
		requestLocationButton.setOnClickListener(this);

		edit = (EditText) findViewById(R.id.talkmessage_edit);
		sendButton = (Button) findViewById(R.id.talkmessage_send);
		sendButton.setOnClickListener(this);

		list = new ArrayList<DetailEntity>();
		messageList = new ArrayList<DetailEntity>();
		
		View voiceView = LayoutInflater.from(TalkMessageAct.this).inflate(R.layout.record_voiceview, null);
		voiceDialog = new AlertDialog.Builder(TalkMessageAct.this).setView(voiceView).create();
		
//		TFuid = this.getIntent().getStringExtra("TFuid");
		TFuid = "2";
		
		messageList = MessageSQLService.getInstance(this).getdatas(
				Integer.valueOf(UserInfomation.getUserID(TalkMessageAct.this)),
				Integer.valueOf(TFuid));
		
		
		for (int i = 0; i < messageList.size(); i++) {
			
				switch (messageList.get(i).getTtmType()) {
				case 1:

					int id = Integer.valueOf(messageList.get(i).getTtmTuID());
					if (id == Integer.valueOf(TFuid)) {
						DetailEntity other = new DetailEntity(messageList.get(i)
								.getTtmContent(), R.layout.list_say_he_item, TFuid,messageList.get(i)
								.getTtmTime());
						
						list.add(other);
						if (list.size() <= 0) {

						} else {
							talkList.setAdapter(new DetailAdapter(
									TalkMessageAct.this,list,TFuid));
						}

					} else if (id == Integer.valueOf(UserInfomation
							.getUserID(TalkMessageAct.this))) {
						DetailEntity other = new DetailEntity(messageList.get(i)
								.getTtmContent(), R.layout.list_say_me_item,
								UserInfomation.getUserID(TalkMessageAct.this),messageList.get(i)
								.getTtmTime());
						
						list.add(other);
						if (list.size() <= 0) {

						} else {
							talkList.setAdapter(new DetailAdapter(
									TalkMessageAct.this,list,TFuid));
						}
					}

					break;
				case 2:
					int ids = Integer.valueOf(messageList.get(i).getTtmTuID());
					if (ids == Integer.valueOf(TFuid)) {
						DetailEntity other = new DetailEntity(messageList.get(i)
								.getTtmContent(), R.layout.list_say_he_image, TFuid,messageList.get(i)
								.getTtmTime());
						list.add(other);
						if (list.size() <= 0) {

						} else {
							talkList.setAdapter(new DetailAdapter(
									TalkMessageAct.this,list,TFuid));
						}

					} else if (ids == Integer.valueOf(UserInfomation
							.getUserID(TalkMessageAct.this))) {
						DetailEntity other = new DetailEntity(messageList.get(i)
								.getTtmContent(), R.layout.list_say_me_image,
								UserInfomation.getUserID(TalkMessageAct.this),messageList.get(i)
								.getTtmTime());
						
						
						list.add(other);
						if (list.size() <= 0) {

						} else {
							talkList.setAdapter(new DetailAdapter(
									TalkMessageAct.this, list,TFuid));
						}
					}
					break;
				case 3:
					int idsx = Integer.valueOf(messageList.get(i).getTtmTuID());
					if (idsx == Integer.valueOf(TFuid)) {
						DetailEntity other = new DetailEntity(messageList.get(i)
								.getTtmContent(), R.layout.list_say_he_voice, TFuid,messageList.get(i)
								.getTtmTime());
						list.add(other);
						if (list.size() <= 0) {

						} else {
							talkList.setAdapter(new DetailAdapter(
									TalkMessageAct.this, list,TFuid));
						}

					} else if (idsx == Integer.valueOf(UserInfomation
							.getUserID(TalkMessageAct.this))) {
						DetailEntity other = new DetailEntity(messageList.get(i)
								.getTtmContent(), R.layout.list_say_me_voice,
								UserInfomation.getUserID(TalkMessageAct.this),messageList.get(i)
								.getTtmTime());
						
						
						list.add(other);
						if (list.size() <= 0) {

						} else {
							talkList.setAdapter(new DetailAdapter(
									TalkMessageAct.this, list,TFuid));
						}
					}
					break;
				case 5:
					break;
				case 6:
					int idsxx = Integer.valueOf(messageList.get(i).getTtmTuID());
					if (idsxx == Integer.valueOf(TFuid)) {
						DetailEntity other = new DetailEntity(messageList.get(i)
								.getTtmContent(), R.layout.list_say_he_location, TFuid,messageList.get(i)
								.getTtmTime());
						list.add(other);
						if (list.size() <= 0) {

						} else {
							talkList.setAdapter(new DetailAdapter(
									TalkMessageAct.this, list,TFuid));
						}

					} else if (idsxx == Integer.valueOf(UserInfomation
							.getUserID(TalkMessageAct.this))) {
						DetailEntity other = new DetailEntity(messageList.get(i)
								.getTtmContent(), R.layout.list_say_me_location,
								UserInfomation.getUserID(TalkMessageAct.this),messageList.get(i)
								.getTtmTime());
						
						
						list.add(other);
						if (list.size() <= 0) {

						} else {
							talkList.setAdapter(new DetailAdapter(
									TalkMessageAct.this, list,TFuid));
						}
					}
					break;

				}
			}

		talkList.setSelection(messageList.size());

	}
	

	@Override
	protected void onStart() {
		
		super.onStart();
	}


	@Override
	public void onClick(View v) {

		switch (v.getId()) {
		case R.id.talkmessage_backbtn:
				TalkMessageAct.this.finish();
			break;
		case R.id.talkmessage_showmedia:
			mediaView.setVisibility(View.VISIBLE);
			cancelMediaButton.setVisibility(View.VISIBLE);
			showMediaButton.setVisibility(View.GONE);
			break;
		case R.id.talkmessage_cancelmedia:
			mediaView.setVisibility(View.GONE);
			cancelMediaButton.setVisibility(View.GONE);
			showMediaButton.setVisibility(View.VISIBLE);
			break;

		case R.id.talkmessage_voice:
			Voice_Sel = !Voice_Sel;
			if (Voice_Sel) {
				talkMessage_voice
						.setBackgroundResource(R.drawable.chatting_setmode_msg_btn_normal);
				talkMessage_record.setVisibility(View.VISIBLE);
				edit.setVisibility(View.GONE);
				sendButton.setVisibility(View.GONE);
			} else {
				talkMessage_voice
						.setBackgroundResource(R.drawable.profile_icon_voice_normal);
				edit.setVisibility(View.VISIBLE);
				sendButton.setVisibility(View.VISIBLE);
				talkMessage_record.setVisibility(View.GONE);
			}
			break;

		case R.id.talkmessage_send:
			
			
			if(TextUtils.isEmpty(edit.getText())){

			}else{
				
				DetailEntity d = new DetailEntity(edit.getText().toString(),
						R.layout.list_say_me_item,
						UserInfomation.getUserID(TalkMessageAct.this),DateUtil.getCurrentTiem());

				d.setTtmContent(edit.getText().toString());
				d.setLayoutID(R.layout.list_say_me_item);
				d.setTtmType(1);
				d.setTtmTuID(Integer.valueOf(UserInfomation
						.getUserID(TalkMessageAct.this)));
				d.setTtmToUserId(Integer.valueOf(TFuid));
				d.setTtmTime(DateUtil.getCurrentTiem());

				MessageSQLService.getInstance(TalkMessageAct.this).save(d);
				list.add(d);
				 
				talkList.setAdapter(new DetailAdapter(TalkMessageAct.this,list,TFuid));
				talkList.setSelection(list.size());
				
//				mHandler.sendEmptyMessage(1);
				mHandler.sendEmptyMessage(2);
			}

			break;
		case R.id.talkmessage_edit:
			break;
		case R.id.talkmessage_expression:
			expressionDialog.show();
			break;
		case R.id.talkmessage_camera:
			Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
			startActivityForResult(intent, 1);
			break;
		case R.id.talkmessage_pic:
			Intent album = new Intent(Intent.ACTION_GET_CONTENT);
			album.setType("image/*");
			startActivityForResult(album, 2);
			break;
		case R.id.talkmessage_location:
				
			progressBarBtn.setVisibility(View.VISIBLE);
			progressBarText.setVisibility(View.VISIBLE);
//			mLocationManager.getLocation(this, 1);	
			app = (BMapApiDemoApp)this.getApplication();
			if (app.mBMapMan == null) {
				app.mBMapMan = new BMapManager(getApplication());
				app.mBMapMan.init(app.mStrKey, new BMapApiDemoApp.MyGeneralListener());
			}
			app.mBMapMan.start();
			
	        mLocationListener = new LocationListener(){

				@Override
				public void onLocationChanged(Location location) {
					if(location != null){
						
						baiDu_Lon = location.getLongitude();
	  					baiDu_Lat = location.getLatitude();
	  					
	  					mHandler.sendEmptyMessage(11);
	  					
					}
				}
	        };
			
	        app.mBMapMan.getLocationManager().requestLocationUpdates(mLocationListener);
			app.mBMapMan.start();
			
			break;
		case R.id.talkmessage_requestlocation:
			
			break;
		}
	}

	public static String FilterHtml(String str) {
		str = str.replaceAll("<(?!br|img)[^>]+>", "").trim();
		return str;
	}

	private void setFace(int faceTitle, int faceImg) {

		int start = edit.getSelectionStart();
		Spannable ss = edit.getText().insert(start, "[" + faceTitle + "]");
		Drawable d = getResources().getDrawable(faceImg);
		d.setBounds(0, 0, 30, 30);
		ImageSpan span = new ImageSpan(d, faceTitle + ".gif",
				ImageSpan.ALIGN_BASELINE);
		ss.setSpan(span, start, start + ("[" + faceTitle + "]").length(),
				Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
	}


	private Handler mHandler = new Handler() {

		private DetailEntity d;

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch(msg.what){
			case 1:
				break;
			case 2:
				progressBarBtn.setVisibility(View.GONE);
				progressBarText.setVisibility(View.GONE);
				edit.setText("");
				break;
			case 3:
				Toast.makeText(TalkMessageAct.this,"����ʧ��",300).show();
				break;
			case 4:
				Toast.makeText(TalkMessageAct.this,"�����쳣",300).show();
				break;
			case 5:
				
				d = new DetailEntity(ClippingPicture.talkPicName,
						R.layout.list_say_me_image,
						UserInfomation.getUserID(TalkMessageAct.this),DateUtil.getCurrentTiem());

				d.setTtmContent(ClippingPicture.talkPicName);
				d.setLayoutID(R.layout.list_say_me_image);
				d.setTtmType(2);
				d.setTtmTuID(Integer.valueOf(UserInfomation
						.getUserID(TalkMessageAct.this)));
				d.setTtmToUserId(Integer.valueOf(TFuid));
				d.setTtmTime(DateUtil.getCurrentTiem());

				MessageSQLService.getInstance(TalkMessageAct.this).save(d);
				list.add(d);
				
				talkList.setAdapter(new DetailAdapter(TalkMessageAct.this,list, TFuid));
				talkList.setSelection(list.size());
				
//				mHandler.sendEmptyMessage(6);
				mHandler.sendEmptyMessage(2);
				
				break;
			case 6:
				break;
			case 7:
				break;
			case 8:
				
				d = new DetailEntity(ClippingSounds.talkSoundName,
						R.layout.list_say_me_voice,
						UserInfomation.getUserID(TalkMessageAct.this),DateUtil.getCurrentTiem());

				d.setTtmContent(ClippingSounds.talkSoundName);
				d.setLayoutID(R.layout.list_say_me_voice);
				d.setTtmType(3);
				d.setTtmTuID(Integer.valueOf(UserInfomation
						.getUserID(TalkMessageAct.this)));
				d.setTtmToUserId(Integer.valueOf(TFuid));
				d.setTtmTime(DateUtil.getCurrentTiem());

				MessageSQLService.getInstance(TalkMessageAct.this).save(d);
				list.add(d);
				 
				talkList.setAdapter(new DetailAdapter(TalkMessageAct.this,list,TFuid));
				talkList.setSelection(list.size());
				
//				mHandler.sendEmptyMessage(9);
				mHandler.sendEmptyMessage(2);
				
				break;
			case 9:

				break;
			case 10:

				break;
			case 11:
				
				System.out.println(baiDu_Lat+","+baiDu_Lon);
				
				d = new DetailEntity(baiDu_Lat+","+baiDu_Lon,
						R.layout.list_say_me_location,
						UserInfomation.getUserID(TalkMessageAct.this),DateUtil.getCurrentTiem());

				d.setTtmContent(baiDu_Lat+","+baiDu_Lon);
				d.setLayoutID(R.layout.list_say_me_location);
				d.setTtmType(6);
				d.setTtmTuID(Integer.valueOf(UserInfomation
						.getUserID(TalkMessageAct.this)));
				d.setTtmToUserId(Integer.valueOf(TFuid));
				d.setTtmTime(DateUtil.getCurrentTiem());

				MessageSQLService.getInstance(TalkMessageAct.this).save(d);
				list.add(d);
				 
				talkList.setAdapter(new DetailAdapter(TalkMessageAct.this,list,TFuid));
				talkList.setSelection(list.size());
				
//				mHandler.sendEmptyMessage(12);
				mHandler.sendEmptyMessage(2);
				
				break;
			case 12:

				break;
			case 13:
				
				break;
				
			}
		}
	};

	
//	private BroadcastReceiver mBroadcastReceiver = new BroadcastReceiver() {
//
//		@Override
//		public void onReceive(Context context, Intent intent) {
//
//			String action = intent.getAction();
//			if (action.equals("com.management_talkmessage.recevie")) {
//
//				
//			}
//		}
//	};
	

	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {
		
		ContentResolver resolver = getContentResolver();
		if (resultCode == 0)
			return;
		
		if (requestCode == 1) {
			Bitmap bitmap = (Bitmap) data.getExtras().get("data");
			Bitmap newBitmap = ClippingPicture.Resize(bitmap);
			ClippingPicture.saveTalkBitmap(newBitmap);
			
			mHandler.sendEmptyMessage(5);
			
		}else if (requestCode == 2) {

			Uri originalUri = data.getData();
			if (originalUri != null) {
				try {
					Bitmap bitmap = MediaStore.Images.Media.getBitmap(resolver,
							originalUri);
					Bitmap newBitmap = ClippingPicture.Resize(bitmap);
					ClippingPicture.saveTalkBitmap(newBitmap);
					mHandler.sendEmptyMessage(5);
					
				} catch (FileNotFoundException e) {
					e.printStackTrace();
				} catch (IOException e) {
					e.printStackTrace();
				}

			}

		}

		
		if (data == null)
			return;

		super.onActivityResult(requestCode, resultCode, data);
	}
	
	
	
	private void record(){
		
		mediaRecorder = new MediaRecorder();
		try{
			mediaRecorder.setAudioSource(MediaRecorder.AudioSource.MIC);
			mediaRecorder
					.setOutputFormat(MediaRecorder.OutputFormat.DEFAULT);
			mediaRecorder
					.setAudioEncoder(MediaRecorder.AudioEncoder.DEFAULT);
			mediaRecorder.setOutputFile(ClippingSounds.saveSounds());
			mediaRecorder.prepare();
			mediaRecorder.start();
		}catch(Exception e){
			e.printStackTrace();
		}

	}
	
	

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {

		if (keyCode == KeyEvent.KEYCODE_BACK) {
			
				TalkMessageAct.this.finish();
			
		}

		return super.onKeyDown(keyCode, event);
	}


	class ButtonListener implements OnTouchListener {
		
		public boolean onTouch(View v, MotionEvent event) {

			if (v.getId() == R.id.talk_message_record) {
				
				switch(event.getAction()){
				case MotionEvent.ACTION_DOWN:
					voiceDialog.show();
					record();
					break;
				case MotionEvent.ACTION_UP:
					mediaRecorder.stop();
					mediaRecorder.release();
					voiceDialog.cancel();
					
					mHandler.sendEmptyMessage(8);
					
					break;
				}
				
				
				
			}
			return false;
		}
	}


	private LocationListener mLocationListener = null;
	
	@Override
	protected void onPause() {
		BMapApiDemoApp app = (BMapApiDemoApp)this.getApplication();
		// �Ƴ�listener
		app.mBMapMan.getLocationManager().removeUpdates(mLocationListener);
		app.mBMapMan.stop();
		super.onPause();
	}
	
	@Override
	protected void onResume() {
		
		super.onResume();
	}
	

	@Override
	protected boolean isRouteDisplayed() {
		return false;
	}

}
