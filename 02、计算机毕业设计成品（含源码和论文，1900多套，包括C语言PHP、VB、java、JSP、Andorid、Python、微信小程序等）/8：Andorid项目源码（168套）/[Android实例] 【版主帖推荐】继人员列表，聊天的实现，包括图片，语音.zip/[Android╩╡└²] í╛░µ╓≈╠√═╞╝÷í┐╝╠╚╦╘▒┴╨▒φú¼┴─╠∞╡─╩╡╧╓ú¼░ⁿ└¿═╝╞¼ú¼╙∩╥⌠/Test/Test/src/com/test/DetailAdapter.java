package com.test;

import java.util.List;

import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;


public class DetailAdapter extends BaseAdapter {

	private Context ctx;

	private List<DetailEntity> entitys;
	
	private DetailEntity entity;

	private TextView tvName;
	private TextView tvDate;
	private TextView tvText;
	private TextView time;
	private ImageView userImage;
	private Button voiceBtn;
	private Button locationBtn;

	private Bitmap bmpDefaultPics;

	private View view;

	private ImageView talkImage;

	private SmileyParser parser;

	private ImageView talkImages;
	
	public static boolean isClick = false;
	
	private List<DetailEntity> messageList;


	public DetailAdapter(Context context, List<DetailEntity> entitys,String TFuid) {
		ctx = context;
		this.entitys = entitys;
		messageList = MessageSQLService.getInstance(context).getdatas(
				Integer.valueOf(UserInfomation.getUserID(ctx)),
				Integer.valueOf(TFuid));

	}

	@Override
	public int getCount() {
		return entitys.size();
	}

	@Override
	public Object getItem(int position) {
		return position;
	}

	@Override
	public long getItemId(int position) {
		return position;
	}

	@Override
	public View getView(final int position, View convertView, ViewGroup parent) {
		
		entity = entitys.get(position);

		int itemLayout = entity.getLayoutID();
		
		if("".equals(entity.getText())){
			view = LayoutInflater.from(ctx).inflate(R.layout.list_say_null, null);
			return view;
		}
		

		
		switch(itemLayout){
		case R.layout.list_say_me_item:
			view = LayoutInflater.from(ctx).inflate(itemLayout, null);
			tvText = (TextView) view.findViewById(R.id.messagedetail_row_text);
			SmileyParser.init(ctx);
			parser = SmileyParser.getInstance();
			tvText.setText(parser.addSmileySpans(entity.getTtmContent()));
			
			
			break;
		case R.layout.list_say_he_item:
			view = LayoutInflater.from(ctx).inflate(itemLayout, null);
			tvText = (TextView) view.findViewById(R.id.messagedetail_row_text);
			SmileyParser.init(ctx);
			parser = SmileyParser.getInstance();
			tvText.setText(parser.addSmileySpans(entity.getTtmContent()));
			
			break;	
		case R.layout.list_say_me_image:
			
			view = LayoutInflater.from(ctx).inflate(itemLayout, null);
			talkImage = (ImageView) view.findViewById(R.id.messagegedetail_image);
			
			bmpDefaultPics = BitmapFactory.decodeFile(ClippingPicture.TALK_FILES2+entity.getTtmContent());
			talkImage.setImageBitmap(bmpDefaultPics);
			
			talkImage.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					
					if("".equals(messageList.get(position).getTtmContent())){
						Toast.makeText(ctx, "ͼƬ�����ڻ���ɾ��", 300).show();
					}else{
						Intent intent = new Intent(ctx,TalkMessageImageView.class);
						intent.putExtra("name", messageList.get(position).getTtmContent());
						ctx.startActivity(intent);
					}

				}
			});
			
			break;
		case R.layout.list_say_he_image:
			
			view = LayoutInflater.from(ctx).inflate(itemLayout, null);
			talkImage = (ImageView)view.findViewById(R.id.messagegedetail_images);
			
			
			bmpDefaultPics = BitmapFactory.decodeFile(ClippingPicture.TALK_FILES2+entity.getTtmContent());
			talkImage.setImageBitmap(bmpDefaultPics);
			
			talkImage.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					
					if("".equals(messageList.get(position).getTtmContent())){
						Toast.makeText(ctx, "ͼƬ�����ڻ���ɾ��", 300).show();
					}else{
						Intent intent = new Intent(ctx,TalkMessageImageView.class);
						intent.putExtra("name", messageList.get(position).getTtmContent());
						ctx.startActivity(intent);
					}

				}
			});
			
			break;
		case R.layout.list_say_me_voice:
			
			view = LayoutInflater.from(ctx).inflate(itemLayout, null);
			
			voiceBtn = (Button)view.findViewById(R.id.talkmessage_voice);
			
			voiceBtn.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					final MediaPlayer mediaPlayer;
					try{
						
						mediaPlayer = new MediaPlayer();
						mediaPlayer.setDataSource(ClippingSounds.TALKSOUND_FILE+messageList.get(position).getTtmContent());
						mediaPlayer.prepare();
						mediaPlayer.start();
						
						
						mediaPlayer
								.setOnCompletionListener(new OnCompletionListener() {
									@Override
									public void onCompletion(MediaPlayer mp) {
										mediaPlayer.release();
									}
								});
					}catch(Exception e){
						e.printStackTrace();
					}
					
				}
			});
			
			break;
		case R.layout.list_say_he_voice:
			
			view = LayoutInflater.from(ctx).inflate(itemLayout, null);
			
			voiceBtn = (Button)view.findViewById(R.id.talkmessage_voice);
			
			voiceBtn.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					final MediaPlayer mediaPlayer;
					try{
						mediaPlayer = new MediaPlayer();
						mediaPlayer.setDataSource(ClippingSounds.TALKSOUND_FILE+messageList.get(position).getTtmContent());
						mediaPlayer.prepare();
						mediaPlayer.start();
						
						mediaPlayer
								.setOnCompletionListener(new OnCompletionListener() {
									@Override
									public void onCompletion(MediaPlayer mp) {
										mediaPlayer.release();
									}
								});
					}catch(Exception e){
						e.printStackTrace();
					}
					
				}
			});
			
			break;
		case R.layout.list_say_me_location:
			
			view = LayoutInflater.from(ctx).inflate(itemLayout, null);
			
			locationBtn = (Button)view.findViewById(R.id.messagegedetail_location);
			
			final String[] location = entity.getTtmContent().split(",");
			
			locationBtn.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					
					Intent intentss = new Intent(ctx,PersonnelLocation.class);
					intentss.putExtra("Lon", location[1]);
					intentss.putExtra("Lat", location[0]);
					ctx.startActivity(intentss);
				}
			});
			
			break;
		case R.layout.list_say_he_location:
			
			view = LayoutInflater.from(ctx).inflate(itemLayout, null);
			
			locationBtn = (Button)view.findViewById(R.id.messagegedetail_location);
			
			final String[] locationsx = entity.getTtmContent().split(",");
			
			locationBtn.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					
					Intent intentss = new Intent(ctx,PersonnelLocation.class);
					intentss.putExtra("Lon", locationsx[1]);
					intentss.putExtra("Lat", locationsx[0]);
					ctx.startActivity(intentss);
				}
			});
			
			break;
			
		}
		
		time = (TextView)view.findViewById(R.id.talk_time);
		time.setText(entity.getTtmTime());
		
		userImage = (ImageView)view.findViewById(R.id.messagegedetail_rov_icon);

		return view;
	}

	
}
