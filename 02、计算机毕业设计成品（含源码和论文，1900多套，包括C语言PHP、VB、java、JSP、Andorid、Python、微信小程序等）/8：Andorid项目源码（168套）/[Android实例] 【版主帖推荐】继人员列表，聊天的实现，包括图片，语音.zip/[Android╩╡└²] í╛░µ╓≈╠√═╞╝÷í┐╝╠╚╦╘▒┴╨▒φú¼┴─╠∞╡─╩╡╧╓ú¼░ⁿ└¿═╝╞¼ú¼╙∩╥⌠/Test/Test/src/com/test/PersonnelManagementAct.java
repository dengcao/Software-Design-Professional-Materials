package com.test;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;

import org.json.JSONArray;
import org.json.JSONObject;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ExpandableListView;
import android.widget.ExpandableListView.OnGroupClickListener;
import android.widget.ExpandableListView.OnGroupExpandListener;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;
import android.widget.Toast;

public class PersonnelManagementAct extends Activity  implements OnClickListener{
	
	private Button signinButton;
	private ImageView photoImage;
	
	private EditText searchEdit;
	
	private TextView nameText;
	
	private String json;
	
	private String[] result;
	
	private ManagementListView exList;
	
	private int index;
	
	private List<Department> depList;
	private List<Department> depLists;
	private List<List<Personnel>> childUser;
	private String[] depID;
	
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.personnelmanagement);
        
        signinButton = (Button)findViewById(R.id.personnelmanagement_signin);
        photoImage = (ImageView)findViewById(R.id.personnelmanagement_photo);
        
        searchEdit = (EditText)findViewById(R.id.personnelmanagement_searchedit);
        searchEdit.setOnClickListener(this);
        
        signinButton.setOnClickListener(this);
        photoImage.setOnClickListener(this);
        
        
        exList = (ManagementListView)findViewById(R.id.personnelmanagement_expandableListView);
        exList.setHeaderView(getLayoutInflater().inflate(R.layout.group_header,exList,false));
        
        nameText = (TextView)findViewById(R.id.personnelmanagement_name);
        nameText.setText("eoe");
        
        depList = new ArrayList<Department>();
			
        depList.add(new Department("1", "EOE", "7"));
        depList.add(new Department("2", "����", "8"));
        depList.add(new Department("3", "���ڿ���", "9"));
        depList.add(new Department("4", "����������", "10"));
        depList.add(new Department("5", "����Ա", "11"));
        depList.add(new Department("5", "�����г�", "11"));
        
        childUser = new ArrayList<List<Personnel>>();
        
        
                
             List<Personnel> p1 = new ArrayList<Personnel>();
             p1.add(new Personnel("1", "dota", "xxx", "15800000000", "1", 1));
             p1.add(new Personnel("1", "D3", "xxx", "15800000000", "1", 1));
             p1.add(new Personnel("1", "wow", "xxx", "15800000000", "1", 1));
             
             
             List<Personnel> p2 = new ArrayList<Personnel>();
             p2.add(new Personnel("2", "���ŵ���", "xxx", "15800000000", "1", 1));
             p2.add(new Personnel("2", "ͼ��ר��", "xxx", "15800000000", "1", 1));
             p2.add(new Personnel("2", "�˲���Ƭ", "xxx", "15800000000", "1", 1));
             p2.add(new Personnel("2", "ɳ���", "xxx", "15800000000", "1", 1));
             p2.add(new Personnel("2", "�����г�", "xxx", "15800000000", "1", 1));
             
             List<Personnel> p3 = new ArrayList<Personnel>();
             p3.add(new Personnel("3", "ʵ���̳�", "xxx", "15800000000", "1", 1));
             p3.add(new Personnel("3", "����ֿ�", "xxx", "15800000000", "1", 1));
             p3.add(new Personnel("3", "Դ���о�", "xxx", "15800000000", "1", 1));
             p3.add(new Personnel("3", "�ײ㿪��", "xxx", "15800000000", "1", 1));
             p3.add(new Personnel("3", "��Ϸ����", "xxx", "15800000000", "1", 1));
             
             List<Personnel> p4 = new ArrayList<Personnel>();
             p4.add(new Personnel("4", "���Ϲ���", "xxx", "15800000000", "1", 1));
             p4.add(new Personnel("4", "eoe�ؿ�", "xxx", "15800000000", "1", 1));
             
             List<Personnel> p5 = new ArrayList<Personnel>();
             p5.add(new Personnel("5", "��Ϸ����", "xxx", "15800000000", "1", 1));
             p5.add(new Personnel("5", "����̽��", "xxx", "15800000000", "1", 1));
             p5.add(new Personnel("5", "Դ���о�", "xxx", "15800000000", "1", 1));
             p5.add(new Personnel("5", "wow", "xxx", "15800000000", "1", 1));
             p5.add(new Personnel("5", "SDK", "xxx", "15800000000", "1", 1));
             
             
             List<Personnel> p6 = new ArrayList<Personnel>();
             p6.add(new Personnel("6", "�����߷���", "xxx", "15800000000", "1", 1));
             p6.add(new Personnel("6", "Framework", "xxx", "15800000000", "1", 1));
             p6.add(new Personnel("6", "Դ���о�", "xxx", "15800000000", "1", 1));
             p6.add(new Personnel("6", "������Ѷ", "xxx", "15800000000", "1", 1));
             p6.add(new Personnel("6", "��Ϸ�㷨", "xxx", "15800000000", "1", 1));
             p6.add(new Personnel("6", "��������", "xxx", "15800000000", "1", 1));
             
            
             childUser.add(p1);
             childUser.add(p2);
             childUser.add(p3);
             childUser.add(p4);
             childUser.add(p5);
             childUser.add(p6);
        
           
            ManagementAdapter adapter = new ManagementAdapter(PersonnelManagementAct.this, exList, depList, childUser);
            exList.setAdapter(adapter);
            exList.setVisibility(View.VISIBLE);
        
    }
    
    

	@Override
	public void onClick(View v) {
		
		switch(v.getId()){
		case R.id.personnelmanagement_signin:
			initPopupWindow(PersonnelManagementAct.this, signinButton);
			break;
		case R.id.personnelmanagement_photo:
			startActivity(new Intent(PersonnelManagementAct.this, PersonalInfomation.class));
			break;
		case R.id.personnelmanagement_searchedit:
			startActivity(new Intent(PersonnelManagementAct.this,SearchPernonnel.class));
			overridePendingTransition(android.R.anim.fade_in,
					android.R.anim.fade_out);
			break;
		}
	}
	
	
	

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		
		if(keyCode == KeyEvent.KEYCODE_BACK){
			
		}
		return super.onKeyDown(keyCode, event);
	}
	
	
	@Override
	public boolean onCreateOptionsMenu(Menu menu) {

		menu.add(2, 2, 2, "�л��û�");
		menu.add(3, 3, 3, "�˳�");

		return super.onCreateOptionsMenu(menu);
	}

	@Override
	public boolean onMenuItemSelected(int featureId, MenuItem item) {

		switch (item.getItemId()) {
		case 1:
			break;
		case 2:
			break;
		case 3:
			break;
		}

		return super.onMenuItemSelected(featureId, item);
	}
	
	
	

	private void initPopupWindow(final Context context,View x){
	
	    View view = LayoutInflater.from(context).inflate(R.layout.personnel_administration, null);
	        
		final PopupWindow mPopupWindow = new PopupWindow(view, 120,LayoutParams.WRAP_CONTENT);
	//	mPopupWindow.setBackgroundDrawable(new BitmapDrawable());//��������background������ʧ
		mPopupWindow.setBackgroundDrawable(context.getResources().getDrawable(R.color.back));
		mPopupWindow.setOutsideTouchable(true);
		
		mPopupWindow.setAnimationStyle(android.R.style.Animation_Dialog);
		mPopupWindow.update();
		mPopupWindow.setTouchable(true);
		mPopupWindow.setFocusable(true);
		
	   
		if(!mPopupWindow.isShowing()){
			mPopupWindow.showAsDropDown(x, -40, 0);    
		}
		
		Button signin = (Button)view.findViewById(R.id.administration_function_signin);
		signin.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
			}
		});
	
	}
	
}