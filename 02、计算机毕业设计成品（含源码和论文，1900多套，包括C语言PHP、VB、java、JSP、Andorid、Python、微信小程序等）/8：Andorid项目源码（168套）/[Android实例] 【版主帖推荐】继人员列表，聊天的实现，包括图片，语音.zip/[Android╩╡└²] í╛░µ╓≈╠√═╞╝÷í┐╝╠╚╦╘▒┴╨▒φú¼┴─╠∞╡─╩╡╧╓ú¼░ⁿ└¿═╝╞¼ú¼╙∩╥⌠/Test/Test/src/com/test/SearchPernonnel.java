package com.test;

import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;

public class SearchPernonnel extends Activity {
	
	private EditText searchEdit;
	
	private ListView personnelList;
	
	private TextView resultText;
	
	private List<Personnel> pern;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.searchpernonnel);
		
		searchEdit = (EditText)findViewById(R.id.searchpersonnel_searchedit);
		
		personnelList = (ListView)findViewById(R.id.searchpersonnel_list);
		
		resultText = (TextView)findViewById(R.id.searchpersonnel_nulltext);
		
		searchEdit.addTextChangedListener(new TextWatcher() {
			
			@Override
			public void onTextChanged(CharSequence s, int start, int before, int count) {
				
			}
			
			@Override
			public void beforeTextChanged(CharSequence s, int start, int count,
					int after) {
				
			}
			
			@Override
			public void afterTextChanged(Editable s) {
				
				if(TextUtils.isEmpty(searchEdit.getText())){
					mHandler.sendEmptyMessage(2);
				}else{
					mHandler.sendEmptyMessage(1);
				}
				
			}
		});
		
	}
	
	

	
	
	private Handler mHandler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch(msg.what){
			case 1:
					
					personnelList.setAdapter(new SearchListAdapter(SearchPernonnel.this, pern));
				
				break;
			case 2:
				personnelList.setVisibility(View.GONE);
				resultText.setVisibility(View.VISIBLE);
				
				break;
			}
		}
		
		
	};
	
	
	
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		
		if(keyCode == KeyEvent.KEYCODE_BACK){
			SearchPernonnel.this.finish();
		}
		
		return super.onKeyDown(keyCode, event);
	}



	class SearchListAdapter extends BaseAdapter{
		
		private Context context;
		private List<Personnel> pern;
		
		public SearchListAdapter(Context context,List<Personnel> pern){
			
			this.context = context;
			this.pern = pern;
		}

		@Override
		public int getCount() {
			return 5;
		}

		@Override
		public Object getItem(int position) {
			return position;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(final int position, View convertView, ViewGroup parent) {
			
			View view = LayoutInflater.from(context).inflate(R.layout.searchpersonnel_list_context, null);
			
			TextView name = (TextView)view.findViewById(R.id.searchpersonnel_list_context_name);
			ImageView photo = (ImageView)view.findViewById(R.id.searchpersonnel_list_context_photo);
			
			final Button btn = (Button)view.findViewById(R.id.searchpersonnel_list_context_btn);
			btn.setOnClickListener(new OnClickListener() {
				
				@Override
				public void onClick(View v) {
					
					initPopupWindow(context,btn,
							"15800000000",
							"xx",
							"1");
				}
			});
			
			return view;
		}
		
		
	}
	
	
	
	private void initPopupWindow(final Context context,View x, String phoneNum,
			final String name,final String id){
	
	    View view = LayoutInflater.from(context).inflate(R.layout.management_function, null);
	        
		PopupWindow mPopupWindow = new PopupWindow(view, LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT);
	//	mPopupWindow.setBackgroundDrawable(new BitmapDrawable());//��������background������ʧ
		mPopupWindow.setBackgroundDrawable(context.getResources().getDrawable(R.color.back));
		mPopupWindow.setOutsideTouchable(true);
		
		mPopupWindow.setAnimationStyle(android.R.style.Animation_Dialog);
		mPopupWindow.update();
		mPopupWindow.setTouchable(true);
		mPopupWindow.setFocusable(true);
		
	   
		if(!mPopupWindow.isShowing()){
			mPopupWindow.showAsDropDown(x, 0, 0);    
		}
		
		Button phone = (Button)view.findViewById(R.id.management_function_phone);
		Button message = (Button)view.findViewById(R.id.management_function_message);
		Button personnelinfomation = (Button)view.findViewById(R.id.management_function_personnelinfomation);
		Button talk = (Button)view.findViewById(R.id.management_function_talk);
		
		final String tel = phoneNum;
		
		phone.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
	
					Uri uri = Uri.parse("tel:"+tel);
					Intent it = new Intent(Intent.ACTION_DIAL, uri);
					context.startActivity(it);
				
			}
		});
		
		message.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
					Uri uri = Uri.parse("smsto:"+tel);
					Intent it = new Intent(Intent.ACTION_SENDTO, uri);
					context.startActivity(it);
			}
		});
		
		personnelinfomation.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
			}
		});
		
		talk.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
			}
		});

	
	}

	
}
