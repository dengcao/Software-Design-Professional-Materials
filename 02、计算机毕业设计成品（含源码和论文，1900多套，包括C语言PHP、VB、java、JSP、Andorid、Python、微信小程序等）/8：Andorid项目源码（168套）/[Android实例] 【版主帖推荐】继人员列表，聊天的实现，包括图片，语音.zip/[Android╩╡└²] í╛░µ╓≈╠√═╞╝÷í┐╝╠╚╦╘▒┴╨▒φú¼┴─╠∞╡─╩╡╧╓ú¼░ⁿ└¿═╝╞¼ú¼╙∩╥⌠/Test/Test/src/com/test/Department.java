package com.test;

public class Department {
	
	private String userID;
	
	private String TDtPID;
	private String TDtName;
	private String TDtID;
	
	public Department(){
		
	}
	
	public Department(String TDtID,String TDtName,String TDtPID){
		
		this.TDtID = TDtID;
		this.TDtPID = TDtPID;
		this.TDtName = TDtName;
		
	}
	
	public Department(String TDtID,String TDtName,String TDtPID,String userID){
		
		this.TDtID = TDtID;
		this.TDtPID = TDtPID;
		this.TDtName = TDtName;
		this.userID = userID;
	}
	

	public String getTDtPID() {
		return TDtPID;
	}
	public void setTDtPID(String tDtPID) {
		TDtPID = tDtPID;
	}
	public String getTDtName() {
		return TDtName;
	}
	public void setTDtName(String tDtName) {
		TDtName = tDtName;
	}
	public String getTDtID() {
		return TDtID;
	}
	public void setTDtID(String tDtID) {
		TDtID = tDtID;
	}
	public String getUserID() {
		return userID;
	}
	public void setUserID(String userID) {
		this.userID = userID;
	}

}
