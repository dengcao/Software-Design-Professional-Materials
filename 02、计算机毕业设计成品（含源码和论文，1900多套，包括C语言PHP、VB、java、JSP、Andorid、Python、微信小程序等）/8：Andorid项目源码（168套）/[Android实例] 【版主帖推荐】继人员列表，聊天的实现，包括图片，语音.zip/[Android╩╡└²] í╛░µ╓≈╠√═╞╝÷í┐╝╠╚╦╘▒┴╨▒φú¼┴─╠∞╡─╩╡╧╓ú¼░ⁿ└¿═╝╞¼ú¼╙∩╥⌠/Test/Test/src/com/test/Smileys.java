package com.test;


public class Smileys {
	private static final int[] sIconIds = { R.drawable.f000, R.drawable.f001,
		R.drawable.f002, R.drawable.f003, R.drawable.f004, R.drawable.f005,
		R.drawable.f006, R.drawable.f007, R.drawable.f008, R.drawable.f009,
		R.drawable.f010, R.drawable.f011, R.drawable.f012, R.drawable.f013,
		R.drawable.f014, R.drawable.f015, R.drawable.f016, R.drawable.f017,
		R.drawable.f018, R.drawable.f019, R.drawable.f020, R.drawable.f021,
		R.drawable.f022, R.drawable.f023, R.drawable.f024, R.drawable.f025,
		R.drawable.f026, R.drawable.f027, R.drawable.f028, R.drawable.f029,
		R.drawable.f030, R.drawable.f031, R.drawable.f032, R.drawable.f033,
		R.drawable.f034, R.drawable.f035, R.drawable.f036, R.drawable.f037,
		R.drawable.f038, R.drawable.f039, R.drawable.f040, R.drawable.f041,
		R.drawable.f042, R.drawable.f043, R.drawable.f044, R.drawable.f045,
		R.drawable.f046, R.drawable.f047, R.drawable.f048, R.drawable.f049,
		R.drawable.f050, R.drawable.f051, R.drawable.f052, R.drawable.f053,
		R.drawable.f054, R.drawable.f044, R.drawable.f056, R.drawable.f057,
		R.drawable.f058, R.drawable.f059, R.drawable.f060, R.drawable.f061,
		R.drawable.f062, R.drawable.f063, R.drawable.f064, R.drawable.f065,
		R.drawable.f066, R.drawable.f067, R.drawable.f068, R.drawable.f069,
		R.drawable.f070, R.drawable.f071, R.drawable.f072, R.drawable.f073 };

	{
	};
	public static int HEART = 0;
	public static int ROSE = 1;
	public static int SURPRISED = 2;
	public static int PIG = 3;
	public static int CLAP = 4;
	public static int YE = 5;
	public static int PITIFUL = 6;
	public static int LUCKY = 7;
	public static int WINK = 8;
	public static int ANGRY = 9;
	public static int DIZZY = 10;
	public static int PARENT = 11;
	public static int SERIOUS = 12;
	public static int DOZE = 13;
	public static int SWEAT = 14;
	public static int HAPPY = 15;
	public static int CRY = 16;
	public static int DOUBT = 17;
	public static int HEART1 = 18;
	public static int ROSE1 = 19;
	public static int SURPRISED1 = 20;
	public static int PIG1 = 21;
	public static int CLAP1 = 22;
	public static int YE1 = 23;
	public static int PITIFUL1 = 24;
	public static int LUCKY1 = 25;
	public static int WINK1 = 26;
	public static int ANGRY1 = 27;
	public static int DIZZY1 = 28;
	public static int PARENT1 = 29;
	public static int SERIOUS1 = 30;
	public static int DOZE1 = 31;
	public static int SWEAT1 = 32;
	public static int HAPPY1 = 33;
	public static int CRY1 = 34;
	public static int DOUBT1 = 35;
	public static int HEART2 = 36;
	public static int ROSE2 = 37;
	public static int SURPRISED2 = 38;
	public static int PIG2 = 39;
	public static int CLAP2 = 40;
	public static int YE2 = 41;
	public static int PITIFUL2 = 42;
	public static int LUCKY2 = 43;
	public static int WINK2 = 44;
	public static int ANGRY2 = 45;
	public static int DIZZY2 = 46;
	public static int PARENT2 = 47;
	public static int SERIOUS2 = 48;
	public static int DOZE2 = 49;
	public static int SWEAT2 = 50;
	public static int HAPPY2 = 51;
	public static int CRY2 = 52;
	public static int DOUBT2 = 53;
	public static int HEART3 = 54;
	public static int ROSE3 = 55;
	public static int SURPRISED3 = 56;
	public static int PIG3 = 57;
	public static int CLAP3 = 58;
	public static int YE3 = 59;
	public static int PITIFUL3 = 60;
	public static int LUCKY3 = 61;
	public static int WINK3 = 62;
	public static int ANGRY3 = 63;
	public static int DIZZY3 = 64;
	public static int PARENT3 = 65;
	public static int SERIOUS3 = 66;
	public static int DOZE3 = 67;
	public static int SWEAT3 = 68;
	public static int HAPPY3 = 69;
	public static int CRY3 = 70;
	public static int DOUBT3 = 71;
	public static int CRY4 = 72;
	public static int DOUBT4 = 73;

	public static int getSmileyResource(int which) {
		return sIconIds[which];
	}
}
