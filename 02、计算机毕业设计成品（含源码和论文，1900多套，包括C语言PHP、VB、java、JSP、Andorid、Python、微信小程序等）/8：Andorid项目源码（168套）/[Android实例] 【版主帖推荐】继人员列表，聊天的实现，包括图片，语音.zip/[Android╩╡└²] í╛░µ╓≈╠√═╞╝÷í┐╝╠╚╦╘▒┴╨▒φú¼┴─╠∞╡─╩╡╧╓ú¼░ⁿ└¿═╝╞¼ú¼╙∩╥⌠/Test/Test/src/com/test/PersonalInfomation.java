package com.test;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup.LayoutParams;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.TextView;


public class PersonalInfomation extends Activity implements OnClickListener{
	
	private ListView infomationList;
	private Button commintButton;
	
	private String[] title = { "�ǳ�", "�ֻ�����", "�Ա�", "����", "ְҵ", "ѧ��",
			"ѧУ", "����", "QQ", "����", "����", "���" };
	
	
	private SharedPreferences infomationSPreferences;
	private List<String> contentList;
	
	
	private TextView nameText;
	private TextView phoneText;
	
	private ImageView photoImage;
	
	private Button backButton;

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.personal_information);
		
		infomationList = (ListView)findViewById(R.id.personal_infomation_list);
		infomationList.setAdapter(new InfomationListAdapter(this,title));
		
		commintButton = (Button)findViewById(R.id.personal_infomation_commit);
		commintButton.setOnClickListener(this);
		
		nameText = (TextView)findViewById(R.id.personal_name);
		phoneText = (TextView)findViewById(R.id.personal_telephone);
		
		backButton = (Button)findViewById(R.id.personal_infomation_back);
		backButton.setOnClickListener(this);
		
		photoImage = (ImageView)findViewById(R.id.personal_photo);
		
		infomationSPreferences = this.getSharedPreferences("userinfo", Context.MODE_PRIVATE);
		contentList = new ArrayList<String>();
		
		
		nameText.setText(infomationSPreferences.getString("name", ""));
		phoneText.setText(infomationSPreferences.getString("telphone", ""));
	}
	
	 
	
	class InfomationListAdapter extends BaseAdapter{
		
		private Context context;
		private String[] titles;
		
		public InfomationListAdapter(Context context,String[] titles){
			
			this.context = context;
			this.titles = titles;
		}

		@Override
		public int getCount() {
			return titles.length;
		}

		@Override
		public Object getItem(int position) {
			return position;
		}

		@Override
		public long getItemId(int position) {
			return position;
		}

		@Override
		public View getView(int position, View convertView, ViewGroup parent) {
			
			View view = LayoutInflater.from(context).inflate(R.layout.personal_information_lis_context,null);
			
			TextView title = (TextView)view.findViewById(R.id.personalinformation_list_context_title);
			title.setText(titles[position]);
			
			TextView content = (TextView)view.findViewById(R.id.personalinformation_list_context_content);
			
			return view;
		}
		
	}



	@Override
	public void onClick(View v) {
		
		switch(v.getId()){
		case R.id.personal_infomation_commit:
			initPopupWindow(PersonalInfomation.this, commintButton);
			break;
		case R.id.personal_infomation_back:
			PersonalInfomation.this.finish();
			break;
		}
	}
	
	
	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		
		if(keyCode == KeyEvent.KEYCODE_BACK){
			
			PersonalInfomation.this.finish();
		}
		
		return super.onKeyDown(keyCode, event);
	}
	
	
	private void initPopupWindow(final Context context,View x){
		
	    View view = LayoutInflater.from(context).inflate(R.layout.personnel_administration, null);
	        
		final PopupWindow mPopupWindow = new PopupWindow(view, 120,LayoutParams.WRAP_CONTENT);
	//	mPopupWindow.setBackgroundDrawable(new BitmapDrawable());//��������background������ʧ
		mPopupWindow.setBackgroundDrawable(context.getResources().getDrawable(R.color.back));
		mPopupWindow.setOutsideTouchable(true);
		
		mPopupWindow.setAnimationStyle(android.R.style.Animation_Dialog);
		mPopupWindow.update();
		mPopupWindow.setTouchable(true);
		mPopupWindow.setFocusable(true);
		
	   
		if(!mPopupWindow.isShowing()){
			mPopupWindow.showAsDropDown(x, -40, 0);    
		}
		
		Button signin = (Button)view.findViewById(R.id.administration_function_signin);
		signin.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
			}
		});
	
	}

	
}
