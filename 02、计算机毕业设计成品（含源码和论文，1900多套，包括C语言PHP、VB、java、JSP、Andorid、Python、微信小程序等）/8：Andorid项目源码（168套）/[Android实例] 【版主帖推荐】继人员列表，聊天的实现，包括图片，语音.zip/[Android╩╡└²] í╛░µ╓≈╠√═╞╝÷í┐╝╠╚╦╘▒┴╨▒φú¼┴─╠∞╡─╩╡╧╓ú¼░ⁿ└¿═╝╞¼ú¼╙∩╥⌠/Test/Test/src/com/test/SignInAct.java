package com.test;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.text.TextUtils;
import android.text.method.HideReturnsTransformationMethod;
import android.text.method.PasswordTransformationMethod;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.Toast;


public class SignInAct extends Activity implements OnCheckedChangeListener,OnClickListener {

	private Button commitButton; // ��¼

	private EditText companyEdit; // �ʺű༭��
	private EditText usernameEdit; // �ʺű༭��
	private EditText passwordEdit; // ����༭��

	private CheckBox showPasswordCheck; // ��ʾ����
	private CheckBox rememberPasswordCheck; // ��������

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.signinact);
		
		commitButton = (Button) findViewById(R.id.signinact_commit);
		commitButton.setOnClickListener(this);

		companyEdit = (EditText) findViewById(R.id.signinact_companynumber);
		usernameEdit = (EditText) findViewById(R.id.signinact_username);
		passwordEdit = (EditText) findViewById(R.id.signinact_password);

		showPasswordCheck = (CheckBox) findViewById(R.id.signinact_showpassword);
		rememberPasswordCheck = (CheckBox) findViewById(R.id.signinact_rememberpassword);

		showPasswordCheck.setOnCheckedChangeListener(this);
		rememberPasswordCheck.setOnCheckedChangeListener(this);
		
	}
	
	
	public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {

		switch (buttonView.getId()) {

		case R.id.signinact_showpassword:
			if (isChecked) {
				passwordEdit
						.setTransformationMethod(HideReturnsTransformationMethod
								.getInstance());
			} else {
				passwordEdit
						.setTransformationMethod(PasswordTransformationMethod
								.getInstance());
			}
			break;
		case R.id.signinact_rememberpassword:
			break;

		}

	}


	@Override
	public void onClick(View v) {

		switch (v.getId()) {

		case R.id.signinact_commit:
			if (TextUtils.isEmpty(companyEdit.getText())) {
				Toast.makeText(SignInAct.this, "��������ҵ���", 300).show();
			} else if (TextUtils.isEmpty(usernameEdit.getText())) {
				Toast.makeText(SignInAct.this, "�������û���", 300).show();
			}else if(TextUtils.isEmpty(passwordEdit.getText())){ 
				Toast.makeText(SignInAct.this, "����������", 300).show();
			}else {
				mHandler.sendEmptyMessage(1);
			}
			
			break;
		}
	}
	
	
	private Handler mHandler = new Handler(){

		@Override
		public void handleMessage(Message msg) {
			super.handleMessage(msg);
			switch(msg.what){
			case 1:
				startActivity(new Intent(SignInAct.this, PersonnelManagementAct.class));
				SignInAct.this.finish();
				break;
			case 2:
				break;
			case 3:
				break;
			}
		}
		
		
	};

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		
		if(keyCode == KeyEvent.KEYCODE_BACK){
			
			SignInAct.this.finish();
		}
		
		return super.onKeyDown(keyCode, event);
	}
	
	
}