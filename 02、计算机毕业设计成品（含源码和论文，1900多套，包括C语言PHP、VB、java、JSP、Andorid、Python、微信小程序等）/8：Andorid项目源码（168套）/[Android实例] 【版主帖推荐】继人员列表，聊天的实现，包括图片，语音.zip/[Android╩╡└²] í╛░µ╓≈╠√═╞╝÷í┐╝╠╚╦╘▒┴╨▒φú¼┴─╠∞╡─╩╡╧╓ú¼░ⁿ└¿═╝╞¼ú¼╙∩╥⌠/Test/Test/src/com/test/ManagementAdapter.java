package com.test;


import java.util.HashMap;
import java.util.List;

import com.test.ManagementListView.QQHeaderAdapter;

import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.ViewGroup;
import android.view.ViewGroup.LayoutParams;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.PopupWindow;
import android.widget.TextView;


public class ManagementAdapter extends BaseExpandableListAdapter implements QQHeaderAdapter {
	
	private ManagementListView listView; 
	private Context context;
	
	private List<Department> groupDep;
	private List<List<Personnel>> childUser;
	
	private HashMap<Integer,Integer> groupStatusMap = new HashMap<Integer, Integer>();
	
	public ManagementAdapter(Context context,ManagementListView listView,
					List<Department> groupDep,List<List<Personnel>> childUser) {
		
				this.context = context;
				this.listView = listView;
				this.groupDep = groupDep;
				this.childUser = childUser;
	}


	@Override
	public int getGroupCount() {
		return groupDep.size();
	}
	
	@Override
	public long getGroupId(int groupPosition) {
		return groupPosition;
	}
	
	@Override
	public Object getGroup(int groupPosition) {
		return groupDep.get(groupPosition);
	}
	
	@Override
	public int getChildrenCount(int groupPosition) {

		return childUser.get(groupPosition).size();
	}
	
	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return childUser.get(groupPosition).get(childPosition);
	}
	
	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}
	
	@Override
	public boolean hasStableIds() {
		return false;
	}
	
	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}
	
	
	@Override
	public int getQQHeaderState(int groupPosition, int childPosition) {
		
		final int childCount = getChildrenCount(groupPosition);
		if(childPosition == childCount - 1){  
			return PINNED_HEADER_PUSHED_UP; 
		}
		else if(childPosition == -1 && !listView.isGroupExpanded(groupPosition)){ 
			return PINNED_HEADER_GONE; 
		}
		else{
			return PINNED_HEADER_VISIBLE;
		}
	}

	@Override
	public void configureQQHeader(View header, int groupPosition,
			int childPosition, int alpha) {
		
//		Map<String,String> groupData = (Map<String,String>)this.getGroup(groupPosition);
		((TextView)header.findViewById(R.id.groupto)).setText(groupDep.get(groupPosition).getTDtName());
		
	}

	@Override
	public void setGroupClickStatus(int groupPosition, int status) {
		
		groupStatusMap.put(groupPosition, status);
	}

	@Override
	public int getGroupClickStatus(int groupPosition) {
		
		if(groupStatusMap.containsKey(groupPosition)){
			return groupStatusMap.get(groupPosition);
		}
		else{
			return 0;
		}
	}
	
	
	@Override
	public View getChildView(final int groupPosition, final int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		
		if(convertView==null){
			convertView = LayoutInflater.from(context).inflate(R.layout.child, null);
		}
		
		final Button btn = (Button)convertView.findViewById(R.id.child_function);
		TextView tv = (TextView)convertView.findViewById(R.id.childto);
		tv.setText(childUser.get(groupPosition).get(childPosition).getName());
		
		btn.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				initPopupWindow(context,btn,R.id.child_function,
						childUser.get(groupPosition).get(childPosition).getTelphone(),
						childUser.get(groupPosition).get(childPosition).getName(),
						childUser.get(groupPosition).get(childPosition).getId());
				
			}
		});
		
		Button function = (Button)convertView.findViewById(R.id.child_btn);
		function.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				initPopupWindow(context,btn,R.id.child_function,
						childUser.get(groupPosition).get(childPosition).getTelphone(),
						childUser.get(groupPosition).get(childPosition).getName(),
						childUser.get(groupPosition).get(childPosition).getId());
			}
		});
		
		
		return convertView;
		
	}


	@Override
	public View getGroupView(final int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		
		if(convertView==null){
			convertView = LayoutInflater.from(context).inflate(R.layout.group, null);
		}
		
		
		ImageView iv = (ImageView)convertView.findViewById(R.id.groupIcon);
		TextView tv = (TextView)convertView.findViewById(R.id.groupto);
		tv.setText(groupDep.get(groupPosition).getTDtName());
		
		if (isExpanded) {
			iv.setImageResource(R.drawable.btn_browser2);
		}
		else{
			iv.setImageResource(R.drawable.btn_browser);
		}
		
		
		return convertView;
	}
	
	
	
	private void initPopupWindow(final Context context,View x,int location, String phoneNum,
				final String name,final String id){
		
	    View view = LayoutInflater.from(context).inflate(R.layout.management_function, null);
	        
		PopupWindow mPopupWindow = new PopupWindow(view, LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT);
//		mPopupWindow.setBackgroundDrawable(new BitmapDrawable());//��������background������ʧ
		mPopupWindow.setBackgroundDrawable(context.getResources().getDrawable(R.color.back));
		mPopupWindow.setOutsideTouchable(true);
		
		mPopupWindow.setAnimationStyle(android.R.style.Animation_Dialog);
		mPopupWindow.update();
		mPopupWindow.setTouchable(true);
		mPopupWindow.setFocusable(true);
		
	   
		if(!mPopupWindow.isShowing()){
			mPopupWindow.showAsDropDown(x, 0, 0);    
		}
		
		Button phone = (Button)view.findViewById(R.id.management_function_phone);
		Button message = (Button)view.findViewById(R.id.management_function_message);
		Button personnelinfomation = (Button)view.findViewById(R.id.management_function_personnelinfomation);
		Button talk = (Button)view.findViewById(R.id.management_function_talk);
		Button signin = (Button)view.findViewById(R.id.management_function_signin);
		
		final String tel = phoneNum;
		
		phone.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {

					Uri uri = Uri.parse("tel:"+tel);
					Intent it = new Intent(Intent.ACTION_DIAL, uri);
					context.startActivity(it);
				
			}
		});
		
		message.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
					Uri uri = Uri.parse("smsto:"+tel);
					Intent it = new Intent(Intent.ACTION_SENDTO, uri);
					context.startActivity(it);
			}
		});
		
		personnelinfomation.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
			}
		});
		
		talk.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
				Intent intent = new Intent(context, TalkMessageAct.class);
				context.startActivity(intent);
			}
		});
		
		signin.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				
			}
		});
		
	}

	
}