package com.test;

import android.content.Context;

public class UserInfomation {

	public static String getUserID(Context context) {
		
		return "1";
	}

}
