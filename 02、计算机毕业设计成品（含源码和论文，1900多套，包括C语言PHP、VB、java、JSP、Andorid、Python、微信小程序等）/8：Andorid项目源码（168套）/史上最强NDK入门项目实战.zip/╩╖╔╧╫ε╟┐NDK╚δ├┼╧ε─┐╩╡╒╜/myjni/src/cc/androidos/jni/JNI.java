package cc.androidos.jni;
/**
 * 
 * <p>
 * The jni class
 * </p>
 * @author Wang Xinfeng
 *
 */
public class JNI {
	public native  void write();
}
