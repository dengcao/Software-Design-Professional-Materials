package cc.androidos.jni;

import android.app.Activity;
import android.os.Bundle;

/**
 * <p>
 * The activity
 * </p>
 * @author Wang XinFeng
 *	
 */
public class JniTest extends Activity {
	
	static{
		System.loadLibrary("myjni");
	}
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        JNI j = new JNI();
        j.write();
    }
}