#include <stdio.h>
#include <stdlib.h>
#include "cc_androidos_jni_JNI.h"
JNIEXPORT void JNICALL Java_cc_androidos_jni_JNI_write
(JNIEnv *e, jobject j) {
	FILE * v = fopen("/sdcard/androidos.cc.txt", "w+");
	fprintf(v, "aaaa");
	fclose(v);
}
