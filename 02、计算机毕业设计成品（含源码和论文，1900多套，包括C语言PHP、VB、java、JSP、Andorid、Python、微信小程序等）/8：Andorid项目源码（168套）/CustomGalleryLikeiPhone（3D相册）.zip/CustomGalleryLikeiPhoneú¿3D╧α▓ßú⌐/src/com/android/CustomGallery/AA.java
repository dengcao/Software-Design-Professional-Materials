package com.android.CustomGallery;

import android.content.Context;
import android.util.AttributeSet;
import android.widget.Gallery;

public class AA extends Gallery {

	public AA(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}
	
	

}
