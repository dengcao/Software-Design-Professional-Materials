/** Automatically generated file. DO NOT MODIFY */
package fengyan.viewpager;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}