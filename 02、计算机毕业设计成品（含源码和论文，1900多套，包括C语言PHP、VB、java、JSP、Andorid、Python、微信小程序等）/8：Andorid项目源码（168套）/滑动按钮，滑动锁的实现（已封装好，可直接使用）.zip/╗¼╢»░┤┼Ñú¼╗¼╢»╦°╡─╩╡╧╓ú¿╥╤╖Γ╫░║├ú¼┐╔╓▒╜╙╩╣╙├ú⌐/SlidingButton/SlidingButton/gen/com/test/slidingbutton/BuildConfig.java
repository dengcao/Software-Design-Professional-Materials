/** Automatically generated file. DO NOT MODIFY */
package com.test.slidingbutton;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}