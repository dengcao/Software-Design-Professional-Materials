package com.chen.weixin.test;

public interface OnViewChangeListener {
	public void OnViewChange(int view);
}
