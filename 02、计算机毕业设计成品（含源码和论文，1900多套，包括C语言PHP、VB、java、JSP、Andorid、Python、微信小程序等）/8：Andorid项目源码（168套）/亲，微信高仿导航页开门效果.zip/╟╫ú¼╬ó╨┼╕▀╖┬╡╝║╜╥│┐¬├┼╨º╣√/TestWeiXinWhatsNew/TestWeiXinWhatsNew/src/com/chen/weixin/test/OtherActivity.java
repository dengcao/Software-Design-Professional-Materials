package com.chen.weixin.test;

import android.app.Activity;
import android.os.Bundle;

public class OtherActivity extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.other);
	}
	
}
