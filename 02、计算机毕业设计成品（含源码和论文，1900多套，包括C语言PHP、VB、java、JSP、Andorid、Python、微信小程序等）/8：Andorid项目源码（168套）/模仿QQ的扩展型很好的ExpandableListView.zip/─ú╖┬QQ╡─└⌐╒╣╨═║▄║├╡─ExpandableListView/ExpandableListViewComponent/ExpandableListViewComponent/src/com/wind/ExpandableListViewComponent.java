package com.wind;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ExpandableListView;

import com.wind.ExpandableListViewAdapter.ListRow;
import com.wind.ExpandableListViewAdapter.RowContent;

public class ExpandableListViewComponent extends Activity {
	
	private ExpandableListView list;
	private ExpandableListViewAdapter adapter;
	
	private List<ListRow> groupList = new ArrayList<ListRow>();
	private List<List<ListRow>> childList = new ArrayList<List<ListRow>>();
	
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        list = (ExpandableListView) findViewById(R.id.listView);
        getData();
        fillInListContent();
    }
    
    public void fillInListContent() {
		if (adapter == null) {
			adapter = new ExpandableListViewAdapter(this, groupList, childList);
			list.setAdapter(adapter);
			list.setGroupIndicator(null);
			list.setDivider(null);
//			list.setOnChildClickListener(childClickListener);
		} else {
			adapter.notifyDataSetChanged();
		}
    }

	@Override
	public void onWindowFocusChanged(boolean hasFocus) {
        if (hasFocus) {
            fillInListContent();
        }
		super.onWindowFocusChanged(hasFocus);
	}
	
	public void getData() {
		
		for(int i = 0; i < 4; i++) {
			
	    	ListRow itemRow = new ListRow();
	        itemRow.setRowType(ConstantUtils.ROW_IN_LIST);
	        itemRow.setLayout_id(R.layout.group_row);
	        itemRow.setSelectable(true);
	        
	        ArrayList<RowContent> rowContents = new ArrayList<RowContent>();
	        RowContent content = new RowContent();
	        content.setLayout_id(R.id.groupText);
	        content.setType(ConstantUtils.TEXT);
	        content.setText("����" + i);
	        rowContents.add(content);
	        
	        content = new RowContent();
	        content.setLayout_id(R.id.expandButtonImage);
	        content.setType(ConstantUtils.EXPAND_IMAGE);
	        rowContents.add(content);
	        
	        itemRow.setRowContents(rowContents);
	        groupList.add(itemRow);
			
	        List<ListRow> rows = new ArrayList<ListRow>();
	        for(int j = 0; j < 5; j++) {
	        	itemRow = new ListRow();
	            itemRow.setRowType(ConstantUtils.ROW_IN_LIST);
	            itemRow.setLayout_id(R.layout.child_row);
	            itemRow.setSelectable(true);
	            
	            rowContents = new ArrayList<RowContent>();
	            content = new RowContent();
	            content.setLayout_id(R.id.checkBox);
	            content.setType(ConstantUtils.CHECK_BOX);
	            rowContents.add(content);
	            
	            content = new RowContent();
	            content.setLayout_id(R.id.childText);
	            content.setType(ConstantUtils.TEXT);
	            content.setText("��Ա" + j);
	            rowContents.add(content);
	            
	            content = new RowContent();
	            content.setLayout_id(R.id.delete);
	            content.setType(ConstantUtils.BUTTON);
	            rowContents.add(content);
	            
	            itemRow.setRowContents(rowContents);
	            rows.add(itemRow);
	        }
	        
	        childList.add(rows);
		}
        
    }
	
//	private ExpandableListView.OnChildClickListener childClickListener = new ExpandableListView.OnChildClickListener() {
//		@Override
//		public boolean onChildClick(ExpandableListView parent, View v,
//				int groupPosition, int childPosition, long id) {
//			Toast.makeText(ExpandableListViewComponent.this,
//					"��ѡ���˵�" + groupPosition + "�����Ա" + childPosition + "��",Toast.LENGTH_SHORT).show();
//			return false;
//		}
//	};
        
}