package com.wind;

import java.util.ArrayList;
import java.util.List;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.DialogInterface;
import android.graphics.Color;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseExpandableListAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.CompoundButton.OnCheckedChangeListener;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class ExpandableListViewAdapter extends BaseExpandableListAdapter {
	
	private Context context;
	private List<ListRow> groupList = new ArrayList<ListRow>();
	private List<List<ListRow>> childList = new ArrayList<List<ListRow>>();
	
	public ExpandableListViewAdapter(Context context, List<ListRow> groupList,
			List<List<ListRow>> childList) {
		this.context = context;
		this.groupList = groupList;
		this.childList = childList;
	}

	@Override
	public Object getChild(int groupPosition, int childPosition) {
		return null;
	}

	@Override
	public long getChildId(int groupPosition, int childPosition) {
		return 0;
	}

	@Override
	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		
		ListRow row = (ListRow) childList.get(groupPosition).get(childPosition);
		ListRowView view = new ListRowView(context, row, groupPosition, childPosition);
		return view;
	}

	@Override
	public int getChildrenCount(int groupPosition) {
		return childList.get(groupPosition).size();
	}

	@Override
	public Object getGroup(int groupPosition) {
		return null;
	}

	@Override
	public int getGroupCount() {
		return groupList.size();
	}

	@Override
	public long getGroupId(int groupPosition) {
		return 0;
	}

	@Override
	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {
		
		ListRow row = (ListRow) groupList.get(groupPosition);
		List<RowContent> viewContents = row.getRowContents();
		for(int i = 0; i < viewContents.size(); i++) {
			RowContent content = viewContents.get(i);
			if(content.getType() == ConstantUtils.EXPAND_IMAGE) {
				if(isExpanded) {
					content.setImage_id(R.drawable.btn_expand2);
				}else {
					content.setImage_id(R.drawable.btn_expand);
				}
			}
		}
		ListRowView view = new ListRowView(context, row, groupPosition, 0);
		return view;
	}

	@Override
	public boolean hasStableIds() {
		return false;
	}

	@Override
	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return false;
	}
	
	
	
	public static class ListRow {

		private int rowType;
		private boolean selectable;
		private int layout_id;
		private boolean isChecked;
		
		private List<RowContent> rowContents = new ArrayList<RowContent>();
		private int index;
		
		
		public int getRowType() {
			return rowType;
		}
		public void setRowType(int rowType) {
			this.rowType = rowType;
		}
		public boolean isSelectable() {
			return selectable;
		}
		public void setSelectable(boolean selectable) {
			this.selectable = selectable;
		}
		public int getLayout_id() {
			return layout_id;
		}
		public void setLayout_id(int layoutId) {
			layout_id = layoutId;
		}
		public List<RowContent> getRowContents() {
			return rowContents;
		}
		public void setRowContents(List<RowContent> rowContents) {
			this.rowContents = rowContents;
		}
		public int getIndex() {
			return index;
		}
		public void setIndex(int index) {
			this.index = index;
		}
		public boolean isChecked() {
			return isChecked;
		}
		public void setChecked(boolean isChecked) {
			this.isChecked = isChecked;
		}
		
	}
	
	
	
	public static class RowContent {

		private int type;
		private int layout_id;
		private String text;
		private int image_id = -1;
		
		private int color = Color.WHITE;
		
		public int getImage_id() {
			return image_id;
		}

		public void setImage_id(int imageId) {
			image_id = imageId;
		}
		
		public int getType() {
			return type;
		}

		public void setType(int type) {
			this.type = type;
		}

		public int getLayout_id() {
			return layout_id;
		}

		public void setLayout_id(int layoutId) {
			layout_id = layoutId;
		}

		public String getText() {
			return text;
		}

		public void setText(String text) {
			this.text = text;
		}

		public int getColor() {
			return color;
		}

		public void setColor(int color) {
			this.color = color;
		}
		
	}
	
	
	
	public class ListRowView extends LinearLayout {

		public ListRow row;
		private int groupIndex;
		private int childIndex;
		private Context context;
		
		public ListRowView(Context context, ListRow row, int groupIndex, int childIndex) {
			super(context);
			this.context = context;
			this.row = row;
			this.groupIndex = groupIndex;
			this.childIndex = childIndex;
			addView(inflate(context, row.getLayout_id(), null));
			setData(row);
		}
		
		public ListRow getRow() {
			return row;
		}
		
		public void setData(ListRow row) {

			List<RowContent> viewContents = row.getRowContents();
			if ((viewContents != null) && (viewContents.size() > 0)) {
				
				for (RowContent viewContent : viewContents) {
					int type = viewContent.getType();
					int layout_id = viewContent.getLayout_id();
					
					switch (type) {
					case ConstantUtils.TEXT:
						TextView textView = (TextView)this.findViewById(layout_id);
						if(textView != null) {
							textView.setText(viewContent.getText());
							if(viewContent.getColor() != Color.WHITE)
								textView.setTextColor(viewContent.getColor());
						}
						break;
					case ConstantUtils.EXPAND_IMAGE:
					case ConstantUtils.IMAGE:
						int icon_id = viewContent.getImage_id();
						if(icon_id != -1)
							((ImageView)this.findViewById(layout_id)).setBackgroundResource(icon_id);
						break;
					case ConstantUtils.EDIT_TEXT:
						EditText editText = (EditText)this.findViewById(layout_id);
						if(editText != null) {
							editText.setText(viewContent.getText());
						}
//						editText.setOnFocusChangeListener(focus_listener_noIM);
//						editText.setOnTouchListener(touch_listener_noIM);
						break;
					case ConstantUtils.CHECK_BOX:
						CheckBox cb = (CheckBox) this.findViewById(layout_id);	
						cb.setChecked(row.isChecked());
						cb.setOnCheckedChangeListener(checkBoxListener);
						break;
					case ConstantUtils.BUTTON:
						Button delete = (Button) this.findViewById(layout_id);
						delete.setOnClickListener(deleteButtonOnClick);
						break;
					default:
						break;
					}
				}
			}
		}
		
		private OnClickListener deleteButtonOnClick = new OnClickListener() {

			@Override
			public void onClick(View v) {
				Dialog dialog = null;
				AlertDialog.Builder builder = new AlertDialog.Builder(context);
				builder.setIcon(android.R.drawable.ic_dialog_alert).setTitle(
						"��ȷ��Ҫ�h�����").setPositiveButton("ȷ��",
						new DialogInterface.OnClickListener() {
							
							public void onClick(DialogInterface dialog,
									int whichButton) {
								childList.get(groupIndex).remove(childIndex);
							}
						}).setNegativeButton("ȡ��",
						new DialogInterface.OnClickListener() {
							public void onClick(DialogInterface dialog,
									int whichButton) {
								
							}
						});
				dialog = builder.create();
				dialog.show();
			}
		};
		
		private OnCheckedChangeListener checkBoxListener = new OnCheckedChangeListener() {
			@Override
			public void onCheckedChanged(CompoundButton buttonView,
					boolean isChecked) {
				// TODO Auto-generated method stub
				row.setChecked(isChecked);
				if(row.isChecked) {
					Toast.makeText(context, "��ѡ���˵�" + childIndex + "�",Toast.LENGTH_SHORT).show();
				}else {
					Toast.makeText(context, "��ȡ���˵�" + childIndex + "�",Toast.LENGTH_SHORT).show();
				}
			}
		};
	}
	
	
	
}
