package com.wind;


public interface ConstantUtils {
	
	// define ListRow types
	public static int LIST_HEADER = 10;
//	public static int LIST_SEPARATOR = 11;
	public static int ROW_IN_LIST = 12;
	
	// define RowContent types
	public static int TEXT = 0;
	public static int EDIT_TEXT = 1;
	public static int IMAGE = 2;
	public static int BUTTON = 3;
	public static int CHECK_BOX = 4;
	public static int EXPAND_IMAGE = 5;
	
	
}
