/** Automatically generated file. DO NOT MODIFY */
package com.qin.zdlock;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}