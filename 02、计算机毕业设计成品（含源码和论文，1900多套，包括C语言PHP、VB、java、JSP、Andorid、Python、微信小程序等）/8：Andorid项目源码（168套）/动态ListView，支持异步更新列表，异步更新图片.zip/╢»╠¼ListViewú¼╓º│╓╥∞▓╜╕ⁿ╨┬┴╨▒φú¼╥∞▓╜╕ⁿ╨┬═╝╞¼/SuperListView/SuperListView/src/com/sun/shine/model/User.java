package com.sun.shine.model;

import android.graphics.drawable.Drawable;

public class User {

	private String name;
	private int res = -1;
	Drawable drawable;

	public User() {
	}

	public void setDrawable(Drawable drawable) {

		this.drawable = drawable;
	}

	public Drawable getDrawable() {

		return drawable;
	}

	public User(String name) {
		this.name = name;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getRes() {

		return res;
	}

	public void setRes(int res) {
		this.res = res;
	}

}
