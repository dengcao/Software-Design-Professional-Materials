package com.sun.shine.superlist;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.os.Bundle;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import com.sun.shine.model.User;
import com.sun.shine.superlist.view.SuperListView;

public class MySuperListView extends Activity implements
		SuperListView.SuperListViewAdapterHelper {
	/** Called when the activity is first created. */
	SuperListView<User> superListView;
	List<User> users;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		superListView = (SuperListView) findViewById(R.id.super_list);
		users = new ArrayList<User>();
		for (int i = 0; i < 10; i++) {
			users.add(new User(String.valueOf(i)));
		}
		superListView.setList(users);
		superListView.setView(R.layout.list_view);
		superListView.setAdapterHelper(this);

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.sun.shine.superlist.view.SuperListView.SuperListViewAdapterHelper
	 * #updateViews(java.util.List, int, android.view.View,
	 * android.view.ViewGroup)
	 */
	@Override
	public boolean updateViews(List list, int position, View convertView,
			ViewGroup parent) {

		ImageView imageView = (ImageView) convertView.findViewById(R.id.head);

		TextView textView = (TextView) convertView.findViewById(R.id.name);
		final User user = (User) list.get(position);
		textView.setText(String.valueOf(user.getName()));

		if (user.getDrawable() != null) {
			imageView.setImageDrawable(user.getDrawable());
			return false;
		} else {
			imageView.setImageResource(R.drawable.default_icon);
			return true;
		}

	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.sun.shine.superlist.view.SuperListView.SuperListViewAdapterHelper
	 * #updateImageViewResouce(java.lang.Object, java.lang.Object)
	 */
	@Override
	public void updateImageViewResouce(Object o, Object lock) {

		User user = (User) o;
		System.out.println("download load begin");
		NetImitate.getInstance(MySuperListView.this).downloadAndBindImage(user,
				lock);
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.sun.shine.superlist.view.SuperListView.SuperListViewAdapterHelper
	 * #updateList(java.util.List, java.lang.Object)
	 */
	@Override
	public List updateList(List oldList, Object lock) {
		if (oldList == null) {
			oldList = new ArrayList<User>();
		}
		int begin = oldList.size();
		List<User> newList = NetImitate.getInstance(MySuperListView.this)
				.getUserList(begin, lock);
		return newList;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see
	 * com.sun.shine.superlist.view.SuperListView.SuperListViewAdapterHelper
	 * #refreshImageView(java.lang.Object, android.view.View)
	 */
	public void refreshImageView(Object k, View contentView) {
		// TODO Auto-generated method stub
		if (k instanceof User) {
			User user = (User) k;
			if (contentView != null) {
				ImageView imageView = (ImageView) contentView
						.findViewById(R.id.head);
				System.out.println("image is Set " + user.getName()
						+ user.getRes() + imageView);
				// Log.i("cmcc", "image is Set " + user.getName() + user.res
				// + contentView);
				// imageView.setImageResource(user.getRes());
				if (imageView.getDrawable() == user.getDrawable()) {
					return;
				} else {
					imageView.setImageDrawable(user.getDrawable());
				}
			}
		}

	}

	/**
	 * 
	 * 这是一个网络模拟类，它模拟下载图片和list列表
	 */
	static class NetImitate {
		private static NetImitate netImitate;

		Context context;

		private NetImitate(Context context) {
			this.context = context;
		}

		public static NetImitate getInstance(Context context) {
			if (netImitate == null) {
				netImitate = new NetImitate(context);
			}
			return netImitate;
		}

		/**
		 * 本方法模拟网络下载数据,sleep是用来模拟数据正在下载所需要的时间,一定要注意lock的用法，必需调用lock.notify
		 * 否则Ui那边会一直等待
		 * 
		 * 
		 * 
		 * @param user
		 * @param lock
		 *            {@link SuperListView#imageLock}
		 * 
		 */
		public void downloadAndBindImage(final User user, final Object lock) {

			new Thread(new Runnable() {

				@Override
				public void run() {
					System.out.println("sleep 500 begin");
					try {
						Thread.sleep(500);
					} catch (InterruptedException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();

					}

					Drawable drawable = context.getResources().getDrawable(
							R.drawable.download);

					drawable.setBounds(0, 0, drawable.getIntrinsicWidth(),
							drawable.getIntrinsicHeight());
					int width = drawable.getIntrinsicWidth();
					int height = drawable.getIntrinsicHeight();
					final Bitmap bitmap = Bitmap.createBitmap((int) width,
							(int) height, Bitmap.Config.ARGB_4444);
					final Canvas c = new Canvas(bitmap);
					// c.translate(10, 10);
					drawable.draw(c);
					Paint paint = new Paint();
					paint.setTextSize(50);
					paint.setAntiAlias(true);
					paint.setColor(Color.BLUE);
					c.drawText(user.getName(), 0, paint.getFontMetrics().bottom
							- paint.getFontMetrics().top, paint);
					BitmapDrawable bitmapDrawable = new BitmapDrawable(bitmap);
					// bitmap.recycle();

					user.setDrawable(bitmapDrawable);
					System.out.println("sleep 500 over");
					synchronized (lock) {
						System.out.println(user.getName()
								+ "'s image is downloaded ");
						lock.notify();
						System.out.println("notify" + user.getName());
						user.setRes(R.drawable.download);
					}

				}
			}).start();

		}

		/**
		 * 本方法模拟网络下载数据,sleep是用来模拟数据正在下载所需要的时间
		 * 
		 * @see SuperListView#listLock
		 * @param begin
		 * @param lock
		 *            {@link SuperListView#listLock}
		 * @return
		 */
		public List<User> getUserList(final int begin, final Object lock) {
			final List<User> users = new ArrayList<User>();
			System.out.println("getUserList is called");
			new Thread(new Runnable() {

				@Override
				public void run() {
					// TODO Auto-generated method stub
					synchronized (lock) {
						try {
							Thread.sleep(1000);
						} catch (InterruptedException e) {
							// TODO Auto-generated catch block
							e.printStackTrace();
						}

						for (int i = begin; i < begin + 10; i++) {
							User user = new User(String.valueOf(i));
							users.add(user);
						}
						System.out.println("lock.notify");
						lock.notify();
					}
				}
			}).start();
			return users;
		}
	}

}