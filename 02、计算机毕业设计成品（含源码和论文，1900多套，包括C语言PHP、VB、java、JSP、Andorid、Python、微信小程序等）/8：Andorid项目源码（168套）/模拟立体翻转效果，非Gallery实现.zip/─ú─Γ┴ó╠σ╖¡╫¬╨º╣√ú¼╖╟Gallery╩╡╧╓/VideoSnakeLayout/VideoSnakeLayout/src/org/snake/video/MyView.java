package org.snake.video;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.util.Log;
import android.view.View;

public class MyView extends View {

	public MyView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
	}

	float ydx = 400f;
	float bj = 1406.5f;
	float bty = 54f;
	float yd1_y = bty - bj;

	float bj2 = 1536.5f;
	float tpy = 224f;
	float yd2_y = tpy + bj2;

	@Override
	protected void onDraw(Canvas canvas) {
		// TODO Auto-generated method stub
		super.onDraw(canvas);
//		canvas.translate(0, 4);
		Paint mPaints = new Paint();
		mPaints.setAntiAlias(true);
		mPaints.setStyle(Paint.Style.STROKE);
		mPaints.setColor(Color.WHITE);
		mPaints.setStrokeWidth(4);
		// RectF oval = new RectF(ydx-bj, bty-bj*2, ydx+bj, bty);
		// canvas.drawArc(oval, 0, 180, false, mPaints);

		// RectF oval1 = new RectF(ydx-bj2, tpy, ydx+bj2,tpy+bj2*2);
		// canvas.drawArc(oval1, 180, 360, false, mPaints);

		// 1
		// (0,24)(114.5,36.5)
		// (0,24+143)(114.5,122.5)
		canvas.drawPoint(0, 24, mPaints);
		canvas.drawPoint(114.5f, 36.5f, mPaints);
		canvas.drawPoint(0, 24 + 143, mPaints);
		canvas.drawPoint(114.5f, 122.5f, mPaints);

		// 2
		// (50,13)(200,33)
		// (50,13+172)(200,165)
		canvas.drawPoint(50, 13, mPaints);
		canvas.drawPoint(200, 33, mPaints);
		canvas.drawPoint(50, 13 + 172, mPaints);
		canvas.drawPoint(200, 165, mPaints);

		// 3
		// (124,5)(321,28)
		// (124,5+212)(321,194)
		canvas.drawPoint(124, 5, mPaints);
		canvas.drawPoint(321, 28, mPaints);
		canvas.drawPoint(124, 5 + 212, mPaints);
		canvas.drawPoint(321, 194, mPaints);

		// 4
		// (234,0)(563,0)
		// (236,0+246)(563,246)
		canvas.drawPoint(234, 0, mPaints);
		canvas.drawPoint(563, 0, mPaints);
		canvas.drawPoint(236, 0 + 246, mPaints);
		canvas.drawPoint(563, 246, mPaints);

		// 5
		// (479,28)(676,5)
		// (479,194)(676,5+212)
		canvas.drawPoint(479, 28, mPaints);
		canvas.drawPoint(676, 5, mPaints);
		canvas.drawPoint(479, 194, mPaints);
		canvas.drawPoint(676, 5 + 212, mPaints);

		// 6
		// (600,33)(750,13)
		// (600,165)(750,13+172)
		canvas.drawPoint(600, 33, mPaints);
		canvas.drawPoint(750, 13, mPaints);
		canvas.drawPoint(600, 165, mPaints);
		canvas.drawPoint(750, 13 + 172, mPaints);

		// 7
		// (685.5,36.5)(800,24)
		// (685.5,122.5)(800,24+143)
		canvas.drawPoint(685.5f, 36.5f, mPaints);
		canvas.drawPoint(800, 24, mPaints);
		canvas.drawPoint(685.5f, 122.5f, mPaints);
		canvas.drawPoint(800, 24 + 143, mPaints);

		mPaints.setStrokeWidth(1);
		
//		float[] arcInfo1 = getArcInfo(new float[]{0,24}, new float[]{124,5}, new float[]{234,0});
//		if(arcInfo1 != null){
//
//			RectF oval1 = new RectF(arcInfo1[0] - arcInfo1[2], arcInfo1[1] - arcInfo1[2], arcInfo1[0] + arcInfo1[2], arcInfo1[1]
//					+ arcInfo1[2]);
//			canvas.drawArc(oval1, 0, 360, false, mPaints);
//		}
		

//		float[] arcInfo2 = getArcInfo(new float[]{114.5f,36.5f}, new float[]{321,28}, new float[]{563,0});
//		if(arcInfo2 != null){
//
//			RectF oval1 = new RectF(arcInfo2[0] - arcInfo2[2], arcInfo2[1] - arcInfo2[2], arcInfo2[0] + arcInfo2[2], arcInfo2[1]
//					+ arcInfo2[2]);
//			canvas.drawArc(oval1, 0, 360, false, mPaints);
//		}

//		float[] arcInfo3 = getArcInfo(new float[]{0,24+143}, new float[]{124,5+212}, new float[]{236,0+246});
//		if(arcInfo3 != null){
//
//			RectF oval1 = new RectF(arcInfo3[0] - arcInfo3[2], arcInfo3[1] - arcInfo3[2], arcInfo3[0] + arcInfo3[2], arcInfo3[1]
//					+ arcInfo3[2]);
//			canvas.drawArc(oval1, 0, 360, false, mPaints);
//		}
//		
		float[] arcInfo4 = getArcInfo(new float[]{114.5f,122.5f}, new float[]{321,194}, new float[]{563,246});
		if(arcInfo4 != null){

			RectF oval1 = new RectF(arcInfo4[0] - arcInfo4[2], arcInfo4[1] - arcInfo4[2], arcInfo4[0] + arcInfo4[2], arcInfo4[1]
					+ arcInfo4[2]);
			canvas.drawArc(oval1, 0, 360, false, mPaints);
		}
//		
//		float[] arcInfo5 = getArcInfo(new float[]{234,0}, new float[]{479,28}, new float[]{685.5f,36.5f});
//		if(arcInfo5 != null){
//
//			RectF oval1 = new RectF(arcInfo5[0] - arcInfo5[2], arcInfo5[1] - arcInfo5[2], arcInfo5[0] + arcInfo5[2], arcInfo5[1]
//					+ arcInfo5[2]);
//			canvas.drawArc(oval1, 0, 360, false, mPaints);
//		}
//		
//		float[] arcInfo6 = getArcInfo(new float[]{563,0}, new float[]{676,5}, new float[]{800,24});
//		if(arcInfo6 != null){
//
//			RectF oval1 = new RectF(arcInfo6[0] - arcInfo6[2], arcInfo6[1] - arcInfo6[2], arcInfo6[0] + arcInfo6[2], arcInfo6[1]
//					+ arcInfo6[2]);
//			canvas.drawArc(oval1, 0, 360, false, mPaints);
//		}
//		
		float[] arcInfo7 = getArcInfo(new float[]{236,0+246}, new float[]{479,194}, new float[]{685.5f,122.5f});
		if(arcInfo7 != null){

			RectF oval1 = new RectF(arcInfo7[0] - arcInfo7[2], arcInfo7[1] - arcInfo7[2], arcInfo7[0] + arcInfo7[2], arcInfo7[1]
					+ arcInfo7[2]);
			canvas.drawArc(oval1, 0, 360, false, mPaints);
		}
//		
		float[] arcInfo8 = getArcInfo(new float[]{563,246}, new float[]{676,5+212}, new float[]{800,24+143});
		if(arcInfo8 != null){

			RectF oval1 = new RectF(arcInfo8[0] - arcInfo8[2], arcInfo8[1] - arcInfo8[2], arcInfo8[0] + arcInfo8[2], arcInfo8[1]
					+ arcInfo8[2]);
			canvas.drawArc(oval1, 0, 360, false, mPaints);
		}
	}

	/**
	 * ��֪3�㣬��Բ��Ϣ
	 * @param point1
	 * @param point2
	 * @param point3
	 * @return float[0]��Բ��x���꣬float[1]��Բ��y���꣬float[2]��Բ�뾶
	 */
	private static float[] getArcInfo(float[] point1, float[] point2,
			float[] point3) {

		float k1 = (point2[1] - point1[1]) / (point2[0] - point1[0]);
		float k2 = (point3[1] - point2[1]) / (point3[0] - point2[0]);
		if (k1 == k2) {
			System.out.println("the three points on a line!");
			return null;
		}
		float[] point_center1 = { (point1[0] + point2[0]) / 2,
				(point1[1] + point2[1]) / 2 };
		float[] point_center2 = { (point3[0] + point2[0]) / 2,
				(point3[1] + point2[1]) / 2 };

		k1 = -1 / k1;
		k2 = -1 / k2;
		float z1 = point_center1[1] - k1 * point_center1[0];
		float z2 = point_center2[1] - k2 * point_center2[0];

		float x = (z2 - z1) / (k1 - k2), y = k1 * x + z1, bj = (float) Math
				.sqrt((x - point2[0]) * (x - point2[0]) + (y - point2[1])
						* (y - point2[1]));

		System.out.println("arcPoint(x,y)=(" + x + "," + y + ") ; bj = " + bj);
		return new float[]{x,y,bj};

	}
}
