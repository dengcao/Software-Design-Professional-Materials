package org.snake.video;

import android.content.Context;
import android.content.res.TypedArray;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PaintFlagsDrawFilter;
import android.graphics.drawable.BitmapDrawable;
import android.graphics.drawable.Drawable;
import android.util.AttributeSet;
import android.widget.ImageView;

public class MyImageView extends ImageView {
	private Bitmap mBitmap;
	private float[] src;
	private float[] dst;
	private Matrix mMatrix = new Matrix();
	/**
	 * �����
	 */
	private PaintFlagsDrawFilter pfd = new PaintFlagsDrawFilter(0,
			Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);

	public MyImageView(Context context, AttributeSet attrs) {
		super(context, attrs);
		TypedArray a = context.obtainStyledAttributes(attrs,
				R.styleable.MyImageView);
		String src_str = a.getString(R.styleable.MyImageView_src);
		String dst_str = a.getString(R.styleable.MyImageView_dst);
		a.recycle();
		if (src_str != null) {
			String[] strs = src_str.split(",");
			src = new float[strs.length];
			for (int i = 0; i < strs.length; i++) {
				src[i] = Float.valueOf(strs[i]);
			}
		}
		if (dst_str != null) {
			String[] strs = dst_str.split(",");
			dst = new float[strs.length];
			for (int i = 0; i < strs.length; i++) {
				dst[i] = Float.valueOf(strs[i]);
			}
		}
	}

	@Override
	protected void onDraw(Canvas canvas) {
		canvas.setDrawFilter(pfd);
		int bw = mBitmap.getWidth(), bh = mBitmap.getHeight();
		if (src != null && dst != null) {
			mMatrix.reset();
			mMatrix.setPolyToPoly(src, 0, dst, 0, src.length >> 1);
			canvas.concat(mMatrix);
		}
		canvas.scale((float) getWidth() / bw, (float) getHeight() / bh,
				0, 0);
		canvas.drawBitmap(mBitmap, 0, 0, null);
	}

	@Override
	public void setImageBitmap(Bitmap bm) {
		mBitmap = bm;
		invalidate();
	}

	@Override
	public void setImageDrawable(Drawable drawable) {
		mBitmap = ((BitmapDrawable) drawable).getBitmap();
		invalidate();
	}

	@Override
	public void setImageResource(int resId) {
		mBitmap = BitmapFactory.decodeResource(this.getResources(), resId);
		invalidate();
	}

}
