package org.snake.video;

import org.snake.video.SnakeLayout.OnSelectListener;

import android.app.Activity;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.LinearGradient;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.PorterDuffXfermode;
import android.graphics.Bitmap.Config;
import android.graphics.PorterDuff.Mode;
import android.graphics.Shader.TileMode;
import android.os.Bundle;
import android.view.View;
import android.widget.Toast;

public class SnakeLayoutActivity extends Activity {
    /** Called when the activity is first created. */
	private SnakeLayout mSnake;

	/**
	 * ����ͼ����
	 */
	private final static int ITEM_WIDTH = 329;
	/**
	 * ����ͼ�߶�
	 */
	private final static int ITEM_HEIGHT = 246;
	
	/**
	 * ���������ʾλͼ
	 */
	private Bitmap bitmapWithReflection;
	/**
	 * ��Ƭ������
	 */
	private Matrix mMatrix = new Matrix();
    @Override
    public void onCreate(Bundle savedInstanceState) {
		System.gc();
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        mSnake = (SnakeLayout)findViewById(R.id.snakeLayout);
        mSnake.setOnSelectListener(new OnSelectListener() {
			@Override
			public void onSelected(int position) {
				Toast.makeText(SnakeLayoutActivity.this, "selected Item num is " + position, Toast.LENGTH_SHORT).show();
			}
		});
        
        mSnake.addBitmap(getBitmap(R.drawable.temp));
        mSnake.addBitmap(getBitmap(R.drawable.test1));
        mSnake.addBitmap(getBitmap(R.drawable.test2));
        mSnake.addBitmap(getBitmap(R.drawable.test3));
        mSnake.addBitmap(getBitmap(R.drawable.test4));
        mSnake.addBitmap(getBitmap(R.drawable.test5));
        mSnake.addBitmap(getBitmap(R.drawable.test6));
        mSnake.addBitmap(getBitmap(R.drawable.test1));
        mSnake.addBitmap(getBitmap(R.drawable.test2));
        mSnake.addBitmap(getBitmap(R.drawable.test4));
        mSnake.addBitmap(getBitmap(R.drawable.test1));
        mSnake.addBitmap(getBitmap(R.drawable.test7));
        mSnake.addBitmap(getBitmap(R.drawable.test1));
        mSnake.addBitmap(getBitmap(R.drawable.test2));
        mSnake.Init();
    }
    
    public void doClick(View v){
        mSnake.addBitmap(getBitmap(R.drawable.test2),0);
        mSnake.addBitmap(getBitmap(R.drawable.test2),1);
        mSnake.addBitmap(getBitmap(R.drawable.test2),2);
        mSnake.addBitmap(getBitmap(R.drawable.test2),3);
        mSnake.addBitmap(getBitmap(R.drawable.test2),4);
        mSnake.addBitmap(getBitmap(R.drawable.test2),5);
        mSnake.addBitmap(getBitmap(R.drawable.test2),6);
        mSnake.notifyDataChange();
    }

    /**
     * ���ƴ������λͼ
     * @param src
     * @return
     */
    private Bitmap getBitmap(int src){
		System.gc();
    	final int reflectionGap = 2;
    	Bitmap originalImage = BitmapFactory.decodeResource(this
				.getResources(), src);
			int width = originalImage.getWidth();
			int height = originalImage.getHeight();

			Bitmap bitmapWithReflection = Bitmap.createBitmap(width,
					(height + height / 2), Config.ARGB_8888);

			Canvas canvas = new Canvas(bitmapWithReflection);
			canvas.drawBitmap(originalImage, 0, 0, null);

			canvas.save();
			canvas.scale(1, -1, 0, bitmapWithReflection.getHeight() + reflectionGap);
			canvas.drawBitmap(originalImage, 0, height + reflectionGap,
					null);
			canvas.restore();
			
			canvas.save();
			Paint paint = new Paint();
			LinearGradient shader = new LinearGradient(0, originalImage
					.getHeight(), 0, bitmapWithReflection.getHeight()
					+ reflectionGap, 0x70ffffff, 0x00ffffff, TileMode.CLAMP);
			paint.setShader(shader);
			paint.setXfermode(new PorterDuffXfermode(Mode.DST_IN));
			canvas.drawRect(0, height, width, bitmapWithReflection
					.getHeight()
					+ reflectionGap, paint);
			canvas.restore();
		return bitmapWithReflection;
    }
}