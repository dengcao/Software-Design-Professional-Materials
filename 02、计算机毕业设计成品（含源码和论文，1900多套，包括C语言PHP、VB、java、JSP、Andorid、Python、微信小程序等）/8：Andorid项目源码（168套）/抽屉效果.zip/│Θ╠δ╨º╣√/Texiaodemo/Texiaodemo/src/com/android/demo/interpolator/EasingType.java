package com.android.demo.interpolator;

public class EasingType {
	public static final int IN = 0;
	public static final int OUT = 1;
	public static final int INOUT = 2;

}
