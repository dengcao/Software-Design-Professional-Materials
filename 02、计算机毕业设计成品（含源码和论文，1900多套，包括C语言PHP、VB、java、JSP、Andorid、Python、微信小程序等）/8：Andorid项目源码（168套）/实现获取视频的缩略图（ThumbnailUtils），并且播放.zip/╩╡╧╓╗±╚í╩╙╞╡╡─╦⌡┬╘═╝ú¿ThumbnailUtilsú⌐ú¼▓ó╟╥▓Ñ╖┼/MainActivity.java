package com.test.activity;  
import java.text.DecimalFormat;  
import java.text.NumberFormat;  
import java.util.List;  
import android.app.Activity;  
import android.app.AlertDialog;  
import android.content.Context;  
import android.content.DialogInterface;  
import android.content.Intent;  
import android.graphics.Bitmap;  
import android.graphics.drawable.BitmapDrawable;  
import android.graphics.drawable.Drawable;  
import android.net.Uri;  
import android.os.Bundle;  
import android.os.Environment;  
import android.provider.MediaStore.Images.Thumbnails;  
import android.view.View;  
import android.widget.Button;  
import android.widget.ImageView;  
import android.widget.TextView;  
import android.location.Criteria;  
import android.location.Location;  
import android.location.LocationListener;  
import android.location.LocationManager;  
import android.media.ThumbnailUtils;  
import com.google.android.maps.GeoPoint;  
import com.google.android.maps.MapActivity;  
import com.google.android.maps.MapController;  
import com.google.android.maps.MapView;  
import com.google.android.maps.Overlay;  
import com.google.android.maps.OverlayItem;  
import com.test.activity.util.HelloItemizedOverlay;  
import com.test.activity.util.MyOverLay;  
public
class MainActivity extends Activity {  
    @Override
    public
void onCreate(Bundle savedInstanceState) {  
        super.onCreate(savedInstanceState);  
        setContentView(R.layout.main);  
          Bitmap bitmap=ThumbnailUtils.createVideoThumbnail(Environment.getExternalStorageDirectory()+"/20110.mp4",Thumbnails.MINI_KIND);  

          Bitmap bitmap1=ThumbnailUtils.extractThumbnail(bitmap,200,200);  
          BitmapDrawable   d=new BitmapDrawable (bitmap1);  
          ((ImageView)findViewById(R.id.imageview)).setBackgroundDrawable(d);  
          ((ImageView)findViewById(R.id.imageview)).setOnClickListener(new View.OnClickListener() {  

            @Override
            public
void onClick(View v) {  
                // TODO Auto-generated method stub
                    Intent it = new Intent(Intent.ACTION_VIEW);   
                    System.out.println(Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED));  
                    Uri uri = Uri.parse(Environment.getExternalStorageDirectory()+"/20110.mp4");   
                    it.setDataAndType(uri , "video/mp4");   
                    startActivity(it);   
            }  
        });  
        }  
}  