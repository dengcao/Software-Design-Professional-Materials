package com.zrgj.book.ui;


import android.app.TabActivity;
import android.content.Intent;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.Window;
import android.widget.TabHost;
import android.widget.Toast;

public class BookActivity extends TabActivity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        overridePendingTransition(R.anim.fadein, R.anim.fadeout);
        
        TabHost host = getTabHost();
        
        //����ѡ���ǩ
        host.addTab(host.newTabSpec("add")//��ǩ����
        		//����ָʾ���ԣ�����ѡ���������ݣ�
        		.setIndicator("����",getResources().getDrawable(R.drawable.bookopen))
        		.setContent(new Intent(this,FileBrowserActivity.class))//���ø�ѡ���ǩ��Ӧ�ľ�������
        		);
        host.addTab(host.newTabSpec("update")
        		.setIndicator("�Ķ�",getResources().getDrawable(R.drawable.bookfav))
        		.setContent(new Intent(this,ReadActivity.class))
        		);
        host.addTab(host.newTabSpec("delete")
        		.setIndicator("��ǩ",getResources().getDrawable(R.drawable.fav))
        		.setContent(new Intent(this,BookmarksActivity.class))
        		);
        host.addTab(host.newTabSpec("search")
        		.setIndicator("����",getResources().getDrawable(R.drawable.books))
        		.setContent(new Intent(this,OnlineActivity.class))
        		);
    }
    

}