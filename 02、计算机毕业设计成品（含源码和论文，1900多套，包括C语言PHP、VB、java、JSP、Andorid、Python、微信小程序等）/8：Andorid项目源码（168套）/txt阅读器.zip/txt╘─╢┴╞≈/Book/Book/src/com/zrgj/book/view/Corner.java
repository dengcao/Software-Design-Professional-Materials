package com.zrgj.book.view;

public enum Corner {
	LeftTop, RightTop, LeftBottom, RightBottom, None
}
