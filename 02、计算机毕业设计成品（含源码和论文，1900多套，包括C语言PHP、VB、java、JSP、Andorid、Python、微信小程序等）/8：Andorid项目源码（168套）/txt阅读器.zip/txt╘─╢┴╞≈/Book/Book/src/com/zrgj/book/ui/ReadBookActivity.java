package com.zrgj.book.ui;

import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Window;

import com.zrgj.book.view.BookAdapter;
import com.zrgj.book.view.BookLayout;


public class ReadBookActivity extends Activity {
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
    	super.onCreate(savedInstanceState);
    	requestWindowFeature(Window.FEATURE_NO_TITLE);
    	 BookLayout bk = new BookLayout(this);
    	 Intent intent = getIntent();
         ArrayList<String> str = intent.getExtras().getStringArrayList("texts");
         BookAdapter ba = new BookAdapter(this);
         ba.addItem(str);
         bk.setPageAdapter(ba);
         setContentView(bk);
    }
}