package com.zrgj.book.ui;

import android.app.Activity;
import android.view.KeyEvent;
import android.widget.Toast;

public class BookmarksActivity extends Activity {
	
	 // ���������¼�
 	private long exitTime = 0;

 	@Override
 	public boolean onKeyDown(int keyCode, KeyEvent event) {
 		if (keyCode == KeyEvent.KEYCODE_BACK
 				&& event.getAction() == KeyEvent.ACTION_DOWN) {
 			if ((System.currentTimeMillis() - exitTime) > 1500) {
 				Toast.makeText(getApplicationContext(), "�ٰ�һ���˳�����",
 						Toast.LENGTH_SHORT).show();
 				exitTime = System.currentTimeMillis();
 			} else {
 				finish();
 				System.exit(0);
 			}
 			return true;
 		}
 		return super.onKeyDown(keyCode, event);
 	}
}
