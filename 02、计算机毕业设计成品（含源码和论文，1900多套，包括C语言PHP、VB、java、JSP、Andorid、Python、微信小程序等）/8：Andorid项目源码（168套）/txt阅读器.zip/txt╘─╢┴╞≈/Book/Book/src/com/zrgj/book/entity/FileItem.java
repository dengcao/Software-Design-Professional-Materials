package com.zrgj.book.entity;

import android.graphics.drawable.Drawable;

public class FileItem {
	
	
	public FileItem() {
		super();
	}
	
	
	public FileItem(String fileName, Drawable fileIcon) {
		super();
		this.fileName = fileName;
		this.fileIcon = fileIcon;
	}


	String fileName;
	Drawable fileIcon;
	public String getFileName() {
		return fileName;
	}
	public void setFileName(String fileName) {
		this.fileName = fileName;
	}
	public Drawable getFileIcon() {
		return fileIcon;
	}
	public void setFileIcon(Drawable fileIcon) {
		this.fileIcon = fileIcon;
	}
	
	
}
