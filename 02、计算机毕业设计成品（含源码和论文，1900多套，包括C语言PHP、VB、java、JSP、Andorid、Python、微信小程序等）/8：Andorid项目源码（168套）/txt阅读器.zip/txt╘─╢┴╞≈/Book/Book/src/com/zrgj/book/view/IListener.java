package com.zrgj.book.view;

public interface IListener {
	public void onPrevPage();

	public void onNextPage();

	public void onInit();
}
