package com.zrgj.book.ui;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.ContextMenu.ContextMenuInfo;
import android.view.KeyEvent;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.view.Window;
import android.widget.AdapterView.AdapterContextMenuInfo;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.Toast;

import com.zrgj.book.utils.StreamTool;

public class ReadActivity extends Activity {

	private ListView lvRead;
	private ArrayAdapter<String> adapter;
	private static final int MENU_READ = 1;
	private static final int MENU_COMMON_READ = 2;
	private static final int MENU_COPY = 3;

	private void findView() {
		lvRead = (ListView) findViewById(R.id.Read_list);

		try {
			String[] str = getAssets().list("");
			adapter = new ArrayAdapter<String>(this, R.layout.row, R.id.text1,
					str);
			lvRead.setAdapter(adapter);

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		lvRead.setOnCreateContextMenuListener(new OnCreateContextMenuListener() {

			@Override
			public void onCreateContextMenu(ContextMenu menu, View v,
					ContextMenuInfo menuInfo) {
				// TODO Auto-generated method stub
				// ��ȡ�¼�Դ��position
				menu.add(0, MENU_COMMON_READ, 1, "��ͨ�Ķ�");
				menu.add(0, MENU_READ, 2, "����Ч���Ķ�");
				menu.add(0, MENU_COPY, 3, "����sdcard");

			}
		});
	}

	// �����Ĳ˵��ĵ����¼�
	@Override
	public boolean onContextItemSelected(MenuItem item) {
		// TODO Auto-generated method stub
		int position = ((AdapterContextMenuInfo) item.getMenuInfo()).position;
		Intent intent;
		InputStream in;
		String str = adapter.getItem(position);
		switch (item.getItemId()) {
		case MENU_COMMON_READ:
			try {
				intent = new Intent(ReadActivity.this, ViewFile.class);
				in = getAssets().open(str);
				Bundle bundle = new Bundle();
				byte[] bytes = new byte[in.available()];
				in.read(bytes);
				in.close();
				String text = new String(bytes, "GB2312");
				bundle.putSerializable("text", text);
				intent.putExtras(bundle);
				startActivity(intent);

			} catch (IOException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}

			break;
		case MENU_READ:

			try {
				in = getAssets().open(str);
				// byte[] bytes = new byte[1024];
				// in.read(bytes);
				// in.close();
				// String text = new String(bytes, "GB2312");
				// bundle.putSerializable("text", text);
				// intent.putExtras(bundle);
				intent = new Intent(ReadActivity.this, ReadBookActivity.class);
				ArrayList<String> texts = StreamTool.readBook(in);
				intent.putStringArrayListExtra("texts", texts);
				startActivity(intent);
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}

			break;
		case MENU_COPY:
			try {
				in = getAssets().open(str);
				File directory  = new File("/mnt/sdcard/Assert");
				File file = new File("/mnt/sdcard/Assert/"+str );
				if (!directory.exists()) {
					directory.mkdir();
				}
				if(!file.createNewFile()){
					file.createNewFile();
				}
				Toast.makeText(this, "����ɹ�", Toast.LENGTH_SHORT).show();
				StreamTool.saveData(in, file);
				

			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			break;
		}
		return super.onContextItemSelected(item);
	}

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		requestWindowFeature(Window.FEATURE_NO_TITLE);
		setContentView(R.layout.read_list);
		findView();
	}
	 // ���������¼�
 	private long exitTime = 0;

 	@Override
 	public boolean onKeyDown(int keyCode, KeyEvent event) {
 		if (keyCode == KeyEvent.KEYCODE_BACK
 				&& event.getAction() == KeyEvent.ACTION_DOWN) {
 			if ((System.currentTimeMillis() - exitTime) > 1500) {
 				Toast.makeText(getApplicationContext(), "�ٰ�һ���˳�����",
 						Toast.LENGTH_SHORT).show();
 				exitTime = System.currentTimeMillis();
 			} else {
 				finish();
 				System.exit(0);
 			}
 			return true;
 		}
 		return super.onKeyDown(keyCode, event);
 	}
}
