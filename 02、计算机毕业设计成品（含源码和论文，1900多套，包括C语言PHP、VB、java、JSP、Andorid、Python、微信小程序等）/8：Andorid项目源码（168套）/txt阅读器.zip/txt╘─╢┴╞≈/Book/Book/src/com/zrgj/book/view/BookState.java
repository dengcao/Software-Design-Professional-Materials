package com.zrgj.book.view;

public enum BookState {
	ABOUT_TO_ANIMATE, ANIMATING, ANIMATE_END, READY, TRACKING
}
