// Decompiled by Jad v1.5.8e2. Copyright 2001 Pavel Kouznetsov.
// Jad home page: http://kpdus.tripod.com/jad.html
// Decompiler options: packimports(3) fieldsfirst ansi space 
// Source File Name:   StringEncodings.java

package org.apache.commons.codec.net;


interface StringEncodings
{

	public static final String US_ASCII = "US-ASCII";
	public static final String UTF8 = "UTF-8";
}
