package com.android.tools;
/*
 * Copyright (C) 2011 Androd源码工作室
 * 
 * Android实战教程--网络视频类播发器
 * 
 * taobao : http://androidsource.taobao.com
 * mail : androidSource@139.com
 * QQ:    androidSource@139.com
 * 
 */

public interface HttpResponseCallback
{

	public abstract void CloseWaitDialog();

	public abstract void ResponseData(String s);
}
