package com.android.tools;

import com.android.datastruct.ListItemBean;
/*
 * Copyright (C) 2011 Androd源码工作室
 * 
 * Android实战教程--网络视频类播发器
 * 
 * taobao : http://androidsource.taobao.com
 * mail : androidSource@139.com
 * QQ:    androidSource@139.com
 * 
 */

public interface RemoveCallback
{

	public abstract int RemoveCollectItemBean(ListItemBean listitembean);
}
