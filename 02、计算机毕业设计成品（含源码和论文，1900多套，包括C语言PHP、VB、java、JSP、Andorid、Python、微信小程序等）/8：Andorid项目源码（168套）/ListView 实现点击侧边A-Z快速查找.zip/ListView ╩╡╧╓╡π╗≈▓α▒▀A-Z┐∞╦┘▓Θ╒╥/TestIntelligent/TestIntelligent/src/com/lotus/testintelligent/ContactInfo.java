package com.lotus.testintelligent;


final class ContactInfo {
    public long personId;
    public String name;
    public String number;
    public String formattedNumber;
}