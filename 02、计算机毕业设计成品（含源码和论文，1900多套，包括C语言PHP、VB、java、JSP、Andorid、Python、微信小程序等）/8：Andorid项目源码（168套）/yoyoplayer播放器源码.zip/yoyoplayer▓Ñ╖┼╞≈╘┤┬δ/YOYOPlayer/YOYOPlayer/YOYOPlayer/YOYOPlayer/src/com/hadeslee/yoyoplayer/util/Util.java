/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hadeslee.yoyoplayer.util;

import com.hadeslee.yoyoplayer.lyric.*;
import com.hadeslee.yoyoplayer.playlist.PlayListItem;
import com.hadeslee.yoyoplayer.setting.OptionDialog;
import com.hadeslee.yoyoplayer.setting.SettingPanel;
import com.sun.jna.examples.WindowUtils;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Desktop;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.MediaTracker;
import java.awt.Rectangle;
import java.awt.Toolkit;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.net.URL;
import java.net.URLEncoder;
import java.text.DecimalFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import javax.swing.ButtonGroup;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JCheckBoxMenuItem;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JMenu;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JRadioButtonMenuItem;
import javax.swing.JToggleButton;
import javax.swing.event.ChangeListener;
import org.apache.commons.httpclient.Header;
import org.apache.commons.httpclient.HttpClient;
import org.apache.commons.httpclient.URI;
import org.apache.commons.httpclient.UsernamePasswordCredentials;
import org.apache.commons.httpclient.auth.AuthScope;
import org.apache.commons.httpclient.methods.GetMethod;

/**
 * һ�������࣬��Ҫ����������
 * ���ҵ��������������Ȼ�󱣴�ɱ�׼��ʽ���ļ�
 * ����һЩ���õķ���
 * @author hadeslee
 */
public final class Util {

    public static String VERSION = "1.2";//�汾��,���ڶԱȸ���
    private static Logger log = Logger.getLogger(Util.class.getName());
    private static final JPanel panel = new JPanel();
    private static final JFileChooser jfc = new JFileChooser();

    private Util() {
    }

    /**
     * �������µ�һ���ܷ���ķ���,
     * �ܶ�ط������Ե��õ��˷���,���Ҵ˷���
     * ���𵯳��Ի������û�ѡ���������һЩʵ��
     * @param ver �õ��İ汾����
     * @param ignoreNoUpdate �Ƿ����û�и��µ���ʾ��
     */
    public static void checkUpdate(Version remote, boolean ignoreNoUpdate) {
        if (remote != null && remote.getVersion() != null) {
            if (Util.canUpdate(remote.getVersion())) {
                int i = JOptionPane.showConfirmDialog(null, Config.getResource("Util.currentVersion") + Util.VERSION + "\n" +
                        Config.getResource("Util.remoteVersion") + remote.getVersion() + "\n" +
                        Config.getResource("Util.versionDescription") + remote.getDescription() + Config.getResource("Util.areyouupdate"), Config.getResource("Util.hasUpdate"), JOptionPane.YES_NO_OPTION);
                if (i == JOptionPane.YES_OPTION) {
                    try {
                        Desktop.getDesktop().browse(new java.net.URI(remote.getUrl()));
                    } catch (Exception ex) {
                        Logger.getLogger(SettingPanel.class.getName()).log(Level.SEVERE, null, ex);
                    }
                }
            } else if (!ignoreNoUpdate) {
                JOptionPane.showMessageDialog(null, Config.getResource("Util.currentVersion") + Util.VERSION + "\n" +
                        Config.getResource("Util.remoteVersion") + remote.getVersion() + Config.getResource("Util.noUpdate"));
            }
        }
    }

    /**
     * ����Զ��ȡ���İ汾�����ڵİ汾�Ա�
     * ���ܲ��ܸ���
     * @param version Զ�̵İ汾
     * @return �ܲ��ܸ���
     */
    private static boolean canUpdate(String version) {
        if (version == null) {
            return false;
        }
        return VERSION.compareTo(version) < 0;
    }

    public static boolean voteOpen() {
        return GAEUtil.vote("voteOpen");
    }

    public static boolean voteOneHour() {
        return GAEUtil.vote("voteHour");
    }

    /**
     * �õ�Զ�̵İ汾�ķ���,����һ���ַ���,
     * ��ʽΪx.x.xȻ�����÷�����Ϊ�Ƚ�
     * �汾����Ϣ������ȡ������,һ��汾����ϢURL
     * Ҳ��д�ڱ�������,��Ϊ���еĳ�����,���п��ܸ��µľ���
     * ����,��Ϊ����������ʵĴ�����ܻ�Ҫ�Ķ�
     * ��Ϊ������վ��仯
     * @return Զ�̵İ汾����
     */
    public static Version getRemoteVersion() {
        try {
            return GAEUtil.getRemoteVersion();
        } catch (IOException ex) {
            Logger.getLogger(Util.class.getName()).log(Level.SEVERE, null, ex);
            return null;
        }
    }

    /**
     * һ����������һϵ�н�����ɫ�ķ���,һ��������128
     * ���ո�,�����ӻ�������
     * @param c1 ��һ����ɫ
     * @param c2 �ڶ�����ɫ
     * @param c3 ��������ɫ
     * @param count ���ɼ�����ɫ
     * @return ����ɫ
     */
    public static Color[] getColors(Color c1, Color c2, Color c3, int count) {
        if (count < 3) {
            throw new IllegalArgumentException("����ɫ����������3!");
        }
        Color[] cs = new Color[count];
        int half = count / 2;
        float addR = (c2.getRed() - c1.getRed()) * 1.0f / half;
        float addG = (c2.getGreen() - c1.getGreen()) * 1.0f / half;
        float addB = (c2.getBlue() - c1.getBlue()) * 1.0f / half;
//        log.log(Level.INFO, "addR="+addR+",addG="+addG+",addB="+addB);
        int r = c1.getRed();
        int g = c1.getGreen();
        int b = c1.getBlue();
        for (int i = 0; i < half; i++) {
            cs[i] = new Color((int) (r + i * addR), (int) (g + i * addG), (int) (b + i * addB));
//            log.log(Level.INFO, "cs["+i+"]="+cs[i]);
        }
        addR = (c3.getRed() - c2.getRed()) * 1.0f / half;
        addG = (c3.getGreen() - c2.getGreen()) * 1.0f / half;
        addB = (c3.getBlue() - c2.getBlue()) * 1.0f / half;
        r = c2.getRed();
        g = c2.getGreen();
        b = c2.getBlue();
        for (int i = half; i < count; i++) {
            cs[i] = new Color((int) (r + (i - half) * addR), (int) (g + (i - half) * addG), (int) (b + (i - half) * addB));
//            log.log(Level.INFO, "cs["+i+"]="+cs[i]);
        }
        return cs;
    }

    /**
     * �����ض�����ɫ����һ��ͼ��ķ���
     * @param c ��ɫ
     * @param width ����
     * @param height �߶�
     * @return ͼ��
     */
    public static ImageIcon createColorIcon(Color c, int width, int height) {
        BufferedImage bi = createImage(c, width, height);
        return new ImageIcon(bi);
    }

    /**
     * �����ض�����ɫ,���������ɫ��һ��ͼƬ
     * һ��������ʾ��ͼƬ��ť����ΪICON��
     * @param c ��ɫ
     * @param width ͼƬ�Ŀ���
     * @param height ͼƬ�ĸ߶�
     * @return ���ɵ�ͼƬ
     */
    public static BufferedImage createImage(Color c, int width, int height) {
        BufferedImage bi = new BufferedImage(width, height, BufferedImage.TYPE_INT_RGB);
        Graphics2D g = bi.createGraphics();
        g.setColor(c);
        g.fillRect(0, 0, width, height);
        g.setColor(new Color(128, 128, 128));
        g.drawRect(0, 0, width - 1, height - 1);
        g.setColor(new Color(236, 233, 216));
        g.drawRect(1, 1, width - 3, height - 3);
        return bi;
    }

    /**
     * ���ٵ����ɸ���������Ĳ˵��ķ���
     * @param pop �˵� 
     * @param lp ������
     */
    public static void generateLyricMenu(JMenu pop, final LyricPanel lp) {
        final Config config = Config.getConfig();
        JMenu adjust = new JMenu(Config.getResource("Util.adjustLyric"));
        JMenu showType = new JMenu(Config.getResource("Util.displayMode"));
//        JMenu set = new JMenu("����");
        adjust.add(Config.getResource("Util.ff0.5")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                lp.getLyric().adjustTime(-500);
            }
        });
        adjust.add(Config.getResource("Util.ss0.5")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                lp.getLyric().adjustTime(500);
            }
        });
        adjust.add(Config.getResource("Util.adjustAll")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                String s = JOptionPane.showInputDialog(Config.getResource("Util.inputAdjustTime") +
                        Config.getResource("Util.adjustTip"));
                if (s != null) {
                    try {
                        int time = Integer.parseInt(s);
                        lp.getLyric().adjustTime(time);
                    } catch (Exception exe) {
                    }
                }
            }
        });
        adjust.addSeparator();
        final JCheckBoxMenuItem check = new JCheckBoxMenuItem(Config.getResource("Util.mouseWheelAdjust"));
        check.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                config.setMouseScrollAjustTime(check.isSelected());
            }
        });
        check.setSelected(config.isMouseScrollAjustTime());
        adjust.add(check);
        pop.add(Config.getResource("lyric.hideLyric")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                lp.hideMe();
            }
        });

        pop.add(Config.getResource("Util.searchOnline")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                new WebSearchDialog(lp.getPlayer().getCurrentItem(), lp).setVisible(true);
            }
        });
        pop.add(Config.getResource("Util.relativeLyric")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                JOptionPane.showMessageDialog(lp, Config.getResource("Util.relativeTip"));
            }
        });
        pop.add(Config.getResource("Util.undoLyric")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                lp.getPlayer().getCurrentItem().setLyricFile(null);
                lp.getLyric().setEnabled(false);
            }
        });
        pop.add(Config.getResource("Util.reloadLyric")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                Lyric ly = new Lyric(lp.getPlayer().getCurrentItem());
                lp.getPlayer().setLyric(ly);
                lp.setLyric(ly);
            }
        });
        ButtonGroup bg = new ButtonGroup();
        JRadioButtonMenuItem showH = new JRadioButtonMenuItem(Config.getResource("lyric.showLyricH"), config.getLpState() == LyricPanel.H);
        JRadioButtonMenuItem showV = new JRadioButtonMenuItem(Config.getResource("lyric.showLyricV"), config.getLpState() == LyricPanel.V);
        bg.add(showH);
        bg.add(showV);
        showType.add(showH);
        showType.add(showV);
        showType.addSeparator();
        showH.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                lp.setState(LyricPanel.H);
                config.setLpState(LyricPanel.H);
            }
        });
        showV.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                lp.setState(LyricPanel.V);
                config.setLpState(LyricPanel.V);
            }
        });
        final JCheckBoxMenuItem isAuto = new JCheckBoxMenuItem(Config.getResource("lyric.isAutoResize"), config.isAutoResize());
        isAuto.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                config.setAutoResize(isAuto.isSelected());
                if (isAuto.isSelected()) {
                    lp.setResized(false);
                }
            }
        });
        final JCheckBoxMenuItem isKaraoke = new JCheckBoxMenuItem(Config.getResource("lyric.isKaraoke"), config.isKaraoke());
        isKaraoke.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                config.setKaraoke(isKaraoke.isSelected());
            }
        });
        final JCheckBoxMenuItem isAnti = new JCheckBoxMenuItem(Config.getResource("Util.textAnti"), config.isAntiAliasing());
        isAnti.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                config.setAntiAliasing(isAnti.isSelected());
            }
        });
        final JCheckBoxMenuItem trans = new JCheckBoxMenuItem(Config.getResource("Util.bgTrans"), config.isTransparency());
        trans.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                config.setTransparency(trans.isSelected());
                if (trans.isSelected()) {
                    lp.getPlayer().getLyricUI().setBorderEnabled(config.isShowLrcBorder());
                    JDialog jd = lp.getPlayer().getLoader().changeLrcDialog();
                    WindowUtils.setWindowTransparent(jd, true);
                    lp.start();
                } else {
                    lp.getPlayer().getLyricUI().setBorderEnabled(true);
                    WindowUtils.setWindowTransparent(config.getLrcWindow(), false);
                }
            }
        });

        final JCheckBoxMenuItem showBorder = new JCheckBoxMenuItem(Config.getResource("Util.showBorder"), config.isShowLrcBorder());
        showBorder.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                boolean b = showBorder.isSelected();
                config.setShowLrcBorder(b);
                lp.getPlayer().getLyricUI().setBorderEnabled(b);
            }
        });
        showBorder.setEnabled(config.isTransparency());
        if (config.isLinux()) {
            trans.setEnabled(false);
            showBorder.setEnabled(false);
        }
        showType.add(isAuto);
        showType.add(isKaraoke);
        showType.add(isAnti);
        showType.add(trans);
        showType.add(showBorder);
        pop.add(adjust);
        pop.add(showType);
        final JCheckBoxMenuItem topShow = new JCheckBoxMenuItem(Config.getResource("Util.showOnTop"), config.isLyricTopShow());
        topShow.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                config.setLyricTopShow(topShow.isSelected());
                config.getLrcWindow().setAlwaysOnTop(topShow.isSelected());
            }
        });
        pop.add(topShow);
        pop.add(Config.getResource("Util.option")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                OptionDialog jd = config.getOptionDialog();
                jd.setSelected(Config.getResource("Util.lyric"));
                jd.setVisible(true);
            }
        });


    }

    /**
     * ���ٵ����ɸ���������Ĳ˵��ķ���
     * @param pop �˵� 
     * @param lp ������
     */
    public static void generateLyricMenu(JPopupMenu pop, final LyricPanel lp) {
        final Config config = Config.getConfig();
        JMenu adjust = new JMenu(Config.getResource("Util.adjustLyric"));
        JMenu showType = new JMenu(Config.getResource("Util.displayMode"));
//        JMenu set = new JMenu("����");
        adjust.add(Config.getResource("Util.ff0.5")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                lp.getLyric().adjustTime(-500);
            }
        });
        adjust.add(Config.getResource("Util.ss0.5")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                lp.getLyric().adjustTime(500);
            }
        });
        adjust.add(Config.getResource("Util.adjustAll")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent e) {
                String s = JOptionPane.showInputDialog(Config.getResource("Util.inputAdjustTime") +
                        Config.getResource("Util.adjustTip"));
                if (s != null) {
                    try {
                        int time = Integer.parseInt(s);
                        lp.getLyric().adjustTime(time);
                    } catch (Exception exe) {
                    }
                }
            }
        });
        adjust.addSeparator();
        final JCheckBoxMenuItem check = new JCheckBoxMenuItem(Config.getResource("Util.mouseWheelAdjust"));
        check.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                config.setMouseScrollAjustTime(check.isSelected());
            }
        });
        check.setSelected(config.isMouseScrollAjustTime());
        adjust.add(check);
        pop.add(Config.getResource("lyric.hideLyric")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                lp.hideMe();
            }
        });

        pop.add(Config.getResource("Util.searchOnline")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                new WebSearchDialog(lp.getPlayer().getCurrentItem(), lp).setVisible(true);
            }
        });
        pop.add(Config.getResource("Util.relativeLyric")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                JOptionPane.showMessageDialog(lp, Config.getResource("Util.relativeTip"));
            }
        });
        pop.add(Config.getResource("Util.undoLyric")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                lp.getPlayer().getCurrentItem().setLyricFile(null);
                lp.getLyric().setEnabled(false);
            }
        });
        pop.add(Config.getResource("Util.reloadLyric")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                Lyric ly = new Lyric(lp.getPlayer().getCurrentItem());
                lp.getPlayer().setLyric(ly);
                lp.setLyric(ly);
            }
        });
        ButtonGroup bg = new ButtonGroup();
        JRadioButtonMenuItem showH = new JRadioButtonMenuItem(Config.getResource("lyric.showLyricH"), config.getLpState() == LyricPanel.H);
        JRadioButtonMenuItem showV = new JRadioButtonMenuItem(Config.getResource("lyric.showLyricV"), config.getLpState() == LyricPanel.V);
        bg.add(showH);
        bg.add(showV);
        showType.add(showH);
        showType.add(showV);
        showType.addSeparator();
        showH.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                lp.setState(LyricPanel.H);
                config.setLpState(LyricPanel.H);
            }
        });
        showV.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                lp.setState(LyricPanel.V);
                config.setLpState(LyricPanel.V);
            }
        });
        final JCheckBoxMenuItem isAuto = new JCheckBoxMenuItem(Config.getResource("lyric.isAutoResize"), config.isAutoResize());
        isAuto.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                config.setAutoResize(isAuto.isSelected());
                if (isAuto.isSelected()) {
                    lp.setResized(false);
                }
            }
        });
        final JCheckBoxMenuItem isKaraoke = new JCheckBoxMenuItem(Config.getResource("lyric.isKaraoke"), config.isKaraoke());
        isKaraoke.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                config.setKaraoke(isKaraoke.isSelected());
            }
        });
        final JCheckBoxMenuItem isAnti = new JCheckBoxMenuItem(Config.getResource("Util.textAnti"), config.isAntiAliasing());
        isAnti.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                config.setAntiAliasing(isAnti.isSelected());
            }
        });
        final JCheckBoxMenuItem trans = new JCheckBoxMenuItem(Config.getResource("Util.bgTrans"), config.isTransparency());
        trans.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                config.setTransparency(trans.isSelected());
                if (trans.isSelected()) {
                    lp.getPlayer().getLyricUI().setBorderEnabled(config.isShowLrcBorder());
                    JDialog jd = lp.getPlayer().getLoader().changeLrcDialog();
                    WindowUtils.setWindowTransparent(jd, true);
                    lp.start();
                } else {
                    lp.getPlayer().getLyricUI().setBorderEnabled(true);
                    WindowUtils.setWindowTransparent(config.getLrcWindow(), false);
                }
            }
        });

        final JCheckBoxMenuItem showBorder = new JCheckBoxMenuItem(Config.getResource("Util.showBorder"), config.isShowLrcBorder());
        showBorder.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                boolean b = showBorder.isSelected();
                config.setShowLrcBorder(b);
                lp.getPlayer().getLyricUI().setBorderEnabled(b);
            }
        });
        showBorder.setEnabled(config.isTransparency());
        if (config.isLinux()) {
            trans.setEnabled(false);
            showBorder.setEnabled(false);
        }
        showType.add(isAuto);
        showType.add(isKaraoke);
        showType.add(isAnti);
        showType.add(trans);
        showType.add(showBorder);
        pop.add(adjust);
        pop.add(showType);
        final JCheckBoxMenuItem topShow = new JCheckBoxMenuItem(Config.getResource("Util.showOnTop"), config.isLyricTopShow());
        topShow.addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                config.setLyricTopShow(topShow.isSelected());
                config.getLrcWindow().setAlwaysOnTop(topShow.isSelected());
            }
        });
        pop.add(topShow);
        pop.add(Config.getResource("Util.option")).addActionListener(new ActionListener() {

            public void actionPerformed(ActionEvent ae) {
                OptionDialog jd = config.getOptionDialog();
                jd.setSelected(Config.getResource("Util.lyric"));
                jd.setVisible(true);
            }
        });

    }

    /**
     * һ���򵥵ķ���,�õ�����ȥ�ĸ��ֺͱ����
     * ����������,��һ���б���ʽ����
     * @param artist ������,����Ϊ��
     * @param title ����,����Ϊ��
     * @return
     */
    public static List<SearchResult> getSearchResults(String artist, String title) {
        List<SearchResult> list = new ArrayList<SearchResult>();
        try {
            list = LRCUtil.search(artist, title);
        } catch (Exception ex) {
            Logger.getLogger(Util.class.getName()).log(Level.SEVERE, null, ex);
        }
        return list;
    }

    /**
     * ��һ��intֵ�õ������������ֽ�����
     * @param i ֵ 
     * @return �ֽ�����
     */
    public static byte[] getBytesFromInt(int i) {
        byte[] data = new byte[4];
        data[0] = (byte) (i & 0xff);
        data[1] = (byte) ((i >> 8) & 0xff);
        data[2] = (byte) ((i >> 16) & 0xff);
        data[3] = (byte) ((i >> 24) & 0xff);
        return data;
    }

    /**
     * ���ַ���ת��ϵͳԤ��ı���
     * @param source
     * @return
     */
    public static String convertString(String source) {
        return convertString(source, Config.getConfig().getEncoding());
    }

    /**
     * һ�����ķ�������һ���ַ�����ת����һ���ַ���
     * @param source Դ�ַ���
     * @param encoding ����
     * @return �µ��ַ���
     */
    public static String convertString(String source, String encoding) {
        try {
            byte[] data = source.getBytes("ISO8859-1");
            return new String(data, encoding);
        } catch (UnsupportedEncodingException ex) {
            return source;
        }
    }

    /**
     * ת���һ������ķ���
     * @param source Ҫת���ַ���
     * @param sourceEnc �ַ���ԭ���ı���
     * @param distEnc Ҫת�ɵı���
     * @return ת����ַ���
     */
    public static String convertString(String source, String sourceEnc, String distEnc) {
        try {
            byte[] data = source.getBytes(sourceEnc);
            return new String(data, distEnc);
        } catch (UnsupportedEncodingException ex) {
            return source;
        }
    }

    /**
     * �Ӵ����������õ��������
     * ��ɵ����͵Ĵ�С
     * @param data ����
     * @return ����
     */
    public static int getInt(byte[] data) {
        if (data.length != 4) {
            throw new IllegalArgumentException("���鳤�ȷǷ�,Ҫ����Ϊ4!");
        }
        return (data[0] & 0xff) | ((data[1] & 0xff) << 8) | ((data[2] & 0xff) << 16) | ((data[3] & 0xff) << 24);
    }

    /**
     * �Ӵ��������ֽ�����õ�
     * ����ֽ���������ɵĳ����͵Ľ��
     * @param data �ֽ�����
     * @return ������
     */
    public static long getLong(byte[] data) {
        if (data.length != 8) {
            throw new IllegalArgumentException("���鳤�ȷǷ�,Ҫ����Ϊ4!");
        }
        return (data[0] & 0xff) |
                ((data[1] & 0xff) << 8) |
                ((data[2] & 0xff) << 16) |
                ((data[3] & 0xff) << 24) |
                ((data[4] & 0xff) << 32) |
                ((data[5] & 0xff) << 40) |
                ((data[6] & 0xff) << 48) |
                ((data[7] & 0xff) << 56);
    }

    /**
     * �õ���Ӧ���ļ�ѡ���,��ΪҪ��һ��һ��
     * @param filter 
     * @param canDir 
     * @return
     */
    public static JFileChooser getFileChooser(FileNameFilter filter, int mode) {
        jfc.resetChoosableFileFilters();
        jfc.setFileSelectionMode(mode);
        jfc.setAcceptAllFileFilterUsed(false);
        jfc.setFileFilter(filter);
        jfc.setFileHidingEnabled(true);
        return jfc;
    }

    /**
     * ����һ���ļ���ȫ·���õ�������չ��
     * @param path ȫ·��
     * @return  ��չ��
     */
    public static String getExtName(String path) {
        return path.substring(path.lastIndexOf(".") + 1);
    }

    /**
     * �õ��������εľ���
     * @param rec1 ����1
     * @param rec2 ����2
     * @return ����
     */
    public static int getDistance(Rectangle rec1, Rectangle rec2) {
        if (rec1.intersects(rec2)) {
            return Integer.MAX_VALUE;
        }
        int x1 = (int) rec1.getCenterX();
        int y1 = (int) rec1.getCenterY();
        int x2 = (int) rec2.getCenterX();
        int y2 = (int) rec2.getCenterY();
        int dis1 = Math.abs(x1 - x2) - rec1.width / 2 - rec2.width / 2;
        int dis2 = Math.abs(y1 - y2) - rec1.height / 2 - rec2.height / 2;
        return Math.max(dis1, dis2) - 1;
    }

    /**
     * ����һЩ����,ͳһ����һ��������
     * @param min ��Сֵ 
     * @param max ���ֵ
     * @param value ��ǰֵ
     * @param ball1 ��1
     * @param ball2 ��2
     * @param ball3 ��3
     * @param bg1 ����1
     * @param bg2 ����2
     * @param listener ������
     * @param orientation ����
     * @return ������
     */
    public static YOYOSlider createSlider(int min, int max, int value,
            Image ball1, Image ball2, Image ball3, Image bg1,
            Image bg2, ChangeListener listener, int orientation) {
        YOYOSlider yoyo = new YOYOSlider();
        YOYOSliderUI ui = new YOYOSliderUI(yoyo);
        yoyo.setOpaque(false);
        yoyo.setMaximum(max);
        yoyo.setMinimum(min);
        yoyo.setValue(value);
        yoyo.setOrientation(orientation);
        ui.setThumbImage(ball1);
        ui.setThumbOverImage(ball2);
        ui.setThumbPressedImage(ball3);
        ui.setBackgroundImages(bg1);
        ui.setActiveBackImage(bg2);
        yoyo.setUI(ui);
        yoyo.addChangeListener(listener);
        return yoyo;
    }

    /**
     * ����һЩ�������ٵع������ť��
     * ��Щ��ť������Ͽ�����һЩ����İ�ť
     * @param name ��ťͼƬ����Ե�ַ
     * @param cmd ����
     * @param listener ������
     * @return ��ť
     */
    public static JButton createJButton(String name, String cmd, ActionListener listener) {
        Image[] icons = Util.getImages(name, 3);
        JButton jb = new JButton();
        jb.setBorderPainted(false);
        jb.setFocusPainted(false);
        jb.setContentAreaFilled(false);
        jb.setDoubleBuffered(true);
        jb.setIcon(new ImageIcon(icons[0]));
        jb.setRolloverIcon(new ImageIcon(icons[1]));
        jb.setPressedIcon(new ImageIcon(icons[2]));
        jb.setOpaque(false);
        jb.setFocusable(false);
        jb.setActionCommand(cmd);
        jb.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        jb.addActionListener(listener);
        return jb;
    }

    /**
     * ����һЩ�������ٵع������ť��
     * ��Щ��ť������Ͽ�����һЩ����İ�ť
     * @param name ��ťͼƬ����Ե�ַ
     * @param cmd ����
     * @param listener ������
     * @param selected �Ƿ�ѡ����
     * @return ��ť
     */
    public static JToggleButton createJToggleButton(String name, String cmd, ActionListener listener, boolean selected) {
        Image[] icons = Util.getImages(name, 3);
        JToggleButton jt = new JToggleButton();
        jt.setBorder(null);
        jt.setContentAreaFilled(false);
        jt.setFocusPainted(false);
        jt.setDoubleBuffered(true);
        jt.setIcon(new ImageIcon(icons[0]));
        jt.setRolloverIcon(new ImageIcon(icons[1]));
        jt.setSelectedIcon(new ImageIcon(icons[2]));
        jt.setOpaque(false);
        jt.setFocusable(false);
        jt.setActionCommand(cmd);
        jt.setSelected(selected);
        jt.setCursor(Cursor.getPredefinedCursor(Cursor.HAND_CURSOR));
        jt.addActionListener(listener);
        return jt;
    }

    /**
     * �õ�һϵ�е�ͼƬ�������ֵ�����Ϊ���е�
     * @param who ͼƬ�Ļ���
     * @param count ����
     * @return ͼƬ����
     */
    public static Image[] getImages(String who, int count) {
        Image[] imgs = new Image[3];
        MediaTracker mt = new MediaTracker(panel);
        Toolkit tk = Toolkit.getDefaultToolkit();
        for (int i = 1; i <= count; i++) {
            URL url = Util.class.getResource("/com/hadeslee/yoyoplayer/pic/" + who + i + ".png");
            imgs[i - 1] = tk.createImage(url);
            mt.addImage(imgs[i - 1], i);
        }
        try {
            mt.waitForAll();
        } catch (Exception exe) {
            exe.printStackTrace();
        }

        return imgs;
    }

    /**
     * ����ĳ��URL�õ����URL������ͼƬ
     * ���ҰѸ�ͼƬ�����ڴ�
     * @param name URL
     * @return ͼƬ
     */
    public static Image getImage(String name) {
        URL url = Util.class.getResource("/com/hadeslee/yoyoplayer/pic/" + name);
        Image im = Toolkit.getDefaultToolkit().createImage(url);
        try {
            MediaTracker mt = new MediaTracker(panel);
            mt.addImage(im, 0);
            mt.waitForAll();
        } catch (Exception exe) {
            exe.printStackTrace();
        }
        return im;
    }

    /**
     * ����һ�������õ�������ɫ֮��Ľ���ɫ
     * @param c1 ��һ����ɫ
     * @param c2 �ڶ�����ɫ
     * @param f ����
     * @return �µ���ɫ
     */
    public static Color getGradientColor(Color c1, Color c2, float f) {
        int deltaR = c2.getRed() - c1.getRed();
        int deltaG = c2.getGreen() - c1.getGreen();
        int deltaB = c2.getBlue() - c1.getBlue();
        int r1 = (int) (c1.getRed() + f * deltaR);
        int g1 = (int) (c1.getGreen() + f * deltaG);
        int b1 = (int) (c1.getBlue() + f * deltaB);
        Color c = new Color(r1, g1, b1);
        return c;
    }

    /**
     * �õ�������ɫ�Ļ��ɫ
     * @param c1 ��һ����ɫ
     * @param c2 �ڶ�����ɫ
     * @return ���ɫ
     */
    public static Color getColor(Color c1, Color c2) {
        int r = (c2.getRed() + c1.getRed()) / 2;
        int g = (c2.getGreen() + c1.getGreen()) / 2;
        int b = (c2.getBlue() + c1.getBlue()) / 2;
        return new Color(r, g, b);
    }

    /**
     * һ�����ػ�ȡ�ַ����߶ȵķ���
     * @param s �ַ���
     * @param g ����
     * @return �߶�
     */
    public static int getStringHeight(String s, Graphics g) {
        return (int) g.getFontMetrics().getStringBounds(s, g).getHeight();
    }

    /**
     * һ�����ػ�ȡ�ַ������ȵķ���
     * @param s �ַ���
     * @param g ����
     * @return ����
     */
    public static int getStringWidth(String s, Graphics g) {
        return (int) g.getFontMetrics().getStringBounds(s, g).getWidth();
    }

    /**
     * �Զ���Ļ��ַ����ķ��������ַ��������Ͻǿ�ʼ��
     * ����JAVA�Ĵ����½ǿ�ʼ�Ļ���
     * @param g ����
     * @param s �ַ���
     * @param x X����
     * @param y Y����
     */
    public static void drawString(Graphics g, String s, int x, int y) {
        FontMetrics fm = g.getFontMetrics();
        int asc = fm.getAscent();
        g.drawString(s, x, y + asc);
    }

    /**
     * һ���������ַ�������ĳ����еĻ���
     * @param g ����
     * @param s �ַ���
     * @param x X����
     * @param y Y����
     */
    public static void drawStringCenter(Graphics g, String s, int x, int y) {
        FontMetrics fm = g.getFontMetrics();
        int asc = fm.getAscent();
        int width = getStringWidth(s, g);
        g.drawString(s, x - width / 2, y + asc);
    }

    /**
     * һ����ݵķ���,���ַ����Ҷ���ķ���
     * @param g ����
     * @param s �ַ���
     * @param x �Ҷ����X����
     * @param y �Ҷ����Y����
     */
    public static void drawStringRight(Graphics g, String s, int x, int y) {
        FontMetrics fm = g.getFontMetrics();
        int asc = fm.getAscent();
        int width = getStringWidth(s, g);
        g.drawString(s, x - width, y + asc);
    }

    /**
     * �õ��ļ��ĸ�ʽ
     * @param f �ļ�
     * @return ��ʽ
     */
    public static String getType(File f) {
        String name = f.getName();
        return name.substring(name.lastIndexOf(".") + 1);
    }

    /**
     * �����ļ����õ�����������
     * @param f �ļ���
     * @return ������
     */
    public static String getSongName(File f) {
        String name = f.getName();
        name = name.substring(0, name.lastIndexOf("."));
        return name;
    }

    /**
     * �����ļ����õ�����������
     * @param name �ļ���
     * @return ������
     */
    public static String getSongName(String name) {
        try {
            int index = name.lastIndexOf(File.separator);
            name = name.substring(index + 1, name.lastIndexOf("."));
            return name;
        } catch (Exception exe) {
            return name;
        }

    }

    /**
     * ���ݸ�������Ϣȥ���ظ������
     * @param fileName �ļ�����
     * @param info ������Ϣ
     * @return �������
     */
    public static String getLyric(PlayListItem info) throws IOException {
        log.log(Level.INFO, "�����Ҹ����");
        String ly="";
        	try {
        		ly = getLyricTTPlayer(info);
			} catch (Exception e) {
				// TODO: handle exception
				e.printStackTrace();
			}
        if (ly != null) {
            log.log(Level.INFO, "TT����������...");
        } else {
            ly = getLyricBaidu(info);
        }
        return ly;

    }

    /**
     * ��ǧǧ�����ķ��������������
     * @param info ������Ϣ����
     * @return ���
     * @throws java.io.IOException
     */
    private static String getLyricTTPlayer(PlayListItem info) throws IOException {
        List<SearchResult> list = LRCUtil.search(info);
        String searchConent="";
        if(list!=null){
	        if (list.isEmpty()) {
	            return searchConent;
	        } else {
	        	searchConent=list.get(0).getContent();
	        }
        }
        return searchConent;
    }

    /**
     * ��һ��������õ���������ַ���
     * ������ʽ
     * @param is ��
     * @return �ַ���
     */
    private static String getString(InputStream is) {
        InputStreamReader r = null;
        try {
            StringBuilder sb = new StringBuilder();
            //TODO �����ǹ̶�����ҳ���ݵı���д��GBK,Ӧ���ǿ����õ�
            r = new InputStreamReader(is, "GBK");
            char[] buffer = new char[128];
            int length = -1;
            while ((length = r.read(buffer)) != -1) {
                sb.append(new String(buffer, 0, length));
            }
            return sb.toString();
        } catch (Exception ex) {
            Logger.getLogger(Util.class.getName()).log(Level.SEVERE, null, ex);
            return "";
        } finally {
            try {
                r.close();
            } catch (Exception ex) {
                Logger.getLogger(Util.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
    }

    /**
     * ����ת��00:00֮����ַ���
     * @param sec ����
     * @return �ַ���
     */
    public static String secondToString(int sec) {
        DecimalFormat df = new DecimalFormat("00");
        StringBuilder sb = new StringBuilder();
        sb.append(df.format(sec / 60)).append(":").append(df.format(sec % 60));
        return sb.toString();
    }

    /**
     * �õ�URL������,�����ֻ�ްٶ�ʹ��
     * @param url URL
     * @return ����,������NULL
     * @throws java.lang.Exception
     */
    private static String getURLContent(String url) throws IOException {
        HttpClient http = new HttpClient();
        Config config = Config.getConfig();
        if (config.isUseProxy()) {
            if (config.getProxyUserName() != null && config.getProxyPwd() != null) {
                http.getState().setProxyCredentials(
                        new AuthScope(config.getProxyHost(), Integer.parseInt(config.getProxyPort())),
                        new UsernamePasswordCredentials(config.getProxyUserName(), config.getProxyPwd()));
            }
            http.getHostConfiguration().setProxy(config.getProxyHost(),
                    Integer.parseInt(config.getProxyPort()));
        }
        http.getParams().setContentCharset("GBK");
        GetMethod get = new GetMethod();
        URI uri = new URI(url, false, "GBK");
        get.setURI(uri);
        http.executeMethod(get);
        System.out.println(get.getResponseCharSet());
        Header[] hs = get.getResponseHeaders();
        for (Header h : hs) {
            System.out.print(h);
        }
        return getString(get.getResponseBodyAsStream());

    }

    /**
     * �õ��ڰٶ����������ĸ�ʵ�����
     * @param key �ؼ�����
     * @return ����
     * @throws java.lang.Exception
     */
    private static String getBaidu_Lyric(String key) throws Exception {
        HttpClient http = new HttpClient();
        Config config = Config.getConfig();
        if (config.isUseProxy()) {
            if (config.getProxyUserName() != null && config.getProxyPwd() != null) {
                http.getState().setProxyCredentials(
                        new AuthScope(config.getProxyHost(), Integer.parseInt(config.getProxyPort())),
                        new UsernamePasswordCredentials(config.getProxyUserName(), config.getProxyPwd()));
            }
            http.getHostConfiguration().setProxy(config.getProxyHost(),
                    Integer.parseInt(config.getProxyPort()));
        }
        http.getParams().setContentCharset("GBK");
        GetMethod get = new GetMethod("http://www.baidu.com/s?wd=" + URLEncoder.encode("filetype:lrc " + key, "GBK"));
        get.addRequestHeader("Host", "www.baidu.com");
        get.addRequestHeader("User-Agent", "Mozilla/5.0 (Windows; U; Windows NT 5.1; zh-CN; rv:1.8.1.11) Gecko/20071127 Firefox/2.0.0.11");
        get.addRequestHeader("Accept", "text/xml,application/xml,application/xhtml+xml,text/html;q=0.9,text/plain;q=0.8,image/png,*/*;q=0.5");
        get.addRequestHeader("Accept-Language", "zh-cn,zh;q=0.5");
        get.addRequestHeader("Keep-Alive", "300");
        get.addRequestHeader("Referer", "http://www.baidu.com/");
        get.addRequestHeader("Connection", "keep-alive");
        int i = http.executeMethod(get);
        String temp = getString(get.getResponseBodyAsStream());
        get.releaseConnection();
//        System.out.println("TEMP="+temp);
//        Matcher m = Pattern.compile("(?<=<b>��LRC��</b>).*?(?=�ļ���ʽ)").matcher(temp);
//        Matcher m = Pattern.compile("(?<='\\)\" href=\").*?(?=\" target=\"_blank\"><font size=\"3\">)").matcher(temp);
        Matcher m = Pattern.compile("(?<=LRC/Lyric - <a href=\").*?(?=\" target=\"_blank\">HTML��</a>)").matcher(temp);
        String content = null;
        if (m.find()) {
            String str = m.group();
            content = Util.getURLContent(str);
            m = Pattern.compile("(?<=<body>).*?(?=</body>)").matcher(content);
            if (m.find()) {
                content = m.group();
            }
        }
        return htmlTrim2(content);
    }

    /**
     * ȥ��HTML���
     * @param str1 ����HTML��ǵ��ַ���
     * @return ȥ��������ַ���
     */
    public static String htmlTrim(String str1) {
        String str = "";
        str = str1;
        //�޳���<html>�ı�ǩ
        str = str.replaceAll("</?[^>]+>", "");
        //ȥ���ո�
        str = str.replaceAll("\\s", "");
        str = str.replaceAll("&nbsp;", "");
        str = str.replaceAll("&amp;", "&");
        str = str.replace(".", "");
        str = str.replace("\"", "��");
        str = str.replace("'", "��");
        return str;
    }

    private static String htmlTrim2(String str1) {
        String str = "";
        str = str1;
        //�޳���<html>�ı�ǩ
        str = str.replaceAll("<BR>", "\n");
        str = str.replaceAll("<br>", "\n");
        str = str.replaceAll("</?[^>]+>", "");
        return str;
    }

    /**
     * �Ӱٶ�ȥ�������
     * @param info ������
     * @return ������ݣ�����ΪNULL
     */
    private static String getLyricBaidu(PlayListItem info) {
        try {
            //��ȫ��ƥ��
            String song = info.getTitle();
            String name = info.getFormattedName();
            String s = getBaidu_Lyric(name);
            if (s == null) {
                s = getBaidu_Lyric(song);
                return s;
            } else {
                return s;
            }
        } catch (Exception ex) {
            return null;
        }
    }

    static enum Test {

        Album, TITLE;
    }

    public static void main(String[] args) throws Exception {
        System.out.println(htmlTrim2(Util.getBaidu_Lyric("��Ρ ��һ��")));

    }
}

