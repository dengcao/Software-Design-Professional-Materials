/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package com.hadeslee.yoyoplayer.playlist;

import javax.swing.JLabel;
import javax.swing.plaf.LabelUI;

/**
 *
 * @author hadeslee
 */
public class YOYOLabel extends JLabel {

    private static final long serialVersionUID = 20071214L;
    private PlayListItem item;//Ҫ������Ŀ 
    private int index;//Ҫ�����±�
    private boolean isSelected;//�Ƿ�ѡ����
    private boolean hasFocus;//�Ƿ����˽���
    private boolean uiseted;//UI�Ƿ��Ѿ�����
    private int itemCount;//Ҫ������Ŀ������
    public YOYOLabel() {
        this.setUI(new YOYOLabelUI(this));
        uiseted = true;
    }

    public boolean isHasFocus() {
        return hasFocus;
    }

    public void setHasFocus(boolean hasFocus) {
        this.hasFocus = hasFocus;
    }

    public int getItemCount() {
        return itemCount;
    }

    public void setItemCount(int itemCount) {
        this.itemCount = itemCount;
    }
    
    @Override
    public void setUI(LabelUI ui) {
        if (!uiseted) {
            super.setUI(new YOYOLabelUI(this));
        }
    }

    public void setPlayListItem(PlayListItem item) {
        this.item = item;
    }

    public PlayListItem getPlayListItem() {
        return item;
    }

    public int getIndex() {
        return index;
    }

    public void setIndex(int index) {
        this.index = index;
    }

    public boolean getIsSelected() {
        return isSelected;
    }

    public void setIsSelected(boolean hasFocus) {
        this.isSelected = hasFocus;
    }
}
