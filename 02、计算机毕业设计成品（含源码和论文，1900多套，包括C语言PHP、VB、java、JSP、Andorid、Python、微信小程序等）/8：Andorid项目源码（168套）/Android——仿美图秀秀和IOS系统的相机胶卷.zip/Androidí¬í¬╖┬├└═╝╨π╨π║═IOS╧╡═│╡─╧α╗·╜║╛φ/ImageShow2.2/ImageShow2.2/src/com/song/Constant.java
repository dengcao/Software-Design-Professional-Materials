package com.song;

import com.song.util.AsyncImageLoader;

public class Constant {
	
	public static AsyncImageLoader loader = new AsyncImageLoader(); 
	public static int width = 80;
	public static int height = 80;
	public static int max = 9;

}
