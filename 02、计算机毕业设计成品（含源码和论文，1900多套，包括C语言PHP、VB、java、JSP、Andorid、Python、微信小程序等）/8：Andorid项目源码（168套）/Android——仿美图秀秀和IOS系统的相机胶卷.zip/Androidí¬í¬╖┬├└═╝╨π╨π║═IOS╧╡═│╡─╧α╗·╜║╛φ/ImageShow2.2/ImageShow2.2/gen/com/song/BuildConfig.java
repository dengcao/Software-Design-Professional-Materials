/** Automatically generated file. DO NOT MODIFY */
package com.song;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}