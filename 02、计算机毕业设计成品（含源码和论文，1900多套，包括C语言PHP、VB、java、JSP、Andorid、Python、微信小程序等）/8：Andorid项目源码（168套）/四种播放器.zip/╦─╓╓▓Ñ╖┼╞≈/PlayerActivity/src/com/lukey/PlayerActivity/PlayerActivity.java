package com.lukey.PlayerActivity;

import java.io.File;
import java.io.FilenameFilter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.media.MediaPlayer;
import android.media.MediaPlayer.OnCompletionListener;
import android.os.Bundle; 
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnTouchListener;
import android.view.ViewGroup.LayoutParams;
import android.view.animation.AnimationUtils;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.GridView;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.SeekBar;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ViewFlipper;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class PlayerActivity extends Activity {
    /** Called when the activity is first created. */
	Context context = this;
	private SeekBar timeBar;
	/** �ײ��˵� **/
	private TextView textView,timeTextView;
	private GridView menuGridView;
	/** �ײ��˵����� **/
	private String [] menu_toolbar = { "����", "��һ��", "��һ��", "ֹͣ", "����" };
	/** �ײ��˵�ͼƬ **/
	private int [] pic_toolbar = { R.drawable.play, 
			 R.drawable.last,R.drawable.next, 
			R.drawable.stop, R.drawable.sound_on};
	/** �����˵� **/
	private GridView topGridView;
	/** �����˵����� **/
	private String[] top_toolbar = { "ѡ��", "ģʽ", "����","����" ,"����"};
	private ArrayAdapter<String> grid_Adapter,list_Adapter;
	/** �����б� **/
	private ListView listView;
	private List<String> music_list = new ArrayList<String>();
	/** ���ڲ��ŵ���Ŀ��Ĭ��ֵ0��һ��**/
	private int nowPlayId = 0;
	/**����������**/
	MediaPlayer player = new MediaPlayer();;
	SeekBarThread seekTh;
	private int volumeSize = 60;
	public static boolean set_vl = false;	
	public  boolean startplay = false;
	float stime,ctime;
	private RefreshHandler myHandler = new RefreshHandler();
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
		findSdCardMuisc();
		init_body();
        init_toptoolbar();
        init_downtoolbar();
        seektoplay();
    }
	private void init_toptoolbar() {
		// TODO Auto-generated method stub
		topGridView = (GridView)findViewById(R.id.GridView_top);
		topGridView.setBackgroundResource(R.drawable.top_bg);
		topGridView.setNumColumns(5);
		topGridView.setGravity(Gravity.CENTER);
        grid_Adapter = new ArrayAdapter<String>(this, R.layout.toptext, top_toolbar);
        topGridView.setAdapter(grid_Adapter);
        topGridView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				switch (arg2) {
				case Data.TOP_OPTION://ѡ��
					
					break;
				case Data.TOP_MODE://ģʽ

					break;
				case Data.TOP_SET://����

					break;
				case Data.TOP_NET://����

					break;
				case Data.TOP_OTHER://����
					
					break;
				}
			}
		});
	}
	private void init_downtoolbar() {
		// TODO Auto-generated method stub
		textView = (TextView)findViewById(R.id.play_news);
		timeTextView = (TextView)findViewById(R.id.nowtime);
		menuGridView = (GridView)findViewById(R.id.GridView_tool);
		menuGridView.setNumColumns(5);// ����ÿ������
		menuGridView.setGravity(Gravity.CENTER);// λ�þ���
		menuGridView.setAdapter(getMenuAdapter(menu_toolbar,
				pic_toolbar));
		menuGridView.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				switch (arg2) {
				case Data.DOWN_PLAY://����
					if(pic_toolbar[0] != R.drawable.pause && menu_toolbar[0] != "��ͣ"){
						if(startplay = false){
							play();
						}else{
							pause();
						}
						pic_toolbar[0] = R.drawable.pause;
						menu_toolbar[0] = "��ͣ";
					}
					else{
						pause();
						pic_toolbar[0] = R.drawable.play;
						menu_toolbar[0] = "����";
					}
					break;
				case Data.DOWN_LAST://��һ��
					last();
					break;
				case Data.DOWN_NEXT://��һ��
					next();
					break;
				case Data.DOWN_STOP://ֹͣ
					stop();
					pic_toolbar[0] = R.drawable.play;
					menu_toolbar[0] = "����";
					break;
				case Data.DOWN_VOLUME://����		
					volume();
					break;
				}
				init_downtoolbar();
			}
		});
		timeBar = (SeekBar) findViewById(R.id.SeekBar);
	}	
	/**
	 * ����˵�Adapter
	 * 
	 * @param menuNameArray
	 *            ����
	 * @param imageResourceArray
	 *            ͼƬ
	 * @return SimpleAdapter
	 */
	private SimpleAdapter getMenuAdapter(String[] menuNameArray,
			int[] imageResourceArray) {
		ArrayList<HashMap<String, Object>> data = new ArrayList<HashMap<String, Object>>();
		for (int i = 0; i < menuNameArray.length; i++) {
			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put("itemImage", imageResourceArray[i]);
			map.put("itemText", menuNameArray[i]);
			data.add(map);
		}
		SimpleAdapter simperAdapter = new SimpleAdapter(this, data,
				R.layout.item_menu, new String[] { "itemImage", "itemText" },
				new int[] { R.id.item_image, R.id.item_text });
		return simperAdapter;
	}

	private void findSdCardMuisc() {
		// TODO Auto-generated method stub
		File muiscFile = new File("/sdcard/");
		//�ж�sd���������ļ�
		if(muiscFile.listFiles().length > 0){
    		for(File file:muiscFile.listFiles(new MusicFilter()))
    		{
    			//ȥ���ļ���ʽ��׺
    			//String music = file.getName().substring(0, file.getName().length()-4);			
    			music_list.add(file.getName());
    		}
		}
		else{
			Toast.makeText(context,R.string.sdcardnull, Toast.LENGTH_SHORT).show();
		}
	} 
	private void init_body() {
		// TODO Auto-generated method stub
		listView = (ListView)findViewById(R.id.ListView);
		list_Adapter = new ArrayAdapter<String>(this, R.layout.bodytext, music_list);
		list_Adapter.setDropDownViewResource(android.R.layout.simple_list_item_checked);
		listView.setAdapter(list_Adapter); 
		listView.setOnItemClickListener(new OnItemClickListener() {

			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				// TODO Auto-generated method stub
				nowPlayId = arg2;
				play();
			}
		});
	}
	//�ļ����͹�����
    class MusicFilter implements FilenameFilter
	{
		public boolean accept(File dir, String name) 
		{
			//���ﻹ��������������ʽ�������ļ�
			return (name.endsWith(".mp3"));
		} 
	}
    public void play()//����ָ��·��������
    {
    	try 
    	{
    		player.reset();
			player.setDataSource("/sdcard/"+music_list.get(nowPlayId));
			player.prepare();
			player.start();
			seekTh = new SeekBarThread();
			seekTh.start();//����ͬ�����������߳�
            startplay = true;
            listView.setSelected(true);
			textView.setTextColor(Color.WHITE);
			textView.setText("���ڲ��ţ�"+music_list.get(nowPlayId));
			//Log.i("play", textView.getText()+"");
		} catch (IllegalArgumentException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IllegalStateException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (IOException e) 
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		player.setOnCompletionListener(new OnCompletionListener() 
		{
			public void onCompletion(MediaPlayer arg0)
			{
				//�������һ��֮�������һ��
				next();
			}
		});
    }
    public void pause()
    {
    	if(player!=null){
        	if(player.isPlaying())
        	{
        		player.pause();
    			textView.setTextColor(Color.WHITE);
    			textView.setText("����ͣ��"+music_list.get(nowPlayId));
        		
        	}
        	else
        	{
        		player.start();
    			textView.setTextColor(Color.WHITE);
    			textView.setText("���ڲ��ţ�"+music_list.get(nowPlayId));
        	}
    	}
    }
    
    public void stop()
    {
    	if(player!=null)
    	{
    	    player.stop();
			textView.setTextColor(Color.LTGRAY);
			textView.setText(R.string.stop_Play);
			startplay = false;
    	}
    }
    
    public void last()
    {
    	if(--nowPlayId<0)
    		nowPlayId = music_list.size()-1;
    	play();
    }
    
    public void next()
    {
    	if(++nowPlayId>=music_list.size())
    		nowPlayId = 0;
    	play();
    }
	private void volume() {
		// TODO Auto-generated method stub
		 Intent myIntent = new Intent();
		 myIntent.setClass(PlayerActivity.this, M_Volume.class);
		 
		 Bundle myBundle = new Bundle();
		 myBundle.putInt("music_volume", volumeSize);
		 
		 myIntent.putExtras(myBundle);
		 startActivity(myIntent);
	}
    public void seektoplay()//�����϶����¼�
    {
    	timeBar.setOnTouchListener(new OnTouchListener(){

			public boolean onTouch(View v, MotionEvent event) 
			{
				float c = timeBar.getProgress();
				int d  = player.getDuration();
				int a = (int) (d*(c/10000.0));	
				player.seekTo(a); 
				return false;
			}});
    }
    class SeekBarThread extends Thread
    {
    	public void run()
    	{
    		
    		while(true)
    		{  
    			try {
					sleep(500);
					if(player.isPlaying()){
						stime = player.getDuration();//���Ž���
						ctime = player.getCurrentPosition();//��ʱ��
						int sc = (int) (10000*(ctime/stime));
						Message msg = new Message();
						msg.what = 0;
						myHandler.sendMessage(msg);
						timeBar.setProgress(sc);
					}
				} catch (InterruptedException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
    		}
    	}
    }
	@Override
	protected void onResume() {
		// TODO Auto-generated method stub
		super.onResume();
		set_Volume();
	}
	private void set_Volume() {
		// TODO Auto-generated method stub
		Bundle newBundle = this.getIntent().getExtras();
		if(set_vl){
			volumeSize = newBundle.getInt("new_volume");
			//player.setVolume(leftVolume, rightVolume);
			Toast.makeText(context,R.string.v_set, Toast.LENGTH_SHORT).show(); 
		}
		if(volumeSize == 0){
			pic_toolbar[4] = R.drawable.sound_off;
		}
		else{
			pic_toolbar[4] = R.drawable.sound_on;
		}
		init_downtoolbar();
	}
	class RefreshHandler extends Handler {
		@Override
		public void handleMessage(Message msg) {
			timeTextView.setText(timeConvert((int)ctime)+"��������������������������������"+timeConvert((int)stime));
		}
	}
	private String timeConvert(int time) {
		// TODO Auto-generated method stub
		int cm = time/1000;
		String m = (cm / 60)+"";
		String s = (cm % 60)+"";
		return (format(m)+":"+format(s));
	}
	private String format(String m) {
		// TODO Auto-generated method stub
		if(m.length() == 1){
			m = "0"+ m ;
		}
		return m;
	}
}