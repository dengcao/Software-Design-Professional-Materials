package com.lukey.PlayerActivity;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.SeekBar.OnSeekBarChangeListener;

public class M_Volume extends Activity {
	Context context = this;
    SeekBar myBar;
    TextView myView;
    Bundle  bundle,reBundle;
    int volume;
    Button myButtonOK,myButtonCAL;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
        setContentView(R.layout.volume);
        initUI();
        action();
        bottonclick();
	}
	private void bottonclick() {
		// TODO Auto-generated method stub
		myButtonOK.setOnClickListener(new OnClickListener() {
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				 Intent myIntent = new Intent();
				 myIntent.setClass(M_Volume.this,PlayerActivity.class);
				 
				 reBundle = new Bundle();
				 reBundle.putInt("new_volume", myBar.getProgress());
				 
				 myIntent.putExtras(reBundle);
				 startActivity(myIntent);
				 finish();
			}
		});
		myButtonCAL.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View v) {
				// TODO Auto-generated method stub
				 Intent myIntent = new Intent();
				 myIntent.setClass(M_Volume.this,PlayerActivity.class);
				 startActivity(myIntent);
				 PlayerActivity.set_vl = false;
				 finish();
			}
		});
	}
	private void action() {
		// TODO Auto-generated method stub
		myBar.setOnSeekBarChangeListener(new OnSeekBarChangeListener() {
			
			@Override
			public void onStopTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
			}
			
			@Override
			public void onStartTrackingTouch(SeekBar seekBar) {
				// TODO Auto-generated method stub
				
			}
			
			@Override
			public void onProgressChanged(SeekBar seekBar, int progress,
					boolean fromUser) {
				// TODO Auto-generated method stub
				myView.setText(myBar.getProgress()+"");
			}
		});
	}
	private void initUI() {
		// TODO Auto-generated method stub
		myButtonCAL = (Button)findViewById(R.id.Button_cal);
		myButtonOK = (Button)findViewById(R.id.Button_ok);
		bundle = this.getIntent().getExtras();
		volume = bundle.getInt("music_volume");
		myBar = (SeekBar)findViewById(R.id.SeekBar_volume);
		myBar.setProgress(volume);
		myView = (TextView)findViewById(R.id.TextView_v);
		myView.setText(volume+"");	
		PlayerActivity.set_vl = true;
	}

}
