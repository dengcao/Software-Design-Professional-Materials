package com.Aina.Android;

public class lrcObject {
	   public int begintime;
	   public int endtime;
	   public int timeline;
	   public String lrc;
}