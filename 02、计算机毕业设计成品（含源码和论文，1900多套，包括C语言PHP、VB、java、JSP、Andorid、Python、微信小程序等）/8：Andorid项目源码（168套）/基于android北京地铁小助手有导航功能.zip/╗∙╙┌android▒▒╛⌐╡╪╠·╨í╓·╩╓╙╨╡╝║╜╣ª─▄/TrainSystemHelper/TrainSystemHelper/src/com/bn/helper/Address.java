package com.bn.helper;

public class Address 
{
   public String jdStr;
   public String wdStr;
   public String msgStr;
   public String listStr;
   
   public Address(String jdStr,String wdStr,String msgStr,String listStr)
   {
	   this.jdStr=jdStr;
	   this.wdStr=wdStr;
	   this.msgStr=msgStr;
	   this.listStr=listStr;
   }
}
