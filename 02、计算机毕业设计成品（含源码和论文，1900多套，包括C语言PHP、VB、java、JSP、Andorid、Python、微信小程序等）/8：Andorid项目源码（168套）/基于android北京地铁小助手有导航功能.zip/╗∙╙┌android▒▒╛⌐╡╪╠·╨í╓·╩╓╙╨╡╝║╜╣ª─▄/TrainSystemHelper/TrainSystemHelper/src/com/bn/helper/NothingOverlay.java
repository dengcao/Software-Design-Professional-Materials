package com.bn.helper;

import com.google.android.maps.Overlay;

public class NothingOverlay extends Overlay{
		//nothing
}
