package cn.tongcard.activity;

import android.app.Activity;
import android.view.KeyEvent;

public class BaseActivity extends Activity{

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if(keyCode == KeyEvent.KEYCODE_BACK){
			return ((BaseGroup)getParent()).onKeyDown(keyCode, event);
		}
		return super.onKeyDown(keyCode, event);
	}

	
}
