package cn.tongcard.activity;

import cn.tongcard.activity.R;
import cn.tongcard.tongcard.constant.TongCardConstant.TabIds;
import cn.tongcard.tongcard.view.TabBtnAdapter;
import android.app.TabActivity;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.TabHost;
import android.widget.AdapterView.OnItemClickListener;

public class LoginSucActivity extends TabActivity{

	private TabHost mHost;
	private GridView gvTopBar;
	private TabBtnAdapter topImgAdapter;
	/** ������ťͼƬ **/
	int[] imgIds = { R.drawable.ic_menu_share,
			R.drawable.ic_menu_share, R.drawable.ic_menu_share};
	int[] strIds = {R.string.tab_card,R.string.tab_msg,R.string.tab_more};
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.login_suc);
		fillViews();
		setupIntent();
		SwitchActivity(0);
	}

	private void fillViews(){
		gvTopBar = (GridView) this.findViewById(R.tab.gridview);
		gvTopBar.setNumColumns(imgIds.length);// ����ÿ������
		gvTopBar.setSelector(new ColorDrawable(Color.TRANSPARENT));// ѡ�е�ʱ��Ϊ͸��ɫ
		gvTopBar.setGravity(Gravity.CENTER);// λ�þ���
		gvTopBar.setVerticalSpacing(0);// ��ֱ���
		int width = this.getWindowManager().getDefaultDisplay().getWidth()
				/ imgIds.length;
		topImgAdapter = new TabBtnAdapter(this, imgIds, width, 30, R.drawable.tab_sel_top, strIds);
		gvTopBar.setAdapter(topImgAdapter);
		gvTopBar.setOnItemClickListener(new ItemClickEvent());// ��Ŀ����¼�
	}

	
	 private void setupIntent() {
	        this.mHost = getTabHost();
	        TabHost localTabHost = this.mHost;
	        localTabHost.addTab(buildTabSpec(TabIds.TAB_CARD, R.string.tab_card,
	        		new Intent(this,TabCardGroup.class)/*.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)*/));
	        localTabHost.addTab(buildTabSpec(TabIds.TAB_MSG, R.string.tab_msg,
	        		new Intent(this,TabMsgGroup.class)/*.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP)*/));


	    }
	 private TabHost.TabSpec buildTabSpec(String tag, int resLabel, 
	            final Intent content) {
	        return this.mHost
	                .newTabSpec(tag)
	                .setIndicator(getString(resLabel))
	                .setContent(content);
	    }
	 
	 class ItemClickEvent implements OnItemClickListener {
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				SwitchActivity(arg2);
			}
		}
	 
	 void SwitchActivity(int id) {
			topImgAdapter.SetFocus(id);
			switch (id) {
			case 0:
				this.mHost.setCurrentTabByTag(TabIds.TAB_CARD);
				break;
			case 1:
				this.mHost.setCurrentTabByTag(TabIds.TAB_MSG);
				break;
			case 2:
				this.mHost.setCurrentTabByTag(TabIds.TAB_MORE);
				break;
			}
			
		}
}
