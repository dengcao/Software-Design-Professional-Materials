package cn.tongcard.tongcard.domain;

public class Coupon {

	private String id;
	private Float cost;

	public Coupon(String id, Float cost) {
		super();
		this.id = id;
		this.cost = cost;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public Float getCost() {
		return cost;
	}

	public void setCost(Float cost) {
		this.cost = cost;
	}
}
