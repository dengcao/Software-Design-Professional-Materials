package cn.tongcard.tongcard.constant;

public class TongCardConstant {

	public static class TabIds{
		public static final String TAB_CARD = "tab_card";
		public static final String TAB_MSG = "tab_msg";
		public static final String TAB_MORE = "tab_more";
		public static final String TAB_CARD_PREBIND = "pre_bind";
		public static final String TAB_CARD_BIND = "bind";
		public static final String TAB_CARD_FIRSTBIND = "first_bind";
		public static final String TAB_CARD_SINGLECARD = "single_card";
		public static final String TAB_CARD_TRANSLIST = "trans_list";
		public static final String TAB_CARD_MUTIPLECARD = "mutiple_card";
		public static final String TAB_CARD_TRANS_PAY = "trans_pay";
		public static final String TAB_CARD_TRANS_GRADE = "trans_grade";
		public static final String TAB_CARD_TRANS_GRADE_SUC = "trans_grade_suc";
		public static final String TAB_CARD_TRANS_RAFFLE = "trans_raffle";
		public static final String TAB_CARD_TRANS_DETAIL = "trans_detail";
		public static final String TAB_MSG_LIST = "msg_list";
		public static final String TAB_MORE_MAIN = "more_main";
		public static final String TAB_MORE_UNAME = "more_uname";
		public static final String TAB_MORE_ALIAS = "more_alias";
		public static final String TAB_MORE_SHARE = "more_share";
		public static final String TAB_MORE_SHARE_ACCOUNT = "more_share_account";
	}
	
	public static class IntentFlags{
		public static final String FLAG_REGIST = "regist";
		public static final String FLAG_RETREIVE = "retrieve";
		public static final String FLAG_BIND = "bind";
	}
	public static class MessageFlag{
		public static final int MSG_DATA_FINISH = 1;
	}
}
