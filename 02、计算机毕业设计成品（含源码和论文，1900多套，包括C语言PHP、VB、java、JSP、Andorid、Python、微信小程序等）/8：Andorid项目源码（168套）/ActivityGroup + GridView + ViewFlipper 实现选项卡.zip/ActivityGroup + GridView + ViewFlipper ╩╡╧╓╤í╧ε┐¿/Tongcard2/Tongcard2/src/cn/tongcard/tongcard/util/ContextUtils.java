package cn.tongcard.tongcard.util;

import android.content.Context;

public class ContextUtils {

	public static String getString(Context context,int id){
		return context.getResources().getString(id);
	}
	
	public static String[] getStrings(Context context,int[] ids){
		String[] strings = new String[ids.length];
		for(int i = 0;i < ids.length;i++){
			strings[i] = getString(context, ids[i]);
		}
		return strings;
	}
}
