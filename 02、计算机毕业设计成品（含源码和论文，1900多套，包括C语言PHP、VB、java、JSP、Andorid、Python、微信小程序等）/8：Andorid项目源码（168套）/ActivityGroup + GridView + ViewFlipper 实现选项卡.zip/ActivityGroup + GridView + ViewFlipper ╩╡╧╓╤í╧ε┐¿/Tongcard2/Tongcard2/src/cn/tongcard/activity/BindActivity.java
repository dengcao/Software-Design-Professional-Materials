package cn.tongcard.activity;


import cn.tongcard.tongcard.constant.TongCardConstant.IntentFlags;
import cn.tongcard.tongcard.constant.TongCardConstant.TabIds;
import cn.tongcard.tongcard.domain.Card;
import cn.tongcard.tongcard.service.CardService;
import cn.tongcard.tongcard.util.ValidateUtils;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.WindowManager;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;

public class BindActivity extends BaseActivity implements OnClickListener{

	private LinearLayout aliasLayout;
	private Button bindBtn;
	private Button cancelBtn;
	private EditText phoneText;
	private EditText cardText;
	private EditText codeText;
	private EditText aliasText;
	public static final int FLAG_INTENT_FIRSTBIND = 10;
	private static final String TAG = "BindActivity";
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.bind);
		fillViews();
		ajustViews();
	}
	
	
	private void ajustViews() {
		if(getIntent().getIntExtra(IntentFlags.FLAG_BIND, 0) != FLAG_INTENT_FIRSTBIND){
			aliasLayout.setVisibility(View.GONE);
			cancelBtn.setVisibility(View.VISIBLE);
		}
	}
	private void fillViews() {
		
		aliasLayout = (LinearLayout) findViewById(R.bind.aliasLayout);
		
		phoneText = (EditText) findViewById(R.bind.phone);
		cardText = (EditText) findViewById(R.bind.card);
		codeText = (EditText) findViewById(R.bind.code);
		aliasText = (EditText) findViewById(R.bind.alias);
		
		bindBtn = (Button) findViewById(R.bind.bind);
		cancelBtn = (Button) findViewById(R.bind.cancel);
		bindBtn.setOnClickListener(this);
		cancelBtn.setOnClickListener(this);
	}
	@Override
	public void onClick(View v) {
		if(v.getId() == R.bind.bind){
			String phone = phoneText.getText().toString();
			String cardId = cardText.getText().toString();
			String code = codeText.getText().toString();
			String alias = aliasText.getText().toString();
			if(getIntent().getIntExtra(IntentFlags.FLAG_BIND, 0) == FLAG_INTENT_FIRSTBIND){
				if(!ValidateUtils.isNull(this, new int[]{R.string.phone,R.string.card,R.string.code,R.string.alias}
						,new String[]{phone,cardId,code,alias})){
					Intent intent = new Intent(this,SingleCardActivity.class);
					CardService service = new CardService();
					Card c = service.getCardById(cardId);
					Bundle extras = new Bundle();
					extras.putSerializable("card", c);
					intent.putExtras(extras);
					((TabCardGroup)getParent()).switchActivity(TabIds.TAB_CARD_SINGLECARD,intent,R.anim.push_left_in,R.anim.push_left_out);
				}
			}else{
				if(!ValidateUtils.isNull(this, new int[]{R.string.phone,R.string.card,R.string.code}
						,new String[]{phone,cardId,code})){
//					Intent intent = new Intent(this,MutipleCardActivity.class);
//					((TabCardGroup)getParent()).switchActivity(TabIds.TAB_CARD_MUTIPLECARD,intent);
				}
			}
		}else if(v.getId() == R.bind.cancel){
			((TabCardGroup)getParent()).back();
		}
		
	}
}
