package cn.tongcard.tongcard.domain;

import cn.tongcard.activity.R;
import cn.tongcard.tongcard.util.ContextUtils;
import android.content.Context;

public class CouponItem {


	private Coupon coupon;
	private Integer sum;

	public Coupon getCoupon() {
		return coupon;
	}

	public void setCoupon(Coupon coupon) {
		this.coupon = coupon;
	}

	public Integer getSum() {
		return sum;
	}

	public void setSum(Integer sum) {
		this.sum = sum;
	}

	public CouponItem(Coupon coupon, Integer sum) {
		super();
		this.coupon = coupon;
		this.sum = sum;
	}
	public String buildExpress(Context context){
		return buildCardExpress(context) + " " + buildCostExpress(context);
	}
	//60Ԫ����ȯ1
	public String buildCardExpress(Context context){
		StringBuilder builder = new StringBuilder();
		builder.append(coupon.getCost());
		builder.append(ContextUtils.getString(context, R.string.rmb));
		builder.append(ContextUtils.getString(context, R.string.trans_coupon));
		builder.append(sum);
		builder.append(ContextUtils.getString(context, R.string.trans_pay_zhang));
		return builder.toString();
	}
	//60Ԫ
	public String buildCostExpress(Context context){
		StringBuilder builder = new StringBuilder();
		builder.append(ContextUtils.getString(context, R.string.trans_pay_di));
		builder.append(sum * coupon.getCost());
		builder.append(ContextUtils.getString(context, R.string.rmb));
		return builder.toString();
	}
}
