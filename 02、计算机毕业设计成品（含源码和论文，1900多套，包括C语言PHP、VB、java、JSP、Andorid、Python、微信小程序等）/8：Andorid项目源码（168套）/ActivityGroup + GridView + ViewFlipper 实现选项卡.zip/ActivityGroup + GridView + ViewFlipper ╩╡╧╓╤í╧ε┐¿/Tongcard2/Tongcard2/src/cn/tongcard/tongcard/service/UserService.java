package cn.tongcard.tongcard.service;

import cn.tongcard.tongcard.domain.User;

public class UserService {

	public static User user;
	
	
	public static User getUser(){
		user = new User();
		user.setUsername("yanhj@sina.com");
		user.setAlias("���ͷ");
		return user;
	}
	public static void clearUser(){
		user = null;
	}
}
