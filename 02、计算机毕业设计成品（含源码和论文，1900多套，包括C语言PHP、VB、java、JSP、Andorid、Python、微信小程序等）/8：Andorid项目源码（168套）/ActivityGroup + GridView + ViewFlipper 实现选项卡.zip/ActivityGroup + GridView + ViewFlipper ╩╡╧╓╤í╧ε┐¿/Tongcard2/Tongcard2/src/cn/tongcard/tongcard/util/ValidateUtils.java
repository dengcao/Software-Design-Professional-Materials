package cn.tongcard.tongcard.util;

import cn.tongcard.activity.R;
import android.content.Context;
import android.text.TextUtils;
import android.widget.Toast;

public class ValidateUtils {

	public static boolean isNull(Context context, int label, String content) {
		if (content != null && TextUtils.isEmpty(content.trim())) {
			showToast(context, ContextUtils.getString(context, label)
					+ ContextUtils
							.getString(context, R.string.validate_notnull));
			return true;
		}
		return false;
	}

	private static void showToast(Context context, String str) {
		Toast.makeText(context, str, Toast.LENGTH_SHORT).show();
	}
	
	public static boolean isNull(Context context,int[] labels,String[] contents){
		if(labels.length != contents.length)
			throw new IllegalArgumentException(ContextUtils.getString(context, R.string.exception_arg_length_not_equal));
		for(int i = 0;i < labels.length;i++){
			if(isNull(context, labels[i], contents[i]))
				return true;
		}
		return false;
	}
}
