package cn.tongcard.tongcard.view;

import cn.tongcard.activity.R;
import android.content.Context;
import android.util.Log;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;


	public class TabBtnAdapter extends BaseAdapter {
		private static final String TAG = "TabBtnAdapter";
		private Context mContext;
		private int selResId;
		private int[] txIds;
		private LinearLayout[] layouts;
		
		public TabBtnAdapter(Context c, int[] picIds, int width, int height,
				int selResId,int[] textIds) {
			mContext = c;
			this.selResId = selResId;
			this.txIds = textIds;
			layouts = new LinearLayout[picIds.length];
			for (int i = 0; i < textIds.length; i++) {
				layouts[i] = new LinearLayout(mContext);
				layouts[i] = new LinearLayout(mContext);
				layouts[i].setOrientation(LinearLayout.VERTICAL);
				ImageView iv = new ImageView(mContext);
				Log.i(TAG, "imgItems["+ i + "] = " + iv.getClass());
				iv.setLayoutParams(new GridView.LayoutParams(width,height));
				iv.setAdjustViewBounds(false);
				iv.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
				iv.setPadding(1, 1, 1, 1);
				iv.setImageResource(picIds[i]);
				layouts[i].addView(iv);
				
				TextView tv = new TextView(mContext);
				tv.setText(txIds[i]);
				tv.setTextColor(R.color.white);
				tv.setGravity(Gravity.CENTER);
				layouts[i].addView(tv);
			}
		}

		public int getCount() {
			return layouts.length;
		}

		public Object getItem(int position) {
			return position;
		}

		public long getItemId(int position) {
			return position;
		}

		/**
		 * ����ѡ�е�Ч��
		 */
		public void SetFocus(int index) {
			Log.i(TAG, "position:" + index);
			for (int i = 0; i < layouts.length; i++) {
				if (i != index) {
					layouts[i].setBackgroundDrawable(null);// �ָ�δѡ�е���ʽ
				}
			}
			layouts[index].setBackgroundResource(selResId);// ����ѡ�е���ʽ
		}

		public View getView(int position, View convertView, ViewGroup parent) {
			LinearLayout layout;
			if(convertView == null){
				layout = layouts[position];
			}else{
				layout = (LinearLayout) convertView;
			}
			return layout;
		}
	}

