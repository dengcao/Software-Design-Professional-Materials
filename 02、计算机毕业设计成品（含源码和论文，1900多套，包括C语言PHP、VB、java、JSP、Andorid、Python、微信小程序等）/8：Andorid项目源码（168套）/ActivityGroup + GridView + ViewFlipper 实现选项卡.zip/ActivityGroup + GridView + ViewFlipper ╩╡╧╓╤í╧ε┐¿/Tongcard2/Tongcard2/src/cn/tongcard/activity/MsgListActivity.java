package cn.tongcard.activity;

import java.util.List;

import cn.tongcard.tongcard.domain.Message;
import cn.tongcard.tongcard.service.MessageService;
import cn.tongcard.tongcard.view.MsgListAdapter;
import android.app.Activity;
import android.os.Bundle;
import android.widget.ListView;

public class MsgListActivity extends BaseActivity{

	private ListView listView;
	private MsgListAdapter adapter;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.massage);
		fillViews();
	}

	private void fillViews(){
		listView = (ListView) findViewById(R.msg.listview);
		List<Message> data = new MessageService().getAllMsgs();
		adapter = new MsgListAdapter(this, data, R.layout.item_msg);
		listView.setAdapter(adapter);
	}
}
