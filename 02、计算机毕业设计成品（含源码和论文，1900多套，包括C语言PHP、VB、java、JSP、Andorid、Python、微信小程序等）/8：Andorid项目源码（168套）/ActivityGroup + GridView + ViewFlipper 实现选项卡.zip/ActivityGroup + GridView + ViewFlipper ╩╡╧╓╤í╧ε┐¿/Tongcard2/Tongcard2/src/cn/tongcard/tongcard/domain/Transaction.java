package cn.tongcard.tongcard.domain;

import java.util.List;

import cn.tongcard.activity.R;
import cn.tongcard.tongcard.util.ContextUtils;

import android.content.Context;

public class Transaction {

	private String id;// ���׺�
	private Grade grade;

	public Grade getGrade() {
		return grade;
	}

	public void setGrade(Grade grade) {
		this.grade = grade;
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	private Card card;// ����
	private String store;// ��Ӧ�ĵ���
	private String state;// ״̬
	private Float amount;// ���ѽ��
	private String useBalance;// ʹ��Ԥ��
	private String awardBalance;// ��õ�Ԥ��
	private String awardCoupon;// ����Ż�ȯ
	private String time;// ʱ��
	private Integer point;// �˱ʽ��׿ɻ�û���
	private List<CouponItem> coupons;

	public static final String STATE_NOT_PAY = "0";
	public static final String STATE_NOT_GRADE = "1";
	public static final String STATE_FINISH = "2";
	public static final String STATE_UNUSEABLE = "3";

	public List<CouponItem> getCoupons() {
		return coupons;
	}

	public void setCoupons(List<CouponItem> coupons) {
		this.coupons = coupons;
	}

	public String getTime() {
		return time;
	}

	public void setTime(String time) {
		this.time = time;
	}

	public Card getCard() {
		return card;
	}

	public void setCard(Card card) {
		this.card = card;
	}

	public String getStore() {
		return store;
	}

	public void setStore(String store) {
		this.store = store;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public Float getAmount() {
		return amount;
	}

	public void setAmount(Float amount) {
		this.amount = amount;
	}

	public String getUseBalance() {
		return useBalance;
	}

	public void setUseBalance(String useBalance) {
		this.useBalance = useBalance;
	}

	public String getAwardBalance() {
		return awardBalance;
	}

	public void setAwardBalance(String awardBalance) {
		this.awardBalance = awardBalance;
	}

	public Integer getPoint() {
		return point;
	}

	public void setPoint(Integer point) {
		this.point = point;
	}

	public String getAwardCoupon() {
		return awardCoupon;
	}

	public void setAwardCoupon(String awardCoupon) {
		this.awardCoupon = awardCoupon;
	}

	public String getRemain(Context context) {
		float total = this.amount;
		for (CouponItem item : this.coupons) {
			total -= item.getSum() * item.getCoupon().getCost();
		}
		total -= Integer.parseInt(useBalance);
		total -= card.getPoints();
		return total + ContextUtils.getString(context, R.string.rmb);
	}

	public boolean canView() {
		if (STATE_NOT_GRADE.equals(state) || STATE_FINISH.equals(state))
			return true;
		else
			return false;
	}

	public String buildCoupons(Context context) {
		StringBuilder builder = new StringBuilder();
		for (CouponItem item : coupons) {
			builder.append(item.buildCardExpress(context));
			builder.append("\n");
		}
		builder.deleteCharAt(builder.length() - 1);
		return builder.toString();
	}
}
