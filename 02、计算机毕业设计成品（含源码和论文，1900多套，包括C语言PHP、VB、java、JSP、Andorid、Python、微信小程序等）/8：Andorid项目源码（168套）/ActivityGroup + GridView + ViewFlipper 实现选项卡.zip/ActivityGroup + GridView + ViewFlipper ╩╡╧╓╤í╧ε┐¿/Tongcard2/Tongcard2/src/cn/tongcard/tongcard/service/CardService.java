package cn.tongcard.tongcard.service;

import cn.tongcard.tongcard.domain.Card;

public class CardService {

	public Card getCardById(String id){
		Card c = new Card();
		c.setNumber("2008200500106500");
		c.setStore("����ݯ���");
		return c;
	}
}
