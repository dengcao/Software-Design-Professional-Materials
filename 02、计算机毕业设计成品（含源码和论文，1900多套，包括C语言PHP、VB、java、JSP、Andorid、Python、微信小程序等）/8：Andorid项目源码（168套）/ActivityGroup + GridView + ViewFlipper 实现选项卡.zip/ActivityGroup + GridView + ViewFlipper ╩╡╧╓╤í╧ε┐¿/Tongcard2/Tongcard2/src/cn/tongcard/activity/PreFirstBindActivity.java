package cn.tongcard.activity;


import cn.tongcard.tongcard.constant.TongCardConstant.IntentFlags;
import cn.tongcard.tongcard.constant.TongCardConstant.TabIds;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.View;
import android.view.GestureDetector.OnGestureListener;
import android.view.View.OnClickListener;
import android.widget.Button;

public class PreFirstBindActivity extends Activity implements OnClickListener{

	private static final String TAG = "PreFirstBindActivity";
	private Button bindBtn;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.first_bind);
		fillViews();
	}

	private void fillViews(){
		bindBtn = (Button) findViewById(R.bind.bind);
		bindBtn.setOnClickListener(this);
	}

	@Override
	public void onClick(View v) {
		if(v.getId() == R.bind.bind){
			TabCardGroup parent = (TabCardGroup) getParent();
			Intent intent = new Intent(this,BindActivity.class);
			intent.putExtra(IntentFlags.FLAG_BIND, BindActivity.FLAG_INTENT_FIRSTBIND);
			parent.switchActivity(TabIds.TAB_CARD_FIRSTBIND,intent,R.anim.push_left_in,R.anim.push_left_out);
		}
	}
	
}
