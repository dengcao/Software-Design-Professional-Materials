package cn.tongcard.tongcard.service;

public class ShareService {

	public void shareToWeibo(){
		
	}
}
