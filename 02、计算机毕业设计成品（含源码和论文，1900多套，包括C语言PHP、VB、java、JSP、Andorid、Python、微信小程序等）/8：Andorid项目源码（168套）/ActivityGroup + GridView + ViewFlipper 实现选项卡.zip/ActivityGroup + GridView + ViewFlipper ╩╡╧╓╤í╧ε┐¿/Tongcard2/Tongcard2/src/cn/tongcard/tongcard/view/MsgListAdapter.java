package cn.tongcard.tongcard.view;

import java.util.List;

import cn.tongcard.activity.R;
import cn.tongcard.tongcard.domain.Message;

import android.content.Context;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

public class MsgListAdapter extends BaseAdapter{

	private static final String TAG = "MsgListAdapter";
	private List<Message> data;
	private int resource;
	private LayoutInflater mInflater;
	public MsgListAdapter(Context context,List<Message> data,int resource){
		this.data = data;
		this.resource = resource;
		this.mInflater = LayoutInflater.from(context);
	}
	
	@Override
	public int getCount() {
		return data.size();
	}

	@Override
	public Object getItem(int position) {
		return data.get(position);
	}

	@Override
	public long getItemId(int position) {
		return 0;
	}

	@Override
	public View getView(int position, View convertView, ViewGroup parent) {
		if(convertView == null){
			Message msg = (Message) getItem(position);
			convertView = mInflater.inflate(resource, null);
			TextView storeV = (TextView) convertView.findViewById(R.msg.item_store);
			TextView timeV = (TextView) convertView.findViewById(R.msg.item_time);
			TextView contentV = (TextView) convertView.findViewById(R.msg.item_content);
			storeV.setText(msg.getStore());
			timeV.setText(msg.getTime());
			contentV.setText(msg.getContent());
		}
		return convertView;
	}

}
