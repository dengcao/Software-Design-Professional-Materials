package cn.tongcard.activity;

import cn.tongcard.tongcard.constant.TongCardConstant.TabIds;
import cn.tongcard.tongcard.domain.Card;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;

public class SingleCardActivity extends BaseActivity implements OnClickListener {

	private static final String TAG = "SingleCardActivity";
	private LinearLayout transManageLayout;
	private LinearLayout balanceLayout;
	private Button bindBtn;
	private Card card;
	private TextView nameView;
	private TextView cardIdView;
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.singcard);
		card = (Card) getIntent().getSerializableExtra("card");
		fillViews();
	}


	private void fillViews() {
		transManageLayout = (LinearLayout) findViewById(R.singlecard.transManage);
		balanceLayout = (LinearLayout) findViewById(R.singlecard.balance);
		bindBtn = (Button) findViewById(R.singlecard.bind);
		transManageLayout.setOnClickListener(this);
		balanceLayout.setOnClickListener(this);
		bindBtn.setOnClickListener(this);
		
		nameView = (TextView) findViewById(R.singlecard.name);
		cardIdView = (TextView) findViewById(R.singlecard.card);
		
		nameView.setText(card.getStore());
		cardIdView.setText(card.getNumber());
	}


	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.singlecard.transManage:
			Log.i(TAG, "translayout was clicked");
			Intent intent = new Intent(this,PreFirstBindActivity.class);
			((TabCardGroup)getParent()).popSome(TabIds.TAB_CARD_TRANSLIST);
			((TabCardGroup)getParent()).switchActivity(TabIds.TAB_CARD_TRANSLIST,intent,R.anim.push_right_in,R.anim.push_right_out);
			break;
		case R.singlecard.balance:
			
			break;
		case R.singlecard.bind:
			intent = new Intent(this,BindActivity.class);
			((TabCardGroup)getParent()).switchActivity(TabIds.TAB_CARD_BIND,intent,R.anim.push_left_in,R.anim.push_left_out);
			break;
		}
	}
}
