package cn.tongcard.activity;


import cn.tongcard.tongcard.constant.TongCardConstant;
import android.content.Intent;
import android.os.Bundle;
import android.view.MotionEvent;
import android.widget.ViewFlipper;

public class TabCardGroup extends BaseGroup/* implements OnGestureListener*/{

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.tab_content);
		fillViews();
	}

	private void fillViews(){
		containerFlipper = (ViewFlipper) findViewById(R.tab.content);
		Intent intent = new Intent(this,PreFirstBindActivity.class);
		switchActivity(TongCardConstant.TabIds.TAB_CARD_PREBIND,intent,-1,-1);
	}
	
	@Override
	public boolean onTouchEvent(MotionEvent event) {
		return this.getLocalActivityManager().getCurrentActivity().onTouchEvent(event);
	}
}
