package cn.tongcard.tongcard.domain;

import android.content.Context;
import cn.tongcard.activity.R;
import cn.tongcard.tongcard.util.ContextUtils;

public class Grade {

	private String overal;
	private Float taste;
	private Float service;
	private Float surrouding;
	private String suggestion;
	private String answer;
	private String content;

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public Float getTaste() {
		return taste;
	}

	public Float getService() {
		return service;
	}

	public Float getSurrouding() {
		return surrouding;
	}

	public String getAnswer() {
		return answer;
	}

	public void setAnswer(String answer) {
		this.answer = answer;
	}

	public String getOveral() {
		return overal;
	}

	public void setOveral(String overal) {
		this.overal = overal;
	}

	public String getTaste(Context c) {
		return taste
				+ ContextUtils.getString(c, R.string.trans_detail_grade_star);
	}

	public void setTaste(Float taste) {
		this.taste = taste;
	}

	public String getService(Context c) {
		return service
				+ ContextUtils.getString(c, R.string.trans_detail_grade_star);
	}

	public void setService(Float service) {
		this.service = service;
	}

	public String getSurrouding(Context c) {
		return surrouding
				+ ContextUtils.getString(c, R.string.trans_detail_grade_star);
	}

	public void setSurrouding(Float surrouding) {
		this.surrouding = surrouding;
	}

	public String getSuggestion() {
		return suggestion;
	}

	public void setSuggestion(String suggestion) {
		this.suggestion = suggestion;
	}

	public String getOveral(Context context, int id) {
		switch (id) {
//		case R.trans.grade_good:
//			return ContextUtils.getString(context, R.string.trans_grade_good);
//		case R.trans.grade_general:
//			return ContextUtils
//					.getString(context, R.string.trans_grade_general);
//		case R.trans.grade_bad:
//			return ContextUtils.getString(context, R.string.trans_grade_bad);
		}
		return null;
	}
}
