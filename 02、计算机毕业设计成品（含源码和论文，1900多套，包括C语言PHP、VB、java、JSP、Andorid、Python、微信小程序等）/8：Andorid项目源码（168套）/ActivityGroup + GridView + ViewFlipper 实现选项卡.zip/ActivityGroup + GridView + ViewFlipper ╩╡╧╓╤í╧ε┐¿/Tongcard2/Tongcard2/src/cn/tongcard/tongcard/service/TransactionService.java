package cn.tongcard.tongcard.service;

import java.util.ArrayList;
import java.util.List;

import cn.tongcard.tongcard.domain.Card;
import cn.tongcard.tongcard.domain.Coupon;
import cn.tongcard.tongcard.domain.CouponItem;
import cn.tongcard.tongcard.domain.Grade;
import cn.tongcard.tongcard.domain.Transaction;

public class TransactionService {

	public List<Transaction> getAllTrans(){
		List<Transaction> translList = new ArrayList<Transaction>();
		Transaction trans1 = new Transaction();
		trans1.setId("1");
		trans1.setAmount(256f);
		trans1.setStore("�����ŵ�");
		trans1.setState("0");
		trans1.setTime("2011-03-12 13:15:26");
		
		Transaction trans2 = new Transaction();
		trans2.setId("2");
		trans2.setAmount(256f);
		trans2.setStore("�йش��");
		trans2.setState("1");
		trans2.setTime("2011-03-12 13:15:26");
		
		Transaction trans3 = new Transaction();
		trans3.setId("3");
		trans3.setAmount(256f);
		trans3.setStore("��Ԫ�ŵ�");
		trans3.setState("2");
		trans3.setTime("2011-03-12 13:15:26");
		
		Transaction trans4 = new Transaction();
		trans4.setId("4");
		trans4.setAmount(256f);
		trans4.setStore("��Ԫ�ŵ�");
		trans4.setState("3");
		trans4.setTime("2011-03-12 13:15:26");
		
		translList.add(trans1);
		translList.add(trans2);
		translList.add(trans3);
		translList.add(trans4);
		
		
		return translList;
	}
	
	public List<Card> getAllCards(){
		List<Card> cards = new ArrayList<Card>();
		Card c1 = new Card();
		c1.setNumber("2008200500106500");
		c1.setStore("����ݯ���");
			
		Card c2 = new Card();
		c2.setNumber("4521100210106500");
		c2.setStore("���ϵ�");
		
		Card c3 = new Card();
		cards.add(c1);
		cards.add(c2);
		cards.add(c3);
		
		return cards;
	}

	public Transaction getTransById(String id) {
		if("3".equals(id)){
			Transaction trans = new Transaction();
			trans.setAwardBalance("20Ԫ");
			trans.setAwardCoupon("30Ԫ����ȯ1��");
			trans.setUseBalance("100");
			trans.setAmount(225f);
			trans.setTime("2011-05-30 13:02:15");
			Coupon c = new Coupon("123", 30f);
			CouponItem item1 = new CouponItem(c, 1);
			CouponItem item2 = new CouponItem(new Coupon("124", 50f), 1);
			List<CouponItem> coupons = new ArrayList<CouponItem>();
			coupons.add(item1);
			coupons.add(item2);
			trans.setStore("����ݯ���");
			trans.setCoupons(coupons);
			Card card = new Card();
			card.setNumber("4521100210106500");
			card.setBalance(100f);
			card.setPoints(10);
			trans.setCard(card);
			Grade g = new Grade();
			g.setOveral("����");
			g.setService(4f);
			g.setTaste(4f);
			g.setSurrouding(4f);
			g.setContent("���������ˡ�����");
			g.setAnswer("�����Ѿ��Ľ��ˡ�����лл���Ľ��顣");
			trans.setGrade(g);
			return trans;
		}else
			return getTransById2(id);
		
	}
	public Transaction getTransById2(String id) {
		Transaction trans = new Transaction();
		trans.setAwardBalance("20Ԫ");
		trans.setAwardCoupon("30Ԫ����ȯ2��");
		trans.setUseBalance("100");
		trans.setAmount(225f);
		trans.setTime("2011-05-30 13:02:15");
		Coupon c = new Coupon("123", 30f);
		CouponItem item1 = new CouponItem(c, 1);
		CouponItem item2 = new CouponItem(new Coupon("124", 50f), 1);
		List<CouponItem> coupons = new ArrayList<CouponItem>();
		coupons.add(item1);
		coupons.add(item2);
		trans.setCoupons(coupons);
		Card card = new Card();
		card.setNumber("4521100210106500");
		card.setBalance(100f);
		card.setPoints(10);
		trans.setCard(card);
		return trans;
	}
	
	public void publishGrade(Grade g){
		
	}
}
