package a.b;

import java.util.ArrayList;
import java.util.List;
import simtice.demo.R;
import android.app.Activity;
import android.os.Bundle;
import android.os.Parcelable;
import android.support.v4.view.PagerAdapter;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;

public class TestViewPager extends Activity
{
	private ViewPager myViewPager;

	private MyPagerAdapter myAdapter;

	private LayoutInflater mInflater;
	private List<View> mListViews;
	private View layout1 = null;
	private View layout2 = null;
	private View layout3 = null;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		super.onCreate(savedInstanceState);
		setContentView(R.layout.viewpager_layout);
		myAdapter = new MyPagerAdapter();
		myViewPager = (ViewPager) findViewById(R.id.viewpagerLayout);
		myViewPager.setAdapter(myAdapter);

		mListViews = new ArrayList<View>();
		mInflater = getLayoutInflater();
		layout1 = mInflater.inflate(R.layout.layout1, null);
		layout2 = mInflater.inflate(R.layout.layout2, null);
		layout3 = mInflater.inflate(R.layout.layout3, null);

		mListViews.add(layout1);
		mListViews.add(layout2);
		mListViews.add(layout3);

		// ��ʼ����ǰ��ʾ��view
		myViewPager.setCurrentItem(1);

		myViewPager.setOnPageChangeListener(new OnPageChangeListener()
		{

			@Override
			public void onPageSelected(int arg0)
			{
				Log.d("k", "onPageSelected - " + arg0);
				// activity��1��2������2�����غ���ô˷���
				View v = mListViews.get(arg0);
				EditText editText = (EditText) v.findViewById(R.id.editText1);
				editText.setText("��" + (arg0 + 1) + "ҳ");
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2)
			{
				Log.d("k", "onPageScrolled - " + arg0);
				// ��1��2��������1����ǰ����
			}

			@Override
			public void onPageScrollStateChanged(int arg0)
			{
				Log.d("k", "onPageScrollStateChanged - " + arg0);
				// ״̬������0���У�1�����ڻ����У�2Ŀ��������
				/**
				 * Indicates that the pager is in an idle, settled state. The
				 * current page is fully in view and no animation is in
				 * progress.
				 */
				// public static final int SCROLL_STATE_IDLE = 0;
				/**
				 * Indicates that the pager is currently being dragged by the
				 * user.
				 */
				// public static final int SCROLL_STATE_DRAGGING = 1;
				/**
				 * Indicates that the pager is in the process of settling to a
				 * final position.
				 */
				// public static final int SCROLL_STATE_SETTLING = 2;

			}
		});

	}

	private class MyPagerAdapter extends PagerAdapter
	{

		// ����arg1λ�õĽ���
		@Override
		public void destroyItem(View arg0, int arg1, Object arg2)
		{
			((ViewPager) arg0).removeView(mListViews.get(arg1));
		}

		// ��ȡ��ǰ���������
		@Override
		public int getCount()
		{
			return mListViews.size();
		}

		// ��ʼ��arg0λ�õĽ���
		@Override
		public Object instantiateItem(View arg0, int arg1)
		{
			Log.d("k", "instantiateItem");
			((ViewPager) arg0).addView(mListViews.get(arg1), 0);
			return mListViews.get(arg1);
		}

		// �ж��Ƿ��ɶ������ɽ���
		@Override
		public boolean isViewFromObject(View arg0, Object arg1)
		{
			Log.d("k", "isViewFromObject");
			return arg0 == (arg1);
		}

	}

}