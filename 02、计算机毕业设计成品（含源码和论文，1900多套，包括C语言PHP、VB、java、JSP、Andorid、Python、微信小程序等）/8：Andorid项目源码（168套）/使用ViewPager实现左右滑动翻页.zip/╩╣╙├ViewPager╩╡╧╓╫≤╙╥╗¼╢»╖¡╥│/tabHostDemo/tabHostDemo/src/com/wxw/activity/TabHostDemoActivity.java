package com.wxw.activity;

import java.util.ArrayList;
import java.util.List;

import android.app.Activity;
import android.os.Bundle;
import android.support.v4.view.ViewPager;
import android.support.v4.view.ViewPager.OnPageChangeListener;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.EditText;
import android.widget.RelativeLayout;

import com.wxw.adpter.MyPagerAdapter;

public class TabHostDemoActivity extends Activity {
	/** Called when the activity is first created. */

	private ViewPager myViewPager;

	private MyPagerAdapter myAdapter;
	private LayoutInflater mInflater;

	private List<View> listViews;

	private View layout1 = null;
	private View layout2 = null;
	private View layout3 = null;
	private View layout4 = null;
	private RelativeLayout rmml1, rmml2, rmml3, rmml4;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		// �����˵����ֶ���
		rmml1 = (RelativeLayout) findViewById(R.id.rmml1);
		rmml2 = (RelativeLayout) findViewById(R.id.rmml2);
		rmml3 = (RelativeLayout) findViewById(R.id.rmml3);
		rmml4 = (RelativeLayout) findViewById(R.id.rmml4);

		rmml1.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setImageBackground(0);
				myViewPager.setCurrentItem(0);

			}
		});
		rmml2.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setImageBackground(1);
				myViewPager.setCurrentItem(1);

			}
		});
		rmml3.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setImageBackground(2);
				myViewPager.setCurrentItem(2);

			}
		});
		rmml4.setOnClickListener(new OnClickListener() {

			@Override
			public void onClick(View v) {
				setImageBackground(3);
				myViewPager.setCurrentItem(3);

			}
		});

		listViews = new ArrayList<View>();
		mInflater = getLayoutInflater();
		layout1 = mInflater.inflate(R.layout.help1, null);
		layout2 = mInflater.inflate(R.layout.help2, null);
		layout3 = mInflater.inflate(R.layout.help3, null);
		layout4 = mInflater.inflate(R.layout.help4, null);
		listViews.add(layout1);
		listViews.add(layout2);
		listViews.add(layout3);
		listViews.add(layout4);

		myAdapter = new MyPagerAdapter(listViews);
		myViewPager = (ViewPager) findViewById(R.id.myMesPager);
		myViewPager.setAdapter(myAdapter);
		myViewPager.setCurrentItem(0);

		myViewPager.setOnPageChangeListener(new OnPageChangeListener() {

			@Override
			public void onPageSelected(int arg0) {
				View view = listViews.get(arg0);
				EditText edit;
				// activity��1��2������2�����غ���ô˷���
				switch (arg0) {

				case 0:
					edit = (EditText) view.findViewById(R.id.one);
					edit.setText("��ǰ����һҳ");
					setImageBackground(0);
					break;
				case 1:
					edit = (EditText) view.findViewById(R.id.two);
					edit.setText("��ǰ���ڶ�ҳ");
					setImageBackground(1);
					break;
				case 2:
					edit = (EditText) view.findViewById(R.id.three);
					edit.setText("��ǰ������ҳ");
					setImageBackground(2);
					break;
				case 3:
					edit = (EditText) view.findViewById(R.id.four);
					edit.setText("��ǰ������ҳ");
					setImageBackground(3);
					break;
				default:
					break;
				}
			}

			@Override
			public void onPageScrolled(int arg0, float arg1, int arg2) {
				// ��1��2��������1����ǰ����
			}

			@Override
			public void onPageScrollStateChanged(int arg0) {
				Log.d("k", "onPageScrollStateChanged - " + arg0);
				// ״̬������0���У�1�����ڻ����У�2Ŀ��������

			}
		});
	}

	private void setImageBackground(int position) {
		switch (position) {
		case 0:
			rmml1.setBackgroundResource(R.drawable.ico_menu_focus);
			rmml2.setBackgroundResource(R.drawable.ico_menu_nofocus);
			rmml3.setBackgroundResource(R.drawable.ico_menu_nofocus);
			rmml4.setBackgroundResource(R.drawable.ico_menu_nofocus);
			break;
		case 1:
			rmml1.setBackgroundResource(R.drawable.ico_menu_nofocus);
			rmml2.setBackgroundResource(R.drawable.ico_menu_focus);
			rmml3.setBackgroundResource(R.drawable.ico_menu_nofocus);
			rmml4.setBackgroundResource(R.drawable.ico_menu_nofocus);
			break;
		case 2:
			rmml1.setBackgroundResource(R.drawable.ico_menu_nofocus);
			rmml2.setBackgroundResource(R.drawable.ico_menu_nofocus);
			rmml3.setBackgroundResource(R.drawable.ico_menu_focus);
			rmml4.setBackgroundResource(R.drawable.ico_menu_nofocus);
			break;
		case 3:
			rmml1.setBackgroundResource(R.drawable.ico_menu_nofocus);
			rmml2.setBackgroundResource(R.drawable.ico_menu_nofocus);
			rmml3.setBackgroundResource(R.drawable.ico_menu_nofocus);
			rmml4.setBackgroundResource(R.drawable.ico_menu_focus);
			break;
		case 4:
			rmml1.setBackgroundResource(R.drawable.ico_menu_nofocus);
			rmml2.setBackgroundResource(R.drawable.ico_menu_nofocus);
			rmml3.setBackgroundResource(R.drawable.ico_menu_nofocus);
			rmml4.setBackgroundResource(R.drawable.ico_menu_focus);
			break;
		default:
			break;

		}

	}

}