package com.xiaohua.pageturn;

import android.app.Activity;
import android.os.Bundle;
import android.widget.TextView;

public class About extends Activity
{
	private TextView tvAbout;

	@Override
	protected void onCreate(Bundle savedInstanceState)
	{
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.about);
		tvAbout = (TextView) findViewById(R.id.tvAbout);
		String about = "小花阅读器Android版1.0\n\n";
		about += "功能: 实现翻书效果\n\n";
		about += "作者：花新昌\n\n";
		about += "Tel：15210477080\n\n";
		about += "博客：http://hi.baidu.com/huaxinchang/home\n\n";
		about += "邮箱：592409652@qq.com";
		tvAbout.setText(about);
	}
}
