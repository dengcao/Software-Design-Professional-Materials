package com.ostrichmyself.api.util;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;

/**
 * ���л��һ��URL���ı�����
 * @author Administrator
 *
 */
public class URLProcesser {
	
	
	public static String getStringFromURL(String urlString, String encoding) {
		StringBuffer buffer = new StringBuffer();
		try {
			URL url = new URL(urlString);
			URLConnection uc = url.openConnection();
			uc.setRequestProperty("Authorization", "Basic " + encoding);
			uc.setRequestProperty("User-Agent", "Mozilla/5.0");
			InputStream content = (InputStream) uc.getInputStream();
			BufferedReader in = new BufferedReader(new InputStreamReader(
					content, encoding));
			while (in.ready()) {
				String line = in.readLine().trim();
				if (line.length() != 0) {
					buffer.append(line + "\r\n");
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return buffer.toString().trim();
	}

}
