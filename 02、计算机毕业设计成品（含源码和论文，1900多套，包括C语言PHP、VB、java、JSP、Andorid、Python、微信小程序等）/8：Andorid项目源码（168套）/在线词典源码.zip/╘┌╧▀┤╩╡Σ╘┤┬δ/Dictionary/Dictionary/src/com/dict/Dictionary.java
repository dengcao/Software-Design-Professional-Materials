package com.dict;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;

import android.app.Activity;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.View;
import android.view.View.OnClickListener;
import android.view.View.OnKeyListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import app.dict.net.DictRemoteConnection;

import common.connection.net.IRemoteConnection;
import common.xmlParser.net.AndroidXMLParser;
import common.xmlParser.net.BaseParser;
import common.xmlParser.net.Example;

public class Dictionary extends Activity {
	
	private Button searchButton;
	private EditText condtionText;
	private TextView chineseTV;
	private TextView exampleTv;
	private String meaning;
	private List<Example> exampleList;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        searchButton = (Button)findViewById(R.id.search);
        condtionText = (EditText)findViewById(R.id.condtion);
        chineseTV = (TextView)findViewById(R.id.chinese);
        exampleTv = (TextView)findViewById(R.id.example);
        searchButton.setOnClickListener(new SearchButtonAction());
        condtionText.setOnKeyListener(new TheKeyListener());
        loadDataAndDisplay();
    }
    
    
    class SearchButtonAction implements OnClickListener
    {

		public void onClick(View v) {
			sendRequest();
		}
    }
    
    private void sendRequest()
    {
    	String searchConditionTxt = condtionText.getText().toString();
		if (searchConditionTxt != null)
		{
			String searchCondtion = searchConditionTxt.trim();
			if (searchCondtion.length() != 0) {
				connectServer(searchCondtion);					
			}
		}
    }
    
    class TheKeyListener implements OnKeyListener
    {

		public boolean onKey(View v, int keyCode, KeyEvent event) {
			if (keyCode == KeyEvent.KEYCODE_ENTER)
			{
				sendRequest();
				String searchConditionTxt = condtionText.getText().toString().trim();
				condtionText.setText(searchConditionTxt);
			}
			return false;
		}

    	
    }
    
    private void connectServer(String searchCondtion) {
    	searchCondtion = searchCondtion.replaceAll("  ", " ");
    	searchCondtion = searchCondtion.replaceAll(" ", "%20");
    	IRemoteConnection connection = new DictRemoteConnection();
		AndroidXMLParser parser = new AndroidXMLParser(connection.getConnectionURI(searchCondtion));
		Element rootElement = parser.getRoot();
		if (rootElement == null)
		{
			return;
		}
		BaseParser bParser = new BaseParser(rootElement);
		meaning = bParser.getExplain();
		exampleList = bParser.getExampleList();
		displaySearchResult();
	}
    
    private void displaySearchResult()
    {
    	if (meaning != null)
    	{
    		chineseTV.setText(meaning);
    		dispalyExample(exampleList);
    	}
    }
    
    private void loadDataAndDisplay()
    {
    	final Object data = getLastNonConfigurationInstance();
    	if ( data == null)
    	{
    		return;
    	}
    	else
    	{
    		List<Object> lst = (List<Object>) data;
    		meaning = (String)lst.get(0);
    		exampleList = (List<Example>)lst.get(1);
    		displaySearchResult();
    	}
    }

	private void dispalyExample(List<Example> exList) {
		
		if (exList == null || exList.size() == 0)
		{
			return;
		}
		exampleTv.setText("");
		for (Example example : exList)
		{
			exampleTv.append(example.getEnglishSentence());
			exampleTv.append("\n");
			exampleTv.append(example.getTranslateSentence());
			exampleTv.append("\n");
			exampleTv.append("\n");
		}
		
	}

	/**
	 * ������Ļ��ת
	 */
	@Override
	public Object onRetainNonConfigurationInstance() {
		List<Object> arrayObj = new ArrayList<Object>();
		arrayObj.add(meaning);
		arrayObj.add(exampleList);
		return arrayObj;
	}
	
	
    
}