package app.dict.net;

import common.connection.net.IRemoteConnection;


/**
 * dict.cn�Ľӿ�
 * @author Administrator
 *
 */
public class DictRemoteConnection implements IRemoteConnection {
	
	private final String  baseUrl = "http://deepfinding.appspot.com/dict?word=";
	private final String coding = "GB2312";
	
	public String getConnectionURI(String query) {
		return baseUrl + query;
	}
	
	public String getCoding()
	{
		return coding;
	}


}
