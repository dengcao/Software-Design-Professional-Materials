package app.dict.net;

public class DictXMLParser {

}
