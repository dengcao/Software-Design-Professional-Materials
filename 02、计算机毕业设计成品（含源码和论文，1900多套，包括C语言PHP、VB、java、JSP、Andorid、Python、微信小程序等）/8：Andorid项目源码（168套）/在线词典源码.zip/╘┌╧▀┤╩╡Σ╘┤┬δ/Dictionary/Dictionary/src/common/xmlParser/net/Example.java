package common.xmlParser.net;

/**
 * ��������
 * @author Administrator
 *
 */
public class Example
{
	public Example()
	{
		
	}
	
	public boolean isValidExample()
	{
		if (englishSentence == null)
		{
			return false;
		}
		
		if (translateSentence == null)
		{
			return false;
		}
			
		return true;
	}
	
	
	
	public String getEnglishSentence() {
		return englishSentence;
	}
	public void setEnglishSentence(String englishSentence) {
		this.englishSentence = englishSentence;
	}
	public String getTranslateSentence() {
		return translateSentence;
	}
	public void setTranslateSentence(String translateSentence) {
		this.translateSentence = translateSentence;
	}



	String englishSentence;
	String translateSentence;
}