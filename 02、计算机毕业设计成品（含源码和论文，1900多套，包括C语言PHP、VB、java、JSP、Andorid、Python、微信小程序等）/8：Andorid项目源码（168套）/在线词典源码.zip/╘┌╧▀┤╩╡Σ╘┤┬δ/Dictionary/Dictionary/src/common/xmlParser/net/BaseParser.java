package common.xmlParser.net;

import java.util.ArrayList;
import java.util.List;

import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;

/**
 * �����õ��Ľ��
 * @author Administrator
 *
 */
public class BaseParser {
	
	

	protected String words;
	protected String pronounciation;
	protected String explain;
	protected String audioUrl;
	protected List<Example> exampleList;
	protected final String notFond = "Not Found";
	protected final String defNode = "def";
	protected final String sentNode = "sent";
	protected final String englishSentence = "orig";
	protected final String chineseTranslation = "trans";
	
	
	public BaseParser(Element root)
	{
		NodeList deflist = root.getElementsByTagName("def");
		if (deflist == null) {
			return;
		}
		
		Node defNode = deflist.item(0);
		explain = defNode.getFirstChild().getNodeValue();
		
		if (explain.equalsIgnoreCase(notFond)) {
			return;
		}
		
		NodeList sentList = root.getElementsByTagName("sent");
		processSentList(sentList);
	}
	
	/**
	 * ����sent�ڵ�
	 * @param nlist
	 */
	private void processSentList(NodeList nList)
	{
		if (nList == null || nList.getLength() == 0)
		{
			return;
		}
		exampleList = new ArrayList<Example>();
		for (int i = 0; i < nList.getLength(); i++){
			Example example = processSigleSent(nList.item(i));
			if (example.isValidExample())
			{
				exampleList.add(example);
			}
		}
	}
	
	private Example processSigleSent(Node sentNode)
	{
		Example example = new Example();;
		NodeList children = sentNode.getChildNodes();
		for(int i = 0;i < children.getLength(); i++)
		{
		        Node child = children.item(i);
		        if (child instanceof Element)
		        {
		          Element childElement = (Element)child;
		          String name = childElement.getNodeName();
		          String value = childElement.getFirstChild().getNodeValue();
		          if (name.equalsIgnoreCase(englishSentence))
		          {
		        	  example.setEnglishSentence(value);
		          }
		          else
		          {
		        	  example.setTranslateSentence(value);
		          }
		        }
		}
		return example;
	}
	
	
	public String getWords() {
		return words;
	}


	public String getPronounciation() {
		return pronounciation;
	}


	public String getExplain() {
		return explain;
	}


	public String getAudioUrl() {
		return audioUrl;
	}


	public List<Example> getExampleList() {
		return exampleList;
	}

}
