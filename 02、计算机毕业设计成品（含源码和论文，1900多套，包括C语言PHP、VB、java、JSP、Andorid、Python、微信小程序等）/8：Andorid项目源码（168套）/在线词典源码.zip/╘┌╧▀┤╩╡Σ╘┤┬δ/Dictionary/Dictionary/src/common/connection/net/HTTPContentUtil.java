package common.connection.net;

import java.io.BufferedReader;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.URL;
import java.net.URLConnection;


/*�õ�HTTP����*/
public class HTTPContentUtil {
	
	public static String getHttpContent(String rometURL, String encoding)
	{
		try {
			 URL url = new URL (rometURL);
		        URLConnection uc = url.openConnection();
		        uc.setRequestProperty  ("Authorization", "Basic " + encoding);
		        uc.setRequestProperty("User-Agent", "Mozilla/5.0");
		          
		        InputStream content = (InputStream)uc.getInputStream();
		        BufferedReader in = new BufferedReader (new InputStreamReader (content,encoding));
		        StringBuffer buffer = new StringBuffer();
		        while (in.ready()) {
					String inString = in.readLine().trim();
					if (inString.length() != 0)
					{
						buffer.append(inString);
					}
				}
		        return buffer.toString();
		} catch (Exception e) {
		}
       return null;
	}
	
	public static void main(String args[])
	{
		String myString = HTTPContentUtil.getHttpContent("http://dict.cn/ws.php?q=come%20on", "GB2312");
		System.out.println(myString);
	}

}
