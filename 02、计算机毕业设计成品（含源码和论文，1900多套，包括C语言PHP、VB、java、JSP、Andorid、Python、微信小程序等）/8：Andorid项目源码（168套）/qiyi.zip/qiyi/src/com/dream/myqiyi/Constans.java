package com.dream.myqiyi;


/**
 * 
 * @author iteye whyhappy01
 *
 */
public class Constans {
	public static boolean DEBUG = true;

}
