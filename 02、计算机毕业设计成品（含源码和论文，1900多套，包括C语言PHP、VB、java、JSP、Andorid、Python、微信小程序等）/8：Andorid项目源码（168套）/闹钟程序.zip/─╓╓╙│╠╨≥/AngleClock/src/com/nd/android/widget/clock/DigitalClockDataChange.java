package com.nd.android.widget.clock;

public class DigitalClockDataChange {
    public boolean isChange;
    public String changeValue;
}
