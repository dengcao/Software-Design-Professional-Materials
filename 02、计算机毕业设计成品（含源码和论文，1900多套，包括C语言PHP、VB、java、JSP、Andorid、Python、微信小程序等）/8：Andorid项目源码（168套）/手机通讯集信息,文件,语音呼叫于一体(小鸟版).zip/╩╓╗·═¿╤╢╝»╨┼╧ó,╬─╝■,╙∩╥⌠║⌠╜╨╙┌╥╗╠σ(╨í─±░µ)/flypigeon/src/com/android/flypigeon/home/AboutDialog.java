package com.android.flypigeon.home;

import android.app.Dialog;
import android.content.Context;

public class AboutDialog extends Dialog {
	private Context context = null;
	public AboutDialog(Context context) {
		super(context);
		this.context = context;
	}

	
}
