package com.android.flypigeon.home;


import android.app.AlertDialog;
import android.content.Context;

public class PersonLongClickDialog extends AlertDialog {
	
	public PersonLongClickDialog(Context context) {
		super(context);
	}
}
