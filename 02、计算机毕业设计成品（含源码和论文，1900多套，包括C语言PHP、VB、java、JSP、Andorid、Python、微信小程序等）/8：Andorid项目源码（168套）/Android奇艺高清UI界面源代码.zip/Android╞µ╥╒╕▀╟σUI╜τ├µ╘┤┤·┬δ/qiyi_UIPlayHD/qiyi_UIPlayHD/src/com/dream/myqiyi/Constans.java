package com.dream.myqiyi;


public class Constans {
	public static boolean DEBUG = true;

}
