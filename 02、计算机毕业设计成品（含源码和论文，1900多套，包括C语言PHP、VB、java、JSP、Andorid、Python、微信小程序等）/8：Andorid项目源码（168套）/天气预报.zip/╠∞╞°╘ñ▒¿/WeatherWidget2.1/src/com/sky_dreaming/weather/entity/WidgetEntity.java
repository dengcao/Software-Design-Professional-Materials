/**
 * 
 */
package com.sky_dreaming.weather.entity;

import java.util.ArrayList;

/**
 * ****************************************************************
 * 文件名称	: WidgetEntity.java
 * 作    者	: sky_dreaming
 * 创建时间	: 2010-10-26 下午04:25:28
 * 文件描述	: widget数据实体封装类
 *****************************************************************
 */
public class WidgetEntity {	

	private Integer id;
	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	/**
	 * 天气预报详情
	 */
	private ArrayList<ForecastEntity> details = new ArrayList<ForecastEntity>();
	/**
	 * 数据更新时间间隔
	 */
	private Integer updateMilis;
	/**
	 * 所预报的城市
	 */
	private String city;
	/**
	 * 城市所对应的邮政编码
	 */
	private String postalCode;
	/**
	 * 获取预报的日期
	 */
	private Long forecastDate;
	/**
	 * 当前天气情况
	 */
	private String condition;
	/**
	 * ？？
	 */
	private Integer tempF;
	/**
	 * 当前温度
	 */
	private Integer tempC;
	/**
	 * 湿度
	 */
	private String humidity;
	/**
	 * 表示当前天气情况图标的描述
	 */
	private String icon;
	/**
	 * 风向
	 */
	private String windCondition;
	/**
	 * 最后一次更新时间
	 */
	private Long lastUpdateTime;
	/**
	 * 标志是否已经设置过了
	 */
	private Integer isConfigured;

	public Integer getUpdateMilis() {
		return updateMilis;
	}

	public void setUpdateMilis(Integer updateMilis) {
		this.updateMilis = updateMilis;
	}

	public ArrayList<ForecastEntity> getDetails() {
		return details;
	}

	public void setDetails(ArrayList<ForecastEntity> details) {
		this.details = details;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getPostalCode() {
		return postalCode;
	}

	public void setPostalCode(String postalCode) {
		this.postalCode = postalCode;
	}
	

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public Integer getTempF() {
		return tempF;
	}

	public void setTempF(Integer tempF) {
		this.tempF = tempF;
	}

	public Integer getTempC() {
		return tempC;
	}

	public void setTempC(Integer tempC) {
		this.tempC = tempC;
	}

	public String getHumidity() {
		return humidity;
	}

	public void setHumidity(String humidity) {
		this.humidity = humidity;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getWindCondition() {
		return windCondition;
	}

	public void setWindCondition(String windCondition) {
		this.windCondition = windCondition;
	}

	/**
	 * @param isConfigured the isConfigured to set
	 */
	public void setIsConfigured(Integer isConfigured) {
		this.isConfigured = isConfigured;
	}

	/**
	 * @return the isConfigured
	 */
	public Integer getIsConfigured() {
		return isConfigured;
	}

	/**
	 * @param forecastDate the forecastDate to set
	 */
	public void setForecastDate(Long forecastDate) {
		this.forecastDate = forecastDate;
	}

	/**
	 * @return the forecastDate
	 */
	public Long getForecastDate() {
		return forecastDate;
	}

	/**
	 * @param lastUpdateTime the lastUpdateTime to set
	 */
	public void setLastUpdateTime(Long lastUpdateTime) {
		this.lastUpdateTime = lastUpdateTime;
	}

	/**
	 * @return the lastUpdateTime
	 */
	public Long getLastUpdateTime() {
		return lastUpdateTime;
	}

}
