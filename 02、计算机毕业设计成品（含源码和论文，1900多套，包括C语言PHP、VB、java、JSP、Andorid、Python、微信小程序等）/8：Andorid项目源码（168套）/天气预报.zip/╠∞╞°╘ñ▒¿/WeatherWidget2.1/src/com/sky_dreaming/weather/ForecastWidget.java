/**
 * 
 */
package com.sky_dreaming.weather;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.text.format.DateFormat;
import android.text.format.Time;
import android.util.Log;
import android.widget.RemoteViews;

import com.sky_dreaming.weather.entity.WidgetEntity;
import com.sky_dreaming.weather.service.ForecastService;
import com.sky_dreaming.weather.service.ForecastTimeService;
import com.sky_dreaming.weather.util.ForecastUtil;
import com.sky_dreaming.weather.util.WebServiceUtil;
import com.sky_dreaming.weather.R;

/**
 * ****************************************************************
 * 文件名称	: ForecastWidget.java
 * 作    者	: sky_dreaming
 * 创建时间	: 2010-10-26 下午05:30:04
 * 文件描述	: widget程序入口，提供界面更新方法，开启各项相关服务
 *****************************************************************
 */
public class ForecastWidget extends AppWidgetProvider {
	private static final String TAG = "ForecastWidget";
	private static Time TIME_WIDGET = new Time();

	/**
	 * 当AppWidget provider 被调用来为widget程序集提供用于显示控件的RemoteViews时候，
	 * onUpdate方法用来处理ACTION_APPWIDGET_UPDATE广播
	 * @param context
	 * @param appWidgetManager
	 * @param appWidgetIds 需要更新的widget应用的ID，注意：appWidgetIds可能是该provider得所有widget应用实例，
	 * 					        也可能是其中一个子集
	 */
	@Override
	public void onUpdate(Context context, AppWidgetManager appWidgetManager,
			int[] appWidgetIds) {
		// TODO Auto-generated method stub
		super.onUpdate(context, appWidgetManager, appWidgetIds);

		/**
		 * 获取需要更新的widget ID
		 */
		ForecastService.addWidgetIDs(appWidgetIds);

		/**
		 * Request that a given application service be started. The Intent can either 
		 * 请求开始一个应用服务，Intent包含了一个完整的服务类名，或者一个抽象定义的服务。如果该服务当前未开启，
		 * 则实例化并且开启服务（如果需要可开启线程）；如果该服务当前已经开启，则保持运行状态。
		 * 
		 * 每次调用本方法将会导致相应的服务调用onStart(Intent, int)方法，通过intent的传递，提供了一个方便的方式将
		 * 数据提交给service而不需要绑定和调用服务接口。
		 * 
		 * 服务将一直运行直到stopService(Intent)方法被调用，注意，startService方法并不嵌套：无论多少次调用该方法
		 * 一次调用stopService(Intent)将会停止服务。
		 *  
		 * 系统企图尽可能多地运行服务，只有当当前应用程序需要资源不够时才需要kill服务，如果在服务进程中出现任何错误
		 * 将自动重新启动服务。
		 * 
		 * 当用户无权限启动一个服务时抛出SecurityException异常
		 * 
		 * Returns：如果成功启动服务，返回ComponentName；如果服务不存在返回null并抛出SecurityException异常
		 */
		/**
		 * 启动获取天气预报信息的服务
		 */
		context.startService(new Intent(context, ForecastService.class));

		/**
		 * 启动时间信息的服务
		 */
		context.startService(new Intent(context, ForecastTimeService.class));
	}

	/**
	 * RemoteViews类描述了一个可以在其他进程中显示的视图体系，可以通过布局源文件（layout resource file）获取。
	 * 这个类提供了些修改视图内容的基本操作。
	 * @param context
	 * @param uri
	 * @return
	 */
	public static RemoteViews updateViews(Context context, Uri uri) {
		Log.d(TAG, "Building medium widget update");

		RemoteViews views = new RemoteViews(context.getPackageName(),
				R.layout.weather);
		WidgetEntity widgetEntity = WebServiceUtil.getWidgetEntity(context, uri, true);

		if (widgetEntity != null) {
			Log.d(TAG, "update View from widgetEntity");
			/**
			 * 参数：1、需要改变Image的控件ID；2、新资源的 ID
			 */
			views.setImageViewResource(R.id.forecastImage, ForecastUtil
					.getForecastImage(widgetEntity.getIcon()));
			/**
			 * 相当于调用TextView.setText()，第一个参数代表控件ID，第二个参数代表要填充的Ｔｅｘｔ
			 */
			
			views.setTextViewText(R.id.cityText, widgetEntity.getCity());
			views.setTextViewText(R.id.conditionText, widgetEntity
					.getCondition());
			views.setTextViewText(R.id.tempCText, widgetEntity.getTempC()
					.toString()
					+ "°");
			views.setTextViewText(R.id.hightText, "H:"
					+ widgetEntity.getDetails().get(0).getHight().toString()
					+ "°");
			views.setTextViewText(R.id.lowText, "L:"
					+ widgetEntity.getDetails().get(0).getLow().toString()
					+ "°");
		}

		 /**
		  * 设置点击views启动DetailForecastActivity
		  */
        Intent detailIntent = new Intent(context, DetailForecastActivity.class);
        detailIntent.setData(uri);

        /**
         * Note that the activity will be started outside of the context of an existing activity, 
         * so you must use the Intent.FLAG_ACTIVITY_NEW_TASK launch flag in the Intent.
         * 获取一个即将启动新的activity的PendingIntent对象，如同调用Context.startActivity(Intent).
         * 注意：将要启动的activity将在当前存在的activity的上下文之外启动，所以必须使用Intent.FLAG_ACTIVITY_NEW_TASK
         * 
         * 参数：
         * context  PendingIntent将在该Context内启动activity
         * requestCode  Private request code for the sender (currently not used). 
         * intent  启动activity的intent
         * flags  Intent.fillIn()提供的flags 例如：FLAG_ONE_SHOT, FLAG_NO_CREATE, FLAG_CANCEL_CURRENT, FLAG_UPDATE_CURRENT 
         */
        PendingIntent pending = PendingIntent.getActivity(context, 0, detailIntent, 0);

        /**
         * 相当于调用setOnClickListener，注册点击启动的PendingIntent。
         * 参数：1、启动PendingIntent时用户所点击的view的ID；2、点击发送的PendingIntent
         */
        views.setOnClickPendingIntent(R.id.absoluteLayout, pending);
		
		return views;
	}

	public static RemoteViews updateTime(Context context) {
		// TODO Auto-generated method stub
		RemoteViews views = new RemoteViews(context.getPackageName(),
				R.layout.weather);
		/**
		 * 更新至当前
		 */
		TIME_WIDGET.setToNow();
		/**
		 * 获取时间图像的标志位
		 */
		int hour01 = TIME_WIDGET.hour / 10;
		int hour02 = TIME_WIDGET.hour % 10;
		int minute01 = TIME_WIDGET.minute / 10;
		int minute02 = TIME_WIDGET.minute % 10;
		
		int dayOfWeek = TIME_WIDGET.weekDay;
		/**
		 * 获取日期字符串
		 */
		CharSequence dt = DateFormat.format(context.getString(R.string.dateFormat), TIME_WIDGET.toMillis(false));
		
		views.setTextViewText(R.id.dateText, dt);
		views.setTextViewText(R.id.dayText, ForecastUtil.getDayofWeek(context, dayOfWeek));
		views.setImageViewResource(R.id.hour01Image, ForecastUtil.getImageNumber(hour01));
		views.setImageViewResource(R.id.hour02Image, ForecastUtil.getImageNumber(hour02));
		views.setImageViewResource(R.id.minute01Image, ForecastUtil.getImageNumber(minute01));
		views.setImageViewResource(R.id.minute02Image, ForecastUtil.getImageNumber(minute02));
		
		return views;
	}

	
}
