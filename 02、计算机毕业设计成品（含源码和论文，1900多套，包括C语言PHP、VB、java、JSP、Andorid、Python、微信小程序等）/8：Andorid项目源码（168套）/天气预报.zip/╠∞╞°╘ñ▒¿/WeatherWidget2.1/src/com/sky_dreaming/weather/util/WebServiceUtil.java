/**
 * 
 */
package com.sky_dreaming.weather.util;

import java.io.IOException;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

import org.apache.http.HttpEntity;
import org.apache.http.HttpResponse;
import org.apache.http.StatusLine;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.xmlpull.v1.XmlPullParser;
import org.xmlpull.v1.XmlPullParserException;
import org.xmlpull.v1.XmlPullParserFactory;

import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.util.Log;
import android.util.TimeFormatException;

import com.sky_dreaming.weather.entity.ForecastEntity;
import com.sky_dreaming.weather.entity.WidgetEntity;
import com.sky_dreaming.weather.fusion.FusionField;

/**
 * ****************************************************************
 * 文件名称	: WebServiceHelper.java
 * 作    者	: sky_dreaming
 * 创建时间	: 2010-10-26 下午04:23:10
 * 文件描述	: 提供联网获取数据方法，数据库获取更新数据并封装实体方法
 *****************************************************************
 */
public class WebServiceUtil {
	private static final String TAG = "WebServiceHelper";
	/**
	 * 只在本文件中用到的静态字符串
	 */
	private static final String FORECAST_INFORMATION = "forecast_information";
	private static final String CURRENT_CONDITIONS = "current_conditions";
	private static final String FORECAST_CONDITIONS = "forecast_conditions";
	private static final String PROBLEM_CAUSE = "problem_cause";

	private static final String CITY = "city";
	private static final String FORECAST_DATE = "forecast_date";
	private static final String CONDITION = "condition";
	private static final String TEMP_F = "temp_f";
	private static final String TEMP_C = "temp_c";
	private static final String HUMIDITY = "humidity";
	private static final String ICON = "icon";
	private static final String WIND_CONDITION = "wind_condition";

	private static final String DAY_OF_WEEK = "day_of_week";
	private static final String LOW = "low";
	private static final String HIGH = "high";

	/**
	 * 更新天气预报信息
	 * @param context
	 * @param widgetUri
	 * @throws ForecastParseException
	 */
	public static void updateForecasts(Context context, Uri widgetUri)
	throws ForecastParseException {
		Log.d(TAG, "update the nowest forecast!");

		/**
		 * forecastUri："content://com.ty.weather/widgets/" + widgetId + "/forecasts"
		 */
		Uri forecastUri = Uri.withAppendedPath(widgetUri,
				FusionField.FORECAST_END);
		
		/**
		 * 获取ContentResolver对象
		 */
		ContentResolver resolver = context.getContentResolver();

		/**
		 * 从widgetUri获取邮编
		 */
		Cursor cursor = null;
		String postalCode = null;
		try {
			cursor = resolver.query(widgetUri,
					new String[] {FusionField.POSTALCODE }, null, null, null);
			if (cursor != null && cursor.moveToFirst()) {
				postalCode = cursor.getString(0);
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}

		/**
		 * 获取天气信息并封装实体类数据对象
		 */
		WidgetEntity widgetEntity = queryWebservice(postalCode);

		if (widgetEntity == null) {
			throw new ForecastParseException(
				"No forecasts found from webservice query");
		}

		/**
		 * 清空原来"/forecasts"信息，数据项对应于天气预报详细信息界面显示
		 */
		resolver.delete(forecastUri, null, null);
		
		/**
		 * 重新填入"/forecasts"信息，数据项对应于天气预报详细信息界面显示
		 */
		ContentValues values = new ContentValues();
		for (ForecastEntity forecast : widgetEntity.getDetails()) {
			values.clear();
			values.put(FusionField.DAYOFWEEK, forecast.getDayOfWeek());
			values.put(FusionField.HIGHT, forecast.getHight());
			values.put(FusionField.LOW, forecast.getLow());
			values.put(FusionField.ICON, forecast.getIcon());
			values.put(FusionField.CONDITION, forecast.getCondition());

			Log.d(TAG, "insert detail forecast infomations:"
					+ forecast.getDayOfWeek());
			resolver.insert(forecastUri, values);
		}

		/**
		 * 更新Widget界面信息，数据项对应于Widget界面显示
		 */
		values.clear();
		values.put(FusionField.CITY, widgetEntity.getCity());
		values.put(FusionField.CONDITION, widgetEntity.getCondition());
		values.put(FusionField.FORECASTDATE, widgetEntity.getForecastDate());
		values.put(FusionField.HUMIDITY, widgetEntity.getHumidity());
		values.put(FusionField.ICON, widgetEntity.getIcon());
		values.put(FusionField.TEMPC, widgetEntity.getTempC());
		values.put(FusionField.TEMPF, widgetEntity.getTempF());
		values.put(FusionField.WINDCONDITION, widgetEntity.getWindCondition());
		values.put(FusionField.LAST_UPDATE_TIME, System.currentTimeMillis());

		Log.d(TAG, "update the weather infomation");
		resolver.update(widgetUri, values, null, null);

	}

	/**
	 * 通过邮编获取某个地区的天气信息，并封装成实体类数据对象
	 * @param postalCode
	 * @return
	 */
	private static WidgetEntity queryWebservice(String postalCode)
	throws ForecastParseException{
		if (postalCode == null) {
			throw new ForecastParseException("can not covert to entity");
		}
		/**
		 * 联网获取数据的URL
		 */
		String httpURL = String.format(FusionField.WEBSERVICE_URL, postalCode);
		Log.d(TAG, "uri:" + httpURL);

		Reader responseReader;
		WidgetEntity widgetEntity = null;

		/**
		 * HttpClient
		 */
		HttpClient client = new DefaultHttpClient();
		/**
		 * HttpGet方式提交参数获取数据
		 */
		HttpGet request = new HttpGet(httpURL);

		try {
			Log.d(TAG, "get google's weather infomation");
			HttpResponse response = client.execute(request);

			StatusLine status = response.getStatusLine();
			Log.d(TAG, "Request returned status " + status);
			
			if(status.getStatusCode() == 200)
			{
				HttpEntity entity = response.getEntity();
				responseReader = new InputStreamReader(entity.getContent(), "GB2312");
				
				/**
				 * 解析数据流
				 */
				if (responseReader != null) {
					widgetEntity = parseResponse(responseReader);
				}
			}
		} catch (UnsupportedEncodingException e) {
			throw new ForecastParseException("Problem calling forecast API", e);
		} catch (IllegalStateException e) {
			throw new ForecastParseException("Problem calling forecast API", e);
		} catch (IOException e) {
			throw new ForecastParseException("Problem calling forecast API", e);
		}
		return widgetEntity;

	}

	/**
	 * xml转换为实体
	 * 
	 * @param responseReader
	 * @return
	 */
	private static WidgetEntity parseResponse(Reader responseReader)
			throws ForecastParseException {
		Log.d(TAG, "conver xml to widgetEntity");
		WidgetEntity widgetEntity = new WidgetEntity();

		try {
			XmlPullParserFactory factory = XmlPullParserFactory.newInstance();
			XmlPullParser xpp = factory.newPullParser();

			String tagName = null;
			xpp.setInput(responseReader);
			int eventType = xpp.getEventType();

			/**
			 * SAX方式循环解析xml文件
			 */
			while (eventType != XmlPullParser.END_DOCUMENT) {
				
				if (eventType == XmlPullParser.START_TAG) {
					
					/**
					 * 获取xml元素名
					 */
					tagName = xpp.getName();
					/**
					 * 城市代码错误，抛出异常
					 */
					if (PROBLEM_CAUSE.equals(tagName)) {
						throw new ForecastParseException("the city is non correct!");
					} else if (FORECAST_INFORMATION.equals(tagName)) {
						/**
						 * forecast_information
						 */
						dealWithInfomation(tagName, widgetEntity, xpp);
					} else if (CURRENT_CONDITIONS.equals(tagName)) {
						/**
						 * current_conditions
						 */
						dealWithCurrentConditions(tagName, widgetEntity, xpp);
					} else if (FORECAST_CONDITIONS.equals(tagName)) {
						/**
						 * forecast_conditions
						 */
						dealWithForecastConditions(tagName, widgetEntity, xpp);
					}
				}
				eventType = xpp.next();
			}
		} catch (IOException e) {
			throw new ForecastParseException("Problem parsing XML forecast", e);
		} catch (XmlPullParserException e) {
			throw new ForecastParseException("Problem parsing XML forecast", e);
		} catch (TimeFormatException e) {
			throw new ForecastParseException("Problem parsing XML forecast", e);
		}
		Log.d(TAG, "covert xml to entity success");
		return widgetEntity;
	}

	/**
	 * 封装天气信息
	 * @param name 
	 * @param widgetEntity
	 * @param xpp
	 * @throws IOException
	 * @throws XmlPullParserException
	 */
	private static void dealWithInfomation(String name,
			WidgetEntity widgetEntity, XmlPullParser xpp) throws IOException,XmlPullParserException {

		Log.d(TAG, "dealWithInfomation");
		/**
		 * 指向下一个元素
		 */
		xpp.next();
		/**
		 * 获取标签类型：开始，结束
		 */
		int eventType = xpp.getEventType();
		/**
		 * 获取元素标签名
		 */
		String tagName = xpp.getName();
		
		while ((!name.equals(tagName) || eventType != XmlPullParser.END_TAG)
				&& eventType != XmlPullParser.END_DOCUMENT) {
			/**
			 * 如果元素标签为开始标签
			 */
			if (eventType == XmlPullParser.START_TAG) {
				
				if (tagName.equals(CITY)) {
					/**
					 * city信息
					 */
					widgetEntity.setCity(xpp.getAttributeValue(null, "data"));
				} else if (tagName.equals(FORECAST_DATE)) {
					/**
					 * 日期信息
					 */
					widgetEntity.setForecastDate(convertStr2Date(xpp
							.getAttributeValue(null, "data")).getTime());
				}
			}
			/**
			 * 指向下一个元素
			 */
			xpp.next();

			eventType = xpp.getEventType();
			tagName = xpp.getName();
		}
	}
	
	/**
	 * 封装后几天的预报信息
	 * @param name
	 * @param widgetEntity
	 * @param xpp
	 * @throws IOException
	 * @throws XmlPullParserException
	 */
	private static void dealWithForecastConditions(String name,
			WidgetEntity widgetEntity, XmlPullParser xpp) throws IOException,XmlPullParserException {
		
		Log.d(TAG, "dealWithForecastConditions");
		ForecastEntity forecast = new ForecastEntity();
		/**
		 * 指向下一个元素
		 */
		xpp.next();

		/**
		 * 获取标签类型：开始，结束
		 */
		int eventType = xpp.getEventType();
		/**
		 * 获取元素标签名
		 */
		String tagName = xpp.getName();
		
		while ((!name.equals(tagName) || eventType != XmlPullParser.END_TAG)
				&& eventType != XmlPullParser.END_DOCUMENT) {
			/**
			 * 如果元素标签为开始标签
			 */
			if (eventType == XmlPullParser.START_TAG) {
				if (tagName.equals(CONDITION)) {
					/**
					 * 天气状态
					 */
					forecast.setCondition(xpp.getAttributeValue(null, "data"));
				} else if (tagName.equals(DAY_OF_WEEK)) {
					/**
					 * 周几
					 */
					forecast.setDayOfWeek(xpp.getAttributeValue(null, "data"));
				} else if (tagName.equals(HIGH)) {
					/**
					 * 最高温度
					 */
					forecast.setHight(Integer.parseInt(xpp.getAttributeValue(
							null, "data")));
				} else if (tagName.equals(LOW)) {
					/**
					 * 最低温度
					 */
					forecast.setLow(Integer.parseInt(xpp.getAttributeValue(
							null, "data")));
				} else if (tagName.equals(ICON)) {
					/**
					 * 对天气状态的图标的描述
					 */
					forecast.setIcon(xpp.getAttributeValue(null, "data"));
				}
			}
			xpp.next();

			eventType = xpp.getEventType();
			tagName = xpp.getName();
		}
		/**
		 * 加入天气列表（通常显示后4天的天气）
		 */
		widgetEntity.getDetails().add(forecast);
	}

	/**
	 * 封装当前的天气信息
	 * @param name
	 * @param widgetEntity
	 * @param xpp
	 * @throws IOException
	 * @throws XmlPullParserException
	 */
	private static void dealWithCurrentConditions(String name,
			WidgetEntity widgetEntity, XmlPullParser xpp) throws IOException,XmlPullParserException {

		Log.d(TAG, "dealWithCurrentConditions");
		/**
		 * 指向下一个元素
		 */
		xpp.next();

		/**
		 * 获取标签类型：开始，结束
		 */
		int eventType = xpp.getEventType();
		/**
		 * 获取元素标签名
		 */
		String tagName = xpp.getName();
		
		while ((!name.equals(tagName) || eventType != XmlPullParser.END_TAG)
				&& eventType != XmlPullParser.END_DOCUMENT) {
			/**
			 * 如果元素标签为开始标签
			 */
			if (eventType == XmlPullParser.START_TAG) {
				if (tagName.equals(CONDITION)) {
					/**
					 * 天气状态
					 */
					widgetEntity.setCondition(xpp.getAttributeValue(null,
							"data"));
					Log.d(TAG, "condition" + widgetEntity.getCondition());
				} else if (tagName.equals(TEMP_F)) {
					/**
					 * ？？
					 */
					widgetEntity.setTempF(Integer.parseInt(xpp
							.getAttributeValue(null, "data")));
					Log.d(TAG, "TEMP_F" + widgetEntity.getTempF());
				} else if (tagName.equals(TEMP_C)) {
					/**
					 * 当前温度
					 */
					widgetEntity.setTempC(Integer.parseInt(xpp
							.getAttributeValue(null, "data")));
					Log.d(TAG, "TEMP_C" + widgetEntity.getTempC());
				} else if (tagName.equals(HUMIDITY)) {
					/**
					 * 湿度信息
					 */
					widgetEntity.setHumidity(xpp
							.getAttributeValue(null, "data"));
				} else if (tagName.equals(ICON)) {
					/**
					 * 对当前天气状态的图标描述
					 */
					widgetEntity.setIcon(xpp.getAttributeValue(null, "data"));
				} else if (tagName.equals(WIND_CONDITION)) {
					/**
					 * 风向信息
					 */
					widgetEntity.setWindCondition(xpp.getAttributeValue(null,
							"data"));
				}
			}
			xpp.next();

			eventType = xpp.getEventType();
			tagName = xpp.getName();
		}
	}

	
	/**
	 * 日期格式转换
	 * @param str
	 * @return
	 */
	private static Date convertStr2Date(String str) {
		Date d = null;
		try{
			SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd");
			d = f.parse(str);
		}catch(ParseException e){
			Log.d(TAG, "date format exception");
		}
		return d;
	}
	
	/**
	 * 获取天气预报实体类
	 * @param context
	 * @param uri
	 * @return
	 */
	public static WidgetEntity getWidgetEntity(Context context, Uri uri, boolean needDetails) {

		/**
		 * 所获取的信息在updateForecasts(Context context, Uri widgetUri)方法中更新至数据库
		 */
		Log.d(TAG, "get forcast infomation from database");
		
		WidgetEntity widgetEn = null;
		ContentResolver res = context.getContentResolver();

		Cursor cursor = null;

		/**
		 * 封装Widget界面信息，数据项对应于Widget界面显示
		 */
		try {
			cursor = res.query(uri, FusionField.widgetProjection, null, null,
					null);
			if (cursor != null && cursor.moveToFirst()) {
				widgetEn = new WidgetEntity();
				widgetEn.setUpdateMilis(cursor.getInt(0));
				widgetEn.setCity(cursor.getString(1));
				widgetEn.setPostalCode(cursor.getString(2));
				widgetEn.setForecastDate(cursor.getLong(3));
				widgetEn.setCondition(cursor.getString(4));
				widgetEn.setTempF(cursor.getInt(5));
				widgetEn.setTempC(cursor.getInt(6));
				widgetEn.setHumidity(cursor.getString(7));
				widgetEn.setIcon(cursor.getString(8));
				widgetEn.setWindCondition(cursor.getString(9));
				widgetEn.setLastUpdateTime(cursor.getLong(10));
				widgetEn.setIsConfigured(cursor.getInt(11));
			} else {
				return null;
			}
		} finally {
			if (cursor != null) {
				cursor.close();
			}
		}

		/**
		 * 封装"/forecasts"信息，数据项对应于天气预报详细信息界面显示
		 */
		if (needDetails){
			try {
				/**
				 * forecastUri："content://com.ty.weather/widgets/" + widgetId + "/forecasts"
				 */
				Uri forecastUri = Uri.withAppendedPath(uri,
						FusionField.FORECAST_END);
				
				cursor = res.query(forecastUri, FusionField.forecastProjection,
						null, null, null);
				
				ForecastEntity forecast = null;
				while (cursor != null && cursor.moveToNext()) {
					forecast = new ForecastEntity();
					forecast.setDayOfWeek(cursor.getString(1));
					forecast.setLow(cursor.getInt(2));
					forecast.setHight(cursor.getInt(3));
					forecast.setIcon(cursor.getString(4));
					forecast.setCondition(cursor.getString(5));
					forecast.setWidgetId(cursor.getInt(6));
	
					widgetEn.getDetails().add(forecast);
				}
			} finally {
				if (cursor != null) {
					cursor.close();
				}
			}
		}
		return widgetEn;
	}

	/**
	 * ****************************************************************
	 * 文件名称	: WebServiceHelper.java
	 * 作    者	: qiang.hou
	 * 创建时间	: 2010-10-26 下午04:22:03
	 * 类     描述	: 自定义异常
	 *****************************************************************
	 */
	public static final class ForecastParseException extends Exception {
		/**
		 * serialVersionUID
		 */
		private static final long serialVersionUID = -891526452631557227L;

		public ForecastParseException(String detailMessage) {
			super(detailMessage);
		}

		public ForecastParseException(String detailMessage, Throwable throwable) {
			super(detailMessage, throwable);
		}
	}
}
