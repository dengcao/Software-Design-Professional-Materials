/**
 * 
 */
package com.sky_dreaming.weather.entity;

/**
 * ****************************************************************
 * 文件名称	: ForecastEntity.java
 * 作    者	: sky_dreaming
 * 创建时间	: 2010-10-26 下午04:41:15
 * 文件描述	: 每天的天气预报信息封装类
 *****************************************************************
 */
public class ForecastEntity {

	private Integer id;
	/**
	 * 周几
	 */
	private String dayOfWeek;
	/**
	 * 最低温度
	 */
	private Integer low;
	/**
	 * 最高温度
	 */
	private Integer hight;
	/**
	 * 天气状态图标描述
	 */
	private String icon;
	/**
	 * 天气状态
	 */
	private String condition;
	/**
	 * 所属widget的ID
	 */
	private Integer widgetId;
	

	public Integer getId() {
		return id;
	}
	
	public void setId(Integer id) {
		this.id = id;
	}

	public String getDayOfWeek() {
		return dayOfWeek;
	}

	public void setDayOfWeek(String dayOfWeek) {
		this.dayOfWeek = dayOfWeek;
	}

	public Integer getLow() {
		return low;
	}

	public void setLow(Integer low) {
		this.low = low;
	}

	public Integer getHight() {
		return hight;
	}

	public void setHight(Integer hight) {
		this.hight = hight;
	}

	public String getIcon() {
		return icon;
	}

	public void setIcon(String icon) {
		this.icon = icon;
	}

	public String getCondition() {
		return condition;
	}

	public void setCondition(String condition) {
		this.condition = condition;
	}

	public void setWidgetId(Integer widgetId) {
		this.widgetId = widgetId;
	}

	public Integer getWidgetId() {
		return widgetId;
	}

}
