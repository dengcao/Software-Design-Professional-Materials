package com.sky_dreaming.weather.fusion;

import android.net.Uri;
import android.provider.BaseColumns;

public class FusionField {
	/**
	 * 天气预报联网API地址
	 */
	public static final String WEBSERVICE_URL = "http://www.google.com/ig/api?weather=%s&hl=zh-cn";
	/**
	 * 程序包路径
	 */
	public static final String PACKAGE_PATH = "com.sky_dreaming.weather";
	
	
	
	/**
	 * WeatherWidgets
	 */
	public static final Uri CONTENT_URI = Uri.parse("content://"
			+ PACKAGE_PATH + "/widgets");
	
	public static final String FORECAST_END = "forecasts";

	public static final String CONTENT_TYPE = "vnd.android.cursor.dir/awidget";
	public static final String CONTENT_ITEM_TYPE = "vnd.android.cursor.item/widget";


	/**
	 * WeatherDetails
	 */
	public static final Uri CONTENT_URI_DETAILS = Uri.parse("content://"
			+ PACKAGE_PATH + "/forecasts");
	public static final String CONTENT_TYPE_DETAILS = "vnd.android.cursor.dir/forecasts";
	public static final String CONTENT_ITEM_TYPE_DETAILS = "vnd.android.cursor.item/forecasts";
	
	/**
	 * widget endity
	 */
	/**
	 * widget数据更新时间间隔字段
	 */
	public static final String UPDATE_MILIS = "updateMilis";
	/**
	 * 城市
	 */
	public static final String CITY = "city";
	/**
	 * 邮政编码
	 */
	public static final String POSTALCODE = "postalCode";
	/**
	 * 预报日期，当前天气状态，，，湿度，天气图标，风向，最后一次更新时间，是否设置
	 */
	public static final String FORECASTDATE = "forecastDate";
	public static final String CONDITION = "condition";
	public static final String TEMPF = "tempF";
	public static final String TEMPC = "tempC";
	public static final String HUMIDITY = "humidity";
	public static final String ICON = "icon";
	public static final String WINDCONDITION = "windCondition";
	public static final String LAST_UPDATE_TIME = "lastUpdateTime";
	public static final String IS_CONFIGURED = "isConfigured";
	/**
	 * widget entity 相关字段
	 */
	public static final String[] widgetProjection = new String[]{
		UPDATE_MILIS,
		CITY,
		POSTALCODE,
		FORECASTDATE,
		CONDITION,
		TEMPF,
		TEMPC,
		HUMIDITY,
		ICON,
		WINDCONDITION,
		LAST_UPDATE_TIME,
		IS_CONFIGURED
		
	};
	
	/**
	 * forecast endity
	 */
	public static final String DAYOFWEEK = "dayOfWeek";
	public static final String LOW = "low";
	public static final String HIGHT = "hight";
	public static final String WIDGET_ID = "widgetId";
	/**
	 * forecast entity 相关字段
	 */
	public static final String[] forecastProjection = new String[]{
		BaseColumns._ID,
		DAYOFWEEK, 
		LOW,
		HIGHT,
		ICON,
		CONDITION,
		WIDGET_ID		
	};
}
