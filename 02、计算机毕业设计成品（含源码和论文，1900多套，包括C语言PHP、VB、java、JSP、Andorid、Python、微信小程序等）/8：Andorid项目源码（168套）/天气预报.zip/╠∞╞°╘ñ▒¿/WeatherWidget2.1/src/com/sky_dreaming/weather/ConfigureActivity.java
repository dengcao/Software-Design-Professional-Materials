package com.sky_dreaming.weather;

import android.app.Activity;
import android.appwidget.AppWidgetManager;
import android.content.ContentResolver;
import android.content.ContentValues;
import android.content.Intent;
import android.os.Bundle;
import android.provider.BaseColumns;
import android.util.Log;
import android.view.View;
import android.view.Window;
import android.widget.Button;
import android.widget.EditText;

import com.sky_dreaming.weather.fusion.FusionField;
import com.sky_dreaming.weather.service.ForecastService;
import com.sky_dreaming.weather.R;

/**
 * ****************************************************************
 * 文件名称	: ConfigureActivity.java
 * 作    者	: sky_dreaming
 * 创建时间	: 2010-10-27 下午04:02:04
 * 文件描述	: 参数设置界面
 *****************************************************************
 */
public class ConfigureActivity extends Activity implements View.OnClickListener{
	private static String TAG = "ConfigureActivity";
	
	private EditText editCity, editUpdatetime;
	private String city;
	private int updatetime;

    private int widgetId = AppWidgetManager.INVALID_APPWIDGET_ID;
	
	/** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Log.d(TAG, "ty-weather configure started");
        
        requestWindowFeature(Window.FEATURE_INDETERMINATE_PROGRESS);        
        setContentView(R.layout.configure);
        
        editCity = (EditText)findViewById(R.id.editCity);
        editUpdatetime = (EditText)findViewById(R.id.editUpdatetime);
        final Button btnSave = (Button)findViewById(R.id.btnSave);
        
        btnSave.setOnClickListener(this);
        
        /**
         * Read the appWidgetId to configure from the incoming intent
         */
        widgetId = getIntent().getIntExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        
        setConfigureResult(Activity.RESULT_CANCELED);
        
        /**
         * 如果获取的widgetId为默认值，也就是没有取到需要设置的widgetId
         */
        if (widgetId == AppWidgetManager.INVALID_APPWIDGET_ID) {
            finish();
            return;
        }
        
        /**
         * 如果以前设置好的参数的默认值的话，取得并初始化控件
         */
        if (savedInstanceState != null){
        	city = savedInstanceState.getString("city");
        	updatetime = savedInstanceState.getInt("updatetime");
        	
        	editCity.setText(city);
        	editUpdatetime.setText(updatetime);
        }
    }
    
    /**
     * 该Activity被kill时调用，保存在本Activity中设置的参数
     * @param outState
     */
    @Override
    protected void onSaveInstanceState(Bundle outState) {
    	super.onSaveInstanceState(outState);
    	
    	outState.putString("city", city);
    	outState.putInt("updatetime", updatetime);    	

		Log.d(TAG, "ty-weather onSaveInstanceState!");
    }

    @Override
	public void onClick(View v) {
		Log.d(TAG, "ty-weather configure save!");
		switch (v.getId()) {
		case R.id.btnSave: {
			city = editCity.getText().toString();
			updatetime = Integer.parseInt(editUpdatetime.getText().toString());
			
			/**
			 * 数据库插入本次设置的Widget相关信息
			 */
			ContentValues values = new ContentValues();
			values.put(BaseColumns._ID, widgetId);
			values.put(FusionField.POSTALCODE, city);
			values.put(FusionField.UPDATE_MILIS, updatetime);
			values.put(FusionField.LAST_UPDATE_TIME, -1);
			values.put(FusionField.IS_CONFIGURED, 1);
			
			ContentResolver resolver = getContentResolver();
			resolver.insert(FusionField.CONTENT_URI, values);
			
			/**
			 * 向服务添加所设置的Widget的ID，并启动服务
			 */
			Log.d(TAG, "ty-weather start Service!");
			ForecastService.addWidgetIDs(new int[]{widgetId});
			startService(new Intent(this, ForecastService.class));
			
			setConfigureResult(Activity.RESULT_OK);
            finish();
			break;
		}
		}
	}
	
	/**
     * Convenience method to always include {@link #widgetId} when setting
     * the result {@link Intent}.
     */
	public void setConfigureResult(int resultCode) {
        final Intent data = new Intent();
        data.putExtra(AppWidgetManager.EXTRA_APPWIDGET_ID, widgetId);
        /**
         * Call this to set the result that your activity will return to its caller
         */
        setResult(resultCode, data);
    }
}
