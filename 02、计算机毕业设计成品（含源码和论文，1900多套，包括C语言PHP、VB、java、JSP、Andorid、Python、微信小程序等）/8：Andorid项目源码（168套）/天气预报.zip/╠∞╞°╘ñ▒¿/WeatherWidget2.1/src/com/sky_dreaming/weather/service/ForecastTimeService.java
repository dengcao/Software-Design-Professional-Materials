/**
 * 
 */
package com.sky_dreaming.weather.service;

import com.sky_dreaming.weather.ForecastWidget;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.os.IBinder;
import android.util.Log;
import android.widget.RemoteViews;
/**
 * ****************************************************************
 * 文件名称	: ForecastTimeService.java
 * 作    者	: sky_dreaming
 * 创建时间	: 2010-10-25 下午05:04:33
 * 文件描述	: 时间信息的服务
 *****************************************************************
 */
public class ForecastTimeService extends Service {
	private static final String TAG = "ForecastTimeService";	

	/**
	 * (non-Javadoc)
	 * 
	 * @see android.app.Service#onBind(android.content.Intent)
	 */
	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}
	
	/**
	 * 开启服务
	 * @param intent
	 * @param startId
	 */
	@Override
	public void onStart(Intent intent, int startId) {
		// TODO Auto-generated method stub
		super.onStart(intent, startId);
		Log.d(TAG, "start service Time update");
        
		AppWidgetManager manager = AppWidgetManager.getInstance(this);
		
		RemoteViews updateViews = ForecastWidget.updateTime(this);
		
		if (updateViews != null){
			/**
			 * 获取提供ForecastWidget的provider所提供的widget应用的ID
			 */
			int widgetId[] = manager.getAppWidgetIds(new ComponentName(this,
					ForecastWidget.class));
			/**
			 * 更新widget：将updateViews应用于widgetId所代表的Widget应用
			 */
			manager.updateAppWidget(widgetId, updateViews);
		}
		
		/**
		 *  设置下次执行时间,每隔20秒刷新一次
		 */
		long now = System.currentTimeMillis();
		long updateMilis = 20 * 1000;
		
		PendingIntent pendingIntent = PendingIntent.getService(this, 0,
				intent, 0);
		
		/**
		 *  Schedule alarm, and force the device awake for this update
		 *  设置在nextUpdate时间间隔后发送pendingIntent
		 */
		AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		alarmManager.set(AlarmManager.RTC_WAKEUP, now + updateMilis, pendingIntent);

		/**
		 * 停止服务
		 */
		stopSelf();
	}

}
