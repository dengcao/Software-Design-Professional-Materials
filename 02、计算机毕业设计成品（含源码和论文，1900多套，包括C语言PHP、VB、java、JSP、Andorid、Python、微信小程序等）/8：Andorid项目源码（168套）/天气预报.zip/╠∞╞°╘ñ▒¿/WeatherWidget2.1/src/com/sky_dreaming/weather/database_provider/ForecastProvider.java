/**
 * 
 */
package com.sky_dreaming.weather.database_provider;

import android.content.ContentProvider;
import android.content.ContentUris;
import android.content.ContentValues;
import android.content.UriMatcher;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteQueryBuilder;
import android.net.Uri;
import android.provider.BaseColumns;
import android.util.Log;

import com.sky_dreaming.weather.fusion.FusionField;
/**
 * ****************************************************************
 * 文件名称	: ForecastProvider.java
 * 作    者	: sky_dreaming
 * 创建时间	: 2010-10-27 下午02:24:27
 * 文件描述	: 重写ContentProvider，实现对数据库的URI方式操作
 *****************************************************************
 */
public class ForecastProvider extends ContentProvider {
	private static final String TAG = "ForecastProvider";

	/**
	 * 创建过滤器，过滤传参进来的URI
	 */
	private static final UriMatcher uriMatcher = new UriMatcher(
			UriMatcher.NO_MATCH);

	private static final int WIDGETS = 101;
	private static final int WIDGETS_ID = 102;
	private static final int WIDGETS_FORECASTS = 103;

	private static final int FORECASTS = 201;
	private static final int FORECASTS_ID = 202;

	static {
		uriMatcher.addURI(FusionField.PACKAGE_PATH, "widgets", WIDGETS);
		uriMatcher.addURI(FusionField.PACKAGE_PATH, "widgets/#", WIDGETS_ID);
		uriMatcher.addURI(FusionField.PACKAGE_PATH, "widgets/#/forecasts", WIDGETS_FORECASTS);

		uriMatcher.addURI(FusionField.PACKAGE_PATH, "forecasts", FORECASTS);
		uriMatcher.addURI(FusionField.PACKAGE_PATH, "forecasts/#", FORECASTS_ID);
	}
	
	private DBHelper dbHelper;
	
	/**
	 * 重写
	 * 
	 * @see android.content.ContentProvider#onCreate()
	 */
	@Override
	public boolean onCreate() {
		Log.d(TAG, "Forecast Provider onCreate!");
		dbHelper = new DBHelper(getContext());
		return true;
	}
	/**
	 * 重写
	 * 
	 * @see android.content.ContentProvider#delete(android.net.Uri,
	 * java.lang.String, java.lang.String[])
	 */
	@Override
	public int delete(Uri uri, String selection, String[] selectionArgs) {
		Log.d(TAG, "delete() with uri=" + uri);
		SQLiteDatabase db = dbHelper.getWritableDatabase();
		int count = 0;
		switch (uriMatcher.match(uri)) {
		case WIDGETS: {
			/**
			 * 清空weather_widget表
			 */
            count = db.delete(DBHelper.TABLE_WIDGET, selection, selectionArgs);
            break;
        }
        case WIDGETS_ID: {
            /**
             * 删除weather_widget表中一个特定的Widget数据行
             * uri.getPathSegments().get(1)：获取uri中第二个切片，第一个为/widgets，第二个为/#
             */
            long appWidgetId = Long.parseLong(uri.getPathSegments().get(1));
            count = db.delete(DBHelper.TABLE_WIDGET, BaseColumns._ID + "=" + appWidgetId, null);
            count += db.delete(DBHelper.TABLE_FORECAST, FusionField.WIDGET_ID + "="
                    + appWidgetId, null);
            break;
        }
        case WIDGETS_FORECASTS: {
            /**
             * 删除weather_forecast中符合指定appWidgetId的数据行
             */
            long appWidgetId = Long.parseLong(uri.getPathSegments().get(1));
            /**
             * 重构删除条件
             */
            if (selection == null) {
                selection = "";
            } else {
                selection = "(" + selection + ") AND ";
            }
            selection += FusionField.WIDGET_ID + "=" + appWidgetId;
            
            count = db.delete(DBHelper.TABLE_FORECAST, selection, selectionArgs);
            break;
        }
		case FORECASTS: {
			/**
             * 清空weather_forecast表
             */
			count = db.delete(DBHelper.TABLE_FORECAST, selection, selectionArgs);
			break;
		}
		case FORECASTS_ID: {
			/**
             * 删除weather_forecast中特定数据行
             */
			long forecaseId = Long.parseLong(uri.getPathSegments().get(1));
			count = db.delete(DBHelper.TABLE_FORECAST, BaseColumns._ID + "=" + forecaseId,
					null);
			break;
		}
		default:
			throw new UnsupportedOperationException();
		}

		return count;
	}

	/**
	 * 重写
	 * 
	 * @see android.content.ContentProvider#getType(android.net.Uri)
	 */
	@Override
	public String getType(Uri uri) {
		switch (uriMatcher.match(uri)) {
        case WIDGETS:
            return FusionField.CONTENT_TYPE;
        case WIDGETS_ID:
            return FusionField.CONTENT_ITEM_TYPE;
        case WIDGETS_FORECASTS:
            return FusionField.CONTENT_TYPE;
		case FORECASTS:
			return FusionField.CONTENT_TYPE;
		case FORECASTS_ID:
			return FusionField.CONTENT_ITEM_TYPE;
		}
		throw new IllegalStateException();
	}

	/**
	 * 重写
	 * 
	 * @see android.content.ContentProvider#insert(android.net.Uri,
	 * android.content.ContentValues)
	 */
	@Override
	public Uri insert(Uri uri, ContentValues values) {
		Log.d(TAG, "insert() with uri=" + uri);
		SQLiteDatabase db = dbHelper.getWritableDatabase();

		Uri resultUri = null;

		switch (uriMatcher.match(uri)) {
		case WIDGETS: {
			/**
			 * 插入一个widget信息
			 */
            long rowId = db.insert(DBHelper.TABLE_WIDGET, FusionField.POSTALCODE, values);
            if (rowId != -1) {
                resultUri = ContentUris.withAppendedId(FusionField.CONTENT_URI, rowId);
            }
            break;
        }
        case WIDGETS_FORECASTS: {
            /**
             * 为指定widget插入一个forcast数据行
             */
            long appWidgetId = Long.parseLong(uri.getPathSegments().get(1));
            values.put(FusionField.WIDGET_ID, appWidgetId);
            long rowId = db.insert(DBHelper.TABLE_FORECAST, FusionField.CONDITION, values);
            if (rowId != -1) {
                resultUri = ContentUris.withAppendedId(FusionField.CONTENT_URI_DETAILS, rowId);
            }
            break;
        }
        case FORECASTS: {
        	/**
             * 插入一个forcast数据行
             */
			long rowId = db.insert(DBHelper.TABLE_FORECAST, FusionField.CONDITION, values);
			if (rowId != -1) {
				resultUri = ContentUris.withAppendedId(FusionField.CONTENT_URI_DETAILS,
						rowId);
			}
			break;
		}
		default:
			throw new UnsupportedOperationException();
		}

		return resultUri;
	}

	/**
	 * 重写
	 * 
	 * @see android.content.ContentProvider#query(android.net.Uri,
	 * java.lang.String[], java.lang.String, java.lang.String[],
	 * java.lang.String)
	 */
	@Override
	public Cursor query(Uri uri, String[] projection, String selection,
			String[] selectionArgs, String sortOrder) {
		Log.d(TAG, "query() with uri=" + uri);
		
		SQLiteDatabase db = dbHelper.getReadableDatabase();
		SQLiteQueryBuilder qb = new SQLiteQueryBuilder();

		String limit = null;

		switch (uriMatcher.match(uri)) {
		case WIDGETS: {
			/**
			 * 查询多个表，可形成特殊条件下的联合查询，
			 * 例如：setTables("foo, bar")
			 * 		 setTables("foo LEFT OUTER JOIN bar ON (foo.id = bar.foo_id)")
			 * 形成联合查询
			 */
            qb.setTables(DBHelper.TABLE_WIDGET);
            break;
        }
        case WIDGETS_ID: {
            String appWidgetId = uri.getPathSegments().get(1);
            qb.setTables(DBHelper.TABLE_WIDGET);
            qb.appendWhere(BaseColumns._ID + "=" + appWidgetId);
            break;
        }
        case WIDGETS_FORECASTS: {
            /**
             * 查询指定widgetID下的所有forcasts，按ID的升序返回
             */
            String appWidgetId = uri.getPathSegments().get(1);
            qb.setTables(DBHelper.TABLE_FORECAST);
            qb.appendWhere(FusionField.WIDGET_ID + "=" + appWidgetId);
            sortOrder = BaseColumns._ID + " ASC";
            break;
        }case FORECASTS: {
			qb.setTables(DBHelper.TABLE_FORECAST);
			break;
		}
		case FORECASTS_ID: {
			String forecastId = uri.getPathSegments().get(1);
			qb.setTables(DBHelper.TABLE_FORECAST);
			qb.appendWhere(BaseColumns._ID + "=" + forecastId);
			break;
		}
		}

		return qb.query(db, projection, selection, selectionArgs, null, null,
				sortOrder, limit);
	}

	/**
	 * 重写
	 * 
	 * @see android.content.ContentProvider#update(android.net.Uri,
	 * android.content.ContentValues, java.lang.String, java.lang.String[])
	 */
	@Override
	public int update(Uri uri, ContentValues values, String selection,
			String[] selectionArgs) {
		Log.d(TAG, "update() with uri=" + uri);
		
		SQLiteDatabase db = dbHelper.getWritableDatabase();

		switch (uriMatcher.match(uri)) {
		case WIDGETS: {
			/**
        	 * 更新特定条件下的widgets信息
        	 */
            return db.update(DBHelper.TABLE_WIDGET, values, selection, selectionArgs);
        }
        case WIDGETS_ID: {
        	/**
        	 * 按ID值更新一个特定的widget信息
        	 */
            long appWidgetId = Long.parseLong(uri.getPathSegments().get(1));
            return db.update(DBHelper.TABLE_WIDGET, values, BaseColumns._ID + "=" + appWidgetId,
                    null);
        }
        case FORECASTS: {
        	/**
        	 * 更新特定条件下的forecasts信息
        	 */
			return db.update(DBHelper.TABLE_FORECAST, values, selection, selectionArgs);
		}
		}

		throw new UnsupportedOperationException();
	}
}
