/**
 * 
 */
package com.sky_dreaming.weather.service;

import java.util.LinkedList;
import java.util.Queue;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.Service;
import android.appwidget.AppWidgetManager;
import android.content.ComponentName;
import android.content.ContentResolver;
import android.content.ContentUris;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.IBinder;
import android.util.Log;
import android.widget.RemoteViews;

import com.sky_dreaming.weather.ForecastWidget;
import com.sky_dreaming.weather.fusion.FusionField;
import com.sky_dreaming.weather.util.WebServiceUtil;
import com.sky_dreaming.weather.util.WebServiceUtil.ForecastParseException;

/**
 * ****************************************************************
 * 文件名称	: ForecastService.java
 * 作    者	: sky_dreaming
 * 创建时间	: 2010-10-25 下午03:49:21
 * 文件描述	: 获取天气预报信息的服务
 *****************************************************************
 */
public class ForecastService extends Service implements Runnable {
	private static String TAG = "ForecastService";

	/**
	 *  所需更新的widget ID
	 */
	private static Queue<Integer> requestWidgetIDs = new LinkedList<Integer>();
	
	/**
	 *  用于维护桌面小控件的ID队列的同步锁对象
	 */
	private static Object sLock = new Object();
	
	/**
	 *  控制线程运行的变量
	 */
	private static boolean isThreadRun = false;
	
	/**
	 *  所需更新的Widget
	 */
	public static final String ACTION_UPDATE_ALL = "com.ty.weather.UPDATE_ALL";
	
	/**
	 * 本文件中用到的widget相关字段：是否设置，最后更新时间，更新时间间隔
	 */
	private static final String[] widgetProjection = new String[] {
		FusionField.IS_CONFIGURED, FusionField.LAST_UPDATE_TIME,
		FusionField.UPDATE_MILIS };

	/**
	 * function addWedgetIDs 向队列中添加widget ID
	 */
	public static void addWidgetIDs(int[] widgetIDs) {
		synchronized (sLock) {
			for (int id : widgetIDs) {
				Log.d(TAG, "add widget ID:" + id);
				requestWidgetIDs.add(id);
			}
		}
	}

	/**
	 * function hasMoreWidgetIds 判断队列中是否还有widget ID
	 */
	public static boolean hasMoreWidgetIDs() {
		synchronized (sLock) {
			/**
			 * 也就是当控件队列为空时，设置isThreadRun = false，返回false
			 */
			boolean hasMore = !requestWidgetIDs.isEmpty();
			if (!hasMore) {
				isThreadRun = hasMore;
			}
			return hasMore;
		}
	}

	/**
	 * function nextWidgetIDs 获取队列中的widget ID
	 */
	public static Integer nextWidgetIDs() {
		synchronized (sLock) {
			/**
			 * function peek 获取但不移除队列的头元素
			 */
			if (requestWidgetIDs.peek() != null) {
				/**
				 * function poll 获取并移除队列的头元素，如果队列为空时返回null
				 */
				return requestWidgetIDs.poll();
			} else {
				/**
				 * AppWidget 管理器从来不会用来当做appWidgetId的一个无效ID值
				 */
				return AppWidgetManager.INVALID_APPWIDGET_ID;
			}
		}
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see android.app.Service#onBind(android.content.Intent)
	 */
	@Override
	public IBinder onBind(Intent arg0) {
		return null;
	}

	/**
	 * 开启服务
	 * @param intent
	 * @param startId
	 */
	@Override
	public void onStart(Intent intent, int startId) {
		super.onStart(intent, startId);
		Log.d(TAG, "service started");
		
		/**
		 * 当判定action为更新所有控件时……
		 */
		if (ACTION_UPDATE_ALL.equals(intent.getAction())) {
			Log.d(TAG, "Requested UPDATE_ALL action");
			
			/**
			 * 实例化AppWidgetManager
			 */
			AppWidgetManager manager = AppWidgetManager.getInstance(this);
			
			/**
			 * 特殊应用程序组件的标识，两个参数分别代表了组件所在包，包中的类
			 */
			ComponentName identity = new ComponentName(this,
					ForecastWidget.class);
			
			/**
			 * 获取被绑定在所给出的AppWidget provider中的appWidgetIds列表
			 */
			int [] appWidgetIds = manager.getAppWidgetIds(identity);
			
			/**
			 * 将获取的IDs加入队列
			 */
			addWidgetIDs(appWidgetIds);
		}

		/**
		 * 服务未运行，开始线程，启动服务
		 */
		synchronized (sLock) {
			if (!isThreadRun) {
				isThreadRun = true;
				new Thread(this).start();
			}
		}
	}

	/**
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Runnable#run()
	 */
	@Override
	public void run() {
		
		Log.d(TAG, "the ForecastService Thread Run!");
		
        AppWidgetManager manager = AppWidgetManager.getInstance(this);
		ContentResolver resolver = getContentResolver();

		long now = System.currentTimeMillis();
		/**
		 * 默认两小时更新一次
		 */
		long updateMilis = 2 * 60 * 60 * 1000;

		while (hasMoreWidgetIDs()) {
			Log.d(TAG, "run across very widiget Ids");
			/**
			 * 获取控件ID列表头元素
			 */
			int widgetId = nextWidgetIDs();
			
			/**
			 * 将获得的widgetId加到uri的尾部 ："content://com.ty.weather/widgets" + widgetId
			 */
			Uri uri = ContentUris.withAppendedId(FusionField.CONTENT_URI,
					widgetId);

			Cursor cursor = null;
			boolean isConfigured = false;
			boolean shouldUpdate = false;

			try {
				/**
				 * 在uri指定位置获取widgetProjection指定列的内容，其他三个参数为选择，选择参数，返回顺序
				 */
				cursor = resolver
						.query(uri, widgetProjection, null, null, null);

				if (cursor != null && cursor.moveToFirst()) {
					Log.d(TAG, "query the widgets infomation");
					
					isConfigured = cursor.getInt(0) == 1;
					
					long lastUpdateTime = cursor.getLong(1);
					
					updateMilis = cursor.getLong(2) * 60 * 60 * 1000;

					shouldUpdate = Math.abs(now - updateMilis) > lastUpdateTime;
				}
			} finally {
				if (cursor != null) {
					cursor.close();
				}
			}

			if (!isConfigured) {
				Log.d(TAG, "no configured , next Widget");
				continue;
			} else if (shouldUpdate) {
				try {
					/**
					 * 更新天气预报信息
					 */
					WebServiceUtil.updateForecasts(this, uri);
				} catch (ForecastParseException e) {
					Log.e(TAG, "Problem parsing forecast", e);
				}
			}
			
			Log.d(TAG, "update Views");
			RemoteViews updateViews = ForecastWidget.updateViews(this, uri);
            if (updateViews != null) {
            	
            	/**
            	 * 更新widget：将updateViews应用于widgetId所代表的Widget应用
            	 */
                manager.updateAppWidget(widgetId, updateViews);
            }
		}
		
		Log.d(TAG, "set next time update");
		
		/**
		 * 设置下一次的更新时间，每隔30分钟执行一次，也就是每30分钟启动一次服务。
		 * 注意：当数据更新时间间隔updateMilis小于30分钟时，服务启动时立即更新一次数据，也就是每隔30分钟更新一次
		 */
		now = System.currentTimeMillis();		
		long nextUpdate = now + 30 * 60 * 1000;

		Intent updateIntent = new Intent(ACTION_UPDATE_ALL);
		updateIntent.setClass(this, ForecastService.class);

		PendingIntent pendingIntent = PendingIntent.getService(this, 0,
				updateIntent, 0);

		/**
		 *  Schedule alarm, and force the device awake for this update
		 *  设置在nextUpdate时间间隔后发送pendingIntent
		 */
		AlarmManager alarmManager = (AlarmManager) getSystemService(Context.ALARM_SERVICE);
		alarmManager.set(AlarmManager.RTC_WAKEUP, nextUpdate, pendingIntent);

		/**
		 * 停止服务
		 */
		stopSelf();
	}

}
