package com.sky_dreaming.weather.database_provider;

import com.sky_dreaming.weather.fusion.FusionField;

import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.provider.BaseColumns;
import android.util.Log;

public class DBHelper extends SQLiteOpenHelper {

	private static final String TAG = "DBHelper";
	private static final String DATABASE_NAME = "forecasts.db";
	
	public static final String TABLE_WIDGET = "weather_widget";

	public static final String TABLE_FORECAST = "weather_forecast";

	private static final int DATABASE_VERSION = 2;

	public DBHelper(Context context) {
		super(context, DATABASE_NAME, null, DATABASE_VERSION);
	}

	@Override
	public void onCreate(SQLiteDatabase db) {
		db.execSQL("CREATE TABLE " + TABLE_WIDGET + " (" 
				+ BaseColumns._ID + " INTEGER PRIMARY KEY," 
				+ FusionField.CITY + " TEXT,"
				+ FusionField.UPDATE_MILIS + " INTEGER,"
				+ FusionField.IS_CONFIGURED + " INTEGER,"
				+ FusionField.POSTALCODE + " TEXT,"
				+ FusionField.FORECASTDATE + " INTEGER,"
				+ FusionField.CONDITION + " TEXT,"
				+ FusionField.TEMPF + " INTEGER," 
				+ FusionField.TEMPC + " INTEGER," 
				+ FusionField.HUMIDITY + " TEXT,"
				+ FusionField.ICON + " TEXT,"
				+ FusionField.WINDCONDITION + " TEXT,"
				+ FusionField.LAST_UPDATE_TIME + " INTEGER);");

		db.execSQL("CREATE TABLE " + TABLE_FORECAST + " (" 
				+ BaseColumns._ID + " INTEGER PRIMARY KEY," 
				+ FusionField.WIDGET_ID + " INTEGER," 
				+ FusionField.DAYOFWEEK + " TEXT,"
				+ FusionField.LOW + " INTEGER,"
				+ FusionField.HIGHT + " INTEGER,"
				+ FusionField.ICON + " TEXT,"
				+ FusionField.CONDITION + " TEXT);");
	}

	@Override
	public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
		int version = oldVersion;

		if (version != DATABASE_VERSION) {
			Log.w(TAG, "Destroying old data during upgrade.");
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_WIDGET);
			db.execSQL("DROP TABLE IF EXISTS " + TABLE_FORECAST);
			onCreate(db);
		}
	}
}
