Title:		FragmentBasics
Created on:	2012/7/2
Base on:	Android 4.0.3
Describe:	A simple but complete example of implementing multiple UI flows using fragments. 



Author:         li wei
HomePage:	http://mindlee.net
Mail:		mindlee@me.com

