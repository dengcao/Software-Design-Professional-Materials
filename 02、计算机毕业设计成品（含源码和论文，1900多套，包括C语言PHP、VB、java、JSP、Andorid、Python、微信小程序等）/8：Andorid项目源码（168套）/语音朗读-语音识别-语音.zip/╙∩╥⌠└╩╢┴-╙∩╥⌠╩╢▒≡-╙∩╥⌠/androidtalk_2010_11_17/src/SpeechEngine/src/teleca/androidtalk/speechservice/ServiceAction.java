package teleca.androidtalk.speechservice;

/**
 * @description ServiceOpType
 * @version 1.0
 * @author sundy
 * @date 2010-11-5
 */
public class ServiceAction {
	public final static String TTS_ACTION = "TTS_ACTION"  ;
	public final static String SR_ACTION = "SR_Action" ;
	public final static String STT_ACTION = "STT_ACTION" ;
}
