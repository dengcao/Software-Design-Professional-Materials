/**
 * @description Support languages .
 * @version 1.0
 * @author sundy
 * @date 2010-11-5
 */
package teleca.androidtalk.speechengine.kernel;

/**
 * @author Administrator
 *
 */
public enum SupportLanguage {

}
