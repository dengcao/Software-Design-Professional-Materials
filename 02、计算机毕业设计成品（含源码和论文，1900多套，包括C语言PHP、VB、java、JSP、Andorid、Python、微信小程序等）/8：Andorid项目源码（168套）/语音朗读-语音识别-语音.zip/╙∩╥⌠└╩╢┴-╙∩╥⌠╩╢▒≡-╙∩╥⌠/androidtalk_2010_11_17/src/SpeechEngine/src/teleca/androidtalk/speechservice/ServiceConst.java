package teleca.androidtalk.speechservice;

import android.content.Context;

/**
 * @description static constant define . is expired .
 * @version 1.0
 * @author sundy
 * @date 2010-11-5
 */
public class ServiceConst {
	public static Context TTS_CONTEXT = null ;
	public static String TTS_COMMAND_DATA = null ;
	
}
