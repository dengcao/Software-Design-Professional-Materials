/**
 * @name OpResult 
 * @description Opeartion result object we defined .
 * @version 1.0
 * @author sundy
 * @date 2010-11-5
 */
package teleca.androidtalk.operation;

/**
 * @author cninsuzh
 *
 */
public class OpResult {

}
