<map version="0.8.1">
<!-- To view this file, download free mind mapping software FreeMind from http://freemind.sourceforge.net -->
<node CREATED="1288589987818" ID="Freemind_Link_1651754779" MODIFIED="1288590002115" TEXT="AndroidTalk Team Structure">
<node CREATED="1288590010302" ID="_" MODIFIED="1288590210628" POSITION="right" TEXT="Sundy.Zhang">
<hook NAME="accessories/plugins/NodeNote.properties">
<text>Teamleader and Architect</text>
</hook>
<node CREATED="1288590029396" ID="Freemind_Link_1690675898" MODIFIED="1288590038411" TEXT="Alex.Wang"/>
<node CREATED="1288590038802" ID="Freemind_Link_1372123158" MODIFIED="1288590054817" TEXT="Daniel Luo"/>
<node CREATED="1288590055177" ID="Freemind_Link_21675294" MODIFIED="1288590062380" TEXT="Jacky Zhang"/>
<node CREATED="1288590063348" ID="Freemind_Link_294634350" MODIFIED="1288590068739" TEXT="Kevin Qin"/>
<node CREATED="1288590069379" ID="Freemind_Link_110399142" MODIFIED="1288590078114" TEXT="Andrew Yang"/>
</node>
</node>
</map>
