package com.digua.dict;

import com.digua.common.Common;
import com.digua.util.NetWord;
import com.digua.util.TranWords;

import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.RelativeLayout;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.Spinner;

/**
 * 
 * @author Eric
 *
 */
public class OnlineActivity extends Activity implements OnClickListener {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.onlinetran);
		createMenu();
		initComponent();
	}
	
	private void initComponent()
	{
		btn_tran=(Button)this.findViewById(R.id.btn_tran);
		btn_tran.setOnClickListener(this);
		btn_clear=(Button)this.findViewById(R.id.btn_clear);
		btn_clear.setOnClickListener(this);
		et_value=(EditText)this.findViewById(R.id.et_value);
		et_result=(EditText)this.findViewById(R.id.et_result);
		//下来列表
		spinner_type=(Spinner)this.findViewById(R.id.spinner_type);
		ArrayAdapter<String> adapter=new ArrayAdapter<String>(this,
				android.R.layout.simple_spinner_item);
		adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
		adapter.add("英译汉");
	//	adapter.add("汉译英");
		spinner_type.setAdapter(adapter);		
	}
	
	public void createMenu()
    {
    	CustomerMenu menu=new CustomerMenu(this);
    	toolbarGrid=menu.createViews();
    	re_layout=(RelativeLayout)this.findViewById(R.id.re_layout);
    	RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
	    params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
	    re_layout.addView(toolbarGrid,params);
    }
	
	 /**
     * 查询网络是否连接
     * @return
     */
    private Boolean CheckNet()
    {
    	ConnectivityManager manager=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
    	NetworkInfo info=manager.getActiveNetworkInfo();
    	if(info!=null&&info.isAvailable())
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    }
	
	@Override
	public void onClick(View v) {
		switch (v.getId()) {
		case R.id.btn_tran:			
			if(CheckNet())
			{
				search();	
			}
			else
			{
				Common.alert(OnlineActivity.this, "网络无法连接");
			}
			break;
		case R.id.btn_clear:
			clear();
			break;
		default:
			break;
		}		
	}
	
	 public void search()
    {   	 	  	
    	try
    	{    		
	    	final String words=et_value.getText().toString().trim();
	    	if(words!=null&&!words.equals(""))
	    	{
	    		mProgressDialog = ProgressDialog.show(OnlineActivity.this, null, "Loading...");         
	    		new Thread(){
	    			@Override
	    			public void run() {
	    			    tran=new TranWords(words);
	    				Message message=new Message();
	    				message.what=MES_1;
	    			    handler.sendMessage(message); 
	    			}	    			
	    		}.start();	    					
	    	}
    	}
    	catch (Exception e) {
		}
	}    
	 
	private void clear()
	{
		et_value.setText("");
		et_result.setText("");
	}
	 
	 private Handler handler=new Handler(){
	    	public void handleMessage(Message message)
	    	{
	    		switch (message.what) 
	    		{
					case MES_1:
						mProgressDialog.dismiss();
						et_result.setText(tran.strTran);
						break;
				}
	    	}
	    };
	 
	private static final int MES_1 = 1; 	
	private TranWords tran;
	private GridView toolbarGrid=null;
	private RelativeLayout re_layout=null;
	private Spinner spinner_type;
	private Button btn_tran;
	private Button btn_clear;
	private EditText et_value;
	private EditText et_result;
	private ProgressDialog mProgressDialog  = null;	
}
