package com.digua.util;

import java.io.InputStream;
import java.util.HashMap;
import java.util.List;

import com.digua.common.DataAccess;
import com.digua.common.XMLHelper;

/**
 * 
 * @author Eric
 *
 */
public class NetWord {

	private final static String URL="http://api.dict.cn/ws.php?utf8=true&q=";	
	
	public NetWord(String searchWord)
	{
		Search(searchWord);
	}

	private void Search(String searchWord) 
	{
		List<String> list=null;
		try
		{
			InputStream inputStream=DataAccess.getStreamByUrl(URL+searchWord);
			xmlStr=XMLHelper.inputStreamToString(inputStream);
			list=XMLHelper.getBaseInfo(xmlStr);
			audio=list.get(0);
			pron=list.get(1);
			def=list.get(2);
			listSent=XMLHelper.getData(xmlStr);
		}
		catch (Exception e)
		{	
			audio=null;
			pron=null;
			def=null;
			listSent=null;
		}
		finally
		{
			list=null;
		}
	}
	
	public List<HashMap<String, String>> listSent;
	public String xmlStr;	//完整的XML结构
	public String audio;	//发音
	public String pron;		//音标
	public String def;		//中文意思
}
