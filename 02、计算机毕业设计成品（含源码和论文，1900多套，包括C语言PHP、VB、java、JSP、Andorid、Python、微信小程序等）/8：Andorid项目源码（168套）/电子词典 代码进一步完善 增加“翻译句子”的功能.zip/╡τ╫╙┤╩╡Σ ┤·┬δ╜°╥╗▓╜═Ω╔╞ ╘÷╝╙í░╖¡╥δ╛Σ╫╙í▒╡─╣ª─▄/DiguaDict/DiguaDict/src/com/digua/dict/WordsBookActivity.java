package com.digua.dict;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import com.digua.common.Common;
import com.digua.dao.DBAdapter;
import com.digua.dict.R;
import com.digua.util.WordsBean;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.ContextMenu;
import android.view.View;
import android.view.View.OnCreateContextMenuListener;
import android.view.ViewGroup;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.BaseAdapter;
import android.widget.Button;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.RelativeLayout.LayoutParams;

/**
 * 
 * @author Eric
 *
 */
public class WordsBookActivity extends Activity{			
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		 setContentView(R.layout.wordsbook);  
		 listview=(ListView)this.findViewById(R.id.listview_words);
		 
		 wordList=new ArrayList<WordsBean>();		  
		 dbAdapter=new DBAdapter(this);
		 cursor=dbAdapter.getAllWords(); 		 
	 	 cursor.moveToFirst();
         while(!cursor.isAfterLast() && (cursor.getString(1) != null)){    
        	WordsBean word = new WordsBean();
        	word.setId(cursor.getString(0));
        	word.setName(cursor.getString(1));
        	wordList.add(word);
    		cursor.moveToNext();
    	 }		
	  			
		 listAdapter=new ListAdapter();
		 listview.setAdapter(listAdapter);	
		 setListener();		
		 createMenu();
	}
    
	  public void createMenu()
    {
    	CustomerMenu menu=new CustomerMenu(this);
    	toolbarGrid=menu.createViews();
    	re_layout=(RelativeLayout)this.findViewById(R.id.re_layout);
    	RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
	    params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
	    re_layout.addView(toolbarGrid,params);
    }
	    
	
	/**
	 * 添加事件
	 */
	public void setListener()
	{
		listview.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View view, int position,
					long arg3) {
				String id=wordList.get(position).getId();
				Intent intent=new Intent();
				intent.setClass(WordsBookActivity.this, ShowWordActivity.class);
				intent.putExtra("id", id);
				startActivity(intent);
			}
		});
		
		listview.setOnCreateContextMenuListener(new OnCreateContextMenuListener() {			
			@Override
			public void onCreateContextMenu(ContextMenu menu, View v,
					ContextMenuInfo menuInfo) {
				menu.setHeaderTitle("ContextMenu");       
				menu.add(0, 0, 0, "删除该单词");       				
			}
		});
	}
	
	private class ListAdapter extends BaseAdapter
	{

		public ListAdapter(){
    		super();
    	}
		
		@Override
		public int getCount() {
			return wordList.size();
		}

		@Override
		public Object getItem(int location) {
			return wordList.get(location);
		}

		@Override
		public long getItemId(int position) {			
			return position;
		}

		@Override
		public View getView(final int position, View view, ViewGroup parent) 
		{			
			view=getLayoutInflater().inflate(R.layout.listitem_word, null);
			TextView tvName = (TextView) view.findViewById(R.id.tv_word);
			tvName.setText(""+wordList.get(position).getName());
			TextView tvId = (TextView) view.findViewById(R.id.tv_word_id);
			tvId.setText(""+wordList.get(position).getId());
			TextView tvRemove = (TextView) view.findViewById(R.id.tv_delete);
			tvRemove.setId(Integer.parseInt(wordList.get(position).getId()));			
			tvRemove.setOnClickListener(new Button.OnClickListener() {				
				public void onClick(View v) {
					CreatDialog(v.getId(),position);
				}
			});
			return view;
		}
	}
  
  public void select(int id)
  {
	  cursor = dbAdapter.getWordsById(id);
	  cursor.moveToFirst();
	  while(!cursor.isAfterLast() && (cursor.getString(1) != null)){    
      	Common.alert(WordsBookActivity.this, cursor.getString(1));	
  		cursor.moveToNext();
  	}
  }
	
  public void CreatDialog(final int id, final int p)
  {	 
	  AlertDialog.Builder builder = new AlertDialog.Builder(WordsBookActivity.this);	
	  builder.setIcon(R.drawable.icon);
      builder.setTitle("是否删除该单词？");
      builder.setPositiveButton("是", new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface dialog, int whichButton) {
        	  	dbAdapter.deleteWordsById(id);
				wordList.remove(p);
				listview.setAdapter(new ListAdapter());
          }
      });
      builder.setNegativeButton("否", new DialogInterface.OnClickListener() {
          public void onClick(DialogInterface dialog, int whichButton) {        	
          }
      });
      builder.show();
  }
    private Cursor cursor;
	private DBAdapter dbAdapter;	
	private GridView toolbarGrid;
	private RelativeLayout re_layout;
	private ListView listview;
	private ListAdapter listAdapter;
	private List<WordsBean> wordList;
}