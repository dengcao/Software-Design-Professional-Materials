package com.digua.dao;

import com.digua.util.WordsBean;
import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.util.Log;

/**
 * 
 * @author Eric
 *
 */
public class DBAdapter {
	
	public static final String DB_NAME="DiguaDict.db";
	public static final int DB_VERSION=2;
	
	private Context context;
	private DBHelper dbHelper;
	private SQLiteDatabase db = null;
	
	public DBAdapter(Context c)
	{
		this.context=c;
		open();
	}
	
	public void open()
	{
		dbHelper=new DBHelper(context, DB_NAME, null, DB_VERSION);
		db=dbHelper.getWritableDatabase();
	}
	
	public void close()
	{
		dbHelper.close();
	}
	
	/**
	 * 需要查询的列名
	 * @return
	 */
	private String[] getColu()
	{
		return new String[]{WordsBean.NAME,WordsBean.AUDIO,WordsBean.PRON,
							WordsBean.DEF,WordsBean.XML};
	}
	
	/**
	 * 查询所有单词
	 * @return
	 */
	public Cursor getAllWords()
	{
		return db.query(WordsBean.TB_WORD,
				new String[]{WordsBean.ID,WordsBean.NAME}, 
				null, null, null, null, null);
	}
	
	/**
	 * 根据单词Id，查询单词
	 * @param id 单词Id
	 * @return
	 */
	public Cursor getWordsById(int id)
	{
		Log.i("DBAdapter", "getWordsById");
		return db.query(WordsBean.TB_WORD, getColu(), WordsBean.ID+"="+id,  
				null, null, null, null);
	}
	
	public Cursor getCursorBySql(String sql,String selectionArgs[]){
		Log.i("DBAdapter", "getCursorBySql");
		return db.rawQuery(sql, selectionArgs);
	}
	
	/**
	 * 根据单词Id，删除单词
	 * @param id 单词Id
	 * @return
	 */
	public int deleteWordsById(int id)
	{
		return db.delete(WordsBean.TB_WORD, WordsBean.ID+"="+id, null);
	}
	
	/**
	 * 添加一个单词
	 * @param word 单词对象
	 * @return
	 */
	public long insertWords(WordsBean word)
	{
		ContentValues content=new ContentValues();
		content.put(WordsBean.NAME, word.getName());
		content.put(WordsBean.AUDIO, word.getAudio());
		content.put(WordsBean.PRON, word.getPron());
		content.put(WordsBean.DEF, word.getDef());
		content.put(WordsBean.XML, word.getXml());
		return db.insert(WordsBean.TB_WORD, null, content);
	}
	
}
