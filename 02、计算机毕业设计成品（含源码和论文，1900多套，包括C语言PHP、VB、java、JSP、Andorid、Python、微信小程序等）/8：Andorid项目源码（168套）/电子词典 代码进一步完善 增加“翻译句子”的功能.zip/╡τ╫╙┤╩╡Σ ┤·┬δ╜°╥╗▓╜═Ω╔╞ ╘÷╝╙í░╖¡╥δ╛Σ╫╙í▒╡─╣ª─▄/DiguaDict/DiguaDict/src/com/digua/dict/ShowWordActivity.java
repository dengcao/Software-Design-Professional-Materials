package com.digua.dict;

import java.util.HashMap;
import java.util.List;


import com.digua.common.Common;
import com.digua.common.XMLHelper;
import com.digua.dao.DBAdapter;
import com.digua.util.WordsBean;
import android.app.Activity;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;

/**
 * 
 * @author Eric
 *
 */
public class ShowWordActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		 super.onCreate(savedInstanceState);
		 setContentView(R.layout.showwords);  
		 dbAdapter=new DBAdapter(this);		
		 initComponent();
		 Intent intent=getIntent();
		 Bundle bundle=intent.getExtras();
		 fillValue(bundle.getString("id"));
	}
	
	private void fillValue(String id)
    {
		//word=new WordsBean();
		String sql="select * from "+WordsBean.TB_WORD+" where _id=?";
		String selectionArgs[]={id};
	//	cursor=dbAdapter.getCursorBySql(sql, selectionArgs);
		cursor=dbAdapter.getWordsById(Integer.parseInt(id));
		if(cursor!=null&&cursor.getCount()>0)
		{
			cursor.moveToFirst();
			String a=cursor.getString(1);
			word=new WordsBean();
	      	word.setName(cursor.getString(0));
	      	word.setAudio(cursor.getString(1));
	      	word.setPron(cursor.getString(2));	      	
	      	word.setDef(cursor.getString(3));
	    	word.setXml(cursor.getString(4));
		}
		
		tv_word.setText(word.getName());
		tv_pron.setText("["+word.getPron()+"]");	
		tv_def.setText(word.getDef());
		strAduio=word.getAudio();
		strXml=word.getXml();
		listSent=XMLHelper.getData(strXml);
		//例句			
		listAdapter = new SimpleAdapter(
				this, listSent, R.layout.listitem,
				new String[]{"orig" , "trans"},
				new int[]{R.id.tv_orig , R.id.tv_trans});  
		listView.setAdapter(listAdapter);	
    }
	
	public void initComponent()
    {
        tv_pron=(TextView)findViewById(R.id.tv_pron);   
        tv_def=(TextView)findViewById(R.id.tv_def);   
        tv_word=(TextView)findViewById(R.id.tv_word);  
        listView=(ListView)findViewById(R.id.listview);
    }
	
	private String id;
	private Cursor cursor;
	private DBAdapter dbAdapter;
	private List<HashMap<String, String>> listSent;
	private WordsBean word;  
	private TextView tv_word;
	private TextView tv_pron;	//音标
	private TextView tv_def;	//中文意思
	private SimpleAdapter listAdapter;
	private ListView listView;	
	private String strAduio;//单词发音
	private String strXml;
	
}
