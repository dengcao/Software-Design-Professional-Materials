package com.digua.util;

/**
 * 
 * @author Eric
 *
 */
public class WordsBean {
	
	public static final String TB_WORD="tb_word";
	public static final String ID="_id";
	public static final String NAME="name";
	public static final String AUDIO="audio";
	public static final String PRON="pron";	
	public static final String DEF="def";	
	public static final String XML="xml";
	
	/**
	 * SQL语句，创建表
	 * @return
	 */
	public static String getCreateSql()
	{
		StringBuffer sbSQL=new StringBuffer();
		sbSQL.append("create table if not exists ");
		sbSQL.append(TB_WORD);
		sbSQL.append("(");
		sbSQL.append(ID+" integer primary key,");
		sbSQL.append(NAME+" varchar,");
		sbSQL.append(AUDIO+" varchar,");
		sbSQL.append(PRON+" varchar,");
		sbSQL.append(DEF+" varchar,");
		sbSQL.append(XML+" varchar");
		sbSQL.append(")");
		return sbSQL.toString();
	}	
	
	private String id;
	private String name;
	private String audio;
	private String pron;
	private String def;
	private String xml;

	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAudio() {
		return audio;
	}
	public void setAudio(String audio) {
		this.audio = audio;
	}
	public String getPron() {
		return pron;
	}
	public void setPron(String pron) {
		this.pron = pron;
	}
	public String getDef() {
		return def;
	}
	public void setDef(String def) {
		this.def = def;
	}
	public String getXml() {
		return xml;
	}
	public void setXml(String xml) {
		this.xml = xml;
	}
	
}
