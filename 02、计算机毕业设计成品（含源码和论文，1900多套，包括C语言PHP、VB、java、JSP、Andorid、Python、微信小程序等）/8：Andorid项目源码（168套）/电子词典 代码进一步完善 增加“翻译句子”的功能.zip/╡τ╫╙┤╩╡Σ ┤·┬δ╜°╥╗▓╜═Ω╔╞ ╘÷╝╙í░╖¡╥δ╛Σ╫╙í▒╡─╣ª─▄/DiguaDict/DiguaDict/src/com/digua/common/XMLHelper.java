package com.digua.common;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.Reader;
import java.io.StringReader;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.xmlpull.v1.XmlPullParser;
import android.content.Context;
import android.util.Xml;

/**
 * 
 * @author Eric
 *
 */
public class XMLHelper {
	
	
	public static List<HashMap<String, String>> getData(String params) 
	{
		StringReader reader = null;
		XmlPullParser parser = null;
		List<String> listOrig = null;
		List<String> listTrans = null;
		List<HashMap<String, String>> listSent=null;
		String sent=null;
		try {
			listSent=new ArrayList<HashMap<String,String>>();
			listOrig = new ArrayList<String>();
			listTrans = new ArrayList<String>();
			
			parser = Xml.newPullParser();
			reader = new StringReader(params);
			parser.setInput(reader);
			int eventType = parser.getEventType();
			
			while (eventType != XmlPullParser.END_DOCUMENT) {
				switch (eventType) {
				case XmlPullParser.START_TAG:
					if ("sent".equals(parser.getName())) 
					{				
						sent=parser.getName();						
					}
					if(sent!=null)
					{
						if("orig".equals(parser.getName()))
						{
							listOrig.add(replaceEm(parser.nextText()));
						}
						if("trans".equals(parser.getName()))
						{
							listTrans.add(parser.nextText());
						}
					}
					break;
				}
				eventType = parser.next();
			}
			
			HashMap<String, String> map=null;
			for(int i=0;i<listOrig.size();i++)
			{
				map=new HashMap<String, String>();
				map.put("orig", listOrig.get(i));
				map.put("trans", listTrans.get(i));
				listSent.add(map);
			}
			return listSent;			
		} catch (Exception ex) {
			return null;
		} finally {
			if (reader != null) {
				reader.close();
			}
			reader = null;
			parser = null;
			params = null;
		    listOrig = null;
		    listTrans = null;
		    sent=null;
		}
	}
	
	/**
	 * 去掉<em></em>标签
	 * @param value
	 * @return
	 */
	private static String replaceEm(String value)
	{
		value=value.replace("<em>", "");
		value=value.replace("</em>", "");
		return value;
	}
	
	public static List<String> getBaseInfo(String xmlStr) 
	{
		StringReader reader = null;
		XmlPullParser parser = null;
		List<String> list = new ArrayList<String>();
		list.add("");
		list.add("");
		list.add("");
		try {
			parser = Xml.newPullParser();
			reader = new StringReader(xmlStr);
			parser.setInput(reader);
			int eventType = parser.getEventType();
			while (eventType != XmlPullParser.END_DOCUMENT) {
				switch (eventType) {
				case XmlPullParser.START_TAG:
					if ("audio".equals(parser.getName())) 
					{			
						list.set(0, parser.nextText());		
					}
					else if ("pron".equals(parser.getName())) 
					{			
						list.set(1, parser.nextText());		
					}
					else if ("def".equals(parser.getName())) 
					{			
						list.set(2, parser.nextText());		
					}					
					break;
				}
				eventType = parser.next();
			}
		} catch (Exception ex) {
			System.out.println("CustomFunction:getData---->" + ex.getMessage());
		} finally {
			if (reader != null) {
				reader.close();
			}
			reader = null;
			parser = null;
			xmlStr=null;
		}
		return list;
	}
	
	public static String inputStreamToString(InputStream inputStream)
	{
		InputStreamReader is=null;
		try {
			 is=new InputStreamReader(inputStream, "UTF-8");
		} catch (UnsupportedEncodingException e1) {
			e1.printStackTrace();
		}
		BufferedReader reader = new BufferedReader(is);
		StringBuilder sb = new StringBuilder();
		String line = null;
		try {
		while ((line = reader.readLine()) != null) {
		sb.append(line + " ");
		}
		} catch (IOException e) {
		e.printStackTrace();
		} finally {
		try {
			inputStream.close();
		} catch (IOException e) {
		e.printStackTrace();
		}
		}
		return sb.toString();
	}
	
}
