package com.digua.common;

import java.io.IOException;

import android.content.Context;
import android.media.MediaPlayer;
import android.widget.Toast;

/**
 * 
 * @author Eric
 *
 */
public class Common {
	
	/**
	 * 弹出提示框
	 * @param context
	 * @param str 提示内容
	 */
	public static void alert(Context context,String str)
	{
		Toast.makeText(context, str, Toast.LENGTH_LONG).show();
	}
	
	/**
	 * 播放音频
	 * @param path 音频路径
	 */
	public static void playAudio(String path)
	{
		MediaPlayer mp = null;   
        try {  
        	mp = new MediaPlayer();
            mp.setDataSource(path);  
            mp.prepare();  
            mp.start();  
        	} 
        catch (IOException e) {  
        }  
        finally{
        	mp=null;
        }
	}
	
}
