package com.digua.dict;

import com.digua.common.Common;
import com.digua.dao.DBAdapter;
import com.digua.dict.R;
import com.digua.util.NetWord;
import com.digua.util.WordsBean;
import android.app.Activity;
import android.app.ProgressDialog;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.util.Log;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.RelativeLayout.LayoutParams;
import android.widget.Button;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.SimpleAdapter;
import android.widget.TextView;

/**
 * 
 * @author Eric
 *
 */
public class MainActivity extends Activity implements OnClickListener{	
	
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) 
    {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);     
        initComponent();
        createMenu();
        btn_search.setOnClickListener(new OnClickListener() {			
			public void onClick(View v) {				
				if(CheckNet())
				{
					if(et_search.getText().toString().equals(""))
					{
						clear();
					}
					else
					{
						clear();
						search();		
					}
				}
				else
				{
					Common.alert(MainActivity.this, "网络无法连接");
				}
			}			
		});             
    }       
    
    
    /**
     * 查询网络是否连接
     * @return
     */
    private Boolean CheckNet()
    {
    	ConnectivityManager manager=(ConnectivityManager)getSystemService(Context.CONNECTIVITY_SERVICE);
    	NetworkInfo info=manager.getActiveNetworkInfo();
    	if(info!=null&&info.isAvailable())
    	{
    		return true;
    	}
    	else
    	{
    		return false;
    	}
    }
    
    public void initComponent()
    {
    	et_search=(EditText)findViewById(R.id.et_search);      
        tv_pron=(TextView)findViewById(R.id.tv_pron);   
        tv_def=(TextView)findViewById(R.id.tv_def);   
        tv_word=(TextView)findViewById(R.id.tv_word);  
        btn_search=(Button)findViewById(R.id.btn_search);
        btn_add=(Button)findViewById(R.id.btn_add);
        btn_add.setOnClickListener(this);      
        listView=(ListView)findViewById(R.id.listview);
        btn_aduio=(Button)findViewById(R.id.btn_aduio);
        btn_aduio.setOnClickListener(this);
    }
    
    public void createMenu()
    {
    	CustomerMenu menu=new CustomerMenu(this);
    	toolbarGrid=menu.createViews();
    	re_layout=(RelativeLayout)this.findViewById(R.id.re_layout);
    	RelativeLayout.LayoutParams params = new RelativeLayout.LayoutParams(LayoutParams.FILL_PARENT, LayoutParams.WRAP_CONTENT);
	    params.addRule(RelativeLayout.ALIGN_PARENT_BOTTOM);
	    re_layout.addView(toolbarGrid,params);
    }
    
   
    public void search()
    {   	 	  	
    	try
    	{    		
	    	words=et_search.getText().toString().trim();
	    	if(words!=null&&!words.equals(""))
	    	{
	    		mProgressDialog = ProgressDialog.show(MainActivity.this, null, "Loading...");         
	    		new Thread(){
	    			@Override
	    			public void run() {
	    				netWord=new NetWord(words);
	    				Message message=new Message();
	    				message.what=MES_1;
	    			    handler.sendMessage(message); 
	    			}	    			
	    		}.start();	    					
	    	}
    	}
    	catch (Exception e) {
		}
	}    
    
	private Handler handler=new Handler(){
    	public void handleMessage(Message message)
    	{
    		switch (message.what) 
    		{
				case MES_1:
					mProgressDialog.dismiss();
					fillValue();
					break;
			}
    	}
    };
    
    public void fillValue()
    {
    	tv_word.setText(words);
		btn_add.setVisibility(visible);
		if(!netWord.audio.equals("")&&netWord.audio!=null)
		{
			btn_aduio.setVisibility(visible);
		}		
		if(!netWord.pron.equals("")&&netWord.pron!=null)
		{
			tv_pron.setText("["+netWord.pron+"]");	
		}
		tv_def.setText(netWord.def);
		strAduio=netWord.audio;
		strXml=netWord.xmlStr;
		//例句			
		if(netWord.listSent!=null)
		{
			listAdapter = new SimpleAdapter(
					this, netWord.listSent, R.layout.listitem,
					new String[]{"orig" , "trans"},
					new int[]{R.id.tv_orig , R.id.tv_trans});  
			listView.setAdapter(listAdapter);	
		}
    }
    
    public void clear()
    {
    	tv_pron.setText("");
    	tv_word.setText("");
    	btn_add.setVisibility(disvisible);
    	btn_aduio.setVisibility(disvisible);
    }    
    
	@Override
	public void onClick(View arg0) {
		switch (arg0.getId()) {
		case R.id.btn_add:
			add();
			break;
		case R.id.btn_aduio:
			Common.playAudio(strAduio);
			break;
		}
	}
	
	private void add()
	{
		WordsBean word=null;
		try
		{
			dbAdapter=new DBAdapter(MainActivity.this);
		    word=new WordsBean();
			word.setAudio(strAduio);
			word.setName(tv_word.getText().toString());
			word.setPron(tv_pron.getText().toString());
			word.setDef(tv_def.getText().toString());
			word.setXml(strXml);
			dbAdapter.insertWords(word);
			Common.alert(MainActivity.this, "添加成功");
		}
		catch (Exception e) {
			Log.i("tag", "insertWords-----Error");
		}
		finally{
			dbAdapter=null;
			word=null;
		}
	}
	
	private DBAdapter dbAdapter;
	
	private static final int MES_1 = 1; 	
	private static final int visible=0;
	private static final int disvisible=4;
	private NetWord netWord;
	private String words=null;    
	private Button btn_search;
	private Button btn_add;
	private Button btn_aduio;
	private TextView tv_word;
	private TextView tv_pron;	//音标
	private TextView tv_def;	//中文意思
	private EditText et_search;
	private SimpleAdapter listAdapter;
	private ListView listView;	
	private ProgressDialog mProgressDialog  = null;	
	private GridView toolbarGrid=null;
	private RelativeLayout re_layout=null;
	
	private String strAduio;//单词发音
	private String strXml;
    
}