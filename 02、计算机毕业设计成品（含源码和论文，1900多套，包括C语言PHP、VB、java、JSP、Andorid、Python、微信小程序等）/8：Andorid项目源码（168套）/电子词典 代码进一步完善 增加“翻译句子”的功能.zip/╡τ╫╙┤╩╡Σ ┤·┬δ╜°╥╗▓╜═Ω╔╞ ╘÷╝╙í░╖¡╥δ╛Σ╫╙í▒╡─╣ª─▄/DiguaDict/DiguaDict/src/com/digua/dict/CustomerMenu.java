package com.digua.dict;

import java.util.ArrayList;
import java.util.HashMap;

import com.digua.dict.R;
import android.content.Context;
import android.content.Intent;
import android.view.Gravity;
import android.view.View;
import android.widget.AdapterView;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.GridView;
import android.widget.SimpleAdapter;
import android.widget.Toast;

/**
 * 
 * @author Eric
 *
 */
public class CustomerMenu{
	
	private GridView toolbarGrid;
	
	int[] menu_toolbar_image_array = { R.drawable.menu_search,R.drawable.menu_book,
			R.drawable.menu_tran, R.drawable.menu_test,R.drawable.menu_more };
	String[] menu_toolbar_name_array = { "海词", "生词本", "在线翻译", "测试", "更多" };      
    
	private Context context;
	
	public CustomerMenu(Context context)
	{
		this.context=context;
	}
	
	public GridView createViews()
    {    	        
        toolbarGrid=new GridView(context);    
    	toolbarGrid.setBackgroundResource(R.drawable.bg_toolbar);
		toolbarGrid.setNumColumns(5);
		toolbarGrid.setGravity(Gravity.CENTER);
		toolbarGrid.setVerticalSpacing(10);
		toolbarGrid.setHorizontalSpacing(10);
		toolbarGrid.setAdapter(setAdapter(menu_toolbar_name_array,
				menu_toolbar_image_array));
		toolbarGrid.setOnItemClickListener(new OnItemClickListener() {
			@Override
			public void onItemClick(AdapterView<?> arg0, View arg1, int arg2,
					long arg3) {
				 Intent intent = new Intent(); 
				switch (arg2) {
				case 0:					
	                 intent.setClass(context, MainActivity.class); 
	                 context.startActivity(intent);
					break;
				case 1:
	                 intent.setClass(context, WordsBookActivity.class); 
	                 context.startActivity(intent);
					break;	
				case 2:
					intent.setClass(context, OnlineActivity.class); 
	                context.startActivity(intent);
					break;
				case 3:
					alert("暂未完成");
					break;	
				case 4:
					alert("暂未完成");
					break;				
				default:
					break;
				}							
			}
		});	
		return toolbarGrid;
    }             
     

	
	//弹出提示框
	public void alert(String str)
	{
		Toast.makeText(context, str, Toast.LENGTH_LONG).show();
	}
	
    private SimpleAdapter setAdapter(String[] menuNameArray,
			int[] imageImageArray) {
		ArrayList<HashMap<String, Object>> data = new ArrayList<HashMap<String, Object>>();
		for (int i = 0; i < menuNameArray.length; i++) {
			HashMap<String, Object> map = new HashMap<String, Object>();
			map.put("itemImage", imageImageArray[i]);
			map.put("itemText", menuNameArray[i]);
			data.add(map);
		}
		SimpleAdapter simperAdapter = new SimpleAdapter(context, data,
				R.layout.item_menu, new String[] { "itemImage", "itemText" },
				new int[] { R.id.item_image, R.id.item_text });
		return simperAdapter;
	}
    
}