package com.digua.util;

import java.io.InputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.digua.common.DataAccess;
import com.digua.common.XMLHelper;

/**
 * 
 * @author Eric
 *
 */
public class TranWords {
	
	private final String url ="http://api.dict.cn/ws.php?utf8=true&q=";
	public TranWords(String words)
	{
		Search(words);
	}
	
	public List<HashMap<String, String>> listSent;
	public String strTran;
	public String strOrig;
	
	private void Search(String searchWord) 
	{
		String xmlStr=null;
		List<String> list=new ArrayList<String>();
		try
		{
			InputStream inputStream=DataAccess.getStreamByUrl(url+searchWord);
			xmlStr=XMLHelper.inputStreamToString(inputStream);
			list=XMLHelper.getBaseInfo(xmlStr);
			strTran=list.get(2);
		}
		catch (Exception e)
		{	
		}
		finally
		{
			xmlStr=null;
		}
	}
	
}
