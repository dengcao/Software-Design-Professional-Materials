package com.milifan.util;

public class Common {
	public static int month_total = 240;

}
