package com.xiexj.ebook;

import android.view.ViewGroup.LayoutParams;

public class LayoutBean {

	public static final LayoutParams FF = new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.FILL_PARENT);
	
	public static final LayoutParams FW = new LayoutParams(LayoutParams.FILL_PARENT,LayoutParams.WRAP_CONTENT);
	
	public static final LayoutParams WW = new LayoutParams(LayoutParams.WRAP_CONTENT,LayoutParams.WRAP_CONTENT);
}
