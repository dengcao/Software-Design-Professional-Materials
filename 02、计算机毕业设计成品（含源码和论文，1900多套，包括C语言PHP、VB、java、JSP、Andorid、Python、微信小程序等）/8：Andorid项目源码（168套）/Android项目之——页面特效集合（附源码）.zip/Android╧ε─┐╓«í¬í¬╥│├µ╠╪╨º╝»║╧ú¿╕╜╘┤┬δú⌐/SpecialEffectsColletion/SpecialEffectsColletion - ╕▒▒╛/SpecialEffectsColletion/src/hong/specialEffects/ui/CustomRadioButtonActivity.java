package hong.specialEffects.ui;


import hong.specialEffects.R;
import android.app.Activity;
import android.os.Bundle;

/**
 * �Զ���Բ��radioButton��ʽ
 * @author Hong
 *
 */
public class CustomRadioButtonActivity extends Activity {
	
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.my_radiobutton);
	}
	

}
