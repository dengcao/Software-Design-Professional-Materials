/**=========================================================
 * ��Ȩ���������� ��Ȩ���� (c) 2002 - 2003
 * �ļ��� com.surekam.anroidmobile.exp.apps.common.model.ViewHolderBean
 * ������: ViewHolderBean
 * �޸ļ�¼��
 * ����                  ����           ����
 * =========================================================
 * 2011-4-20     xiaow
 * =========================================================*/

package hong.specialEffects.ui;

import android.widget.TextView;

public class ViewHolderBean {

    private TextView textView01;
    private TextView textView02;
    private TextView textView03;
    private TextView textView04;
    public TextView getTextView04() {
        return textView04;
    }
    public void setTextView04(TextView textView04) {
        this.textView04 = textView04;
    }
    public TextView getTextView05() {
        return textView05;
    }
    public void setTextView05(TextView textView05) {
        this.textView05 = textView05;
    }
    private TextView textView05;
    public TextView getTextView01() {
        return textView01;
    }
    public void setTextView01(TextView textView01) {
        this.textView01 = textView01;
    }
    public TextView getTextView02() {
        return textView02;
    }
    public void setTextView02(TextView textView02) {
        this.textView02 = textView02;
    }
    public TextView getTextView03() {
        return textView03;
    }
    public void setTextView03(TextView textView03) {
        this.textView03 = textView03;
    }
  

}
