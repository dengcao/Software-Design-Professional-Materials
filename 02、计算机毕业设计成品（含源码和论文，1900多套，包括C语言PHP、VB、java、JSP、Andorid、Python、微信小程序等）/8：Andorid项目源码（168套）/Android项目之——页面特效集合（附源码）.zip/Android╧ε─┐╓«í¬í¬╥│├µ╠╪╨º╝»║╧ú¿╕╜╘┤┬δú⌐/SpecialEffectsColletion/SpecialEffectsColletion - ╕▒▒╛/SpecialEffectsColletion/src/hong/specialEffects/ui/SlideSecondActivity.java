package hong.specialEffects.ui;

import hong.specialEffects.R;
import android.app.Activity;
import android.os.Bundle;

public class SlideSecondActivity extends Activity {
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		// TODO Auto-generated method stub
		super.onCreate(savedInstanceState);
		setContentView(R.layout.sec_main);
	}

}
