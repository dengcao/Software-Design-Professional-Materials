/** Automatically generated file. DO NOT MODIFY */
package hong.specialEffects;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}