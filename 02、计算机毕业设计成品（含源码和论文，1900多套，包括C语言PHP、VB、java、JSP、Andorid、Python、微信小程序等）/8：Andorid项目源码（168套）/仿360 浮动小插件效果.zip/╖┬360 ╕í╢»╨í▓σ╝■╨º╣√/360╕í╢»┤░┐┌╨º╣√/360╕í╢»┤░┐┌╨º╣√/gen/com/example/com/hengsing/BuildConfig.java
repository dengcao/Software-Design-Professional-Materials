/** Automatically generated file. DO NOT MODIFY */
package com.example.com.hengsing;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}