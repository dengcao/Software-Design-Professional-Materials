package com.canvas.demo.surface;

public interface IRendererInterface {
    public void doRendererFinished(RendererView view,int tag);
}
