package h264.com;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import h264.com.R;

public class LoginActivity extends Activity {
	Intent intent;
	Bundle bundle;
	
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		 setContentView(R.layout.login);
		 
	      Button btnOK=(Button) findViewById(R.id.btnlogin);
	      btnOK.setOnClickListener(new android.view.View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					Intent intent=new Intent();
					Bundle bundle=new Bundle();	
					intent.setClass(LoginActivity.this, DeviceListActivity.class);
					TextView edt=null;
					edt=(TextView)findViewById(R.id.edtUser);
					bundle.putString("USERID", edt.getText().toString());
					edt=(TextView)findViewById(R.id.edtPasswd);
					bundle.putString("PASSWD", edt.getText().toString());
					edt=(TextView)findViewById(R.id.edtAddr);
					bundle.putString("IPADDR", edt.getText().toString());
					intent.putExtras(bundle);
					startActivity(intent);
					finish();
					
				}
			});
	 
	      Button btnCancel=(Button) findViewById(R.id.btncancel);
	      
	      btnCancel.setOnClickListener(new android.view.View.OnClickListener() {
				
				@Override
				public void onClick(View v) {
					finish();				
				}
			});
	}
}
