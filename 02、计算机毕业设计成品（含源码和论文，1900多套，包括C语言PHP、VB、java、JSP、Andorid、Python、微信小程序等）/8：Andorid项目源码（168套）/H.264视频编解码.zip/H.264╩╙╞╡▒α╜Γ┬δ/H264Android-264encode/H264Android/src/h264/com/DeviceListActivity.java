package h264.com;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.IOException;
import java.net.DatagramPacket;
import java.net.DatagramSocket;
import java.net.InetAddress;
import java.net.SocketException;
import java.net.UnknownHostException;
import java.util.Timer;
import java.util.TimerTask;

import android.app.ExpandableListActivity;
import android.content.Context;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;
import android.view.ContextMenu;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ContextMenu.ContextMenuInfo;
import android.widget.ExpandableListAdapter;
import android.widget.ExpandableListView;
import android.widget.PopupWindow;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ExpandableListView.ExpandableListContextMenuInfo;
import h264.com.DeviceInfo;

public class DeviceListActivity extends ExpandableListActivity {

	private static final int CTRL_PTZ_UP = 0x1006;
	private static final int CTRL_PTZ_DOWN = 0x1007;
	private static final int CTRL_PTZ_LEFT = 0x1008;
	private static final int CTRL_PTZ_RIGHT = 0x1009;
	private static final int CTRL_PTZ_ZOOM_IN = 0x100A;
	private static final int CTRL_PTZ_ZOOM_OUT = 0x100B;
	private static final int CTRL_PTZ_NEAR = 0x100C;
	private static final int CTRL_PTZ_FAR = 0x100D;
	private static final int USERLOGIN_REQUEST = 0x2000;// �û���¼����
	private static final int GETDEVLIST_REQUEST = 0x2002; // �豸�б�����
	private static final int GETDEVCHANNEL_REQUEST = 0x2004;

	Intent intent;
	Bundle bundle;
	private DeviceListAdapter adapter;

	private static final int port = 6010;
	private String ipaddr;
	private InetAddress ip;
	private String userid;
	private String passwd;
	private static final int MAX_DATA_PACKET_LENGTH = 2048;
	private byte[] buffer = new byte[MAX_DATA_PACKET_LENGTH];
	byte[] tname = new byte[8];
	int version = 0;
	int channel = 0;
	int type = 0;
	int sequence = 0;
	int cmd = 0;
	int reserved = 0;

	int nDeviceCount = 0;
	Timer timer = new Timer();
	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1: {
				if (null!=adapter)
					adapter.notifyDataSetChanged();
				if (null!=toast)
					toast.hide();
			}
				break;
			}
			super.handleMessage(msg);
		}

	};

	TimerTask task = new TimerTask() {
		public void run() {
			int result ;
			if (nDeviceCount > adapter.getDeviceCount()||nDeviceCount==0) {
				result = Login(userid, passwd);
			}
			else
			{
				result =reflashOnline();
			}
			if (result==0)
			{
				Message message = new Message();
				message.what = 1;
				handler.sendMessage(message);
			}

		}

	};
	MyToast toast = null;

	public int reflashOnline() {
		DatagramSocket udpSocket = null;
		DatagramPacket dataPacket;
		try {

			udpSocket = new DatagramSocket(9000);
			udpSocket.setSoTimeout(5000);
			ByteArrayOutputStream byteOS = new ByteArrayOutputStream();
			DataOutputStream os = new DataOutputStream(byteOS);
			os.write(tname);
			os.writeInt(VView.ntohl(0)); // version
			os.writeInt(VView.ntohl(0)); // channel
			os.writeInt(VView.ntohl(0)); // type
			os.writeInt(VView.ntohl(0)); // sequence
			os.writeInt(VView.ntohl(GETDEVLIST_REQUEST)); // cmd
			os.writeInt(VView.ntohl(0)); // reserved

			dataPacket = new DatagramPacket(byteOS.toByteArray(), byteOS
					.toByteArray().length, ip, port);
			udpSocket.send(dataPacket);
			dataPacket = new DatagramPacket(buffer, buffer.length);

			udpSocket.receive(dataPacket);
			ByteArrayInputStream byteIS = new ByteArrayInputStream(dataPacket
					.getData(), 0, dataPacket.getLength());
			DataInputStream is = new DataInputStream(byteIS);

			is.read(tname);
			version = VView.htonl(is.readInt()); // version
			channel = VView.htonl(is.readInt()); // channel
			type = VView.htonl(is.readInt()); // type
			sequence = VView.htonl(is.readInt()); // sequence
			cmd = VView.htonl(is.readInt());
			; // cmd
			reserved = VView.htonl(is.readInt());
			; // reserved
			if (reserved != 0) {
				Toast t = new Toast(this);
				t.setText("ˢ��ʧ��");
				t.show();
				udpSocket.close();
				udpSocket = null;
				return -1;
			}

			adapter.cleanDeviceOnline();
			int nPackCount = is.readInt();
			byte[] szTmp = null;
			for (int i = 0; i < nPackCount; i++) {
				DeviceInfo device = new DeviceInfo();
				short strlen = 0;

				strlen = is.readShort();
				szTmp = new byte[strlen - 1];
				is.read(szTmp, 0, strlen - 1);
				String szDeviceID = new String(szTmp, "GB2312");
				is.readByte();

				adapter.setDeviceOnline(szDeviceID);
		
			}
		
		} catch (SocketException e) {
			if (udpSocket != null) {
				udpSocket.close();
				udpSocket = null;
			}
			return -1;
		}

		catch (IOException e) {
			if (udpSocket != null) {
				udpSocket.close();
				udpSocket = null;
			}
			return -2;
		}
		udpSocket.close();
		udpSocket = null;
		return 0;
	}

	public int Login(String user, String passwd) {

		DatagramSocket udpSocket = null;
		DatagramPacket dataPacket;
		try {

			udpSocket = new DatagramSocket(9000);
			udpSocket.setSoTimeout(10000);
			ByteArrayOutputStream byteOS = new ByteArrayOutputStream();
			DataOutputStream os = new DataOutputStream(byteOS);
			os.write(tname);
			os.writeInt(VView.ntohl(0)); // version
			os.writeInt(VView.ntohl(0)); // channel
			os.writeInt(VView.ntohl(0)); // type
			os.writeInt(VView.ntohl(0)); // sequence
			os.writeInt(VView.ntohl(USERLOGIN_REQUEST)); // cmd
			os.writeInt(VView.ntohl(0)); // reserved
			os.writeShort(userid.length() + 1);
			os.writeBytes(userid);
			os.writeByte(0);
			os.writeShort(passwd.length() + 1);
			os.writeBytes(passwd);
			os.writeByte(0);

			dataPacket = new DatagramPacket(byteOS.toByteArray(), byteOS
					.toByteArray().length, ip, port);
			udpSocket.send(dataPacket);
			dataPacket = new DatagramPacket(buffer, buffer.length);
			do {
				udpSocket.receive(dataPacket);
				ByteArrayInputStream byteIS = new ByteArrayInputStream(
						dataPacket.getData(), 0, dataPacket.getLength());
				DataInputStream is = new DataInputStream(byteIS);

				is.read(tname);
				version = VView.htonl(is.readInt()); // version
				channel = VView.htonl(is.readInt()); // channel
				type = VView.htonl(is.readInt()); // type
				sequence = VView.htonl(is.readInt()); // sequence
				cmd = VView.htonl(is.readInt());
				; // cmd
				reserved = VView.htonl(is.readInt());
				; // reserved
				if (reserved != 0) {
					Toast t = new Toast(this);
					t.setText("��¼ʧ��");
					t.show();
					toast = null;
					Intent intent = new Intent();
					Bundle bundle = new Bundle();
					intent.setClass(DeviceListActivity.this,
							LoginActivity.class);
					startActivity(intent);
					this.finish();
					break;
				}

				int nPackCount = is.readInt();
				byte[] szTmp = null;
				for (int i = 0; i < nPackCount; i++) {
					DeviceInfo device = new DeviceInfo();
					short strlen = 0;

					strlen = is.readShort();
					szTmp = new byte[strlen - 1];
					is.read(szTmp, 0, strlen - 1);
					device.szDeviceID = new String(szTmp, "GB2312");
					is.readByte();

					strlen = is.readShort();
					szTmp = new byte[strlen - 1];
					is.read(szTmp, 0, strlen - 1);
					device.szDeviceName = new String(szTmp, "GB2312");
					is.readByte();

					strlen = is.readShort();
					szTmp = new byte[strlen - 1];
					is.read(szTmp, 0, strlen - 1);
					device.szDeviceGroup = new String(szTmp, "GB2312");
					is.readByte();

					strlen = is.readShort();
					szTmp = new byte[strlen - 1];
					is.read(szTmp, 0, strlen - 1);
					device.szDeviceMark = new String(szTmp, "GB2312");
					is.readByte();

					device.nDeviceType = is.readInt();

					strlen = is.readShort();
					szTmp = new byte[strlen - 1];
					is.read(szTmp, 0, strlen - 1);
					device.nCameraMark = new String(szTmp, "GB2312");
					is.readByte();

					adapter.insertDeviceInfo(device);
				}
				nDeviceCount = is.readInt();
				if (nDeviceCount <= adapter.getDeviceCount())
					break;

			} while (true);

		} catch (SocketException e) {
			if (udpSocket != null) {
				udpSocket.close();
				udpSocket = null;
			}
			return -1;
		}

		catch (IOException e) {
			if (udpSocket != null) {
				udpSocket.close();
				udpSocket = null;
			}
			return -2;
		}
		udpSocket.close();
		udpSocket = null;
		return 0;
	}

	public void onDestroy() {
		timer.cancel();
		toast.hide();
		timer = null;
		toast = null;
		super.onDestroy();
	}

	public void onRestart() {
		super.onRestart();
	}

	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER) {
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_BACK) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		// �����б�������IdeasExpandableListAdapter
		ProgressBar pb = new ProgressBar(this);
		// pop = new PopupWindow(pb,500,200);
		adapter = new DeviceListAdapter(this);
		setListAdapter(adapter);
		registerForContextMenu(getExpandableListView());
		toast = new MyToast(this);
		toast.show(pb, -1);

		intent = getIntent();
		bundle = intent.getExtras();
		userid = bundle.getString("USERID");
		passwd = bundle.getString("PASSWD");
		ipaddr = bundle.getString("IPADDR");
		try {
			ip = InetAddress.getByName(bundle.getString("IPADDR"));
		} catch (UnknownHostException e) {
			e.printStackTrace();
		}

		int result = Login(userid, passwd);
		timer.schedule(task, 1000, 5000);
		if (result==0)
			toast.hide();
	}
	
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        super.onCreateOptionsMenu(menu);
        menu.add(0, 1, 0, R.string.logout); 
        menu.add(0, 2, 2, R.string.exit);
        return true;
    }
	
    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        switch (item.getItemId()) {        
	        case 1:
	        {
				Intent intent=new Intent();
				intent.setClass(DeviceListActivity.this, LoginActivity.class);
				startActivity(intent);
				finish();
	            return true;
	        }
	        case 2:
	        {
	        	finish();
	            return true;    	
	        }
        }
        return super.onOptionsItemSelected(item);
    }
	@Override
	public void onCreateContextMenu(ContextMenu menu, View v,
			ContextMenuInfo menuInfo) {
		super.onCreateContextMenu(menu, v, menuInfo);
		ExpandableListView.ExpandableListContextMenuInfo info = (ExpandableListView.ExpandableListContextMenuInfo) menuInfo;

		int type = ExpandableListView
				.getPackedPositionType(info.packedPosition);
		if (type == ExpandableListView.PACKED_POSITION_TYPE_CHILD) {
			int group = ExpandableListView
					.getPackedPositionGroup(info.packedPosition);
			int child = ExpandableListView
					.getPackedPositionChild(info.packedPosition);
			DeviceInfo device = (DeviceInfo) adapter.getChild(group, child);
			if (device.bOnline) {
				
				switch (device.nDeviceType) {
				case 0:
				case 1:
					menu.add(0, 1, 0, "�豸ͨ��1");
					break;
				case 2:
				case 3:
					menu.add(0, 1, 0, "�豸ͨ��1");
					menu.add(0, 2, 0, "�豸ͨ��2");
					break;

				case 4:
				case 5:
					menu.add(0, 1, 0, "�豸ͨ��1");
					menu.add(0, 2, 0, "�豸ͨ��2");
					menu.add(0, 3, 0, "�豸ͨ��3");
					menu.add(0, 4, 0, "�豸ͨ��4");
					break;

				}
			}

		}

	}

	public boolean onContextItemSelected(MenuItem item) {

		boolean flag = false;

		// TODO Auto-generated method stub ExpandableListContextMenuInfo
		ExpandableListContextMenuInfo menuInfo = (ExpandableListContextMenuInfo) item
				.getMenuInfo();
		int type = ExpandableListView
				.getPackedPositionType(menuInfo.packedPosition);
		if (type == ExpandableListView.PACKED_POSITION_TYPE_CHILD) {
			int groupPos = ExpandableListView
					.getPackedPositionGroup(menuInfo.packedPosition);
			int childPos = ExpandableListView
					.getPackedPositionChild(menuInfo.packedPosition);
			DeviceInfo device = (DeviceInfo) adapter.getChild(groupPos,
					childPos);
			Intent intent = new Intent();
			Bundle bundle = new Bundle();
			intent.setClass(DeviceListActivity.this, H264Android.class);
			bundle.putInt("CHANNLE", item.getItemId() - 1);
			bundle.putString("DEVICEID", device.szDeviceID);
			bundle.putString ("IPADDR", ipaddr);
			intent.putExtras(bundle);
			startActivityForResult(intent, 0);

			flag = true;
		} 

//		else if (type == ExpandableListView.PACKED_POSITION_TYPE_GROUP) {
//			int groupPos = ExpandableListView
//					.getPackedPositionGroup(menuInfo.packedPosition);
//			CharSequence cs = "��������GROUP";
//			Toast.makeText(this, cs, Toast.LENGTH_SHORT).show();
//			flag = true;
//		}
		 

		return flag;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see android.app.Activity#onActivityResult(int, int,
	 * android.content.Intent)
	 */
	@Override
	protected void onActivityResult(int requestCode, int resultCode, Intent data) {

	}
}

class MyToast {
	private static final String TAG = "MyToast";
	public static final int LENGTH_MAX = -1; // show until hide() function
	boolean mCanceled = true;
	Handler mHandler;
	Context mContext;
	Toast mToast;

	public MyToast(Context context) {
		this(context, new Handler());
	}

	public MyToast(Context context, Handler h) {
		mContext = context;
		mHandler = h;
		mToast = Toast.makeText(mContext, "", Toast.LENGTH_SHORT);
		mToast.setGravity(Gravity.CENTER, 0, 0);
	}

	public void show(View v, int duration) {
		mToast.setView(v);
		if (duration != LENGTH_MAX) {
			mToast.setDuration(duration);
			mToast.show();
		} else if (mCanceled) {
			mToast.setDuration(Toast.LENGTH_LONG);
			mCanceled = false;
			showUntilCancel();

		}
	}

	public void show(int resId, int duration) {
		mToast.setText(resId);
		if (duration != LENGTH_MAX) {
			mToast.setDuration(duration);
			mToast.show();
		} else if (mCanceled) {
			mToast.setDuration(Toast.LENGTH_LONG);
			mCanceled = false;
			showUntilCancel();

		}
	}

	public void show(String text, int duration) {
		mToast.setText(text);
		if (duration != LENGTH_MAX) {

			mToast.setDuration(duration);
			mToast.show();
		} else {
			if (mCanceled) {
				mToast.setDuration(Toast.LENGTH_LONG);
				mCanceled = false;
				showUntilCancel();
			}
		}
	}

	public void hide() {
		mToast.cancel();
		mCanceled = true;
	}

	public boolean isShowing() {
		return !mCanceled;
	}

	private void showUntilCancel() {
		if (mCanceled)
			return;
		mToast.show();
		mHandler.postDelayed(new Runnable() {
			public void run() {
				showUntilCancel();
			}
		}, 3000);
	}

}
