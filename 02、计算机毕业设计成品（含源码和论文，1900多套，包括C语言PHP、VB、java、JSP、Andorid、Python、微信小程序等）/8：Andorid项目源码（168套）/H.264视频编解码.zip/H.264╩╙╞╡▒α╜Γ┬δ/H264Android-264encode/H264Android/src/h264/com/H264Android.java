package h264.com;

import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;

import java.net.*;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Matrix;
import android.graphics.Paint;
import android.graphics.Rect;
import android.graphics.Bitmap.Config;
import android.os.Bundle;
import android.os.Handler;
import android.os.Message;

import android.util.AttributeSet;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.Menu;
import android.view.MenuItem;
import android.view.MotionEvent;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import h264.com.R;

public class H264Android extends Activity {

	VView vv;

	@Override
	public boolean onKeyDown(int keyCode, KeyEvent event) {
		if (keyCode == KeyEvent.KEYCODE_DPAD_CENTER) {
			openOptionsMenu();
			return true;
		} else if (keyCode == KeyEvent.KEYCODE_BACK) {
			return true;
		}
		return super.onKeyDown(keyCode, event);
	}

	Intent intent;
	Bundle bundle;
	private String ipaddr;
	private String mDeviceID;
	private int mChannle;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.main);
		vv = (VView) findViewById(R.id.h264view);

		intent = getIntent();
		bundle = intent.getExtras();
		mChannle = bundle.getInt("CHANNLE");
		mDeviceID = bundle.getString("DEVICEID");
		ipaddr = bundle.getString("IPADDR");
		return;
	}

	// Menu item Ids
	public static final int PLAY_ID = Menu.FIRST;
	public static final int STOP_ID = Menu.FIRST + 1;
	public static final int EXIT_ID = Menu.FIRST + 2;

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		super.onCreateOptionsMenu(menu);
		menu.add(0, 1, 0, R.string.playCIF);
		menu.add(0, 2, 0, R.string.playQCIF);
		menu.add(0, 3, 0, R.string.stop);
		menu.add(0, 4, 0, R.string.ret);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		switch (item.getItemId()) {
		case 1: {
			vv.PlayVideo(ipaddr, mDeviceID, mChannle, true);
			return true;
		}
		case 2: {
			vv.PlayVideo(ipaddr, mDeviceID, mChannle, false);
			return true;
		}
		case 3: {
			vv.StopVideo();
			return true;
		}
		case 4: {

			setResult(RESULT_OK);
			finish();
			return true;
		}
		}
		return super.onOptionsItemSelected(item);
	}

	@Override
	public void finish() {
		vv.StopVideo();
		super.finish();
	}
}

class VView extends View implements Runnable {
	public boolean onTouchEvent(MotionEvent event) {

		if (event.getAction() == MotionEvent.ACTION_DOWN) {
			SetRotate();
		}
		return super.onTouchEvent(event);

	}

	Toast toast;
	private String mIpaddr;
	private String mDeviceID;
	private int mChannle;
	private boolean mIsCIF = true;

	boolean playing = false;
	byte[] mPixel = new byte[352 * 288 * 4 * 2];
	Thread thread = null;
	
	ByteBuffer buffer = ByteBuffer.wrap(mPixel);
	Bitmap VideoBit = Bitmap.createBitmap(352, 288, Config.RGB_565);

	int mTrans = 0x0F0F0F0F;

	private long encoder;

	public native long InitDecoder();

	public native int UninitDecoder(long encoder);

	public native int DecoderNal(long encoder, byte[] in, int insize, byte[] out);

	public native int GetH264Width(long encoder);

	public native int GetH264Height(long encoder);

	public static native int ntohl(int i);

	public static native int htonl(int i);

	public static native short ntohs(short i);

	public static native short htons(short i);

	int mH264Height;
	int mH264Width;

	float mRotate = 90;
	static {
		System.loadLibrary("H264Android");
	}

	public VView(Context context) {
		super(context);
		int i = mPixel.length;
		toast = Toast.makeText(context, "", Toast.LENGTH_SHORT);
		toast.setGravity(Gravity.CENTER, 0, 0);
		for (i = 0; i < mPixel.length; i++) {
			mPixel[i] = (byte) 0x00;
		}
	}

	public VView(Context context, AttributeSet attrs) {
		super(context, attrs);
		// TODO Auto-generated constructor stub
		int i = mPixel.length;
		toast = Toast.makeText(context, "", Toast.LENGTH_SHORT);
		toast.setGravity(Gravity.CENTER, 0, 0);
		for (i = 0; i < mPixel.length; i++) {
			mPixel[i] = (byte) 0x00;
		}
	}

	public VView(Context context, AttributeSet attrs, int defStyle) {
		super(context, attrs, defStyle);
		int i = mPixel.length;
		toast = Toast.makeText(context, "", Toast.LENGTH_SHORT);
		toast.setGravity(Gravity.CENTER, 0, 0);
		for (i = 0; i < mPixel.length; i++) {
			mPixel[i] = (byte) 0x00;
		}
		// TODO Auto-generated constructor stub
	}

	Handler handler = new Handler() {
		public void handleMessage(Message msg) {
			switch (msg.what) {
			case 1: {
				toast.setDuration(toast.LENGTH_LONG);
				if (mIsCIF) {
					toast.setText("��ʼ����CIF");
				} else {
					toast.setText("��ʼ����QCIF");
				}
				toast.show();
				break;
			}
			case 2: {
				toast.setDuration(toast.LENGTH_LONG);
				toast.setText("ֹͣ����");
				toast.show();
				StopVideo();
				break;
			}

			case 3: {
				String strMsg=(String)msg.obj;
				toast.setDuration(toast.LENGTH_LONG);
				toast.setText("ֹͣ����:�������\n"+strMsg);
				toast.show();
				StopVideo();
				break;
			}
			case 4: {
				toast.setDuration(toast.LENGTH_LONG);
				toast.setText("ֹͣ����:ý�������ܲ�����");
				toast.show();
				StopVideo();
				break;
			}			
			}
			super.handleMessage(msg);
		}

	};

	public void PlayVideo(String ip, String nDeivceID, int nChannle,
			boolean bISCIF) {
		mIpaddr = ip;
		mDeviceID = nDeivceID;
		mChannle = nChannle;
		mIsCIF = bISCIF;
		if (thread == null) {
			encoder = InitDecoder();
			playing = true;
			thread = new Thread(this);
			thread.start();
		}
	}

	public void SetRotate() {
		if (mRotate == 0) {
			mRotate = 90;
		} else {
			mRotate = 0;
		}
	}

	public void StopVideo() {

		if (thread != null) {
			try {
				thread.join(1000);
			} catch (InterruptedException e) {
			}
			thread.stop();
			thread = null;
		}
		if (encoder != 0) {
			UninitDecoder(encoder);
			encoder = 0;
		}

	}

	@Override
	protected void onDraw(Canvas canvas) {
		super.onDraw(canvas);
		if (encoder > 0) {
			if ((mH264Width != GetH264Width(encoder))
					|| (mH264Height != GetH264Width(encoder))) {
				mH264Width = GetH264Width(encoder);
				mH264Height = GetH264Height(encoder);
				VideoBit = Bitmap.createBitmap(mH264Width, mH264Height,
						Config.RGB_565);
			}
			VideoBit.copyPixelsFromBuffer(buffer);
			Rect srcRect = new Rect();
			Rect destRect = new Rect();
			srcRect.set(0, 0, mH264Width, mH264Height);
			destRect.set(0, 0, getWidth(), getHeight());
			Matrix m = new Matrix();
			if (mRotate == 0) {
				m.postScale(1f * getWidth() / mH264Width, 1f * getHeight()
						/ mH264Height);
			} else {
				m.postScale(1f * getHeight() / mH264Width, 1f * getWidth()
						/ mH264Height);
				m.postRotate(90, 0, 0);
				m.postTranslate(getWidth(), 0);
			}
			canvas.drawBitmap(VideoBit, m, null);
		}
	}

	public void run() {
		Message message = null;
		message = new Message();
		message.what = 1;
		handler.sendMessage(message);

		Socket s = null;
		DataInputStream is = null;
		DataOutputStream os = null;
		byte[] tname = { 0, 0, 0, 0, 0, 0, 0, 0 };
		mDeviceID.getBytes(0, mDeviceID.length()>8?8:mDeviceID.length(), tname, 0);
		int version = 0;
		int channel = mChannle;
		int type = 1;
		int sequence = 0;
		int cmd = 0x2004;
		int reserved = 0;
		int result = 0;
		try {
			s = new Socket(mIpaddr, mIsCIF ? 8001 : 8000);
			s.setSoTimeout(5000);

			os = new DataOutputStream(s.getOutputStream());
			is = new DataInputStream(s.getInputStream());

			os.write(tname);
			os.writeInt(ntohl(version));
			os.writeInt(ntohl(channel));
			os.writeInt(ntohl(type));
			os.writeInt(ntohl(sequence));
			os.writeInt(ntohl(cmd));
			os.writeInt(ntohl(reserved));

			is.read(tname);
			version = htonl(is.readInt());
			channel = htonl(is.readInt());
			type = htonl(is.readInt());
			sequence = htonl(is.readInt());
			cmd = htonl(is.readInt());
			reserved = htonl(is.readInt());
			
			if (reserved!=0)
			{
				try {
					if (is != null)
						is.close();
					if (os != null)
						os.close();
					if (s != null)
						s.close();
				} catch (IOException e1) {
				}
				message = new Message();
				message.what = 4;
				handler.sendMessage(message);
				postInvalidate();
				playing = false;				
			}

		} catch (IOException e) {
			e.printStackTrace();
			try {
				if (is != null)
					is.close();
				if (os != null)
					os.close();
				if (s != null)
					s.close();
			} catch (IOException e1) {
			}
			message = new Message();
			message.what = 3;
			message.obj=e.getMessage();
			handler.sendMessage(message);
			playing = false;
			return;
		}

		byte[] NalBuf = new byte[40980];

		int nNalSize = 0;
		int nPos = 0;
		int bytesRead = 0;
		int iTemp = 0;

		while (reserved == 0 && !Thread.currentThread().isInterrupted()
				&& playing) {

			try {
				nNalSize = is.readInt();
				nPos = 0;
				while (nNalSize > nPos) {
					bytesRead = is.read(NalBuf, nPos, nNalSize - nPos);
					if (bytesRead <= 0)
						break;
					nPos += bytesRead;
					// nNalSize-=bytesRead;
				}
				// is.re
			} catch (IOException e) {
				e.printStackTrace();
				UninitDecoder(encoder);
				encoder = 0;
				message = new Message();
				message.what = 3;
				message.obj=e.getMessage();
				handler.sendMessage(message);
				postInvalidate();
				playing = false;
				return;
			}
			if (nNalSize > nPos)
				break;
			iTemp = DecoderNal(encoder, NalBuf, nNalSize, mPixel);

			if (iTemp > 0)
				postInvalidate();
		}
		try {
			if (is != null)
				is.close();
			if (os != null)
				os.close();
			if (s != null)
				s.close();
		} catch (IOException e) {
			e.printStackTrace();
		}

		postInvalidate();
		playing = false;
		message = new Message();
		message.what = 2;
		handler.sendMessage(message);

	}
}
