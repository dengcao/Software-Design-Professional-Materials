package h264.com;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.List;
import android.content.Context;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AbsListView;
import android.widget.BaseExpandableListAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import h264.com.R;

class DeviceInfo {
	String szDeviceID;
	String szDeviceName;// �豸����
	String szDeviceGroup;// �豸����
	String nCameraMark;
	String szDeviceMark;
	int nDeviceType;
	boolean bOnline;
}

public class DeviceListAdapter extends BaseExpandableListAdapter {

	private Context mContext = null;
	private Map<String, List<DeviceInfo>> deviceMap;
	private Map<String, DeviceInfo> alldevices;

	public DeviceListAdapter(Context context) {
		this.mContext = context;
		deviceMap = new HashMap<String, List<DeviceInfo>>();
		alldevices = new HashMap<String, DeviceInfo>();
		//initData();
	}

	/**
	 * 
	 * ��ʼ�����ݣ���������ݷŵ�List�У����㴦��
	 */

	public void insertDeviceInfo(DeviceInfo devInfo)
	{
		if (alldevices.get(devInfo.szDeviceID)==null)
		{
			alldevices.put(devInfo.szDeviceID, devInfo);
			if (deviceMap.get(devInfo.szDeviceGroup)!=null)
			{
					deviceMap.get(devInfo.szDeviceGroup).add(devInfo);
			}
			else
			{
				List<DeviceInfo> deviceList = new ArrayList<DeviceInfo>();
				deviceList.add(devInfo);
				deviceMap.put(devInfo.szDeviceGroup, deviceList);
				
				
			}
		}
	}
	
	public void cleanDeviceOnline()
	{
		for(int i=0;i<deviceMap.size();i++)
		{
			for(int j=0;j<getChildrenCount(i);j++)
			{
				((DeviceInfo)getChild(i,j)).bOnline=false;
			}
		}	
	}
	public void setDeviceOnline(String szDeviceID)
	{

		for(int i=0;i<deviceMap.size();i++)
		{
			for(int j=0;j<getChildrenCount(i);j++)
			{
				DeviceInfo info=(DeviceInfo)getChild(i,j);
				if (info.szDeviceID.compareTo(szDeviceID)==0 )
				{
					info.bOnline=true;
				}
			}
		}
	}
	
	public int getDeviceCount()
	{
		/*
		int nCount=0;
		for(int i=0;i<getGroupCount();i++)
		{
			nCount+=getChildrenCount(i);
		}
		return nCount;
		*/
		return alldevices.size();
	}
	
	public void cleanDeviceInfo()
	{
		deviceMap.clear();
	}
	/*
	private void initData() {
		deviceMap = new HashMap<String, List<DeviceInfo>>();
		for (int jj = 0; jj < 10; jj++) {
			List<DeviceInfo> deviceList = new ArrayList<DeviceInfo>();
			for (int ii = 0; ii < 15; ii++) {
				DeviceInfo deviceInfo = new DeviceInfo();
				deviceInfo.szDeviceName = String.format(
						"Group:%d,DeviceName:%d", jj, ii);
				deviceInfo.szDeviceID = String.format("Group:%d,DeviceID:%d",
						jj, ii);
				deviceInfo.szDeviceGroup = String.format("Group:%d", jj);
				deviceInfo.bOnline = (ii % 2 == 0) ? true : false;
				deviceList.add(deviceInfo);

			}
			deviceMap.put(String.format("Group:%d", jj), deviceList);
		}
	}
	*/
	public boolean areAllItemsEnabled() {
		return false;
	}

	/*
	 * 
	 * ��* �����ӽڵ�������¼�����ʱ���صĶ��󣬿ɴ��һЩ����
	 */

	public Object getChild(int groupPosition, int childPosition) {
		Object[] keys = deviceMap.keySet().toArray();
		return deviceMap.get((String) keys[groupPosition]).get(childPosition);
	}

	public long getChildId(int groupPosition, int childPosition) {
		return childPosition;
	}

	/*
	 * 
	 * �ֽڵ���ͼ������������ʾһ���ı�����
	 */

	public View getChildView(int groupPosition, int childPosition,
			boolean isLastChild, View convertView, ViewGroup parent) {
		View view = null;
		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) mContext
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			view = inflater.inflate(R.layout.deviceinfo, null);
		} else {
			view = convertView;
		}
		ImageView img = null;
		TextView text = null;
		text = (TextView) view.findViewById(R.id.edtDeviceID);
		text.setText(((DeviceInfo) getChild(groupPosition, childPosition)).szDeviceID);
		text = (TextView) view.findViewById(R.id.edtDeviceName);
		text.setText(((DeviceInfo) getChild(groupPosition, childPosition)).szDeviceName);
		img = (ImageView) view.findViewById(R.id.imgState);
		if (((DeviceInfo) getChild(groupPosition, childPosition)).bOnline) {
			img.setImageResource(R.drawable.icon);
		} else {
			img.setImageBitmap(null);
		}
		return view;

	}

	/*
	 * 
	 * ���ص�ǰ������ֽڵ����
	 */

	public int getChildrenCount(int groupPosition) {
		Object[] keys = deviceMap.keySet().toArray();
		return deviceMap.get(keys[groupPosition]).size();
	}

	/*
	 * 
	 * ���ط����������һЩ���ݴ��ݣ����¼�����ʱ��ֱ��ȡ�úͷ�����ص�����
	 */

	public Object getGroup(int groupPosition) {
		return deviceMap.keySet().toArray()[groupPosition];
	}

	/*
	 * 
	 * ����ĸ���
	 */

	public int getGroupCount() {
		return deviceMap.keySet().size();
	}

	public long getGroupId(int groupPosition) {
		return groupPosition;
	}

	/*
	 * 
	 * ������ͼ������Ҳ��һ���ı���ͼ
	 */

	public View getGroupView(int groupPosition, boolean isExpanded,
			View convertView, ViewGroup parent) {

		View view = null;
		if (convertView == null) {
			LayoutInflater inflater = (LayoutInflater) mContext
					.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
			view = inflater.inflate(R.layout.groupinfo, null);
		} else {
			view = convertView;
		}
		TextView text = null;
		text = (TextView) view.findViewById(R.id.lblGroupName);
		text.setText((String) deviceMap.keySet().toArray()[groupPosition]);
		text = (TextView) view.findViewById(R.id.lblOnline);
		
		
		List<DeviceInfo> list=deviceMap.get((String) deviceMap.keySet().toArray()[groupPosition]);
		int nSum=0;
		for(int i=0;i<list.size();i++)
		{
			if (list.get(i).bOnline)
			{
				nSum++;
			}
		}
		
		text.setText(String.format("%d/%d", nSum,list.size()));
		
		return view;

	}

	/*
	 * 
	 * �жϷ����Ƿ�Ϊ�գ���ʾ���������ǹ̶��ģ����Բ���Ϊ�գ����Ƿ���false
	 * 
	 * ��������������ݿ⣬����ʱ�����԰��ж��߼�д����������У����Ϊ��
	 * 
	 * ʱ����true
	 */

	public boolean isEmpty() {
		return false;
	}

	/*
	 * 
	 * �����б�ʱҪ�����Ķ����������
	 */

	public void onGroupCollapsed(int groupPosition) {

	}

	/*
	 * 
	 * չ���б�ʱҪ�����Ķ����������
	 */

	public void onGroupExpanded(int groupPosition) {

	}

	/*
	 * 
	 * Indicates whether the child and group IDs are stable across changes to
	 * 
	 * the underlying data.
	 */

	public boolean hasStableIds() {
		return false;
	}

	/*
	 * 
	 * Whether the child at the specified position is selectable.
	 */

	public boolean isChildSelectable(int groupPosition, int childPosition) {
		return true;
	}
}
