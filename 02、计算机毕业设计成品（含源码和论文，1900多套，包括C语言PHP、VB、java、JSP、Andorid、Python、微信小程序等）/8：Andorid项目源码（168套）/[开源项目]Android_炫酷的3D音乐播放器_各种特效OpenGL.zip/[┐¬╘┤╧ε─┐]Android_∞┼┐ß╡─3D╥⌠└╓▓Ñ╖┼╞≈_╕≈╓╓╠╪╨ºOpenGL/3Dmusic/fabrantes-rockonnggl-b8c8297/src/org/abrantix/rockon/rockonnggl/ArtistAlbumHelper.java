package org.abrantix.rockon.rockonnggl;

public class ArtistAlbumHelper
{
	String	artistId;
	String	albumId = null; // could as well be an array
}