package org.abrantix.rockon.rockonnggl;

import android.graphics.Bitmap;

public class NavItem{
	int		index;
	Bitmap	cover;
	Bitmap	label;
	String	artistName;
	String	albumName;
	String	albumKey;
	String	albumId;
	String	artistId;
	int		nAlbumsFromArtist;
//	String	nAlbumsFromArtistText;
	int		nSongsFromArtist;
	String	songName;
	int		songId;
}