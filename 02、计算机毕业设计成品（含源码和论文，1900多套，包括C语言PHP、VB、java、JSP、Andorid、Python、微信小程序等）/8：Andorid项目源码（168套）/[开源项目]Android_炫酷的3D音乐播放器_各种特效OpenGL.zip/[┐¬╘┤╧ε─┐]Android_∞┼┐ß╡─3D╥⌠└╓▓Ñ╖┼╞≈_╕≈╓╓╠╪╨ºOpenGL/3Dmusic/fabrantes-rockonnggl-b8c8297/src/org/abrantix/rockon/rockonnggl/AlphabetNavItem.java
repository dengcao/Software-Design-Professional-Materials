package org.abrantix.rockon.rockonnggl;

import android.graphics.Bitmap;

public class AlphabetNavItem{
	int		letter;
	Bitmap	letterBitmap;
}