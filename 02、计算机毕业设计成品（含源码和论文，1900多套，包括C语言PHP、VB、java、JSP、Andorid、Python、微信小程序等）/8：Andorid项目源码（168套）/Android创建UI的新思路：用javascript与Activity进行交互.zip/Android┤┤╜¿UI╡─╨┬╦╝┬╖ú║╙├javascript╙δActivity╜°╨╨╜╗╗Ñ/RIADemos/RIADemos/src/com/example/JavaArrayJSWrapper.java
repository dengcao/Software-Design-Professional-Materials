package com.example;

public class JavaArrayJSWrapper {

	private Object[] innerArray;
	
	public JavaArrayJSWrapper(Object[] a){
		this.innerArray = a;
	}
	
	public int length(){
		return this.innerArray.length;
	}
	
	public Object get(int index){
		return this.innerArray[index];
	}
}
