package com.example;

public class Person {

	String name;//name of contact
	String phone_number;//phone number of the contact

	public String getName(){
		
		return name;
	}

	public String getNumber(){
		return phone_number;
	}
}
