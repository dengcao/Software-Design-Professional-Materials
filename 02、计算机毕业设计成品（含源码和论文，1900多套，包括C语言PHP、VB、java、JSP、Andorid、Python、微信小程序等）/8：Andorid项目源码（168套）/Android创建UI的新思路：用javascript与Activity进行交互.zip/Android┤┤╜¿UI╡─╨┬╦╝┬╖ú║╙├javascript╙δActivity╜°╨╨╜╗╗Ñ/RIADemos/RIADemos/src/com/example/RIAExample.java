package com.example;

import java.util.Vector;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.webkit.WebView;

public class RIAExample extends Activity{
	
	private WebView web;
	private Handler mHandler = new Handler();  
	//ģ����벾
	private Vector<Person> phonebook = new Vector<Person>();
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        this.initContacts();
        web = (WebView)this.findViewById(R.id.web);
        
        web.getSettings().setJavaScriptEnabled(true);//����javascript���ã�����WebView��ִ��js�ű�

        web.addJavascriptInterface(this,"phonebook");  
        
        web.loadUrl("file:///android_asset/phonebook.html");
    }
    
    /**
     * �÷�������js�ű��У�ͨ��window.phonebook.getContacts()���е���
     * ���ص�JavaArrayJSWrapper�������ʹ����js�з���Java����
     * @return
     */
    public JavaArrayJSWrapper getContacts(){
    	System.out.println("fetching contacts data");
    	Person[] a = new Person[this.phonebook.size()];
    	a = this.phonebook.toArray(a);
    	return new JavaArrayJSWrapper(a);
    
    }
    
    /**
     * ��ʼ���绰���벾
     */
    public void initContacts(){
    	Person p = new Person();
    	p.name = "Perter123";
    	p.phone_number = "123456789";
    	phonebook.add(p);
    	p = new Person();
    	p.name = "English";
    	p.phone_number = "123456789";
    	phonebook.add(p);
   	
    }
    
    /**
     * ͨ��window.phonebook.debugout�����js������Ϣ��
     * @param info
     */
    public void debugout(String info){
    	Log.i("ss",info);
    	System.out.println(info);
    }
    
    
    public void startActivity(){
    	
    	Intent intent = new Intent(RIAExample.this,JsActivity.class);
    	startActivity(intent);
    } 
}