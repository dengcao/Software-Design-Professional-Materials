package alan.jluzh;

import android.graphics.Canvas;


public interface CalendarElement
{
    public void draw(Canvas canvas);
}
 