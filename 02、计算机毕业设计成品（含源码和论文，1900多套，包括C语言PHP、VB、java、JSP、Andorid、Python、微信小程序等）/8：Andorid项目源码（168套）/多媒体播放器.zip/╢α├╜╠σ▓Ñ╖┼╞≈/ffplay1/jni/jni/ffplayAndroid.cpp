#include <unistd.h>

// map system drivers methods
#include "drivers_map.h"

#include <android/log.h>
#include "jniUtils.h"
#include "methods.h"

extern "C" {

#include "libavcodec/avcodec.h"
#include "libavformat/avformat.h"
#include "libswscale/swscale.h"
#include "libavutil/log.h"

} // end of extern C

#define TAG "FFMpegPlayerAndroid"

struct ffmpeg_fields_t {
	AVFrame 			*pFrame;
	AVFormatContext 	*pFormatCtx;
	struct SwsContext 	*img_convert_ctx;
} ffmpeg_fields;

struct ffmpeg_video_t {
	bool				initzialized;
	int 				stream;
	AVCodecContext 		*codec_ctx;
	AVCodec 			*codec;
} ffmpeg_video;

struct ffmpeg_audio_t {
	bool				initzialized;
	bool				decode;
	int 				stream;
	AVCodecContext 		*codec_ctx;
	AVCodec 			*codec;
} ffmpeg_audio;

enum State {
	STATE_STOPED,
	STATE_STOPING,
	STATE_PLAYING,
	STATE_PAUSE
};
static State status = STATE_STOPED;

jclass ffplayAndroid_getClass(JNIEnv *env) {
	return env->FindClass("com/ffplay/ffplayAndroid");
}

const char *ffplayAndroid_getSignature() {
	return "Lcom/ffplay/ffplayAndroid;";
}

static void ffplayAndroid_handleErrors(void* ptr, int level, const char* fmt, va_list vl) 
{
	switch(level)
	{
	case AV_LOG_PANIC:
		__android_log_print(ANDROID_LOG_ERROR, TAG, "AV_LOG_PANIC: %s", fmt);
		break;

	case AV_LOG_FATAL:
		__android_log_print(ANDROID_LOG_ERROR, TAG, "AV_LOG_FATAL: %s", fmt);
		break;

	case AV_LOG_ERROR:
		__android_log_print(ANDROID_LOG_ERROR, TAG, "AV_LOG_ERROR: %s", fmt);
		break;

	case AV_LOG_WARNING:
		__android_log_print(ANDROID_LOG_ERROR, TAG, "AV_LOG_WARNING: %s", fmt);
		break;

	case AV_LOG_INFO:
		__android_log_print(ANDROID_LOG_INFO, TAG, "%s", fmt);
		break;

	case AV_LOG_DEBUG:
		__android_log_print(ANDROID_LOG_DEBUG, TAG, "%s", fmt);
		break;
	}
}

static void ffplayAndroid_enableErrorCallback(JNIEnv *env, jobject obj) {
	av_log_set_callback(ffplayAndroid_handleErrors);
}

static void ffplayAndroid_initAudio(JNIEnv *env, jobject obj) 
{
	ffmpeg_audio.stream = -1;
	for (int i = 0; i < ffmpeg_fields.pFormatCtx->nb_streams; i++) {
		if (ffmpeg_fields.pFormatCtx->streams[i]->codec->codec_type == CODEC_TYPE_AUDIO) {
			ffmpeg_audio.stream = i;
		}
		if(ffmpeg_audio.stream != -1) {
			break;
		}
	}

	if (ffmpeg_audio.stream == -1) {
		jniThrowException(env,
						  "java/io/IOException",
						  "Didn't find a audio stream");
		return ;
	}
	// Get a pointer to the codec context for the video stream
	ffmpeg_audio.codec_ctx = ffmpeg_fields.pFormatCtx->streams[ffmpeg_audio.stream]->codec;
	ffmpeg_audio.codec = avcodec_find_decoder(ffmpeg_audio.codec_ctx->codec_id);
	if (ffmpeg_audio.codec == NULL) {
		jniThrowException(env,
						  "java/io/IOException",
						  "Couldn't find audio codec!");
		return ; // Codec not found
	}

	// Open codec
	if (avcodec_open(ffmpeg_audio.codec_ctx, ffmpeg_audio.codec) < 0) {
		jniThrowException(env,
						  "java/io/IOException",
						  "Could not open audio codec");
		return ; // Could not open codec
	}
	ffmpeg_audio.initzialized = ffmpeg_audio.decode = true;

	return ;
}

static void ffplayAndroid_initVideo(JNIEnv *env, jobject obj) 
{
	// Find the first video stream
	ffmpeg_video.stream = -1;
	for (int i = 0; i < ffmpeg_fields.pFormatCtx->nb_streams; i++) {
		if (ffmpeg_fields.pFormatCtx->streams[i]->codec->codec_type == CODEC_TYPE_VIDEO) {
			ffmpeg_video.stream = i;
		}
		if(ffmpeg_video.stream != -1) {
			break;
		}
	}

	if (ffmpeg_video.stream == -1) {
		jniThrowException(env,
						  "java/io/IOException",
						  "Didn't find a video stream");
		return ;
	}

	// Get a pointer to the codec context for the video stream
	ffmpeg_video.codec_ctx = ffmpeg_fields.pFormatCtx->streams[ffmpeg_video.stream]->codec;
	ffmpeg_video.codec = avcodec_find_decoder(ffmpeg_video.codec_ctx->codec_id);
	if (ffmpeg_video.codec == NULL) {
		jniThrowException(env,
						  "java/io/IOException",
						  "Couldn't find video codec!");
		return ; // Codec not found
	}

	// Open codec
	if (avcodec_open(ffmpeg_video.codec_ctx, ffmpeg_video.codec) < 0) {
		jniThrowException(env,
						  "java/io/IOException",
						  "Could not open video codec");
		return ; // Could not open codec
	}
	// Allocate video frame
	ffmpeg_fields.pFrame = avcodec_alloc_frame();

	int w = ffmpeg_video.codec_ctx->width;
	int h = ffmpeg_video.codec_ctx->height;
	ffmpeg_fields.img_convert_ctx = sws_getContext(w, h, ffmpeg_video.codec_ctx->pix_fmt, w, h,
				PIX_FMT_RGB565, SWS_POINT, NULL, NULL, NULL);

	ffmpeg_video.initzialized = true;
	return ;
}

static AVFrame *ffplayAndroid_createFrame(JNIEnv* env) {
	void*					pixels;
	AVFrame*				pFrame;
	
	pFrame = avcodec_alloc_frame();
	if (pFrame == NULL) {
		jniThrowException(env,
						  "java/io/IOException",
						  "Couldn't allocate an AVFrame structure");
		return NULL;
	}
	
	if(VideoDriver_getPixels(ffmpeg_video.codec_ctx->width, 
								ffmpeg_video.codec_ctx->height, 
								&pixels) != ANDROID_SURFACE_RESULT_SUCCESS) {
		__android_log_print(ANDROID_LOG_ERROR, TAG, "couldn't get surface's pixels");
		return NULL;
	}
	
	// Assign appropriate parts of buffer to image planes in pFrameRGB
	// Note that pFrameRGB is an AVFrame, but AVFrame is a superset
	// of AVPicture
	avpicture_fill((AVPicture *) pFrame, (uint8_t *)pixels, PIX_FMT_RGB565,
				   ffmpeg_video.codec_ctx->width, ffmpeg_video.codec_ctx->height);
	
	return pFrame;
}

static int ffplayAndroid_processAudio(JNIEnv *env, AVPacket *packet, int16_t *samples, int samples_size) {
	/*
	int size = FFMAX(packet->size * sizeof(*samples), samples_size);
	if(samples_size < size) {
		__android_log_print(ANDROID_LOG_INFO, TAG, "resizing audio buffer from %i to %i", samples_size, size);
		av_free(samples);
		samples_size = size;
		samples = (int16_t *) av_malloc(samples_size);
	}
	*/
	static bool called = false;
	static int temp_size = 0;
	int len = avcodec_decode_audio3(ffmpeg_audio.codec_ctx, samples, &samples_size, packet);
	if(!called) {
		__android_log_print(ANDROID_LOG_INFO, TAG, "starting android audio track");
		if(AudioDriver_set(MUSIC, 
						   ffmpeg_audio.codec_ctx->sample_rate,
						   PCM_16_BIT,
						   (ffmpeg_audio.codec_ctx->channels == 2) ? CHANNEL_OUT_STEREO : CHANNEL_OUT_MONO
						   ) != ANDROID_AUDIOTRACK_RESULT_SUCCESS) {
			jniThrowException(env,
							  "java/io/IOException",
							  "Couldn't set audio track parametres");
			return -1;
		}
		if(AudioDriver_start() != ANDROID_AUDIOTRACK_RESULT_SUCCESS) {
			jniThrowException(env,
							  "java/io/IOException",
							  "Couldn't start audio track");
			return -1;
		}
		temp_size = samples_size;
		called = true;
	}

	if(AudioDriver_write(samples, samples_size) <= 0) {
		jniThrowException(env,
						  "java/io/IOException",
						  "Couldn't write bytes to audio track");
		return -1;
	}
	
	AudioDriver_flush();
	return 0;
}

static int ffplayAndroid_processVideo(JNIEnv *env, jobject obj, AVPacket *packet, AVFrame *pFrameRGB) {
	int						frameFinished;

	// Decode video frame
	avcodec_decode_video(ffmpeg_video.codec_ctx, ffmpeg_fields.pFrame, &frameFinished,
					packet->data, packet->size);

	// Did we get a video frame?
	if (frameFinished) {
		// Convert the image from its native format to RGB
		sws_scale(ffmpeg_fields.img_convert_ctx, ffmpeg_fields.pFrame->data, ffmpeg_fields.pFrame->linesize, 0,
							ffmpeg_video.codec_ctx->height, pFrameRGB->data, pFrameRGB->linesize);
		VideoDriver_updateSurface();
		return 0;
	}
	return -1;
}

static void ffplayAndroid_play(JNIEnv *env, jobject obj) {
	AVPacket				packet;
	int						result = -1;
	int 					samples_size = AVCODEC_MAX_AUDIO_FRAME_SIZE;
	int16_t*				samples;
	AVFrame*				pFrameRGB;
	
	// Allocate an AVFrame structure
	if(ffmpeg_video.initzialized) {
		pFrameRGB = ffplayAndroid_createFrame(env);
		if (pFrameRGB == NULL) {
			jniThrowException(env,
							  "java/io/IOException",
							  "Couldn't crate frame buffer");
			return;
		}
	}
	
	if(ffmpeg_audio.initzialized) {
		samples = (int16_t *) av_malloc(samples_size);
		if(AudioDriver_register() != ANDROID_AUDIOTRACK_RESULT_SUCCESS) {
			jniThrowException(env,
							  "java/io/IOException",
							  "Couldn't register audio track");
			return;
		}
	}
	
	status = STATE_PLAYING;
	while (status != STATE_STOPING) {

		if(status == STATE_PAUSE) {
			usleep(50);
			continue;
		}

		if((result = av_read_frame(ffmpeg_fields.pFormatCtx, &packet)) < 0) {
			status = STATE_STOPING;
			continue;
		}

		// Is this a packet from the video stream?
		if (packet.stream_index == ffmpeg_video.stream &&
				ffmpeg_video.initzialized) {
			if(ffplayAndroid_processVideo(env, obj, &packet, pFrameRGB) < 0) {
				__android_log_print(ANDROID_LOG_ERROR, TAG, "Frame wasn't finished by video decoder");
			}
		} else if (packet.stream_index == ffmpeg_audio.stream &&
				ffmpeg_audio.initzialized && ffmpeg_audio.decode) {
			if(ffplayAndroid_processAudio(env, &packet, samples, samples_size) < 0 ) {
				return; // exception occured so return to java
			}
		}

		// Free the packet that was allocated by av_read_frame
		av_free_packet(&packet);
	}
	
	if(ffmpeg_video.initzialized) {
		if(VideoDriver_unregister() != ANDROID_SURFACE_RESULT_SUCCESS) {
			jniThrowException(env,
							  "java/io/IOException",
							  "Couldn't unregister vide surface");
		}
	}
	if(ffmpeg_audio.initzialized) {
		if(AudioDriver_unregister() != ANDROID_AUDIOTRACK_RESULT_SUCCESS) {
			jniThrowException(env,
							  "java/io/IOException",
							  "Couldn't unregister audio track");
		}
	}
	
	av_free( samples );
	
	// Free the RGB image
	av_free(pFrameRGB);

	status = STATE_STOPED;
	__android_log_print(ANDROID_LOG_INFO, TAG, "end of playing");
}

static jboolean ffplayAndroid_pause(JNIEnv *env, jobject object, jboolean pause) {
	switch(pause) {
	case JNI_TRUE:
		if(status != STATE_PLAYING) {
			return JNI_FALSE;
		}
		status = STATE_PAUSE;
		break;

	case JNI_FALSE:
		if(status != STATE_PAUSE) {
			return JNI_FALSE;
		}
		status = STATE_PLAYING;
		break;
	}
	return JNI_TRUE;
}

static void ffplayAndroid_decodeAudio(JNIEnv *env, jobject object, jboolean decode) {
	ffmpeg_audio.decode = decode;
}

static jboolean ffplayAndroid_isDecodingAudio(JNIEnv *env, jobject object) {
	return ffmpeg_audio.decode;
}

static void ffplayAndroid_stop(JNIEnv *env, jobject object) {
	if(status == STATE_STOPING || status == STATE_STOPED) {
		return;
	}
	status = STATE_STOPING;
}

static void ffplayAndroid_setInputFile(JNIEnv *env, jobject obj, jstring filePath) {
	const char *_filePath = env->GetStringUTFChars(filePath, NULL);
	// Open video file
	if(av_open_input_file(&ffmpeg_fields.pFormatCtx, _filePath, NULL, 0, NULL) != 0) {
		jniThrowException(env,
						  "java/io/IOException",
					      "Can't create input file");
	}
	// Retrieve stream information
	if(av_find_stream_info(ffmpeg_fields.pFormatCtx) < 0) {
		jniThrowException(env,
						  "java/io/IOException",
						  "Couldn't find stream information");
	}
	return ;
}

static void ffplayAndroid_setSurface(JNIEnv *env, jobject obj, jobject jsurface) {
	__android_log_print(ANDROID_LOG_INFO, TAG, "setting surface");

	if(VideoDriver_register(env, jsurface) != ANDROID_SURFACE_RESULT_SUCCESS) {
		__android_log_print(ANDROID_LOG_ERROR, TAG, "couldn't set surface");
	}
}

static void ffplayAndroid_release(JNIEnv *env, jobject obj) {
	// Free the YUV frame
	av_free(ffmpeg_fields.pFrame);
	
	// Close the codec
	avcodec_close(ffmpeg_video.codec_ctx);
	avcodec_close(ffmpeg_audio.codec_ctx);
	
	// Close the video file
	av_close_input_file(ffmpeg_fields.pFormatCtx);
}

static void ffplayAndroid_avcodec_register_all(JNIEnv *env, jobject obj)
{
	__android_log_print(ANDROID_LOG_ERROR, TAG, "Android_avcodec_register_all");

	avcodec_register_all();
}

static void ffplayAndroid_av_register_all(JNIEnv *env, jobject obj)
{
	__android_log_print(ANDROID_LOG_ERROR, TAG, "Android_av_register_all");

    av_register_all();
}
/*
* JNI registration.
*/
static JNINativeMethod methods[] = {
	{ "native_avcodec_register_all", "()V",  (void*) ffplayAndroid_avcodec_register_all },
	{ "native_av_register_all",      "()V",  (void*) ffplayAndroid_av_register_all },
	{ "nativeInitAudio", "()V", (void*) ffplayAndroid_initAudio},
	{ "nativeInitVideo", "()V", (void*) ffplayAndroid_initVideo},
	{ "nativeEnableErrorCallback", "()V", (void*) ffplayAndroid_enableErrorCallback},
	{ "nativeSetInputFile", "(Ljava/lang/String;)V", (void*) ffplayAndroid_setInputFile },
	{ "nativePause", "(Z)Z", (void*) ffplayAndroid_pause},
	{ "nativeDecodeAudio", "(Z)V", (void*) ffplayAndroid_decodeAudio},
	{ "isDecodingAudio", "()Z", (void*) ffplayAndroid_isDecodingAudio},
	{ "nativePlay", "()V", (void*) ffplayAndroid_play },
	{ "nativeStop", "()V", (void*) ffplayAndroid_stop },
	{ "nativeSetSurface", "(Landroid/view/Surface;)V", (void*) ffplayAndroid_setSurface },
	{ "nativeRelease", "()V", (void*) ffplayAndroid_release },
};
	
int register_ffplayAndroid_function(JNIEnv *env) {
	ffmpeg_audio.initzialized = false;
	ffmpeg_video.initzialized = false;

	return jniRegisterNativeMethods(env, "com/ffplay/ffplayAndroid", methods, sizeof(methods) / sizeof(methods[0]));
}
