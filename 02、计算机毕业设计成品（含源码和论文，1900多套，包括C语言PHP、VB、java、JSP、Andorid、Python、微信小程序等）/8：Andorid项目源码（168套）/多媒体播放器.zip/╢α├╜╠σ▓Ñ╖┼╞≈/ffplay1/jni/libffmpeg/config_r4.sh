#ndk-r4, windows 
#!/bin/sh
GCC_VERSION=4.4.0
PREBUILT=${NDK}/build/prebuilt/windows/arm-eabi-${GCC_VERSION}
PLATFORM=${NDK}/build/platforms/android-8/arch-arm
./configure \
--arch=armv5te  \
--target-os=linux --enable-cross-compile --cross-prefix=${PREBUILT}/bin/arm-eabi- \
--enable-static \
--enable-asm \
--enable-armvfp \
--disable-doc \
--disable-ffplay \
--disable-ffmpeg \
--disable-ffprobe \
--disable-ffserver \
--disable-muxers \
--disable-encoders \
--disable-bsfs \
--disable-hwaccels \
--disable-devices \
--disable-filters \
--disable-postproc \
--disable-shared \
--sysinclude=${PLATFORM}/usr/include \
--extra-cflags="-fPIC -DANDROID -std=c99 " \
--extra-ldflags="-Wl,-T,${PREBUILT}/arm-eabi/lib/ldscripts/armelf.x -Wl,-rpath-link=${PLATFORM}/usr/lib -L${PLATFORM}/usr/lib -nostdlib ${PLATFORM}/usr/lib/crtbegin_static.o ${PLATFORM}/usr/lib/crtend_android.o -lc -lm -ldl" 

echo "#undef restrict" >> config.h
echo "#define restrict __restrict__" >> config.h
echo "#undef HAVE_LRINT" >> config.h
echo "#define HAVE_LRINT 1" >> config.h
echo "#undef HAVE_LRINTF" >> config.h
echo "#define HAVE_LRINTF 1" >> config.h
echo "#undef HAVE_ROUND" >> config.h
echo "#define HAVE_ROUND 1" >> config.h
echo "#undef HAVE_ROUNDF" >> config.h
echo "#define HAVE_ROUNDF 1" >> config.h
echo "#undef HAVE_TRUNCF" >> config.h
echo "#define HAVE_TRUNCF 1" >> config.h
